/**
 * Run `build` or `dev` with `SKIP_ENV_VALIDATION` to skip env validation. This is especially useful
 * for Docker builds.
 */
import "./src/env.js";

/** @type {import("next").NextConfig} */
const config = {
	async rewrites() {
		const backendUrl = process.env.BACKEND_API_URL ?? "http://127.0.0.1:8001";

		return [
			{
				source: "/api/risk-exposure/:path*",
				destination: `${backendUrl}/api/risk-exposure/:path*`,
			},
			{
				source: "/api/structure-scr/:path*",
				destination: `${backendUrl}/api/structure-scr/:path*`,
			},
		];
	},
};

export default config;

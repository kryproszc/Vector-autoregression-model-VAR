export type StructureScrTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

export type StructureScrApiResponse = {
  meta?: {
    table?: string;
    insurer?: 16 | 21;
    dbPath?: string;
    rowCount?: number;
  };
  columns: string[];
  rows: Record<string, unknown>[];
};

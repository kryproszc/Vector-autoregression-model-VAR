import { useEffect, useMemo, useState } from "react";
import type { StructureScrApiResponse } from "./types";

type UseProporctionModeluesScrDataResult = {
  data: StructureScrApiResponse | null;
  isLoading: boolean;
  error: string | null;
  usedEndpoint: string;
  attemptedEndpoints: string[];
};

export function useProporctionModeluesScrData(insurer: 16 | 21): UseProporctionModeluesScrDataResult {
  const [data, setData] = useState<StructureScrApiResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usedEndpoint, setUsedEndpoint] = useState("");

  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";
  const attemptedEndpoints = useMemo(
    () => [
      `${baseUrl}/api/structure-scr/proporction-modelues-scr`,
      `${baseUrl}/api/structure-scr/proporction_modelues_scr`,
    ],
    [baseUrl],
  );

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      setIsLoading(true);
      setError(null);
      setData(null);
      setUsedEndpoint("");

      try {
        let lastError: string | null = null;

        for (const endpoint of attemptedEndpoints) {
          try {
            const response = await fetch(endpoint, {
              method: "GET",
              signal: controller.signal,
              headers: {
                Accept: "application/json",
                "x-insurer": String(insurer),
              },
              cache: "no-store",
            });

            if (!response.ok) {
              lastError = `Endpoint ${endpoint} zwrocil status ${response.status}`;
              continue;
            }

            const parsed = (await response.json()) as StructureScrApiResponse;
            setData(parsed);
            setUsedEndpoint(endpoint);
            return;
          } catch (err) {
            if (controller.signal.aborted) {
              return;
            }

            lastError = err instanceof Error ? err.message : "Nieznany blad pobierania danych";
          }
        }

        throw new Error(
          lastError ??
            "Nie udalo sie pobrac danych z zadnego endpointu dla proporction-modelues-scr",
        );
      } catch (err) {
        if (controller.signal.aborted) {
          return;
        }

        setError(err instanceof Error ? err.message : "Nieznany blad pobierania danych");
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false);
        }
      }
    }

    void load();

    return () => {
      controller.abort();
    };
  }, [attemptedEndpoints, insurer]);

  return {
    data,
    isLoading,
    error,
    usedEndpoint,
    attemptedEndpoints,
  };
}

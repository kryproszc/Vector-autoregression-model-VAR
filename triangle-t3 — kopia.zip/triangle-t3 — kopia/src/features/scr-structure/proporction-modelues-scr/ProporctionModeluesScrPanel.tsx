import type { HeaderTabId } from "@/app/_components/navigation/types";
import { QuarterlyChangesTable } from "@/components/tables/QuarterlyChangesTable";
import { ScrIndicatorsTable } from "@/components/tables/ScrIndicatorsTable";
import { YearlyChangesTable } from "@/components/tables/YearlyChangesTable";
import { useState } from "react";
import { useProporctionModeluesScrData } from "@/features/scr-structure/proporction-modelues-scr/data/useProporctionModeluesScrData";

type ProporctionModeluesScrPanelProps = {
  activeTab: HeaderTabId;
  insurer: 16 | 21;
};

export function ProporctionModeluesScrPanel({
  activeTab,
  insurer,
}: ProporctionModeluesScrPanelProps) {
  const [selectedYearlyMetricByInsurer, setSelectedYearlyMetricByInsurer] = useState<
    Record<16 | 21, string | null>
  >({
    16: null,
    21: null,
  });

  const [selectedQuarterlyMetricByInsurer, setSelectedQuarterlyMetricByInsurer] = useState<
    Record<16 | 21, string | null>
  >({
    16: null,
    21: null,
  });

  const { data, isLoading, error, usedEndpoint, attemptedEndpoints } =
    useProporctionModeluesScrData(insurer);

  if (activeTab === "explanations") {
    return (
      <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4">
        <h3 className="text-base font-semibold text-slate-100">Objaśnienia</h3>
        <p className="mt-2 text-sm text-slate-300">
          Test odbioru danych dla <code>structure-scr/proporction-modelues-scr</code>.
        </p>
        <div className="mt-3 text-xs text-slate-300">
          <div>Endpointy probowane po kolei:</div>
          <ul className="mt-1 list-disc pl-5">
            {attemptedEndpoints.map((endpoint) => (
              <li key={endpoint}>
                <code>{endpoint}</code>
              </li>
            ))}
          </ul>
          {usedEndpoint ? (
            <div className="mt-2">
              Uzyty endpoint: <code>{usedEndpoint}</code>
            </div>
          ) : null}
        </div>
      </section>
    );
  }

  if (isLoading) {
    return (
      <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4 text-sm text-slate-300">
        Trwa pobieranie danych dla structure-scr/proporction-modelues-scr...
      </section>
    );
  }

  if (error) {
    return (
      <section className="mt-5 rounded-xl border border-red-800/60 bg-[#2a1010] p-4 text-sm text-red-200">
        <p>Blad pobierania danych: {error}</p>
        <p className="mt-2">Probowane endpointy:</p>
        <ul className="mt-1 list-disc pl-5">
          {attemptedEndpoints.map((endpoint) => (
            <li key={endpoint}>
              <code>{endpoint}</code>
            </li>
          ))}
        </ul>
      </section>
    );
  }

  if (!data) {
    return (
      <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4 text-sm text-slate-300">
        Brak danych.
      </section>
    );
  }

  const splitTables = splitTableBySuffix(data);

  return (
    <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4">
      <div className="mb-3 flex items-center justify-end">
        <span className="rounded-md border border-slate-700/70 bg-[#1b2638] px-2 py-1 text-xs font-semibold text-slate-300">
          Ubezpieczyciel {insurer}
        </span>
      </div>

      {activeTab === "indicators" ? <ScrIndicatorsTable table={splitTables.indicators} /> : null}

      {activeTab === "yearly_changes" ? (
        <YearlyChangesTable
          table={splitTables.yearly}
          indicatorsTable={splitTables.indicators}
          selectedMetric={selectedYearlyMetricByInsurer[insurer]}
          onSelectedMetricChange={(metric) => {
            setSelectedYearlyMetricByInsurer((prev) => ({
              ...prev,
              [insurer]: metric,
            }));
          }}
        />
      ) : null}

      {activeTab === "quarterly_changes" ? (
        <QuarterlyChangesTable
          table={splitTables.quarterly}
          indicatorsTable={splitTables.indicators}
          selectedMetric={selectedQuarterlyMetricByInsurer[insurer]}
          onSelectedMetricChange={(metric) => {
            setSelectedQuarterlyMetricByInsurer((prev) => ({
              ...prev,
              [insurer]: metric,
            }));
          }}
        />
      ) : null}
    </section>
  );
}

type PlainTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

function splitTableBySuffix(table: PlainTableData) {
  const baseColumns = table.columns.slice(0, 3);
  const dataColumns = table.columns.slice(3);

  const quarterlyColumns = dataColumns.filter((column) => isQuarterlyColumn(column));
  const yearlyColumns = dataColumns.filter((column) => isYearlyColumn(column));
  const indicatorsColumns = dataColumns.filter(
    (column) => !isQuarterlyColumn(column) && !isYearlyColumn(column),
  );

  return {
    indicators: pickColumns(table.rows, [...baseColumns, ...indicatorsColumns]),
    yearly: pickColumns(table.rows, [...baseColumns, ...yearlyColumns]),
    quarterly: pickColumns(table.rows, [...baseColumns, ...quarterlyColumns]),
  };
}

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

function isQuarterlyColumn(column: string) {
  return normalizeColumn(column).includes("_kwartalnie");
}

function isYearlyColumn(column: string) {
  return normalizeColumn(column).includes("_rocznie");
}

function pickColumns(rows: Record<string, unknown>[], columns: string[]): PlainTableData {
  return {
    columns,
    rows: rows.map((row) => {
      const picked: Record<string, unknown> = {};
      columns.forEach((column) => {
        picked[column] = row[column];
      });
      return picked;
    }),
  };
}


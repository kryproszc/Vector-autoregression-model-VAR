import type { HeaderTabId } from "@/app/_components/navigation/types";
import type { ComponentType } from "react";
import { LifeInsuranceRiskPanel } from "@/features/risk-exposure/life-insurance/LifeInsuranceRiskPanel";
import { ProporctionModeluesScrPanel } from "@/features/scr-structure/proporction-modelues-scr/ProporctionModeluesScrPanel";

type FeaturePanelProps = {
  categoryId: string;
  subcategoryId?: string;
  activeTab: HeaderTabId;
  insurer: 16 | 21;
};

type RegisteredPanelProps = {
  activeTab: HeaderTabId;
  insurer: 16 | 21;
};

const panelRegistry: Record<string, ComponentType<RegisteredPanelProps>> = {
  "risk_exposure:life_insurance_risk": LifeInsuranceRiskPanel,
  "scr_structure:main_scr": ProporctionModeluesScrPanel,
};

export function FeaturePanel({ categoryId, subcategoryId, activeTab, insurer }: FeaturePanelProps) {
  const key = `${categoryId}:${subcategoryId ?? ""}`;
  const Panel = panelRegistry[key];

  if (!Panel) {
    return null;
  }

  return <Panel activeTab={activeTab} insurer={insurer} />;
}

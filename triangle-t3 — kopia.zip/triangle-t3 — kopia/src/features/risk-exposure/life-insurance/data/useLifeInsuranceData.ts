import { useEffect, useState } from "react";
import type { LifeInsuranceApiResponse } from "./types";

type UseLifeInsuranceDataResult = {
  data: LifeInsuranceApiResponse | null;
  isLoading: boolean;
  error: string | null;
  endpoint: string;
};

export function useLifeInsuranceData(insurer: 16 | 21): UseLifeInsuranceDataResult {
  const [data, setData] = useState<LifeInsuranceApiResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL ?? "";
  const endpoint = `${baseUrl}/api/risk-exposure/life-insurance`;

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      setIsLoading(true);
      setError(null);

      try {
        const response = await fetch(endpoint, {
          method: "GET",
          signal: controller.signal,
          headers: {
            Accept: "application/json",
            "x-insurer": String(insurer),
          },
          cache: "no-store",
        });

        if (!response.ok) {
          throw new Error(`Backend zwrocil status ${response.status}`);
        }

        const parsed = (await response.json()) as LifeInsuranceApiResponse;
        setData(parsed);
      } catch (err) {
        if (controller.signal.aborted) {
          return;
        }

        setError(err instanceof Error ? err.message : "Nieznany blad pobierania danych");
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false);
        }
      }
    }

    void load();

    return () => {
      controller.abort();
    };
  }, [endpoint, insurer]);

  return {
    data,
    isLoading,
    error,
    endpoint,
  };
}

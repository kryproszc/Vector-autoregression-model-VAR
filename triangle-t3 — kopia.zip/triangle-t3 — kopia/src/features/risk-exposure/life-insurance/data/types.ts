export type TableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

export type LifeInsuranceApiResponse = {
  meta: {
    table: string;
    insurer: 16 | 21;
    dbPath: string;
    rowCount: number;
  };
  columns: string[];
  rows: Record<string, unknown>[];
  objasnienia?: unknown;
};

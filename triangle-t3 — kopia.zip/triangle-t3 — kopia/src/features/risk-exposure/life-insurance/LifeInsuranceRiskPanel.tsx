import type { HeaderTabId } from "@/app/_components/navigation/types";
import type { ReactNode } from "react";
import { useState } from "react";
import { IndicatorsTable } from "@/components/tables/IndicatorsTable";
import { QuarterlyChangesTable } from "@/components/tables/QuarterlyChangesTable";
import { YearlyChangesTable } from "@/components/tables/YearlyChangesTable";
import { useLifeInsuranceData } from "@/features/risk-exposure/life-insurance/data/useLifeInsuranceData";
import type { TableData } from "@/features/risk-exposure/life-insurance/data/types";

type LifeInsuranceRiskPanelProps = {
  activeTab: HeaderTabId;
  insurer: 16 | 21;
};

type TabChartSelections = {
  indicators: string | null;
  yearly: string | null;
  quarterly: string | null;
};

type ExplanationRow = {
  name: string;
  numerator: string;
  denominator: string;
};

const initialSelections: Record<16 | 21, TabChartSelections> = {
  16: { indicators: null, yearly: null, quarterly: null },
  21: { indicators: null, yearly: null, quarterly: null },
};

export function LifeInsuranceRiskPanel({ activeTab, insurer }: LifeInsuranceRiskPanelProps) {
  const [selectionsByInsurer, setSelectionsByInsurer] = useState<Record<16 | 21, TabChartSelections>>(
    initialSelections,
  );

  const { data, isLoading, error, endpoint } = useLifeInsuranceData(insurer);

  const rawTable: TableData = {
    columns: data?.columns ?? [],
    rows: data?.rows ?? [],
  };

  const splitTables = splitTableBySuffix(rawTable);
  const explanations = normalizeExplanations(data?.objasnienia);

  if (activeTab === "explanations") {
    return (
      <FeatureCard title="Objaśnienia" insurer={insurer}>
        <p>
          Dane są pobierane z endpointu backendu dla tej podkategorii i wybranego
          ubezpieczyciela. Endpoint: <code className="rounded bg-slate-900/80 px-1">{endpoint}</code>
        </p>

        {isLoading ? <p className="mt-3 text-sm">Trwa pobieranie objaśnień...</p> : null}

        {!isLoading && error ? (
          <p className="mt-3 text-sm text-red-300">Nie udało się pobrać objaśnień: {error}</p>
        ) : null}

        {!isLoading && !error && explanations.length ? (
          <div className="mt-4 grid gap-4">
            {explanations.map((item, index) => (
              <article
                key={`${index}-${item.name}`}
                className="rounded-xl border border-slate-700/70 bg-linear-to-br from-[#14233a] via-[#112139] to-[#0e1a2e] p-4"
              >
                <h4 className="text-sm font-semibold leading-snug text-slate-100">{item.name}</h4>

                <div className="mt-3 rounded-lg border border-slate-600/70 bg-[#0d1a2f]/90 px-4 py-4 sm:px-6">
                  <div className="mx-auto max-w-4xl text-center">
                    <div className="wrap-break-word px-2 pb-2 font-mono text-[15px] font-semibold leading-relaxed text-slate-100">
                      {item.numerator}
                    </div>
                    <div className="h-px w-full bg-linear-to-r from-cyan-300/30 via-cyan-300/80 to-cyan-300/30" />
                    <div className="wrap-break-word px-2 pt-2 font-mono text-[15px] leading-relaxed text-slate-200">
                      {item.denominator}
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : null}

        {!isLoading && !error && !explanations.length ? (
          <p className="mt-3 text-sm text-slate-300">
            Brak danych w polu <code className="rounded bg-slate-900/80 px-1">objasnienia</code>.
          </p>
        ) : null}
      </FeatureCard>
    );
  }

  if (isLoading) {
    return <FeatureCard title="Ładowanie danych" insurer={insurer}>Trwa pobieranie danych z backendu...</FeatureCard>;
  }

  if (error) {
    return (
      <FeatureCard title="Błąd pobierania" insurer={insurer}>
        {error}
        <br />
        Sprawdz endpoint: <code className="rounded bg-slate-900/80 px-1">{endpoint}</code>
      </FeatureCard>
    );
  }

  if (!data) {
    return (
      <FeatureCard title="Brak danych" insurer={insurer}>
        Backend powinien zwrocic pola <code className="rounded bg-slate-900/80 px-1">columns</code> i
        <code className="rounded bg-slate-900/80 px-1">rows</code>.
      </FeatureCard>
    );
  }

  if (activeTab === "indicators") {
    return (
      <FeatureCard title="Wskaźniki" insurer={insurer}>
        <IndicatorsTable
          table={splitTables.indicators}
          selectedMetric={selectionsByInsurer[insurer].indicators}
          onSelectedMetricChange={(metric) => {
            setSelectionsByInsurer((prev) => ({
              ...prev,
              [insurer]: {
                ...prev[insurer],
                indicators: metric,
              },
            }));
          }}
        />
      </FeatureCard>
    );
  }

  if (activeTab === "yearly_changes") {
    return (
      <FeatureCard title="Zmiany roczne" insurer={insurer}>
        <YearlyChangesTable
          table={splitTables.yearlyChanges}
          indicatorsTable={splitTables.indicators}
          selectedMetric={selectionsByInsurer[insurer].yearly}
          onSelectedMetricChange={(metric) => {
            setSelectionsByInsurer((prev) => ({
              ...prev,
              [insurer]: {
                ...prev[insurer],
                yearly: metric,
              },
            }));
          }}
        />
      </FeatureCard>
    );
  }

  return (
    <FeatureCard title="Zmiany kwartalne" insurer={insurer}>
      <QuarterlyChangesTable
        table={splitTables.quarterlyChanges}
        indicatorsTable={splitTables.indicators}
        selectedMetric={selectionsByInsurer[insurer].quarterly}
        onSelectedMetricChange={(metric) => {
          setSelectionsByInsurer((prev) => ({
            ...prev,
            [insurer]: {
              ...prev[insurer],
              quarterly: metric,
            },
          }));
        }}
      />
    </FeatureCard>
  );
}

function splitTableBySuffix(table: TableData) {
  const baseColumns = table.columns.filter(isBaseColumn);

  const quarterlyDataColumns = table.columns.filter(
    (column) => !isBaseColumn(column) && isQuarterlyColumn(column),
  );

  const yearlyDataColumns = table.columns.filter(
    (column) => !isBaseColumn(column) && isYearlyColumn(column),
  );

  const indicatorDataColumns = table.columns.filter(
    (column) => !isBaseColumn(column) && !isQuarterlyColumn(column) && !isYearlyColumn(column),
  );

  const quarterlyColumns = [...baseColumns, ...quarterlyDataColumns];
  const yearlyColumns = [...baseColumns, ...yearlyDataColumns];
  const indicatorColumns = [...baseColumns, ...indicatorDataColumns];

  return {
    indicators: pickColumns(table.rows, indicatorColumns),
    yearlyChanges: pickColumns(table.rows, yearlyColumns),
    quarterlyChanges: pickColumns(table.rows, quarterlyColumns),
  };
}

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

function isBaseColumn(column: string) {
  const normalized = normalizeColumn(column);
  return normalized === "data_spr" || normalized === "typ_okresu" || normalized === "kod_zu";
}

function isQuarterlyColumn(column: string) {
  const normalized = column.trim().toLowerCase();
  return /(^|_)kwartalnie($|_)/.test(normalized);
}

function isYearlyColumn(column: string) {
  const normalized = normalizeColumn(column);
  return /(^|_)(yoy|rocznie)($|_)/.test(normalized);
}

function pickColumns(rows: Record<string, unknown>[], columns: string[]): TableData {
  return {
    columns,
    rows: rows.map((row) => {
      const picked: Record<string, unknown> = {};
      columns.forEach((column) => {
        picked[column] = row[column];
      });
      return picked;
    }),
  };
}

function normalizeExplanations(raw: unknown): ExplanationRow[] {
  if (!Array.isArray(raw) || !raw.length) {
    return [];
  }

  const rows = raw
    .map((entry, index) => normalizeExplanationEntry(entry, index))
    .filter((entry): entry is ExplanationRow => entry !== null);

  return rows;
}

function normalizeExplanationEntry(entry: unknown, index: number): ExplanationRow | null {
  if (Array.isArray(entry)) {
    const name = toText(entry[0]) || `Współczynnik ${index + 1}`;
    const numerator = toText(entry[1]) || "-";
    const denominator = toText(entry[2]) || "-";

    return { name, numerator, denominator };
  }

  if (isRecord(entry)) {
    const name =
      toText(entry.kolumna_1) ||
      toText(entry.column_1) ||
      toText(entry.name) ||
      `Współczynnik ${index + 1}`;
    const numerator = toText(entry.kolumna_2) || toText(entry.column_2) || toText(entry.numerator) || "-";
    const denominator =
      toText(entry.kolumna_3) || toText(entry.column_3) || toText(entry.denominator) || "-";

    return { name, numerator, denominator };
  }

  return null;
}

function toText(value: unknown): string {
  if (value === null || value === undefined) {
    return "";
  }

  if (typeof value === "string") {
    return value.trim();
  }

  if (typeof value === "number" || typeof value === "boolean") {
    return String(value);
  }

  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function FeatureCard({
  title,
  insurer,
  children,
}: {
  title: string;
  insurer: 16 | 21;
  children: ReactNode;
}) {
  return (
    <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-base font-semibold text-slate-100">{title}</h3>
        <span className="rounded-md border border-slate-700/70 bg-[#1b2638] px-2 py-1 text-xs font-semibold text-slate-300">
          Ubezpieczyciel {insurer}
        </span>
      </div>
      <div className="text-sm leading-relaxed text-slate-300">{children}</div>
    </section>
  );
}

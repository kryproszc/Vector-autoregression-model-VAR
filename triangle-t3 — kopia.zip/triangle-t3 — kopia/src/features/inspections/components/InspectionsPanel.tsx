'use client';

import { useMemo, useState } from "react";
import { Check, ChevronsUpDown, Pencil, Plus, SlidersHorizontal, X } from "lucide-react";

import {
  ALL_INSPECTION_COLUMN_KEYS,
  INSPECTION_COLUMNS,
  INSPECTION_ROWS,
  INSPECTION_VIEW_OPTIONS,
  PODSTAWOWE_INSPECTION_COLUMN_KEYS,
  TERMINY_INSPECTION_COLUMN_KEYS,
} from "@/features/inspections/data";
import {
  EMPLOYEE_OPTIONS,
  ENTITY_NAME_OPTIONS,
  ENTITY_TYPE_OPTIONS,
  INSPECTION_SCOPE_OPTIONS,
  INSPECTION_STATUS_OPTIONS,
  INSPECTION_TYPE_OPTIONS,
  MARKET_OPTIONS,
} from "@/features/inspections/dictionaries";
import type { InspectionColumnKey, InspectionRow, InspectionViewId } from "@/features/inspections/types";

type AddInspectionForm = Omit<InspectionRow, "id" | "lp">;

const DEFAULT_ADD_INSPECTION_FORM: AddInspectionForm = {
  nazwaPodmiotu: "",
  typInspekcji: "",
  zakresInspekcji: "",
  poczatekInspekcji: "",
  koniecInspekcji: "",
  osobaKierujaca: "",
  skladZespolu: "",
  rynek: "",
  rodzajPodmiotu: "",
  dataProtokolu: "",
  dataDoreczeniaProtokolu: "",
  dataAkceptacjiSprawozdania: "",
  dataDoreczeniaPisma: "",
  dataPismaZastrzezenia: "",
  dataWplywuPisma: "",
  dataPismaZOdpowiedzia: "",
  dataAkceptacjiNoty: "",
  dataZalecen: "",
  status: "",
  komentarz: "",
};

function getBaseInspectionColumnKeys(viewId: InspectionViewId): InspectionColumnKey[] {
  if (viewId === "podstawowe") {
    return PODSTAWOWE_INSPECTION_COLUMN_KEYS;
  }

  if (viewId === "terminy") {
    return TERMINY_INSPECTION_COLUMN_KEYS;
  }

  return ALL_INSPECTION_COLUMN_KEYS;
}

export function InspectionsPanel() {
  const [inspectionRows, setInspectionRows] = useState<InspectionRow[]>(INSPECTION_ROWS);
  const [selectedInspectionId, setSelectedInspectionId] = useState<string | null>(null);
  const [hiddenColumns, setHiddenColumns] = useState<InspectionColumnKey[]>([]);
  const [selectedInspectionView, setSelectedInspectionView] = useState<InspectionViewId>("calosc");
  const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isTeamPickerOpen, setIsTeamPickerOpen] = useState(false);
  const [editingInspectionId, setEditingInspectionId] = useState<string | null>(null);
  const [draftSelectedInspectionView, setDraftSelectedInspectionView] = useState<InspectionViewId>("calosc");
  const [draftHiddenColumns, setDraftHiddenColumns] = useState<InspectionColumnKey[]>([]);
  const [addInspectionForm, setAddInspectionForm] = useState<AddInspectionForm>(DEFAULT_ADD_INSPECTION_FORM);
  const [addInspectionError, setAddInspectionError] = useState<string | null>(null);

  const baseInspectionColumns = useMemo(
    () => getBaseInspectionColumnKeys(selectedInspectionView),
    [selectedInspectionView],
  );

  const visibleInspectionColumns = useMemo(
    () =>
      baseInspectionColumns.filter((columnKey) => !hiddenColumns.includes(columnKey)),
    [baseInspectionColumns, hiddenColumns],
  );

  const visibleInspectionColumnDefinitions = useMemo(
    () => INSPECTION_COLUMNS.filter((column) => visibleInspectionColumns.includes(column.key)),
    [visibleInspectionColumns],
  );

  const selectableColumnDefinitions = useMemo(
    () => INSPECTION_COLUMNS.filter((column) => baseInspectionColumns.includes(column.key)),
    [baseInspectionColumns],
  );

  const draftBaseInspectionColumns = useMemo(
    () => getBaseInspectionColumnKeys(draftSelectedInspectionView),
    [draftSelectedInspectionView],
  );

  const draftVisibleInspectionColumns = useMemo(
    () => draftBaseInspectionColumns.filter((columnKey) => !draftHiddenColumns.includes(columnKey)),
    [draftBaseInspectionColumns, draftHiddenColumns],
  );

  const draftSelectableColumnDefinitions = useMemo(
    () => INSPECTION_COLUMNS.filter((column) => draftBaseInspectionColumns.includes(column.key)),
    [draftBaseInspectionColumns],
  );

  const selectedTeamMembers = useMemo(
    () =>
      addInspectionForm.skladZespolu
        .split(";")
        .map((member) => member.trim())
        .filter(Boolean),
    [addInspectionForm.skladZespolu],
  );

  const handleTeamMemberToggle = (member: string) => {
    setAddInspectionForm((prev) => {
      const currentMembers = prev.skladZespolu
        .split(";")
        .map((item) => item.trim())
        .filter(Boolean);

      const nextMembers = currentMembers.includes(member)
        ? currentMembers.filter((item) => item !== member)
        : [...currentMembers, member];

      return {
        ...prev,
        skladZespolu: nextMembers.join("; "),
      };
    });
  };

  const hideColumnInDraft = (columnKey: InspectionColumnKey) => {
    setDraftHiddenColumns((prev) => {
      if (prev.includes(columnKey)) {
        return prev;
      }

      return [...prev, columnKey];
    });
  };

  const handleDraftColumnVisibilityChange = (columnKey: InspectionColumnKey, isVisible: boolean) => {
    if (!isVisible && draftVisibleInspectionColumns.length <= 1) {
      return;
    }

    if (isVisible) {
      setDraftHiddenColumns((prev) => prev.filter((key) => key !== columnKey));
      return;
    }

    hideColumnInDraft(columnKey);
  };

  const handleOpenViewModal = () => {
    setDraftSelectedInspectionView(selectedInspectionView);
    setDraftHiddenColumns(hiddenColumns);
    setIsColumnPickerOpen(true);
  };

  const handleDraftViewSelect = (viewId: InspectionViewId) => {
    setDraftSelectedInspectionView(viewId);
    setDraftHiddenColumns([]);
  };

  const handleApplyViewChanges = () => {
    const nextBaseColumns = getBaseInspectionColumnKeys(draftSelectedInspectionView);
    setSelectedInspectionView(draftSelectedInspectionView);
    setHiddenColumns(draftHiddenColumns.filter((columnKey) => nextBaseColumns.includes(columnKey)));
    setIsColumnPickerOpen(false);
  };

  const handleOpenAddModal = () => {
    setAddInspectionForm(DEFAULT_ADD_INSPECTION_FORM);
    setAddInspectionError(null);
    setIsTeamPickerOpen(false);
    setEditingInspectionId(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = () => {
    if (!selectedInspectionId) {
      return;
    }

    const rowToEdit = inspectionRows.find((row) => row.id === selectedInspectionId);

    if (!rowToEdit) {
      return;
    }

    const { id: _id, lp: _lp, ...editableData } = rowToEdit;
    setAddInspectionForm(editableData);
    setAddInspectionError(null);
    setIsTeamPickerOpen(false);
    setEditingInspectionId(rowToEdit.id);
    setIsAddModalOpen(true);
  };

  const closeInspectionFormModal = () => {
    setIsAddModalOpen(false);
    setIsTeamPickerOpen(false);
    setEditingInspectionId(null);
  };

  const handleAddInspection = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (
      !addInspectionForm.nazwaPodmiotu.trim() ||
      !addInspectionForm.poczatekInspekcji ||
      !addInspectionForm.koniecInspekcji ||
      !addInspectionForm.osobaKierujaca.trim() ||
      !addInspectionForm.skladZespolu.trim()
    ) {
      setAddInspectionError("Uzupełnij wymagane pola: podmiot, daty oraz skład zespołu.");
      return;
    }

    const normalize = (value: string, fallback = "brak") => value.trim() || fallback;

    const normalizedFormData: Omit<InspectionRow, "id" | "lp"> = {
      nazwaPodmiotu: addInspectionForm.nazwaPodmiotu.trim(),
      typInspekcji: normalize(addInspectionForm.typInspekcji),
      zakresInspekcji: normalize(addInspectionForm.zakresInspekcji),
      poczatekInspekcji: addInspectionForm.poczatekInspekcji,
      koniecInspekcji: addInspectionForm.koniecInspekcji,
      osobaKierujaca: addInspectionForm.osobaKierujaca.trim(),
      skladZespolu: addInspectionForm.skladZespolu.trim(),
      rynek: normalize(addInspectionForm.rynek),
      rodzajPodmiotu: normalize(addInspectionForm.rodzajPodmiotu),
      dataProtokolu: normalize(addInspectionForm.dataProtokolu),
      dataDoreczeniaProtokolu: normalize(addInspectionForm.dataDoreczeniaProtokolu),
      dataAkceptacjiSprawozdania: normalize(addInspectionForm.dataAkceptacjiSprawozdania),
      dataDoreczeniaPisma: normalize(addInspectionForm.dataDoreczeniaPisma, "brak pisma"),
      dataPismaZastrzezenia: normalize(addInspectionForm.dataPismaZastrzezenia, "brak pisma"),
      dataWplywuPisma: normalize(addInspectionForm.dataWplywuPisma, "brak pisma"),
      dataPismaZOdpowiedzia: normalize(addInspectionForm.dataPismaZOdpowiedzia, "brak pisma"),
      dataAkceptacjiNoty: normalize(addInspectionForm.dataAkceptacjiNoty),
      dataZalecen: normalize(addInspectionForm.dataZalecen),
      status: normalize(addInspectionForm.status, "Nowa"),
      komentarz: addInspectionForm.komentarz.trim(),
    };

    if (editingInspectionId) {
      setInspectionRows((prev) =>
        prev.map((row) => (row.id === editingInspectionId ? { ...row, ...normalizedFormData } : row)),
      );
      closeInspectionFormModal();
      return;
    }

    const nextLp = inspectionRows.reduce((maxLp, row) => Math.max(maxLp, row.lp), 0) + 1;
    const createdRow: InspectionRow = {
      id: `ins-${Date.now()}`,
      lp: nextLp,
      ...normalizedFormData,
      komentarz: normalizedFormData.komentarz || "Nowy rekord dodany ręcznie.",
    };

    setInspectionRows((prev) => [...prev, createdRow]);
    setSelectedInspectionId(createdRow.id);
    closeInspectionFormModal();
  };

  return (
    <section
      className="rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5"
      onClick={(event) => {
        if (event.target === event.currentTarget) {
          setSelectedInspectionId(null);
        }
        event.stopPropagation();
      }}
    >
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3 border-b border-slate-700/70 pb-3">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="text-lg font-semibold text-slate-100">Ewidencja kontroli</h2>

          <button
            type="button"
            onClick={handleOpenViewModal}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-[#5d7eaf] bg-[#243b61] px-3 text-sm font-semibold text-slate-100 transition-colors hover:bg-[#2c4875]"
          >
            <SlidersHorizontal size={14} />
            Widok
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleOpenAddModal}
            className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#8ec5a1] bg-[#b9e8c9] px-3.5 text-sm font-semibold text-[#1f5130] shadow-[inset_0_1px_0_rgba(255,255,255,0.45)] transition-colors hover:bg-[#a5debb]"
          >
            <Plus size={15} />
            Dodaj
          </button>

          <button
            type="button"
            disabled={!selectedInspectionId}
            onClick={handleOpenEditModal}
            className="inline-flex h-10 items-center gap-2 rounded-lg border px-3.5 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:border-slate-700 disabled:bg-[#1a2946] disabled:text-slate-500 enabled:border-[#6ea3f0] enabled:bg-[#2d4d7f] enabled:text-slate-100 enabled:hover:bg-[#375f99]"
          >
            <Pencil size={15} />
            Edytuj
          </button>
        </div>
      </div>

      <div className="max-h-105 w-full max-w-full overflow-x-auto overflow-y-auto rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)]">
        <table className="min-w-350 border-collapse text-sm text-slate-900">
          <thead>
            <tr className="bg-slate-100 text-slate-800">
              {visibleInspectionColumnDefinitions.map((column) => (
                <th
                  key={column.key}
                  className="sticky top-0 z-10 whitespace-nowrap border-b border-slate-300 bg-slate-100 px-3 py-2 text-left font-semibold"
                >
                  <span>{column.label}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {inspectionRows.map((row) => {
              const isActive = selectedInspectionId === row.id;

              return (
                <tr
                  key={row.id}
                  onClick={() => setSelectedInspectionId(row.id)}
                  className={`cursor-pointer border-b border-slate-200 transition-colors last:border-b-0 ${
                    isActive
                      ? "bg-blue-100 text-slate-900 ring-1 ring-inset ring-blue-300"
                      : "bg-white text-slate-900 hover:bg-slate-50"
                  }`}
                >
                  {visibleInspectionColumnDefinitions.map((column) => {
                    const value = row[column.key];
                    return (
                      <td
                        key={column.key}
                        className={`whitespace-nowrap px-3 py-2.5 ${
                          column.key === "lp" && isActive ? "font-medium" : "font-normal"
                        }`}
                      >
                        {column.key === "skladZespolu" ? (
                          <div className="max-w-64 overflow-x-auto whitespace-nowrap">{String(value)}</div>
                        ) : (
                          String(value)
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {isColumnPickerOpen ? (
        <div className="fixed inset-0 z-40 flex items-center justify-center p-4">
          <button
            type="button"
            aria-label="Zamknij okno wyboru kolumn"
            className="absolute inset-0 bg-slate-950/65"
            onClick={() => setIsColumnPickerOpen(false)}
          />

          <div
            role="dialog"
            aria-modal="true"
            aria-label="Wybór kolumn tabeli"
            className="relative z-10 max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
          >
            <div className="mb-4 flex items-center justify-between gap-3 border-b border-slate-200 pb-3">
              <div>
                <h3 className="text-base font-semibold text-slate-900">Widok tabeli</h3>
                <p className="mt-1 text-sm text-slate-600">Wybierz układ kolumn i zaznacz kolumny widoczne w tabeli.</p>
              </div>

              <button
                type="button"
                onClick={() => setIsColumnPickerOpen(false)}
                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
              >
                <X size={14} />
              </button>
            </div>

            <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
              <p className="mb-2 text-sm font-semibold text-slate-700">Układ</p>
              <div className="grid gap-2 sm:grid-cols-3">
                {INSPECTION_VIEW_OPTIONS.map((view) => {
                  const isActive = draftSelectedInspectionView === view.id;

                  return (
                    <button
                      key={view.id}
                      type="button"
                      onClick={() => handleDraftViewSelect(view.id)}
                      className={`rounded-lg border px-3 py-2 text-left transition-colors ${
                        isActive
                          ? "border-blue-300 bg-blue-50 text-slate-900"
                          : "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      <p className="text-sm font-semibold">{view.label}</p>
                      <p className="mt-1 text-xs text-slate-500">{view.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            <p className="mb-2 text-sm font-semibold text-slate-700">Kolumny</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {draftSelectableColumnDefinitions.map((column) => {
                const isVisible = !draftHiddenColumns.includes(column.key);
                const isOnlyVisibleColumn = isVisible && draftVisibleInspectionColumns.length <= 1;

                return (
                  <label
                    key={column.key}
                    className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-800 transition-colors hover:bg-slate-50"
                  >
                    <input
                      type="checkbox"
                      checked={isVisible}
                      disabled={isOnlyVisibleColumn}
                      onChange={(event) => handleDraftColumnVisibilityChange(column.key, event.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-blue-600"
                    />
                    <span>{column.label}</span>
                  </label>
                );
              })}
            </div>

            <div className="mt-4 flex flex-wrap justify-end gap-2 border-t border-slate-200 pt-3">
              <button
                type="button"
                onClick={() => setDraftHiddenColumns([])}
                className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100"
              >
                Pokaż wszystkie
              </button>

              <button
                type="button"
                onClick={() => setIsColumnPickerOpen(false)}
                className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100"
              >
                Anuluj
              </button>

              <button
                type="button"
                onClick={handleApplyViewChanges}
                className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 text-sm font-semibold text-slate-100 transition-colors hover:bg-[#375f99]"
              >
                Pokaż
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {isAddModalOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <button
            type="button"
            aria-label="Zamknij okno dodawania rekordu"
            className="absolute inset-0 bg-slate-950/65"
            onClick={closeInspectionFormModal}
          />

          <div
            role="dialog"
            aria-modal="true"
            aria-label="Dodaj nową inspekcję"
            className="relative z-10 flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
          >
            <div className="mb-4 flex items-center justify-between gap-3 border-b border-slate-200 pb-3">
              <div>
                <h3 className="text-base font-semibold text-slate-900">
                  {editingInspectionId ? "Edytuj inspekcję" : "Dodaj inspekcję"}
                </h3>
                <p className="mt-1 text-sm text-slate-600">
                  {editingInspectionId
                    ? "Zmiany zostaną zapisane od razu w tabeli."
                    : "Nowy rekord zostanie od razu dodany do tabeli."}
                </p>
              </div>

              <button
                type="button"
                onClick={closeInspectionFormModal}
                className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
              >
                <X size={14} />
              </button>
            </div>

            <form className="flex min-h-0 flex-1 flex-col" onSubmit={handleAddInspection}>
              <div className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
                <section className="rounded-xl border border-slate-200 p-3">
                <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-700">Dane podstawowe</h4>

                <div className="grid gap-3 sm:grid-cols-2">
                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Nazwa podmiotu *</span>
                    <select
                      required
                      value={addInspectionForm.nazwaPodmiotu}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, nazwaPodmiotu: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="" disabled>
                        Wybierz podmiot
                      </option>
                      {ENTITY_NAME_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Typ inspekcji</span>
                    <select
                      value={addInspectionForm.typInspekcji}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, typInspekcji: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="">Wybierz typ inspekcji</option>
                      {INSPECTION_TYPE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Zakres inspekcji</span>
                    <select
                      value={addInspectionForm.zakresInspekcji}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, zakresInspekcji: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="">Wybierz zakres inspekcji</option>
                      {INSPECTION_SCOPE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Początek inspekcji *</span>
                    <input
                      required
                      type="date"
                      value={addInspectionForm.poczatekInspekcji}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, poczatekInspekcji: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Koniec inspekcji *</span>
                    <input
                      required
                      type="date"
                      value={addInspectionForm.koniecInspekcji}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, koniecInspekcji: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Osoba kierująca *</span>
                    <select
                      required
                      value={addInspectionForm.osobaKierujaca}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, osobaKierujaca: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="" disabled>
                        Wybierz osobę kierującą
                      </option>
                      {EMPLOYEE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Rynek</span>
                    <select
                      value={addInspectionForm.rynek}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, rynek: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="">Wybierz rynek</option>
                      {MARKET_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Rodzaj podmiotu</span>
                    <select
                      value={addInspectionForm.rodzajPodmiotu}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, rodzajPodmiotu: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="">Wybierz rodzaj podmiotu</option>
                      {ENTITY_TYPE_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>
                </div>

                <label className="mt-3 block text-sm text-slate-700">
                  <span className="mb-1 block">Skład zespołu *</span>
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setIsTeamPickerOpen((prev) => !prev)}
                      className="flex w-full items-center justify-between rounded-lg border border-slate-300 bg-white px-3 py-2 text-left text-sm text-slate-900 transition-colors hover:bg-slate-50"
                    >
                      <span>
                        {selectedTeamMembers.length
                          ? `Wybrano osob: ${selectedTeamMembers.length}`
                          : "Wybierz czlonkow zespolu"}
                      </span>
                      <ChevronsUpDown size={14} className="text-slate-500" />
                    </button>

                    {isTeamPickerOpen ? (
                      <div className="absolute z-20 mt-2 w-full rounded-lg border border-slate-300 bg-white p-2 shadow-lg">
                        <div className="mb-2 flex items-center justify-end gap-2 border-b border-slate-200 pb-2">
                          <button
                            type="button"
                            onClick={() => setAddInspectionForm((prev) => ({ ...prev, skladZespolu: "" }))}
                            className="text-xs font-semibold text-slate-600 hover:text-slate-900"
                          >
                            Wyczysc
                          </button>
                          <button
                            type="button"
                            onClick={() => setAddInspectionForm((prev) => ({ ...prev, skladZespolu: EMPLOYEE_OPTIONS.join("; ") }))}
                            className="text-xs font-semibold text-slate-600 hover:text-slate-900"
                          >
                            Zaznacz wszystkie
                          </button>
                        </div>

                        <div className="max-h-52 space-y-1 overflow-y-auto pr-1">
                          {EMPLOYEE_OPTIONS.map((option) => {
                            const isSelected = selectedTeamMembers.includes(option);

                            return (
                              <button
                                key={option}
                                type="button"
                                onClick={() => handleTeamMemberToggle(option)}
                                className="flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm text-slate-900 transition-colors hover:bg-slate-100"
                              >
                                <span
                                  className={`flex h-4 w-4 items-center justify-center rounded border ${
                                    isSelected ? "border-blue-600 bg-blue-600 text-white" : "border-slate-300 bg-white"
                                  }`}
                                >
                                  {isSelected ? <Check size={12} /> : null}
                                </span>
                                <span>{option}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ) : null}
                  </div>

                  {selectedTeamMembers.length ? (
                    <span className="mt-2 block text-xs text-slate-600">
                      Wybrano: {selectedTeamMembers.join(", ")}
                    </span>
                  ) : null}
                </label>

                <label className="mt-3 block text-sm text-slate-700">
                  <span className="mb-1 block">Komentarz</span>
                  <textarea
                    rows={2}
                    value={addInspectionForm.komentarz}
                    onChange={(event) =>
                      setAddInspectionForm((prev) => ({ ...prev, komentarz: event.target.value }))
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                  />
                </label>
                </section>

                <section className="rounded-xl border border-slate-200 p-3">
                <h4 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-700">Dane terminy</h4>

                <div className="grid gap-3 sm:grid-cols-2">
                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Status</span>
                    <select
                      value={addInspectionForm.status}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, status: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    >
                      <option value="">Wybierz status</option>
                      {INSPECTION_STATUS_OPTIONS.map((option) => (
                        <option key={option} value={option}>
                          {option}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data protokołu / sprawozdania</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataProtokolu}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataProtokolu: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data doręczenia protokołu</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataDoreczeniaProtokolu}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataDoreczeniaProtokolu: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data akceptacji sprawozdania</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataAkceptacjiSprawozdania}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataAkceptacjiSprawozdania: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data doręczenia pisma</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataDoreczeniaPisma}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataDoreczeniaPisma: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data pisma zastrzeżenia</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataPismaZastrzezenia}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataPismaZastrzezenia: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data wpływu pisma</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataWplywuPisma}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataWplywuPisma: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data pisma z odpowiedzią</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataPismaZOdpowiedzia}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataPismaZOdpowiedzia: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data akceptacji noty</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataAkceptacjiNoty}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataAkceptacjiNoty: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>

                  <label className="text-sm text-slate-700">
                    <span className="mb-1 block">Data zaleceń</span>
                    <input
                      type="date"
                      value={addInspectionForm.dataZalecen}
                      onChange={(event) =>
                        setAddInspectionForm((prev) => ({ ...prev, dataZalecen: event.target.value }))
                      }
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 outline-none transition-colors focus:border-blue-400"
                    />
                  </label>
                </div>
                </section>

                {addInspectionError ? (
                  <p className="text-sm font-medium text-rose-600">{addInspectionError}</p>
                ) : null}
              </div>

              <div className="mt-3 flex flex-wrap justify-end gap-2 border-t border-slate-200 bg-white pt-3">
                <button
                  type="button"
                  onClick={closeInspectionFormModal}
                  className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-100"
                >
                  Anuluj
                </button>

                <button
                  type="submit"
                  className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 text-sm font-semibold text-slate-100 transition-colors hover:bg-[#375f99]"
                >
                  {editingInspectionId ? "Zapisz zmiany" : "Dodaj rekord"}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </section>
  );
}

import type {
  InspectionColumn,
  InspectionColumnKey,
  InspectionRow,
  InspectionViewOption,
} from "@/features/inspections/types";

export const INSPECTION_ROWS: InspectionRow[] = [];

export const INSPECTION_COLUMNS: InspectionColumn[] = [
  { key: "lp", label: "Lp." },
  { key: "nazwaPodmiotu", label: "Nazwa podmiotu" },
  { key: "typInspekcji", label: "Typ inspekcji" },
  { key: "zakresInspekcji", label: "Zakres inspekcji" },
  { key: "poczatekInspekcji", label: "Początek" },
  { key: "koniecInspekcji", label: "Koniec" },
  { key: "osobaKierujaca", label: "Osoba kierująca" },
  { key: "skladZespolu", label: "Skład zespołu" },
  { key: "rynek", label: "Rynek" },
  { key: "rodzajPodmiotu", label: "Rodzaj podmiotu" },
  { key: "dataProtokolu", label: "Data protokołu / sprawozdania" },
  { key: "dataDoreczeniaProtokolu", label: "Data doręczenia protokołu" },
  { key: "dataAkceptacjiSprawozdania", label: "Data akceptacji sprawozdania" },
  { key: "dataDoreczeniaPisma", label: "Data doręczenia pisma" },
  { key: "dataPismaZastrzezenia", label: "Data pisma zastrzeżenia" },
  { key: "dataWplywuPisma", label: "Data wpływu pisma" },
  { key: "dataPismaZOdpowiedzia", label: "Data pisma z odpowiedzią" },
  { key: "dataAkceptacjiNoty", label: "Data akceptacji noty" },
  { key: "dataZalecen", label: "Data zaleceń" },
  { key: "status", label: "Status" },
  { key: "komentarz", label: "Komentarz" },
];

export const ALL_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] = INSPECTION_COLUMNS.map(
  (column) => column.key,
);

export const PODSTAWOWE_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] = [
  "lp",
  "nazwaPodmiotu",
  "typInspekcji",
  "zakresInspekcji",
  "osobaKierujaca",
  "skladZespolu",
  "rynek",
  "rodzajPodmiotu",
  "status",
];

export const TERMINY_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] = [
  "lp",
  "nazwaPodmiotu",
  "poczatekInspekcji",
  "koniecInspekcji",
  "dataProtokolu",
  "dataDoreczeniaProtokolu",
  "dataAkceptacjiSprawozdania",
  "dataDoreczeniaPisma",
  "dataPismaZastrzezenia",
  "dataWplywuPisma",
  "dataPismaZOdpowiedzia",
  "dataAkceptacjiNoty",
  "dataZalecen",
  "status",
];

export const INSPECTION_VIEW_OPTIONS: InspectionViewOption[] = [
  {
    id: "calosc",
    label: "Całość",
    description: "Wszystkie kolumny rejestru Inspekcje.",
  },
  {
    id: "podstawowe",
    label: "Podstawowe",
    description: "Najważniejsze informacje operacyjne o inspekcji.",
  },
  {
    id: "terminy",
    label: "Terminy i pisma",
    description: "Daty protokołów, pism, odpowiedzi i zaleceń.",
  },
];

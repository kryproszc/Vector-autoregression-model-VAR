export function PlaceholderPanel() {
  return <section className="min-h-45 rounded-2xl border border-slate-700/70 bg-[#101f39] p-6" />;
}

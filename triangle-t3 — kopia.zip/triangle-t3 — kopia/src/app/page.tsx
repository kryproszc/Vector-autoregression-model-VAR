import { HomeTabs } from "@/app/_components/HomeTabs";

export default function Page() {
  return <HomeTabs />;
}

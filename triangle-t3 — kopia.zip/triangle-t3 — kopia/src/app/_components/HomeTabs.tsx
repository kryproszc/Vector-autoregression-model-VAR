'use client';

import { useState } from "react";
import { FolderOpen, Menu, Wrench } from "lucide-react";

import { InspectionsPanel } from "@/features/inspections/components/InspectionsPanel";
import { PlaceholderPanel } from "@/shared/components/PlaceholderPanel";

type PanelMode = "registry" | "management";

type MenuItem = {
  id: string;
  label: string;
};

type MenuSection = {
  id: string;
  label: string;
  icon: "registers" | "tools";
  items: MenuItem[];
};

const REGISTRY_MENU_SECTIONS: MenuSection[] = [
  {
    id: "registers",
    label: "Rejestry",
    icon: "registers",
    items: [
      { id: "inspections", label: "Inspekcje" },
      { id: "recommendations", label: "Zalecenia" },
      { id: "binding_decisions", label: "Decyzje zobowiązujące" },
      { id: "sanction_requests", label: "Wnioski sankcyjne" },
    ],
  },
  {
    id: "tools",
    label: "Narzędzia",
    icon: "tools",
    items: [
      { id: "reports", label: "Raporty" },
      { id: "dictionaries", label: "Słowniki" },
      { id: "export", label: "Eksport" },
      { id: "logs", label: "Logi" },
    ],
  },
];

const MANAGEMENT_MENU_SECTIONS: MenuSection[] = [
  {
    id: "management",
    label: "Panel Zarządzania",
    icon: "tools",
    items: [
      { id: "add_user", label: "Dodaj użytkownika" },
      { id: "grant_permissions", label: "Nadaj uprawnienia" },
      { id: "edit_dictionaries", label: "Edytuj słowniki" },
    ],
  },
];

const PANEL_MODE_CONFIG: Record<
  PanelMode,
  {
    title: string;
    subtitle: string;
    sections: MenuSection[];
  }
> = {
  registry: {
    title: "Rejestr",
    subtitle: "Nawigacja modułów systemu",
    sections: REGISTRY_MENU_SECTIONS,
  },
  management: {
    title: "Panel Zarządzania",
    subtitle: "Wersja robocza dla kierownika i dyrektora",
    sections: MANAGEMENT_MENU_SECTIONS,
  },
};

function getDefaultMenuItemId(mode: PanelMode) {
  return PANEL_MODE_CONFIG[mode].sections[0]?.items[0]?.id ?? "";
}

function getSectionIcon(icon: MenuSection["icon"]) {
  if (icon === "tools") {
    return Wrench;
  }

  return FolderOpen;
}

export function HomeTabs() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [panelMode, setPanelMode] = useState<PanelMode>("registry");
  const [selectedItemId, setSelectedItemId] = useState<string>(getDefaultMenuItemId("registry"));

  const panelMeta = PANEL_MODE_CONFIG[panelMode];
  const menuSections = panelMeta.sections;

  const switchPanelMode = (mode: PanelMode) => {
    setPanelMode(mode);
    setSelectedItemId(getDefaultMenuItemId(mode));
  };

  const handleMenuItemSelect = (itemId: string) => {
    setSelectedItemId(itemId);
    setIsSidebarOpen(false);
  };

  return (
    <div className="relative flex min-h-screen w-full overflow-x-hidden bg-[#09152b] text-slate-100">
      {isSidebarOpen ? (
        <button
          type="button"
          aria-label="Zamknij menu"
          className="fixed inset-0 z-20 bg-slate-950/50 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      ) : null}

      <aside
        className={`fixed inset-y-0 left-0 z-30 flex h-screen w-80 flex-col border-r border-[#2f4368] bg-linear-to-b from-[#1d3053] via-[#192b49] to-[#14233e] p-5 shadow-[12px_0_28px_rgba(2,8,23,0.38)] transition-transform duration-300 lg:sticky lg:top-0 lg:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="mb-4 rounded-2xl border border-[#3f5f8f] bg-[#22385c]/85 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
          <p className="text-[11px] uppercase tracking-[0.14em] text-slate-300/80">Panel główny</p>
          <h1 className="mt-1 text-[1.75rem] font-bold leading-none">{panelMeta.title}</h1>
          <p className="mt-1 text-sm text-slate-200/80">{panelMeta.subtitle}</p>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-2 rounded-xl border border-[#37537d] bg-[#1c3153]/80 p-1.5">
          <button
            type="button"
            onClick={() => switchPanelMode("registry")}
            className={`rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${
              panelMode === "registry" ? "bg-[#345689] text-white" : "text-slate-200 hover:bg-[#274470]"
            }`}
          >
            Rejestr
          </button>

          <button
            type="button"
            onClick={() => switchPanelMode("management")}
            className={`rounded-lg px-3 py-2 text-sm font-semibold transition-colors ${
              panelMode === "management" ? "bg-[#345689] text-white" : "text-slate-200 hover:bg-[#274470]"
            }`}
          >
            Zarządzanie
          </button>
        </div>

        <nav className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
          {menuSections.map((section) => {
            const SectionIcon = getSectionIcon(section.icon);

            return (
              <section
                key={section.id}
                className="rounded-2xl border border-[#35517b]/75 bg-[#1a2d4c]/72 p-3.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.03)]"
              >
                <div className="mb-2 flex w-full items-center rounded-md px-1 py-1 text-left text-[1rem] font-semibold text-slate-100">
                  <span className="flex items-center gap-2">
                    <SectionIcon size={16} className="text-slate-300" />
                    {section.label}
                  </span>
                </div>

                <div className="space-y-1.5">
                  {section.items.map((item) => {
                    const isActive = item.id === selectedItemId;

                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleMenuItemSelect(item.id)}
                        className={`group relative flex w-full items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[1rem] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
                          isActive
                            ? "border-[#84b0f2] bg-[#345689] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
                            : "border-transparent text-slate-100/90 hover:border-[#43628f] hover:bg-[#22375b]"
                        }`}
                      >
                        {isActive ? <span className="absolute inset-y-1.5 left-0 w-1 rounded-r bg-sky-300" /> : null}
                        <span className={`h-1.5 w-1.5 rounded-full ${isActive ? "bg-sky-300" : "bg-slate-500"}`} />
                        {item.label}
                      </button>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </nav>
      </aside>

      <main className="min-w-0 flex-1 overflow-x-hidden p-4 sm:p-6 lg:p-8">
        <div className="mb-4 flex items-center lg:hidden">
          <button
            type="button"
            onClick={() => setIsSidebarOpen(true)}
            className="inline-flex items-center gap-2 rounded-md border border-slate-700 bg-[#1b2c4a] px-3 py-2 text-sm"
          >
            <Menu size={16} />
            Nawigacja
          </button>
        </div>

        {panelMode === "registry" && selectedItemId === "inspections" ? <InspectionsPanel /> : <PlaceholderPanel />}
      </main>
    </div>
  );
}

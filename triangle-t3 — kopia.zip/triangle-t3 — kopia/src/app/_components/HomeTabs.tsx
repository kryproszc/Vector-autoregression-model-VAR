'use client';

import { useMemo, useState } from "react";
import { Database, Layers, LineChart, Menu } from "lucide-react";
import { APP_CATEGORIES } from "./navigation/config";
import { HEADER_TABS } from "./navigation/types";
import { FeaturePanel } from "@/features/panelRegistry";
import type { Category, HeaderTabId } from "./navigation/types";

type InsurerOption = 16 | 21;

export function HomeTabs() {
  const [selectedCategoryId, setSelectedCategoryId] = useState(APP_CATEGORIES[0]?.id ?? "");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>(
    buildInitialOpenSections(APP_CATEGORIES),
  );
  const [selectedSubcategoryByCategory, setSelectedSubcategoryByCategory] = useState<
    Record<string, string>
  >(buildInitialSubcategories(APP_CATEGORIES));
  const [selectedHeaderTabByCategory, setSelectedHeaderTabByCategory] = useState<
    Record<string, HeaderTabId>
  >(buildInitialHeaderTabs(APP_CATEGORIES));
  const [selectedInsurer, setSelectedInsurer] = useState<InsurerOption>(16);

  const activeCategory = useMemo(
    () => APP_CATEGORIES.find((category) => category.id === selectedCategoryId) ?? APP_CATEGORIES[0],
    [selectedCategoryId],
  );

  if (!activeCategory) {
    return null;
  }

  const activeHeaderTab = selectedHeaderTabByCategory[activeCategory.id] ?? "explanations";
  const activeSubcategoryId = selectedSubcategoryByCategory[activeCategory.id];
  const activeSubcategoryLabel =
    activeCategory.subcategories?.find((subcategory) => subcategory.id === activeSubcategoryId)?.label ??
    null;

  return (
    <div className="relative flex min-h-screen bg-[#0f172a]">
      {isSidebarOpen ? (
        <button
          type="button"
          aria-label="Zamknij menu"
          className="fixed inset-0 z-20 bg-slate-950/45 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      ) : null}

      <aside
        className={`fixed inset-y-0 left-0 z-30 flex h-screen w-74 flex-col border-r border-slate-700/80 bg-linear-to-b from-[#1b2a45] via-[#1a2840] to-[#172338] px-4 py-6 text-gray-100 shadow-[6px_0_20px_rgba(0,0,0,0.25)] transition-transform duration-300 lg:sticky lg:top-0 lg:w-78 lg:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="mb-8 flex flex-col items-center justify-center">
          <h1 className="text-2xl font-extrabold tracking-wider text-blue-400">UPZ</h1>
          <p className="mt-1 text-center text-xs leading-tight text-gray-400">
            Uniwersytet Pomocy
            <br />
            Zagubionym
          </p>
        </div>

        <nav className="min-h-0 flex-1 overflow-y-auto pr-1 pb-8">
          <div className="flex flex-col gap-2">
          {APP_CATEGORIES.map((category) => {
            const Icon = getCategoryIcon(category.icon);
            const hasSubcategories = Boolean(category.subcategories?.length);
            const isSectionOpen = openSections[category.id] ?? false;

            return (
              <div key={category.id}>
                <SidebarItem
                  icon={<Icon size={20} />}
                  label={category.label}
                  isActive={selectedCategoryId === category.id}
                  onClick={() => {
                    setSelectedCategoryId(category.id);

                    if (hasSubcategories) {
                      setOpenSections((prev) => ({
                        ...prev,
                        [category.id]: !prev[category.id],
                      }));
                    }

                    if (!hasSubcategories) {
                      setIsSidebarOpen(false);
                    }
                  }}
                />

                {hasSubcategories && isSectionOpen ? (
                  <div className="mt-1 flex flex-col gap-1.5 pl-2.5">
                    {category.subcategories?.map((subcategory) => (
                      <SidebarSubcategoryItem
                        key={`${category.id}-${subcategory.id}`}
                        label={subcategory.label}
                        isActive={
                          selectedCategoryId === category.id &&
                          selectedSubcategoryByCategory[category.id] === subcategory.id
                        }
                        onClick={() => {
                          setSelectedCategoryId(category.id);
                          setSelectedSubcategoryByCategory((prev) => ({
                            ...prev,
                            [category.id]: subcategory.id,
                          }));
                          setIsSidebarOpen(false);
                        }}
                      />
                    ))}
                  </div>
                ) : null}
              </div>
            );
          })}
          </div>
        </nav>
      </aside>

      <main className="flex-1 overflow-auto bg-[#0f172a] p-4 sm:p-6 lg:p-8">
        <div className="mb-4 flex items-center lg:hidden">
          <button
            type="button"
            onClick={() => setIsSidebarOpen(true)}
            className="inline-flex items-center gap-2 rounded-md border border-slate-700 bg-[#1b2638] px-3 py-2 text-sm font-medium text-slate-100"
          >
            <Menu size={16} />
            Menu
          </button>
        </div>

        {activeCategory.hasTabs ? (
          <TopTabs
            selectedHeaderTab={activeHeaderTab}
            onSelectTab={(tab) => {
              setSelectedHeaderTabByCategory((prev) => ({
                ...prev,
                [activeCategory.id]: tab,
              }));
            }}
          />
        ) : null}

        {!(activeCategory.id === "scr_structure" && activeSubcategoryId === "main_scr") ? (
          <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] px-4 py-3">
            <p className="text-xs uppercase tracking-[0.08em] text-slate-400">Aktualny widok</p>
            <h2 className="mt-1 text-lg font-semibold text-slate-100">
              {activeSubcategoryLabel ? `${activeCategory.label} - ${activeSubcategoryLabel}` : activeCategory.label}
            </h2>
          </section>
        ) : null}

        {activeCategory.id === "data_selection" ? (
          <section className="mt-5 rounded-xl border border-slate-800/80 bg-[#111d30] p-4">
            <p className="text-xs uppercase tracking-[0.08em] text-slate-400">Wybór danych</p>
            <h3 className="mt-1 text-base font-semibold text-slate-100">Wybór ubezpieczyciela</h3>

            <div className="mt-4 inline-flex rounded-lg border border-slate-700/70 bg-[#1b2638] p-1">
              {[16, 21].map((insurer) => (
                <button
                  key={insurer}
                  type="button"
                  onClick={() => setSelectedInsurer(insurer as InsurerOption)}
                  className={`rounded-md px-4 py-2 text-sm font-semibold transition-all ${
                    selectedInsurer === insurer
                      ? "bg-[#2d4364] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
                      : "text-slate-300 hover:bg-[#263853] hover:text-slate-100"
                  }`}
                >
                  Ubezpieczyciel {insurer}
                </button>
              ))}
            </div>
          </section>
        ) : null}

        <FeaturePanel
          categoryId={activeCategory.id}
          subcategoryId={activeSubcategoryId}
          activeTab={activeHeaderTab}
          insurer={selectedInsurer}
        />
      </main>
    </div>
  );
}

function TopTabs({
  selectedHeaderTab,
  onSelectTab,
}: {
  selectedHeaderTab: HeaderTabId;
  onSelectTab: (tab: HeaderTabId) => void;
}) {
  return (
    <div className="w-full">
      <div className="grid w-full grid-cols-4 gap-2 rounded-xl border border-slate-700/60 bg-[#1b2638] p-2 shadow-[0_8px_24px_rgba(0,0,0,0.2)]">
        {HEADER_TABS.map((tab) => (
          <TopTabButton
            key={tab.id}
            label={tab.label}
            isActive={selectedHeaderTab === tab.id}
            onClick={() => onSelectTab(tab.id)}
          />
        ))}
      </div>
    </div>
  );
}

function TopTabButton({
  label,
  isActive,
  onClick,
}: {
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-lg border px-4 py-2.5 text-sm font-semibold tracking-wide transition-all duration-200 ${
        isActive
          ? "border-blue-400/40 bg-linear-to-b from-[#314768] to-[#273852] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_8px_14px_rgba(0,0,0,0.25)]"
          : "border-transparent bg-[#202f46] text-slate-200 hover:border-slate-500/40 hover:bg-[#2a3b57] hover:text-white"
      }`}
    >
      {label}
    </button>
  );
}

function SidebarItem({
  icon,
  label,
  isActive,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition-all duration-200 ${
        isActive
          ? "bg-[#2b3f61] font-semibold text-sky-300 shadow-[inset_0_1px_0_rgba(255,255,255,0.07)]"
          : "text-slate-100 hover:bg-[#243754] hover:text-sky-200"
      }`}
    >
      <span className="shrink-0 text-slate-200">{icon}</span>
      <span className="text-[1.01rem] leading-snug tracking-[0.01em]">{label}</span>
    </button>
  );
}

function SidebarSubcategoryItem({
  label,
  isActive,
  onClick,
}: {
  label: string;
  isActive: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full rounded-lg px-2.5 py-1.5 text-left text-[0.97rem] leading-snug transition-colors ${
        isActive ? "bg-[#203150] text-sky-300" : "text-slate-300 hover:bg-[#1d2b44] hover:text-slate-100"
      }`}
    >
      <span className="flex items-start gap-2">
        <span
          className={`mt-1 h-1.5 w-1.5 rounded-full ${
            isActive ? "bg-sky-300" : "bg-slate-500"
          }`}
        />
        <span className="pr-1">{label}</span>
      </span>
    </button>
  );
}

function getCategoryIcon(iconName: Category["icon"]) {
  switch (iconName) {
    case "database":
      return Database;
    case "layers":
      return Layers;
    default:
      return LineChart;
  }
}

function buildInitialOpenSections(categories: Category[]) {
  return categories.reduce<Record<string, boolean>>((acc, category) => {
    acc[category.id] = Boolean(category.subcategories?.length);
    return acc;
  }, {});
}

function buildInitialSubcategories(categories: Category[]) {
  return categories.reduce<Record<string, string>>((acc, category) => {
    const firstSubcategory = category.subcategories?.[0];
    if (firstSubcategory) {
      acc[category.id] = firstSubcategory.id;
    }
    return acc;
  }, {});
}

function buildInitialHeaderTabs(categories: Category[]) {
  return categories.reduce<Record<string, HeaderTabId>>((acc, category) => {
    if (category.hasTabs) {
      acc[category.id] = "explanations";
    }
    return acc;
  }, {});
}

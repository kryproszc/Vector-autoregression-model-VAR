import type { Category } from "./types";

export const APP_CATEGORIES: Category[] = [
  {
    id: "data_selection",
    label: "Wybór danych",
    icon: "database",
    hasTabs: false,
  },
  {
    id: "risk_exposure",
    label: "Ekspozycja na ryzyko",
    icon: "lineChart",
    hasTabs: true,
    subcategories: [
      { id: "total_requirement", label: "Całkowity wymóg" },
      { id: "non_life_insurance_risk", label: "Ryzyko ubezpieczeniowe majątkowe" },
      { id: "life_insurance_risk", label: "Ryzyko ubezpieczeniowe życiowe" },
      { id: "market_risk", label: "Ryzyko rynkowe" },
      { id: "credit_risk", label: "Ryzyko kredytowe" },
      { id: "operational_risk", label: "Ryzyko operacyjne" },
    ],
  },
  {
    id: "scr_structure",
    label: "Struktura SCR",
    icon: "layers",
    hasTabs: true,
    subcategories: [
      { id: "main_scr", label: "Główny SCR" },
      { id: "non_life_insurance_risk", label: "Ryzyko ubezpieczeniowe majątkowe" },
      { id: "life_insurance_risk", label: "Ryzyko ubezpieczeniowe życiowe" },
      { id: "market_risk", label: "Ryzyko rynkowe" },
      { id: "credit_risk", label: "Ryzyko kredytowe" },
      { id: "operational_risk", label: "Ryzyko operacyjne" },
    ],
  },

  {
    id: "scr_dywersyfikacja",
    label: "Dywersyfikacja SCR",
    icon: "layers",
    hasTabs: true,
    subcategories: [
      { id: "main_scr", label: "Całkowity SCR" },
      { id: "non_life_insurance_risk", label: "Ubezpieczeniowe nonlife basic" },
      { id: "market_risk", label: "Ryzyko rynkowe" },
      { id: "credit_risk", label: "Ryzyko kredytowe" },
      { id: "operational_risk", label: "Ryzyko operacyjne" },
    ],
  },


];

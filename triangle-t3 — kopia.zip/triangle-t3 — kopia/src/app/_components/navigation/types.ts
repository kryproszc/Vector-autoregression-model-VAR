export type HeaderTabId = "explanations" | "indicators" | "yearly_changes" | "quarterly_changes";

export type IconName = "database" | "lineChart" | "layers";

export type Subcategory = {
  id: string;
  label: string;
};

export type Category = {
  id: string;
  label: string;
  icon: IconName;
  hasTabs: boolean;
  subcategories?: Subcategory[];
};

export const HEADER_TABS: { id: HeaderTabId; label: string }[] = [
  { id: "explanations", label: "Objaśnienia" },
  { id: "indicators", label: "Wskaźniki" },
  { id: "yearly_changes", label: "Zmiany roczne" },
  { id: "quarterly_changes", label: "Zmiany kwartalne" },
];

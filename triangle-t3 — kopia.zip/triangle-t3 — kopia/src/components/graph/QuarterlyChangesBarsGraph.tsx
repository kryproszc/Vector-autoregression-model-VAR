"use client";

import {
  Bar,
  CartesianGrid,
  ComposedChart,
  LabelList,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type QuarterlyChartPoint = {
  date: string;
  barValue: number | null;
  lineValue: number | null;
  diffValue: number | null;
};

type QuarterlyChangesBarsGraphProps = {
  metricLabel: string;
  data: QuarterlyChartPoint[];
};

export function QuarterlyChangesBarsGraph({ metricLabel, data }: QuarterlyChangesBarsGraphProps) {
  if (!data.length) {
    return (
      <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-sm text-slate-600">Brak danych do narysowania wykresu kwartalnego.</p>
      </section>
    );
  }

  const domain = getBarDomain(data);
  const chartWidth = Math.max(860, data.length * 132);
  const xByIndex = new Map<number, number>();

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h4 className="mb-2 text-sm font-semibold text-slate-900">Zmiany kwartalne: {metricLabel}</h4>
      <p className="mb-3 text-xs text-slate-500">
        Słupki pokazują poziomy ze wskaźników kwartalnych, a etykieta w niebieskiej ramce pokazuje zmianę k/k.
      </p>

      <div className="overflow-x-auto rounded-lg border border-slate-200 bg-slate-50 p-3">
        <div style={{ width: `${chartWidth}px` }}>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={data} margin={{ top: 26, right: 14, left: 18, bottom: 10 }}>
                <CartesianGrid stroke="#cbd5e1" strokeDasharray="4 4" vertical={false} />
                <XAxis
                  dataKey="date"
                  tick={{ fill: "#64748b", fontSize: 12 }}
                  axisLine={{ stroke: "#cbd5e1" }}
                  tickLine={{ stroke: "#cbd5e1" }}
                />
                <YAxis
                  tick={{ fill: "#64748b", fontSize: 12 }}
                  axisLine={{ stroke: "#cbd5e1" }}
                  tickLine={{ stroke: "#cbd5e1" }}
                  tickFormatter={formatAxisPercent}
                  width={64}
                  domain={domain}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#ffffff",
                    borderColor: "#cbd5e1",
                    borderRadius: "8px",
                  }}
                  formatter={(rawValue: number | string | Array<number | string>, seriesName) => {
                    if (Array.isArray(rawValue)) {
                      return rawValue;
                    }

                    if (typeof rawValue === "number") {
                      return [`${rawValue.toFixed(2).replace(".", ",")}%`, seriesName];
                    }

                    return [rawValue, seriesName];
                  }}
                />

                <Bar dataKey="barValue" name="Wartość (K)" fill="#64748b" radius={[4, 4, 0, 0]} maxBarSize={44}>
                  <LabelList
                    dataKey="barValue"
                    position="top"
                    formatter={(rawValue: number | null) =>
                      rawValue === null ? "" : `${rawValue.toFixed(2).replace(".", ",")}%`
                    }
                    style={{ fill: "#334155", fontSize: 12, fontWeight: 700 }}
                  />
                </Bar>

                <Line
                  type="linear"
                  dataKey="lineValue"
                  name="Poziom wskaźnika"
                  stroke="#2563eb"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "#2563eb" }}
                  connectNulls
                >
                  <LabelList dataKey="lineValue" content={(props) => capturePointX(props, xByIndex)} />
                  <LabelList dataKey="diffValue" content={(props) => renderDiffLabel(props, xByIndex)} />
                </Line>
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </section>
  );
}

function renderDiffLabel(
  props: {
    x?: number | string;
    y?: number | string;
    value?: number | string | null;
    index?: number;
  },
  xByIndex: Map<number, number>,
) {
  const numericValue = toNumberOrNull(props.value);
  const index = props.index;

  if (index !== undefined) {
    xByIndex.set(index, toNumber(props.x));
  }

  if (numericValue === null || index === undefined || index === 0) {
    return null;
  }

  const currentX = toNumber(props.x);
  const prevX = xByIndex.get(index - 1);
  const centerX = prevX !== undefined ? (prevX + currentX) / 2 : currentX;
  const centerY = toNumber(props.y) - 10;
  const label = `${numericValue.toFixed(2).replace(".", ",")}%`;
  const badgeWidth = Math.max(label.length * 7.2 + 14, 50);
  const badgeHeight = 22;

  return (
    <g>
      <rect
        x={centerX - badgeWidth / 2}
        y={centerY - badgeHeight / 2}
        width={badgeWidth}
        height={badgeHeight}
        rx={4}
        fill="#2563eb"
        opacity={0.95}
      />
      <text
        x={centerX}
        y={centerY + 4}
        fill="#ffffff"
        fontSize={12}
        fontWeight={700}
        textAnchor="middle"
      >
        {label}
      </text>
    </g>
  );
}

function capturePointX(
  props: {
    x?: number | string;
    index?: number;
  },
  xByIndex: Map<number, number>,
) {
  if (props.index !== undefined) {
    xByIndex.set(props.index, toNumber(props.x));
  }

  return null;
}

function getBarDomain(data: QuarterlyChartPoint[]): [number, number] {
  const values = data
    .filter((point) => point.barValue !== null)
    .map((point) => point.barValue as number);

  if (!values.length) {
    return [0, 1];
  }

  const min = Math.min(...values, 0);
  const max = Math.max(...values, 0);
  const padding = Math.max((max - min) * 0.15, 1);

  return [min - padding, max + padding];
}

function toNumber(value: number | string | undefined) {
  if (typeof value === "number") {
    return value;
  }

  if (typeof value === "string") {
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  return 0;
}

function toNumberOrNull(value: number | string | null | undefined) {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function formatAxisPercent(value: number) {
  return `${value.toFixed(2).replace(".", ",")}%`;
}

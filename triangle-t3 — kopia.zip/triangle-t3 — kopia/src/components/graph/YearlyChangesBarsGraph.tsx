"use client";

import {
  Bar,
  CartesianGrid,
  ComposedChart,
  LabelList,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type YearlyGraphPoint = {
  currentDate: string;
  previousDate: string;
  currentValue: number | null;
  previousValue: number | null;
  diffValue: number | null;
  periodType: string;
};

type YearlyChangesBarsGraphProps = {
  metricLabel: string;
  data: YearlyGraphPoint[];
};

export function YearlyChangesBarsGraph({ metricLabel, data }: YearlyChangesBarsGraphProps) {
  if (!data.length) {
    return (
      <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-sm text-slate-600">Brak danych do narysowania wykresu zmian rocznych.</p>
      </section>
    );
  }

  const quarterGroups = groupPairsByQuarter(data);
  const yearlyRGroup = data
    .filter((pair) => pair.periodType === "R")
    .sort((a, b) => a.currentDate.localeCompare(b.currentDate));

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <h4 className="mb-3 text-sm font-semibold text-slate-900">Zmiany roczne: {metricLabel}</h4>
      <p className="mb-3 text-xs text-slate-500">
        Słupki pokazują poziomy ze wskaźników, a etykieta na linii między słupkami pokazuje różnicę r/r.
      </p>

      <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
        <div className="space-y-4">
          {quarterGroups.map((group) => (
            <section key={group.quarterKey} className="rounded-md border border-slate-200 bg-white/70 p-2.5">
              <div className="mb-2 flex items-center justify-between">
                <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-700">
                  Kwartał {group.quarterKey}
                </h5>
                <span className="text-[11px] text-slate-500">Porównania r/r: {group.pairs.length}</span>
              </div>

              <QuarterChart pairs={group.pairs} />
            </section>
          ))}

          {yearlyRGroup.length ? (
            <section className="rounded-md border border-slate-200 bg-white/70 p-2.5">
              <div className="mb-2 flex items-center justify-between">
                <h5 className="text-xs font-semibold uppercase tracking-wider text-slate-700">
                  Rok do roku (ujęcie roczne)
                </h5>
                <span className="text-[11px] text-slate-500">Porównania r/r: {yearlyRGroup.length}</span>
              </div>

              <QuarterChart pairs={yearlyRGroup} />
            </section>
          ) : null}
        </div>
      </div>
    </section>
  );
}

type QuarterChartPoint = {
  date: string;
  barValue: number | null;
  lineValue: number | null;
  diffValue: number | null;
};

function QuarterChart({ pairs }: { pairs: YearlyGraphPoint[] }) {
  const chartData = buildQuarterChartData(pairs);
  const domain = getBarDomain(chartData);
  const axisPadding = getXAxisPadding(chartData.length);
  const xByIndex = new Map<number, number>();

  if (!chartData.length) {
    return null;
  }

  return (
    <div className="rounded-lg border border-slate-200 bg-white p-3">
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 24, right: 14, left: 18, bottom: 10 }}>
            <CartesianGrid stroke="#cbd5e1" strokeDasharray="4 4" vertical={false} />
            <XAxis
              dataKey="date"
              tick={{ fill: "#64748b", fontSize: 12 }}
              axisLine={{ stroke: "#cbd5e1" }}
              tickLine={{ stroke: "#cbd5e1" }}
              padding={axisPadding}
            />
            <YAxis
              tick={{ fill: "#64748b", fontSize: 12 }}
              axisLine={{ stroke: "#cbd5e1" }}
              tickLine={{ stroke: "#cbd5e1" }}
              tickFormatter={formatAxisPercent}
              width={64}
              domain={domain}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#ffffff",
                borderColor: "#cbd5e1",
                borderRadius: "8px",
              }}
              formatter={(rawValue: number | string | Array<number | string>, seriesName) => {
                if (Array.isArray(rawValue)) {
                  return rawValue;
                }

                if (typeof rawValue === "number") {
                  if (seriesName === "Różnica r/r") {
                    return [`${rawValue.toFixed(2).replace(".", ",")}%`, seriesName];
                  }
                  return [`${rawValue.toFixed(2).replace(".", ",")}%`, seriesName];
                }

                return [rawValue, seriesName];
              }}
            />

            <Bar dataKey="barValue" name="Wartość" fill="#64748b" radius={[4, 4, 0, 0]} maxBarSize={42}>
              <LabelList
                dataKey="barValue"
                position="top"
                formatter={(rawValue: number | null) =>
                  rawValue === null ? "" : `${rawValue.toFixed(2).replace(".", ",")}%`
                }
                style={{ fill: "#334155", fontSize: 12, fontWeight: 700 }}
              />
            </Bar>

            <Line
              type="linear"
              dataKey="lineValue"
              name="Poziom wskaźnika"
              stroke="#2563eb"
              strokeWidth={2.5}
              dot={{ r: 4, fill: "#2563eb" }}
              connectNulls
            >
              <LabelList dataKey="lineValue" content={(props) => capturePointX(props, xByIndex)} />
              <LabelList
                dataKey="diffValue"
                content={(props) => renderDiffLabel(props, xByIndex)}
              />
            </Line>
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function groupPairsByQuarter(data: YearlyGraphPoint[]) {
  const groups = new Map<string, YearlyGraphPoint[]>();

  data.forEach((pair) => {
    const quarterKey = getQuarterFromDate(pair.currentDate);
    if (!groups.has(quarterKey)) {
      groups.set(quarterKey, []);
    }

    groups.get(quarterKey)?.push(pair);
  });

  return ["Q1", "Q2", "Q3", "Q4"]
    .map((quarterKey) => ({
      quarterKey,
      pairs: (groups.get(quarterKey) ?? []).sort((a, b) => a.currentDate.localeCompare(b.currentDate)),
    }))
    .filter((group) => group.pairs.length > 0);
}

function buildQuarterChartData(pairs: YearlyGraphPoint[]): QuarterChartPoint[] {
  const points: QuarterChartPoint[] = [];
  const sortedPairs = [...pairs].sort((a, b) => a.currentDate.localeCompare(b.currentDate));

  const firstPair = sortedPairs[0];
  if (firstPair) {
    points.push({
      date: firstPair.previousDate,
      barValue: firstPair.previousValue,
      lineValue: firstPair.previousValue,
      diffValue: null,
    });
  }

  sortedPairs.forEach((pair) => {
    points.push({
      date: pair.currentDate,
      barValue: pair.currentValue,
      lineValue: pair.currentValue,
      diffValue: pair.diffValue,
    });
  });

  return points;
}

function renderDiffLabel(props: {
  x?: number | string;
  y?: number | string;
  value?: number | string | null;
  index?: number;
}, xByIndex: Map<number, number>) {
  const numericValue = toNumberOrNull(props.value);
  const index = props.index;

  if (index !== undefined) {
    xByIndex.set(index, toNumber(props.x));
  }

  if (numericValue === null || index === undefined || index === 0) {
    return null;
  }

  const label = `${numericValue.toFixed(2).replace(".", ",")}%`;
  const badgeWidth = Math.max(label.length * 7.2 + 14, 50);
  const badgeHeight = 22;
  const currentX = toNumber(props.x);
  const prevX = xByIndex.get(index - 1);
  const centerX = prevX !== undefined ? (prevX + currentX) / 2 : currentX;
  const centerY = toNumber(props.y) - 10;
  const x = centerX - badgeWidth / 2;
  const y = centerY - badgeHeight / 2;

  return (
    <g>
      <rect x={x} y={y} width={badgeWidth} height={badgeHeight} rx={4} fill="#2563eb" opacity={0.95} />
      <text
        x={centerX}
        y={centerY + 4}
        fill="#ffffff"
        fontSize={12}
        fontWeight={700}
        textAnchor="middle"
      >
        {label}
      </text>
    </g>
  );
}

function capturePointX(
  props: {
    x?: number | string;
    index?: number;
  },
  xByIndex: Map<number, number>,
) {
  if (props.index !== undefined) {
    xByIndex.set(props.index, toNumber(props.x));
  }

  return null;
}

function getBarDomain(data: QuarterChartPoint[]): [number, number] {
  const values = data
    .filter((point) => point.barValue !== null)
    .map((point) => point.barValue as number);

  if (!values.length) {
    return [0, 1];
  }

  const min = Math.min(...values, 0);
  const max = Math.max(...values, 0);
  const padding = Math.max((max - min) * 0.15, 1);

  return [min - padding, max + padding];
}

function toNumber(value: number | string | undefined) {
  if (typeof value === "number") {
    return value;
  }

  if (typeof value === "string") {
    const parsed = Number.parseFloat(value);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  return 0;
}

function toNumberOrNull(value: number | string | null | undefined) {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === "number") {
    return Number.isFinite(value) ? value : null;
  }

  const parsed = Number.parseFloat(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function getQuarterFromDate(date: string) {
  const match = /^\d{4}-(\d{2})-\d{2}$/.exec(date);
  if (!match) {
    return "Q?";
  }

  const month = Number(match[1]);
  if (month <= 3) return "Q1";
  if (month <= 6) return "Q2";
  if (month <= 9) return "Q3";
  return "Q4";
}

function getXAxisPadding(pointCount: number) {
  if (pointCount <= 2) {
    return { left: 360, right: 360 };
  }

  if (pointCount <= 4) {
    return { left: 220, right: 220 };
  }

  return { left: 80, right: 80 };
}

function formatAxisPercent(value: number) {
  return `${value.toFixed(2).replace(".", ",")}%`;
}

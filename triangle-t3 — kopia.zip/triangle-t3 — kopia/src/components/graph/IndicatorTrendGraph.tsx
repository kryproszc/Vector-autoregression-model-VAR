"use client";

import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type TrendPoint = {
  date: string;
  K: number | null;
  R: number | null;
  value: number | null;
};

type IndicatorTrendGraphProps = {
  metricLabel: string;
  data: TrendPoint[];
  showYearlyOnly?: boolean;
};

export function IndicatorTrendGraph({
  metricLabel,
  data,
  showYearlyOnly = false,
}: IndicatorTrendGraphProps) {
  if (!data.length) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-sm text-slate-600">Brak danych do narysowania wykresu dla tego wskaźnika.</p>
      </div>
    );
  }

  return (
    <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h4 className="text-sm font-semibold text-slate-900">Trend wskaźnika: {metricLabel}</h4>
        <div className="flex items-center gap-3 text-xs text-slate-600">
          {showYearlyOnly ? (
            <LegendDot color="#2563eb" label="Roczne (R)" />
          ) : (
            <>
              <LegendDot color="#059669" label="Kwartalne (K)" />
              <LegendDot color="#2563eb" label="Roczne (R)" />
            </>
          )}
        </div>
      </div>

      <div className="h-72 rounded-lg border border-slate-200 bg-slate-50 p-2">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 12, right: 12, bottom: 12, left: 4 }}>
            <CartesianGrid stroke="#cbd5e1" strokeDasharray="4 4" />
            <XAxis
              dataKey="date"
              tick={{ fill: "#334155", fontSize: 11 }}
              axisLine={{ stroke: "#94a3b8" }}
              tickLine={{ stroke: "#94a3b8" }}
            />
            <YAxis
              tickFormatter={formatAxisPercent}
              tick={{ fill: "#334155", fontSize: 11 }}
              axisLine={{ stroke: "#94a3b8" }}
              tickLine={{ stroke: "#94a3b8" }}
              width={56}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#ffffff",
                borderColor: "#cbd5e1",
                borderRadius: "10px",
                color: "#0f172a",
              }}
              labelStyle={{ color: "#0f172a", fontWeight: 600 }}
              formatter={(rawValue: number | string | Array<number | string>, seriesName) => {
                if (Array.isArray(rawValue)) {
                  return rawValue;
                }

                if (typeof rawValue === "number") {
                  return [`${rawValue.toFixed(2).replace(".", ",")}%`, seriesName];
                }

                return [rawValue, seriesName];
              }}
            />
            {!showYearlyOnly ? (
              <Line
                type="monotone"
                dataKey="K"
                name="Kwartalne (K)"
                stroke="#059669"
                strokeWidth={4}
                dot={{ r: 4.5, strokeWidth: 1.5, fill: "#059669" }}
                connectNulls={false}
              />
            ) : null}
            <Line
              type="monotone"
              dataKey="R"
              name="Roczne (R)"
              stroke={showYearlyOnly ? "#2563eb" : "transparent"}
              strokeWidth={showYearlyOnly ? 4 : 0}
              dot={{ r: 5, strokeWidth: 1.5, fill: "#2563eb" }}
              connectNulls={showYearlyOnly}
            />
            {!showYearlyOnly ? (
              <Line
                type="monotone"
                dataKey="value"
                name="Wartość"
                stroke="#f59e0b"
                strokeWidth={4}
                dot={{ r: 4.5, strokeWidth: 1.5, fill: "#f59e0b" }}
                connectNulls={false}
              />
            ) : null}
          </LineChart>
        </ResponsiveContainer>
      </div>
    </section>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="inline-block size-2.5 rounded-full" style={{ backgroundColor: color }} />
      <span>{label}</span>
    </span>
  );
}

function formatAxisPercent(value: number) {
  return `${value.toFixed(0)}%`;
}

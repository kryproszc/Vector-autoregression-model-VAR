"use client";

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";

type PieSlice = {
  name: string;
  value: number;
  share: number;
};

type ScrColumnPieGraphProps = {
  columnLabel: string;
  periodType: string;
  data: PieSlice[];
};

const PIE_COLORS = [
  "#1d4ed8",
  "#0f766e",
  "#f59e0b",
  "#7c3aed",
  "#dc2626",
  "#0891b2",
  "#65a30d",
  "#334155",
  "#be185d",
  "#4f46e5",
  "#15803d",
  "#d97706",
];

export function ScrColumnPieGraph({ columnLabel, periodType, data }: ScrColumnPieGraphProps) {
  if (!data.length) {
    return (
      <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-sm text-slate-600">Brak dodatnich wartosci do narysowania wykresu kolowego.</p>
      </section>
    );
  }

  const sortedData = [...data].sort((a, b) => b.share - a.share);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_20px_40px_rgba(15,23,42,0.12)]">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h4 className="text-sm font-semibold text-slate-900">
          Struktura wskaznikow: {columnLabel}
          {periodType ? ` (${periodType})` : ""}
        </h4>
        <span className="rounded-full border border-blue-200 bg-blue-50 px-2.5 py-1 text-[11px] font-semibold text-blue-700">
          Udzial procentowy
        </span>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,0.82fr)_510px]">
        <div className="h-165 rounded-xl border border-slate-200 bg-linear-to-b from-slate-50 to-white p-3">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sortedData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                innerRadius={123}
                outerRadius={228}
                paddingAngle={3}
                stroke="#ffffff"
                strokeWidth={2}
                labelLine={false}
                label={(props) => renderPercentLabel(props)}
              >
                {sortedData.map((entry, index) => (
                  <Cell key={`${entry.name}-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  borderColor: "#cbd5e1",
                  borderRadius: "10px",
                }}
                formatter={(rawValue: number | string | Array<number | string>, _name, item) => {
                  if (Array.isArray(rawValue)) {
                    return rawValue;
                  }

                  const value = typeof rawValue === "number" ? rawValue : Number.parseFloat(String(rawValue));
                  const share = (item?.payload as PieSlice | undefined)?.share;
                  const shareNumber = typeof share === "number" ? share : null;

                  if (Number.isFinite(value)) {
                    const valueText = `${value.toFixed(2).replace(".", ",")}%`;
                    const shareText = shareNumber !== null
                      ? `Udzial: ${shareNumber.toFixed(1).replace(".", ",")}%`
                      : "";
                    return [shareText ? `${valueText} (${shareText})` : valueText, "Wartosc"];
                  }

                  return [rawValue, "Wartosc"];
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-xl border border-slate-200 bg-slate-50 p-4.5">
          <h5 className="mb-2.5 text-base font-semibold uppercase tracking-wider text-slate-700">Legenda</h5>
          <ul className="space-y-2">
            {sortedData.map((entry, index) => (
              <li key={`${entry.name}-legend-${index}`} className="flex items-start gap-2.5 text-base">
                <span className="flex min-w-0 items-start gap-2 text-slate-700">
                  <span
                    className="mt-1 inline-block h-3.5 w-3.5 shrink-0 rounded-full"
                    style={{ backgroundColor: PIE_COLORS[index % PIE_COLORS.length] }}
                  />
                  <span className="wrap-break-word leading-relaxed">{entry.name}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

function renderPercentLabel(props: {
  cx?: number;
  cy?: number;
  midAngle?: number;
  outerRadius?: number;
  percent?: number;
}) {
  const cx = props.cx ?? 0;
  const cy = props.cy ?? 0;
  const midAngle = props.midAngle ?? 0;
  const outerRadius = props.outerRadius ?? 0;
  const percent = props.percent ?? 0;

  const radius = outerRadius + 22;
  const radian = Math.PI / 180;
  const x = cx + radius * Math.cos(-midAngle * radian);
  const y = cy + radius * Math.sin(-midAngle * radian);
  const textAnchor = x > cx ? "start" : "end";
  const label = `${(percent * 100).toFixed(1).replace(".", ",")}%`;

  return (
    <text
      x={x}
      y={y}
      fill="#0f172a"
      textAnchor={textAnchor}
      dominantBaseline="central"
      fontSize={17}
      fontWeight={800}
    >
      {label}
    </text>
  );
}

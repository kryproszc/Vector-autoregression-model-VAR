"use client";

import { useMemo, useState } from "react";
import { IndicatorTrendGraph } from "../graph/IndicatorTrendGraph";

type IndicatorTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

type PivotDateColumn = {
  label: string;
  key: string;
  periodType: string;
};

type PivotRow = {
  metric: string;
  label: string;
  values: Record<string, unknown>;
};

type TrendPoint = {
  date: string;
  K: number | null;
  R: number | null;
  value: number | null;
};

type TrendDataResult = {
  points: TrendPoint[];
  showYearlyOnly: boolean;
};

type IndicatorsTableProps = {
  table: IndicatorTableData;
  selectedMetric?: string | null;
  onSelectedMetricChange?: (metric: string | null) => void;
};

export function IndicatorsTable({
  table,
  selectedMetric: selectedMetricProp,
  onSelectedMetricChange,
}: IndicatorsTableProps) {
  if (!table.columns.length) {
    return <p className="text-sm italic text-slate-500">Tabela nie zawiera kolumn.</p>;
  }

  const pivot = buildPivotTable(table);

  if (!pivot) {
    return <p className="text-sm italic text-slate-500">Brak kolumny DATA_SPR do zbudowania widoku tabeli.</p>;
  }

  const [internalSelectedMetric, setInternalSelectedMetric] = useState<string | null>(null);
  const selectedMetric = selectedMetricProp ?? internalSelectedMetric;

  const setSelectedMetric = (metric: string | null) => {
    if (onSelectedMetricChange) {
      onSelectedMetricChange(metric);
      return;
    }

    setInternalSelectedMetric(metric);
  };
  const selectedRow = selectedMetric ? pivot.rows.find((row) => row.metric === selectedMetric) ?? null : null;

  const trendData = useMemo<TrendDataResult>(
    () => (selectedRow ? buildTrendData(pivot.dateColumns, selectedRow.values) : { points: [], showYearlyOnly: false }),
    [pivot.dateColumns, selectedRow],
  );

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-2xl shadow-black/20">
        <table className="min-w-full border-collapse bg-white text-sm text-slate-900">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 min-w-50 border-b border-r border-slate-300/70 bg-slate-50 px-4 py-3 text-left text-xs font-semibold uppercase tracking-widest text-slate-500">
                Nazwa
              </th>
              {pivot.dateColumns.map((column) => (
                <th
                  key={column.key}
                  className={`min-w-27.5 border-b border-r border-slate-300/70 px-3 py-3 text-center last:border-r-0 ${getColumnHeaderStyle(column.periodType)}`}
                >
                  <span className="block whitespace-nowrap text-sm font-bold text-slate-900">{getDateLabel(column.label)}</span>
                  {column.periodType ? (
                    <span className={`mt-2 inline-block rounded px-2 py-0.5 text-[11px] font-bold leading-none tracking-widest ${getPeriodBadgeStyle(column.periodType)}`}>
                      {column.periodType}
                    </span>
                  ) : null}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pivot.rows.map((row, idx) => {
              const isSelected = row.metric === selectedMetric;
              return (
                <tr
                  key={row.metric}
                  className={`cursor-pointer border-b border-slate-300/60 last:border-b-0 transition-colors duration-100 hover:bg-slate-50 ${
                    idx % 2 === 0
                        ? "bg-white"
                        : "bg-slate-50/60"
                  }`}
                  onClick={() => {
                    const nextMetric = selectedMetric === row.metric ? null : row.metric;
                    setSelectedMetric(nextMetric);
                  }}
                >
                  <td
                    className={`sticky left-0 z-10 min-w-50 max-w-70 border-r border-slate-300/70 px-4 py-3 align-middle ${
                      isSelected
                        ? "bg-inherit font-semibold shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]"
                        : "bg-inherit"
                    }`}
                  >
                    <span className="block wrap-break-word text-sm font-semibold leading-snug text-slate-800">{row.label}</span>
                  </td>
                  {pivot.dateColumns.map((column, colIdx) => {
                    const raw = row.values[column.key];
                    const isEmpty = raw === "-" || raw === null || raw === undefined;
                    const displayValue = isEmpty ? "-----" : formatPercentValue(raw);
                    const isLastCell = colIdx === pivot.dateColumns.length - 1;
                    return (
                      <td
                        key={`${row.metric}-${column.key}`}
                        className={`border-r border-slate-300/60 px-3 py-3 align-middle font-mono text-lg tabular-nums last:border-r-0 ${
                          isEmpty ? "text-center tracking-wider" : "text-right"
                        } ${isSelected ? getSelectedCellFrameClass(isLastCell) : getColumnCellStyle(column.periodType, isEmpty)}`}
                      >
                        {displayValue}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedRow ? (
        <IndicatorTrendGraph
          metricLabel={selectedRow.label}
          data={trendData.points}
          showYearlyOnly={trendData.showYearlyOnly}
        />
      ) : (
        <p className="text-xs text-slate-300/80">Kliknij wiersz tabeli, aby zobaczyc wykres trendu wskaźnika.</p>
      )}
    </div>
  );
}

function getDateLabel(label: string) {
  return label.replace(/\s*\([^)]*\)\s*$/, "").trim();
}

function parsePercentToNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value * 100;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return null;
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      return Number.isFinite(numericPart) ? numericPart : null;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    return Number.isFinite(numericValue) ? numericValue * 100 : null;
  }

  return null;
}

function buildTrendData(dateColumns: PivotDateColumn[], values: Record<string, unknown>): TrendDataResult {
  const groupedByDate = new Map<string, TrendPoint>();

  dateColumns.forEach((column) => {
    const date = getDateLabel(column.label);
    const parsedValue = parsePercentToNumber(values[column.key]);

    if (!groupedByDate.has(date)) {
      groupedByDate.set(date, {
        date,
        K: null,
        R: null,
        value: null,
      });
    }

    const point = groupedByDate.get(date);
    if (!point) {
      return;
    }

    if (column.periodType === "K") {
      point.K = parsedValue;
      return;
    }

    if (column.periodType === "R") {
      point.R = parsedValue;
      return;
    }

    point.value = parsedValue;
  });

  const sortedPoints = Array.from(groupedByDate.values()).sort((a, b) => a.date.localeCompare(b.date));
  const hasYearlyValues = sortedPoints.some((point) => point.R !== null);
  const hasIntraYearQuarterlyValues = sortedPoints.some(
    (point) => point.K !== null && !isYearEndDate(point.date),
  );

  if (hasYearlyValues && !hasIntraYearQuarterlyValues) {
    return {
      points: sortedPoints.filter((point) => point.R !== null),
      showYearlyOnly: true,
    };
  }

  return {
    points: sortedPoints,
    showYearlyOnly: false,
  };
}

function isYearEndDate(date: string) {
  return /-12-31$/.test(date);
}

function formatPercentValue(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return `${(value * 100).toFixed(2).replace(".", ",")}%`;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return "-";
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      if (Number.isFinite(numericPart)) {
        return `${numericPart.toFixed(2).replace(".", ",")}%`;
      }
      return normalized;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    if (Number.isFinite(numericValue)) {
      return `${(numericValue * 100).toFixed(2).replace(".", ",")}%`;
    }

    return normalized;
  }

  return String(value);
}

function getColumnHeaderStyle(periodType: string) {
  if (periodType === "K") return "bg-violet-100/80";
  if (periodType === "R") return "bg-blue-200";
  return "bg-slate-100";
}

function getPeriodBadgeStyle(periodType: string) {
  if (periodType === "K") return "bg-violet-600 text-white ring-1 ring-inset ring-violet-700/30";
  if (periodType === "R") return "bg-blue-600 text-white ring-1 ring-inset ring-blue-700/30";
  return "bg-slate-300/40 text-slate-600";
}

function getColumnCellStyle(periodType: string, isEmpty: boolean) {
  if (periodType === "K") return isEmpty ? "bg-violet-50 text-slate-500" : "bg-violet-50 text-black";
  if (periodType === "R") return isEmpty ? "bg-blue-100 text-slate-500" : "bg-blue-50 text-black";
  return isEmpty ? "bg-slate-100 text-slate-500" : "text-black";
}

function getSelectedCellFrameClass(isLastCell: boolean) {
  if (isLastCell) {
    return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95),inset_-2px_0_0_0_rgba(99,102,241,0.95)]";
  }

  return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]";
}

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

function buildPivotTable(table: IndicatorTableData): { dateColumns: PivotDateColumn[]; rows: PivotRow[] } | null {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn) {
    return null;
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));

  const dateColumns: Array<{ label: string; key: string; periodType: string }> = Array.from(
    new Set(
      table.rows
        .map((row) => {
          const dateValue = row[dataSprColumn];
          if (dateValue === null || dateValue === undefined) {
            return null;
          }

          const date = String(dateValue);
          const periodType = typOkresuColumn
            ? String(row[typOkresuColumn] ?? "").trim().toUpperCase()
            : "";
          const key = periodType ? `${date}|${periodType}` : date;

          return periodType
            ? `${date} (${periodType}):::${key}:::${periodType}`
            : `${date}:::${key}:::`;
        })
        .filter((value): value is string => Boolean(value)),
    ),
  ).map((value) => {
    const [label = value, key = value, periodType = ""] = value.split(":::");
    return { label, key, periodType };
  });

  const rowLookup = new Map<string, Record<string, unknown>>();
  table.rows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }

    const date = String(dateValue);
    const periodType = typOkresuColumn
      ? String(row[typOkresuColumn] ?? "").trim().toUpperCase()
      : "";
    const key = periodType ? `${date}|${periodType}` : date;

    rowLookup.set(key, row);
  });

  const rows = metricColumns.map((metric) => {
    const values: Record<string, unknown> = {};

    dateColumns.forEach((column) => {
      const match = rowLookup.get(column.key);
      values[column.key] = match?.[metric] ?? "-";
    });

    return {
      metric,
      label: stripMetricSuffix(metric),
      values,
    };
  });

  return {
    dateColumns,
    rows,
  };
}

function stripMetricSuffix(metric: string) {
  return metric.replace(/_(kwartalnie|rocznie|yoy)$/i, "");
}

"use client";

import { useEffect, useMemo, useState } from "react";
import { ScrColumnPieGraph } from "@/components/graph/ScrColumnPieGraph";
import { IndicatorTrendGraph } from "@/components/graph/IndicatorTrendGraph";

type ScrIndicatorsTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

type ScrIndicatorsTableProps = {
  table: ScrIndicatorsTableData;
};

type ChartMode = "column" | "row";

type TrendPoint = {
  date: string;
  K: number | null;
  R: number | null;
  value: number | null;
};

type TrendDataResult = {
  points: TrendPoint[];
  showYearlyOnly: boolean;
};

export function ScrIndicatorsTable({ table }: ScrIndicatorsTableProps) {
  if (!table.columns.length) {
    return <p className="text-sm italic text-slate-500">Tabela nie zawiera kolumn.</p>;
  }

  const pivot = buildPivotTable(table);

  if (!pivot) {
    return <p className="text-sm italic text-slate-500">Brak kolumny DATA_SPR do zbudowania widoku tabeli.</p>;
  }

  const [selectedColumnKey, setSelectedColumnKey] = useState(pivot.dateColumns[0]?.key ?? "");
  const [selectedMetric, setSelectedMetric] = useState<string | null>(null);
  const [chartMode, setChartMode] = useState<ChartMode>("column");

  useEffect(() => {
    if (!pivot.dateColumns.length) {
      setSelectedColumnKey("");
      return;
    }

    const hasSelection = pivot.dateColumns.some((column) => column.key === selectedColumnKey);
    if (!hasSelection) {
      setSelectedColumnKey(pivot.dateColumns[0]?.key ?? "");
    }
  }, [pivot.dateColumns, selectedColumnKey]);

  const selectedColumn =
    pivot.dateColumns.find((column) => column.key === selectedColumnKey) ?? pivot.dateColumns[0] ?? null;

  const selectedRow = selectedMetric
    ? pivot.rows.find((row) => row.metric === selectedMetric) ?? null
    : null;

  const trendData = useMemo<TrendDataResult>(
    () => (selectedRow ? buildTrendData(pivot.dateColumns, selectedRow.values) : { points: [], showYearlyOnly: false }),
    [pivot.dateColumns, selectedRow],
  );

  const pieData = useMemo(() => {
    if (!selectedColumn) {
      return [] as Array<{ name: string; value: number; share: number }>;
    }

    const raw = pivot.rows
      .map((row) => {
        const parsed = parsePercentToNumber(row.values[selectedColumn.key]);
        return {
          name: row.label,
          value: parsed,
        };
      })
      .filter((entry): entry is { name: string; value: number } => entry.value !== null && entry.value > 0);

    const total = raw.reduce((acc, item) => acc + item.value, 0);

    return raw.map((item) => ({
      ...item,
      share: total > 0 ? (item.value / total) * 100 : 0,
    }));
  }, [pivot.rows, selectedColumn]);

  return (
    <div className="space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
        <div className="flex items-center justify-center">
          <div className="inline-flex rounded-xl border border-slate-300 bg-slate-100 p-1 shadow-[inset_0_1px_0_rgba(255,255,255,0.65)]">
          <button
            type="button"
            onClick={() => setChartMode("column")}
            className={`rounded-lg px-4 py-2 text-sm font-semibold transition-all ${
              chartMode === "column"
                ? "bg-[#2b62d9] text-white shadow-[0_2px_8px_rgba(43,98,217,0.4)]"
                : "text-slate-700 hover:bg-slate-200"
            }`}
          >
            Kolumny (kołowy)
          </button>
          <button
            type="button"
            onClick={() => setChartMode("row")}
            className={`rounded-lg px-4 py-2 text-sm font-semibold transition-all ${
              chartMode === "row"
                ? "bg-[#2b62d9] text-white shadow-[0_2px_8px_rgba(43,98,217,0.4)]"
                : "text-slate-700 hover:bg-slate-200"
            }`}
          >
            Wiersze (trend)
          </button>
          </div>
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-2xl shadow-black/20">
        <table className="min-w-full border-collapse bg-white text-sm text-slate-900">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 min-w-50 border-b border-r border-slate-300/70 bg-slate-50 px-4 py-3 text-left text-xs font-semibold uppercase tracking-widest text-slate-500">
                Nazwa
              </th>
              {pivot.dateColumns.map((column) => {
                const isSelected = chartMode === "column" && column.key === selectedColumn?.key;
                return (
                  <th
                    key={column.key}
                    onClick={() => {
                      if (chartMode !== "column") {
                        return;
                      }
                      setSelectedColumnKey(column.key);
                    }}
                    onKeyDown={(event) => {
                      if (chartMode !== "column") {
                        return;
                      }

                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault();
                        setSelectedColumnKey(column.key);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    className={`min-w-27.5 border-b border-r border-slate-300/70 px-3 py-3 text-center last:border-r-0 ${
                      chartMode === "column" ? "cursor-pointer" : "cursor-default"
                    } ${getColumnHeaderStyle(column.periodType)} ${
                      isSelected ? "shadow-[inset_0_-3px_0_0_rgba(30,64,175,0.95)]" : ""
                    }`}
                    title="Kliknij, aby wybrac kolumne do wykresu kolowego"
                  >
                    <span className="block whitespace-nowrap text-sm font-bold text-slate-900">{getDateLabel(column.label)}</span>
                    {column.periodType ? (
                      <span className={`mt-2 inline-block rounded px-2 py-0.5 text-[11px] font-bold leading-none tracking-widest ${getPeriodBadgeStyle(column.periodType)}`}>
                        {column.periodType}
                      </span>
                    ) : null}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {pivot.rows.map((row, rowIndex) => {
              const isRowSelected = chartMode === "row" && row.metric === selectedMetric;
              return (
                <tr
                  key={row.metric}
                  className={`border-b border-slate-300/60 last:border-b-0 ${
                    rowIndex % 2 === 0 ? "bg-white" : "bg-slate-50/60"
                  } ${chartMode === "row" ? "cursor-pointer hover:bg-slate-50" : ""}`}
                  onClick={() => {
                    if (chartMode !== "row") {
                      return;
                    }

                    setSelectedMetric((prev) => (prev === row.metric ? null : row.metric));
                  }}
                >
                <td className="sticky left-0 z-10 min-w-50 max-w-70 border-r border-slate-300/70 bg-inherit px-4 py-3 align-middle">
                  <span
                    className={`block wrap-break-word text-sm font-semibold leading-snug text-slate-800 ${
                      isRowSelected ? "font-bold" : ""
                    }`}
                  >
                    {row.label}
                  </span>
                </td>

                {pivot.dateColumns.map((column, colIdx) => {
                  const raw = row.values[column.key];
                  const isEmpty = raw === "-" || raw === null || raw === undefined;
                  const displayValue = isEmpty ? "-----" : formatPercentValue(raw);
                  const isSelected = chartMode === "column" && column.key === selectedColumn?.key;
                  const isLastCell = colIdx === pivot.dateColumns.length - 1;

                  return (
                    <td
                      key={`${row.metric}-${column.key}`}
                      className={`border-r border-slate-300/60 px-3 py-3 align-middle font-mono text-lg tabular-nums last:border-r-0 ${
                        isEmpty ? "text-center tracking-wider" : "text-right"
                      } ${getColumnCellStyle(column.periodType, isEmpty)} ${
                        isSelected ? "ring-1 ring-inset ring-blue-500/50" : ""
                      } ${
                        isRowSelected ? getSelectedCellFrameClass(isLastCell) : ""
                      }`}
                    >
                      {displayValue}
                    </td>
                  );
                })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {chartMode === "column" && selectedColumn ? (
        <ScrColumnPieGraph
          columnLabel={getDateLabel(selectedColumn.label)}
          periodType={selectedColumn.periodType}
          data={pieData}
        />
      ) : null}

      {chartMode === "row" ? (
        selectedRow ? (
          <IndicatorTrendGraph
            metricLabel={selectedRow.label}
            data={trendData.points}
            showYearlyOnly={trendData.showYearlyOnly}
          />
        ) : (
          <p className="text-xs text-slate-300/80">Kliknij wiersz tabeli, aby zobaczyc wykres trendu wskaźnika.</p>
        )
      ) : null}
    </div>
  );
}

type PivotDateColumn = {
  label: string;
  key: string;
  periodType: string;
};

type PivotRow = {
  metric: string;
  label: string;
  values: Record<string, unknown>;
};

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

function buildPivotTable(table: ScrIndicatorsTableData): { dateColumns: PivotDateColumn[]; rows: PivotRow[] } | null {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn) {
    return null;
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));

  const dateColumns: PivotDateColumn[] = Array.from(
    new Set(
      table.rows
        .map((row) => {
          const dateValue = row[dataSprColumn];
          if (dateValue === null || dateValue === undefined) {
            return null;
          }

          const date = String(dateValue);
          const periodType = typOkresuColumn
            ? String(row[typOkresuColumn] ?? "").trim().toUpperCase()
            : "";
          const key = periodType ? `${date}|${periodType}` : date;

          return periodType
            ? `${date} (${periodType}):::${key}:::${periodType}`
            : `${date}:::${key}:::`;
        })
        .filter((value): value is string => Boolean(value)),
    ),
  ).map((value) => {
    const [label = value, key = value, periodType = ""] = value.split(":::");
    return { label, key, periodType };
  });

  const rowLookup = new Map<string, Record<string, unknown>>();
  table.rows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }

    const date = String(dateValue);
    const periodType = typOkresuColumn
      ? String(row[typOkresuColumn] ?? "").trim().toUpperCase()
      : "";
    const key = periodType ? `${date}|${periodType}` : date;

    rowLookup.set(key, row);
  });

  const rows = metricColumns.map((metric) => {
    const values: Record<string, unknown> = {};

    dateColumns.forEach((column) => {
      const match = rowLookup.get(column.key);
      values[column.key] = match?.[metric] ?? "-";
    });

    return {
      metric,
      label: metric,
      values,
    };
  });

  return {
    dateColumns,
    rows,
  };
}

function getDateLabel(label: string) {
  return label.replace(/\s*\([^)]*\)\s*$/, "").trim();
}

function parsePercentToNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value * 100;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return null;
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      return Number.isFinite(numericPart) ? numericPart : null;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    return Number.isFinite(numericValue) ? numericValue * 100 : null;
  }

  return null;
}

function buildTrendData(dateColumns: PivotDateColumn[], values: Record<string, unknown>): TrendDataResult {
  const groupedByDate = new Map<string, TrendPoint>();

  dateColumns.forEach((column) => {
    const date = getDateLabel(column.label);
    const parsedValue = parsePercentToNumber(values[column.key]);

    if (!groupedByDate.has(date)) {
      groupedByDate.set(date, {
        date,
        K: null,
        R: null,
        value: null,
      });
    }

    const point = groupedByDate.get(date);
    if (!point) {
      return;
    }

    if (column.periodType === "K") {
      point.K = parsedValue;
      return;
    }

    if (column.periodType === "R") {
      point.R = parsedValue;
      return;
    }

    point.value = parsedValue;
  });

  const sortedPoints = Array.from(groupedByDate.values()).sort((a, b) => a.date.localeCompare(b.date));
  const hasYearlyValues = sortedPoints.some((point) => point.R !== null);
  const hasIntraYearQuarterlyValues = sortedPoints.some(
    (point) => point.K !== null && !isYearEndDate(point.date),
  );

  if (hasYearlyValues && !hasIntraYearQuarterlyValues) {
    return {
      points: sortedPoints.filter((point) => point.R !== null),
      showYearlyOnly: true,
    };
  }

  return {
    points: sortedPoints,
    showYearlyOnly: false,
  };
}

function isYearEndDate(date: string) {
  return /-12-31$/.test(date);
}

function formatPercentValue(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return `${(value * 100).toFixed(2).replace(".", ",")}%`;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return "-";
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      if (Number.isFinite(numericPart)) {
        return `${numericPart.toFixed(2).replace(".", ",")}%`;
      }
      return normalized;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    if (Number.isFinite(numericValue)) {
      return `${(numericValue * 100).toFixed(2).replace(".", ",")}%`;
    }

    return normalized;
  }

  return String(value);
}

function getColumnHeaderStyle(periodType: string) {
  if (periodType === "K") return "bg-violet-100/80";
  if (periodType === "R") return "bg-blue-200";
  return "bg-slate-100";
}

function getPeriodBadgeStyle(periodType: string) {
  if (periodType === "K") return "bg-violet-600 text-white ring-1 ring-inset ring-violet-700/30";
  if (periodType === "R") return "bg-blue-600 text-white ring-1 ring-inset ring-blue-700/30";
  return "bg-slate-300/40 text-slate-600";
}

function getColumnCellStyle(periodType: string, isEmpty: boolean) {
  if (periodType === "K") return isEmpty ? "bg-violet-50 text-slate-500" : "bg-violet-50 text-black";
  if (periodType === "R") return isEmpty ? "bg-blue-100 text-slate-500" : "bg-blue-50 text-black";
  return isEmpty ? "bg-slate-100 text-slate-500" : "text-black";
}

function getSelectedCellFrameClass(isLastCell: boolean) {
  if (isLastCell) {
    return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95),inset_-2px_0_0_0_rgba(99,102,241,0.95)]";
  }

  return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]";
}

"use client";

import { useMemo, useState } from "react";
import { YearlyChangesBarsGraph } from "../graph/YearlyChangesBarsGraph";

type YearlyTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

type YearlyChangesTableProps = {
  table: YearlyTableData;
  indicatorsTable: YearlyTableData;
  selectedMetric?: string | null;
  onSelectedMetricChange?: (metric: string | null) => void;
};

type PivotDateColumn = {
  key: string;
  date: string;
  periodType: string;
};

type DisplayColumn = {
  key: string;
  currentDate: string;
  previousDate: string;
  periodType: string;
};

type PivotRow = {
  metric: string;
  label: string;
  values: Record<string, unknown>;
};

type YearlyGraphPoint = {
  currentDate: string;
  previousDate: string;
  currentValue: number | null;
  previousValue: number | null;
  diffValue: number | null;
  periodType: string;
};

export function YearlyChangesTable({
  table,
  indicatorsTable,
  selectedMetric: selectedMetricProp,
  onSelectedMetricChange,
}: YearlyChangesTableProps) {
  if (!table.columns.length) {
    return <p className="text-sm italic text-slate-500">Tabela nie zawiera kolumn.</p>;
  }

  const pivot = buildPivot(table);

  if (!pivot) {
    return <p className="text-sm italic text-slate-500">Brak kolumny DATA_SPR do zbudowania widoku tabeli.</p>;
  }

  const displayColumns = buildYearOverYearColumns(pivot.dateColumns);

  if (!displayColumns.length) {
    return <p className="text-sm italic text-slate-500">Brak par dat rok do roku do wyliczenia.</p>;
  }

  const [internalSelectedMetric, setInternalSelectedMetric] = useState<string | null>(null);
  const selectedMetric = selectedMetricProp ?? internalSelectedMetric;

  const setSelectedMetric = (metric: string | null) => {
    if (onSelectedMetricChange) {
      onSelectedMetricChange(metric);
      return;
    }

    setInternalSelectedMetric(metric);
  };
  const selectedRow = selectedMetric ? pivot.rows.find((row) => row.metric === selectedMetric) ?? null : null;

  const indicatorValueLookup = useMemo(
    () => buildIndicatorValueLookup(indicatorsTable),
    [indicatorsTable],
  );

  const graphData = useMemo(
    () =>
      selectedRow
        ? buildYearlyGraphData(displayColumns, selectedRow, indicatorValueLookup)
        : [],
    [displayColumns, selectedRow, indicatorValueLookup],
  );

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-2xl shadow-black/20">
        <table className="min-w-full border-collapse bg-white text-sm text-slate-900">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 min-w-50 border-b border-r border-slate-300/70 bg-slate-50 px-4 py-3 text-left text-xs font-semibold uppercase tracking-widest text-slate-500">
                Nazwa
              </th>
              {displayColumns.map((column) => (
                <th
                  key={column.key}
                  className={`min-w-44 border-b border-r border-slate-300/70 px-3 py-2.5 text-center last:border-r-0 ${getHeaderClass(column.periodType)}`}
                >
                  <span className="flex items-center justify-center gap-1 text-xs font-semibold text-slate-900">
                    <span className="inline-flex min-w-30 flex-col items-center leading-tight">
                      <span className="px-1">{column.currentDate}</span>
                      <span className="my-0.5 w-[78%] border-t border-slate-500/70" />
                      <span className="px-1">{column.previousDate}</span>
                    </span>
                    <span>- 1</span>
                  </span>
                  <span className={`mt-1 inline-block rounded px-2 py-0.5 text-[11px] font-bold leading-none ${getBadgeClass(column.periodType)}`}>
                    {column.periodType || "?"}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pivot.rows.map((row, idx) => {
              const isSelected = row.metric === selectedMetric;
              return (
                <tr
                  key={row.metric}
                  className={`cursor-pointer border-b border-slate-300/60 last:border-b-0 transition-colors duration-75 hover:bg-slate-50 ${
                    idx % 2 === 0 ? "bg-white" : "bg-slate-50/60"
                  }`}
                  onClick={() => {
                    const nextMetric = selectedMetric === row.metric ? null : row.metric;
                    setSelectedMetric(nextMetric);
                  }}
                >
                  <td
                    className={`sticky left-0 z-10 min-w-50 max-w-70 border-r border-slate-300/70 bg-inherit px-4 py-3 align-middle ${
                      isSelected
                        ? "font-semibold shadow-[inset_4px_0_0_0_rgba(99,102,241,0.95),inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]"
                        : ""
                    }`}
                  >
                    <span className="block wrap-break-word text-sm font-semibold leading-snug text-slate-800">{row.label}</span>
                  </td>
                  {displayColumns.map((column, colIdx) => {
                    const raw = row.values[column.key];
                    const isEmpty = raw === null || raw === undefined || raw === "-";
                    const isLastCell = colIdx === displayColumns.length - 1;
                    return (
                      <td
                        key={`${row.metric}-${column.key}`}
                        className={`border-r border-slate-300/60 px-3 py-3 align-middle font-mono text-lg tabular-nums last:border-r-0 ${
                          isEmpty ? "text-center tracking-wider text-slate-500" : "text-right text-black"
                        } ${getCellClass(column.periodType)} ${isSelected ? getSelectedCellFrameClass(isLastCell) : ""}`}
                      >
                        {isEmpty ? "-----" : formatPercentValue(raw)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedRow ? (
        <YearlyChangesBarsGraph metricLabel={selectedRow.label} data={graphData} />
      ) : (
        <p className="text-xs text-slate-300/80">Kliknij wiersz tabeli, aby zobaczyc wykres zmian rocznych.</p>
      )}
    </div>
  );
}

function parsePercentToNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value * 100;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return null;
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      return Number.isFinite(numericPart) ? numericPart : null;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    return Number.isFinite(numericValue) ? numericValue * 100 : null;
  }

  return null;
}

function buildYearlyGraphData(
  displayColumns: DisplayColumn[],
  yearlyRow: PivotRow,
  indicatorValueLookup: Map<string, Map<string, unknown>>,
) {
  const metricKey = normalizeMetricKey(yearlyRow.metric);
  const indicatorValues = indicatorValueLookup.get(metricKey);
  const columnsByCurrentDate = collapseColumnsByCurrentDate(displayColumns);

  return columnsByCurrentDate
    .map<YearlyGraphPoint>((column) => {
      const previousKey = `${column.previousDate}|${column.periodType}`;

      return {
        currentDate: column.currentDate,
        previousDate: column.previousDate,
        currentValue: parsePercentToNumber(indicatorValues?.get(column.key)),
        previousValue: parsePercentToNumber(indicatorValues?.get(previousKey)),
        diffValue: parsePercentToNumber(yearlyRow.values[column.key]),
        periodType: column.periodType,
      };
    })
    .filter(
      (point) => point.currentValue !== null || point.previousValue !== null || point.diffValue !== null,
    );
}

function collapseColumnsByCurrentDate(displayColumns: DisplayColumn[]) {
  const byDate = new Map<string, DisplayColumn>();

  displayColumns.forEach((column) => {
    const existing = byDate.get(column.currentDate);
    if (!existing) {
      byDate.set(column.currentDate, column);
      return;
    }

    // If both K and R are present for one date, prefer yearly (R) as the representative column.
    if (existing.periodType !== "R" && column.periodType === "R") {
      byDate.set(column.currentDate, column);
    }
  });

  return Array.from(byDate.values()).sort((a, b) => a.currentDate.localeCompare(b.currentDate));
}

function buildIndicatorValueLookup(table: YearlyTableData) {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn || !typOkresuColumn) {
    return new Map<string, Map<string, unknown>>();
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));
  const metricLookup = new Map<string, Map<string, unknown>>();

  metricColumns.forEach((metric) => {
    metricLookup.set(normalizeMetricKey(metric), new Map<string, unknown>());
  });

  table.rows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }

    const periodType = String(row[typOkresuColumn] ?? "").trim().toUpperCase();
    const key = `${String(dateValue)}|${periodType}`;

    metricColumns.forEach((metric) => {
      const target = metricLookup.get(normalizeMetricKey(metric));
      if (!target) {
        return;
      }

      target.set(key, row[metric]);
    });
  });

  return metricLookup;
}

function normalizeMetricKey(metric: string) {
  return stripMetricSuffix(metric).trim().toLowerCase();
}

function buildYearOverYearColumns(dateColumns: PivotDateColumn[]) {
  const lookup = new Set(dateColumns.map((column) => `${column.date}|${column.periodType}`));

  return dateColumns.filter((column) => {
    const previousDate = getPreviousYearDate(column.date);
    if (!previousDate) {
      return false;
    }

    return lookup.has(`${previousDate}|${column.periodType}`);
  }).map<DisplayColumn>((column) => ({
    key: column.key,
    currentDate: column.date,
    previousDate: getPreviousYearDate(column.date) ?? "",
    periodType: column.periodType,
  }));
}

function getPreviousYearDate(date: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  if (!match) {
    return null;
  }

  const [, year, month, day] = match;
  const prevYear = Number(year) - 1;
  if (!Number.isFinite(prevYear)) {
    return null;
  }

  return `${prevYear.toString().padStart(4, "0")}-${month}-${day}`;
}

function getHeaderClass(periodType: string) {
  if (periodType === "K") return "bg-violet-100/80";
  if (periodType === "R") return "bg-blue-200";
  return "bg-slate-100";
}

function getBadgeClass(periodType: string) {
  if (periodType === "K") return "bg-violet-600 text-white";
  if (periodType === "R") return "bg-blue-600 text-white";
  return "bg-slate-300 text-slate-700";
}

function getCellClass(periodType: string) {
  if (periodType === "K") return "bg-violet-50";
  if (periodType === "R") return "bg-blue-50";
  return "bg-slate-100";
}

function getSelectedCellFrameClass(isLastCell: boolean) {
  if (isLastCell) {
    return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95),inset_-2px_0_0_0_rgba(99,102,241,0.95)]";
  }

  return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]";
}

function formatPercentValue(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return `${(value * 100).toFixed(2).replace(".", ",")}%`;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return "-----";
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      if (Number.isFinite(numericPart)) {
        return `${numericPart.toFixed(2).replace(".", ",")}%`;
      }
      return normalized;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    if (Number.isFinite(numericValue)) {
      return `${(numericValue * 100).toFixed(2).replace(".", ",")}%`;
    }

    return normalized;
  }

  return "-----";
}

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

function buildPivot(table: YearlyTableData): { dateColumns: PivotDateColumn[]; rows: PivotRow[] } | null {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn || !typOkresuColumn) {
    return null;
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));

  const dateColumns = Array.from(
    new Set(
      table.rows
        .map((row) => {
          const dateValue = row[dataSprColumn];
          if (dateValue === null || dateValue === undefined) {
            return null;
          }

          const date = String(dateValue);
          const periodType = String(row[typOkresuColumn] ?? "").trim().toUpperCase();
          return `${date}|${periodType}`;
        })
        .filter((value): value is string => Boolean(value)),
    ),
  )
    .map<PivotDateColumn>((value) => {
      const [date = value, periodType = ""] = value.split("|");
      return { key: value, date, periodType };
    })
    .sort((a, b) => a.date.localeCompare(b.date));

  const rowLookup = new Map<string, Record<string, unknown>>();
  table.rows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }

    const date = String(dateValue);
    const periodType = String(row[typOkresuColumn] ?? "").trim().toUpperCase();
    rowLookup.set(`${date}|${periodType}`, row);
  });

  const rows = metricColumns.map((metric) => {
    const values: Record<string, unknown> = {};

    dateColumns.forEach((column) => {
      const match = rowLookup.get(column.key);
      values[column.key] = match?.[metric] ?? null;
    });

    return {
      metric,
      label: stripMetricSuffix(metric),
      values,
    };
  });

  return {
    dateColumns,
    rows,
  };
}

function stripMetricSuffix(metric: string) {
  return metric.replace(/_(kwartalnie|rocznie|yoy)$/i, "");
}

"use client";

import { useMemo, useState } from "react";
import { QuarterlyChangesBarsGraph } from "../graph/QuarterlyChangesBarsGraph";

type QuarterlyTableData = {
  columns: string[];
  rows: Record<string, unknown>[];
};

type QuarterlyChangesTableProps = {
  table: QuarterlyTableData;
  indicatorsTable: QuarterlyTableData;
  selectedMetric?: string | null;
  onSelectedMetricChange?: (metric: string | null) => void;
};

type DisplayColumn = {
  key: string;
  currentDate: string;
  previousDate: string;
};

export function QuarterlyChangesTable({
  table,
  indicatorsTable,
  selectedMetric: selectedMetricProp,
  onSelectedMetricChange,
}: QuarterlyChangesTableProps) {
  if (!table.columns.length) {
    return <p className="text-sm italic text-slate-500">Tabela nie zawiera kolumn.</p>;
  }

  const pivot = buildQuarterlyPivot(table);

  if (!pivot) {
    return <p className="text-sm italic text-slate-500">Brak danych kwartalnych do wyliczenia zmian.</p>;
  }

  const displayColumns = buildDisplayColumns(pivot.dateColumns);

  if (!displayColumns.length) {
    return <p className="text-sm italic text-slate-500">Brak kolejnych kwartalow do wyliczenia przyrostu.</p>;
  }

  const [internalSelectedMetric, setInternalSelectedMetric] = useState<string | null>(null);
  const selectedMetric = selectedMetricProp ?? internalSelectedMetric;

  const setSelectedMetric = (metric: string | null) => {
    if (onSelectedMetricChange) {
      onSelectedMetricChange(metric);
      return;
    }

    setInternalSelectedMetric(metric);
  };

  const selectedRow = selectedMetric ? pivot.rows.find((row) => row.metric === selectedMetric) ?? null : null;

  const indicatorLookup = useMemo(() => buildQuarterlyIndicatorLookup(indicatorsTable), [indicatorsTable]);

  const graphData = useMemo(
    () => (selectedRow ? buildQuarterlyGraphData(displayColumns, selectedRow, indicatorLookup) : []),
    [displayColumns, selectedRow, indicatorLookup],
  );

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-2xl shadow-black/20">
        <table className="min-w-full border-collapse bg-white text-sm text-slate-900">
          <thead>
            <tr>
              <th className="sticky left-0 z-10 min-w-50 border-b border-r border-slate-300/70 bg-slate-50 px-4 py-3 text-left text-xs font-semibold uppercase tracking-widest text-slate-500">
                Nazwa
              </th>
              {displayColumns.map((column) => (
                <th
                  key={column.key}
                  className="min-w-44 border-b border-r border-slate-300/70 bg-violet-100/80 px-3 py-2.5 text-center last:border-r-0"
                >
                  <span className="flex items-center justify-center gap-1 text-xs font-semibold text-slate-900">
                    <span className="inline-flex min-w-30 flex-col items-center leading-tight">
                      <span className="px-1">{column.currentDate}</span>
                      <span className="my-0.5 w-[78%] border-t border-slate-500/70" />
                      <span className="px-1">{column.previousDate}</span>
                    </span>
                    <span>- 1</span>
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pivot.rows.map((row, idx) => {
              const isSelected = row.metric === selectedMetric;

              return (
                <tr
                  key={row.metric}
                  className={`cursor-pointer border-b border-slate-300/60 last:border-b-0 transition-colors duration-75 hover:bg-slate-50 ${
                    idx % 2 === 0 ? "bg-white" : "bg-slate-50/60"
                  }`}
                  onClick={() => {
                    const nextMetric = selectedMetric === row.metric ? null : row.metric;
                    setSelectedMetric(nextMetric);
                  }}
                >
                  <td
                    className={`sticky left-0 z-10 min-w-50 max-w-70 border-r border-slate-300/70 bg-inherit px-4 py-3 align-middle ${
                      isSelected
                        ? "font-semibold shadow-[inset_4px_0_0_0_rgba(99,102,241,0.95),inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]"
                        : ""
                    }`}
                  >
                    <span className="block wrap-break-word text-sm font-semibold leading-snug text-slate-800">{row.label}</span>
                  </td>
                  {displayColumns.map((column, colIdx) => {
                    const raw = row.values[column.key];
                    const isEmpty = raw === null || raw === undefined || raw === "-";
                    const isLastCell = colIdx === displayColumns.length - 1;
                    return (
                      <td
                        key={`${row.metric}-${column.key}`}
                        className={`border-r border-slate-300/60 bg-violet-50 px-3 py-3 align-middle font-mono text-lg tabular-nums last:border-r-0 ${
                          isEmpty ? "text-center tracking-wider text-slate-500" : "text-right text-black"
                        } ${isSelected ? getSelectedCellFrameClass(isLastCell) : ""}`}
                      >
                        {isEmpty ? "-----" : formatPercentValue(raw)}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedRow && graphData.length ? (
        <QuarterlyChangesBarsGraph metricLabel={selectedRow.label} data={graphData} />
      ) : selectedRow ? (
        <p className="text-xs text-slate-300/80">Brak danych kwartalnych K dla wybranego wskaźnika.</p>
      ) : (
        <p className="text-xs text-slate-300/80">Kliknij wiersz tabeli, aby zobaczyc wykres zmian kwartalnych.</p>
      )}
    </div>
  );
}

type QuarterlyGraphPoint = {
  date: string;
  barValue: number | null;
  lineValue: number | null;
  diffValue: number | null;
};

type PivotRow = {
  metric: string;
  label: string;
  values: Record<string, unknown>;
};

function buildQuarterlyGraphData(
  displayColumns: DisplayColumn[],
  quarterlyRow: PivotRow,
  indicatorLookup: Map<string, Map<string, unknown>>,
) {
  const hasQuarterlyDiff = displayColumns.some(
    (column) => parsePercentToNumber(quarterlyRow.values[column.key]) !== null,
  );

  if (!hasQuarterlyDiff) {
    return [];
  }

  const metricKey = normalizeMetricKey(quarterlyRow.metric);
  const indicatorValues = indicatorLookup.get(metricKey);
  const points: QuarterlyGraphPoint[] = [];

  const firstColumn = displayColumns[0];
  if (firstColumn) {
    const firstPreviousKey = `${firstColumn.previousDate}|K`;
    const firstPreviousValue = parsePercentToNumber(indicatorValues?.get(firstPreviousKey));

    points.push({
      date: firstColumn.previousDate,
      barValue: firstPreviousValue,
      lineValue: firstPreviousValue,
      diffValue: null,
    });
  }

  displayColumns.forEach((column) => {
    const barKey = `${column.currentDate}|K`;
    const barValue = parsePercentToNumber(indicatorValues?.get(barKey));

    points.push({
      date: column.currentDate,
      barValue,
      lineValue: barValue,
      diffValue: parsePercentToNumber(quarterlyRow.values[column.key]),
    });
  });

  return points.filter((point) => point.barValue !== null || point.diffValue !== null);
}

function buildQuarterlyIndicatorLookup(table: QuarterlyTableData) {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn || !typOkresuColumn) {
    return new Map<string, Map<string, unknown>>();
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));
  const metricLookup = new Map<string, Map<string, unknown>>();

  metricColumns.forEach((metric) => {
    metricLookup.set(normalizeMetricKey(metric), new Map<string, unknown>());
  });

  table.rows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }

    const periodType = String(row[typOkresuColumn] ?? "").trim().toUpperCase();
    const key = `${String(dateValue)}|${periodType}`;

    metricColumns.forEach((metric) => {
      const target = metricLookup.get(normalizeMetricKey(metric));
      if (!target) {
        return;
      }

      target.set(key, row[metric]);
    });
  });

  return metricLookup;
}

function parsePercentToNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value * 100;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return null;
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      return Number.isFinite(numericPart) ? numericPart : null;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    return Number.isFinite(numericValue) ? numericValue * 100 : null;
  }

  return null;
}

function normalizeMetricKey(metric: string) {
  return stripMetricSuffix(metric).trim().toLowerCase();
}

function getSelectedCellFrameClass(isLastCell: boolean) {
  if (isLastCell) {
    return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95),inset_-2px_0_0_0_rgba(99,102,241,0.95)]";
  }

  return "shadow-[inset_0_2px_0_0_rgba(129,140,248,0.95),inset_0_-2px_0_0_rgba(129,140,248,0.95)]";
}

function buildQuarterlyPivot(table: QuarterlyTableData) {
  const dataSprColumn = table.columns.find((column) => normalizeColumn(column) === "data_spr");
  const typOkresuColumn = table.columns.find((column) => normalizeColumn(column) === "typ_okresu");

  if (!dataSprColumn || !typOkresuColumn) {
    return null;
  }

  const excluded = new Set(["data_spr", "typ_okresu", "kod_zu"]);
  const metricColumns = table.columns.filter((column) => !excluded.has(normalizeColumn(column)));

  const quarterlyRows = table.rows.filter((row) => {
    const periodType = String(row[typOkresuColumn] ?? "").trim().toUpperCase();
    return periodType === "K";
  });

  const uniqueQuarterDates = Array.from(
    new Set(
      quarterlyRows
        .map((row) => row[dataSprColumn])
        .filter((value): value is string | number => value !== null && value !== undefined)
        .map((value) => String(value)),
    ),
  ).sort((a, b) => a.localeCompare(b));

  const dateToRow = new Map<string, Record<string, unknown>>();
  quarterlyRows.forEach((row) => {
    const dateValue = row[dataSprColumn];
    if (dateValue === null || dateValue === undefined) {
      return;
    }
    dateToRow.set(String(dateValue), row);
  });

  const rows = metricColumns.map((metric) => {
    const values: Record<string, unknown> = {};

    uniqueQuarterDates.forEach((dateKey) => {
      const rowForDate = dateToRow.get(dateKey);
      values[dateKey] = rowForDate?.[metric] ?? null;
    });

    return {
      metric,
      label: stripMetricSuffix(metric),
      values,
    };
  });

  return {
    dateColumns: uniqueQuarterDates.map((date) => ({ key: date, date })),
    rows,
  };
}

function buildDisplayColumns(dateColumns: Array<{ key: string; date: string }>) {
  return dateColumns.slice(1).map<DisplayColumn>((column, index) => ({
    key: column.key,
    currentDate: column.date,
    previousDate: dateColumns[index]?.date ?? "",
  }));
}

function formatPercentValue(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return `${(value * 100).toFixed(2).replace(".", ",")}%`;
  }

  if (typeof value === "string") {
    const normalized = value.trim();

    if (!normalized || normalized === "-") {
      return "-----";
    }

    if (normalized.endsWith("%")) {
      const numericPart = Number.parseFloat(normalized.slice(0, -1).replace(",", "."));
      if (Number.isFinite(numericPart)) {
        return `${numericPart.toFixed(2).replace(".", ",")}%`;
      }
      return normalized;
    }

    const numericValue = Number.parseFloat(normalized.replace(",", "."));
    if (Number.isFinite(numericValue)) {
      return `${(numericValue * 100).toFixed(2).replace(".", ",")}%`;
    }

    return normalized;
  }

  return "-----";
}

function stripMetricSuffix(metric: string) {
  return metric.replace(/_(kwartalnie|rocznie|yoy)$/i, "");
}

function normalizeColumn(column: string) {
  return column.trim().toLowerCase();
}

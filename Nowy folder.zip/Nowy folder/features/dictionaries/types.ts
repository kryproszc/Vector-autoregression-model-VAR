export type DictionaryType = {
	kodTypu: string;
	nazwaTypu: string;
	kategoria?: number | string | null;
};

export type DictionaryEntry = {
	id?: number;
	teamId?: number;
	kodTypu: string;
	kodPozycji: string;
	nazwaPozycji: string;
	nazwaUzytkowa?: string | null;
	skrotPozycji: string | null;
	kolejnosc: number | null;
	aktywny: boolean;
	kierownikUserId?: number | null;
	kierownikDisplayName?: string | null;
};

export type AddDictionaryEntryForm = {
	kodPozycji: string;
	nazwaPozycji: string;
	nazwaUzytkowa: string;
	skrotPozycji: string;
	aktywny: boolean;
	kierownikUserId: number | null;
};

export type TeamLeaderOption = {
	id: number;
	displayName: string;
};

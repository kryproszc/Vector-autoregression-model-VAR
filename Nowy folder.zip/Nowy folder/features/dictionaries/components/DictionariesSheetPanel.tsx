"use client";

import { Pencil, Plus, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import type { AuthRole } from "@/app/_components/home-tabs/types";
import {
	updateDictionaryEntry,
	updateTeamEntry,
} from "@/features/dictionaries/api";
import { AddDictionaryEntryModal } from "@/features/dictionaries/components/AddDictionaryEntryModal";
import { useDictionariesSheet } from "@/features/dictionaries/hooks/useDictionariesSheet";
import type {
	DictionaryEntry,
	DictionaryType,
} from "@/features/dictionaries/types";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";
import { TableSurface } from "@/shared/components/table/TableSurface";

type DictionariesSheetPanelProps = {
	operatorLogin: string;
	authRole?: AuthRole;
	preferredKodTypu?: string;
	tableOnly?: boolean;
	title?: string;
	subtitle?: string;
	canEdit?: boolean;
};

type DictionaryCategoryOption = {
	key: string;
	label: string;
	sortOrder: number;
};

const SANCTION_DICTIONARY_CODES = new Set([
	"department",
	"informacja_o_wszczeciu_postepowania_sankcyjnego",
	"naruszenia_skutkujace_sankcja",
	"nazwy_podmiotow_sankcje",
	"podstawa_prawna_sankcji",
	"rozstrzygniecie_wniosku_sankcyjnego_i",
	"sankcja",
]);

const COMMITMENT_DECISION_DICTIONARY_CODES = new Set([
	"rozstrzygniecie_decyzji_i",
	"rozstrzygniecie_decyzji_ii",
]);

const GENERAL_DICTIONARY_CODES = new Set(["department_ogolne"]);

const TEAM_LEAD_EDITABLE_DICTIONARY_TYPE_CODES = new Set([
	"department_ogolne",
	"nazwy_podmiotow",
	"zakresy_inspekcji",
	"department",
	"podstawa_prawna_sankcji",
	"naruszenia_skutkujace_sankcja",
	"nazwy_podmiotow_sankcje",
]);

function inferCategoryKeyFromCode(kodTypu: string): string {
	const normalizedCode = kodTypu.trim().toLowerCase();

	if (normalizedCode === "statusy_zalecen") {
		return "1";
	}

	if (GENERAL_DICTIONARY_CODES.has(normalizedCode)) {
		return "3";
	}

	if (COMMITMENT_DECISION_DICTIONARY_CODES.has(normalizedCode)) {
		return "4";
	}

	if (SANCTION_DICTIONARY_CODES.has(normalizedCode)) {
		return "2";
	}

	return "0";
}

function toHumanLabel(value: string) {
	return value
		.replace(/[_-]+/g, " ")
		.split(" ")
		.filter(Boolean)
		.map((chunk) => chunk.charAt(0).toUpperCase() + chunk.slice(1))
		.join(" ");
}

function resolveCategoryOption(type: DictionaryType): DictionaryCategoryOption {
	const normalizedCode = type.kodTypu.trim().toLowerCase();
	if (GENERAL_DICTIONARY_CODES.has(normalizedCode)) {
		return { key: "3", label: "Ogólne", sortOrder: -1 };
	}

	if (COMMITMENT_DECISION_DICTIONARY_CODES.has(normalizedCode)) {
		return { key: "4", label: "Decyzje zobowiązujące", sortOrder: 4 };
	}

	const rawCategory = type.kategoria;

	if (typeof rawCategory === "number" && Number.isFinite(rawCategory)) {
		const key = String(rawCategory);
		if (key === "0") {
			return { key, label: "Inspekcje", sortOrder: 0 };
		}
		if (key === "1") {
			return { key, label: "Zalecenia", sortOrder: 1 };
		}
		if (key === "2") {
			return { key, label: "Wnioski sankcyjne", sortOrder: 2 };
		}
		if (key === "3") {
			return { key, label: "Ogólne", sortOrder: -1 };
		}
		if (key === "4") {
			return { key, label: "Decyzje zobowiązujące", sortOrder: 4 };
		}

		return { key, label: `Kategoria ${key}`, sortOrder: rawCategory };
	}

	if (typeof rawCategory === "string" && rawCategory.trim()) {
		const normalized = rawCategory.trim().toLowerCase();
		if (["0", "inspekcje", "inspections"].includes(normalized)) {
			return { key: "0", label: "Inspekcje", sortOrder: 0 };
		}
		if (["1", "zalecenia", "recommendations"].includes(normalized)) {
			return { key: "1", label: "Zalecenia", sortOrder: 1 };
		}
		if (
			[
				"2",
				"wnioski sankcyjne",
				"wnioski_sankcyjne",
				"sanction requests",
				"sankcje",
			].includes(normalized)
		) {
			return { key: "2", label: "Wnioski sankcyjne", sortOrder: 2 };
		}
		if (
			[
				"3",
				"ogolne",
				"ogólne",
				"general",
				"common",
			].includes(normalized)
		) {
			return { key: "3", label: "Ogólne", sortOrder: -1 };
		}
		if (
			[
				"4",
				"decyzje zobowiązujące",
				"decyzje zobowiazujace",
				"decyzje_zobowiazujace",
				"commitment decisions",
			].includes(normalized)
		) {
			return { key: "4", label: "Decyzje zobowiązujące", sortOrder: 4 };
		}

		return { key: normalized, label: toHumanLabel(rawCategory.trim()), sortOrder: 100 };
	}

	const fallbackKey = inferCategoryKeyFromCode(type.kodTypu);
	if (fallbackKey === "1") {
		return { key: fallbackKey, label: "Zalecenia", sortOrder: 1 };
	}
	if (fallbackKey === "2") {
		return { key: fallbackKey, label: "Wnioski sankcyjne", sortOrder: 2 };
	}
	if (fallbackKey === "3") {
		return { key: fallbackKey, label: "Ogólne", sortOrder: -1 };
	}
	if (fallbackKey === "4") {
		return { key: fallbackKey, label: "Decyzje zobowiązujące", sortOrder: 4 };
	}

	return { key: fallbackKey, label: "Inspekcje", sortOrder: 0 };
}

function toTitleCaseFromCode(kodTypu: string) {
	return kodTypu
		.split("_")
		.filter(Boolean)
		.map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1))
		.join(" ");
}

function getDictionaryTypeLabel(type: DictionaryType) {
	const normalizedCode = type.kodTypu.trim().toLowerCase();
	if (normalizedCode === "rozstrzygniecie_decyzji_i") {
		return "Rozstrzygnięcie decyzji I";
	}
	if (normalizedCode === "rozstrzygniecie_decyzji_ii") {
		return "Rozstrzygnięcie decyzji II";
	}
	if (normalizedCode === "rozstrzygniecie_wniosku_sankcyjnego_i") {
		return "Rozstrzygnięcie wniosku sankcyjnego";
	}
	if (normalizedCode === "rynki") {
		return "Rynek";
	}
	if (normalizedCode === "statusy_inspekcji") {
		return "Status inspekcji";
	}
	if (normalizedCode === "statusy_zalecen") {
		return "Status zaleceń";
	}
	if (normalizedCode === "department_ogolne") {
		return "Departament";
	}

	const trimmedName = type.nazwaTypu.trim();
	if (trimmedName) {
		return trimmedName.charAt(0).toUpperCase() + trimmedName.slice(1);
	}

	return toTitleCaseFromCode(type.kodTypu);
}

export function DictionariesSheetPanel({
	operatorLogin,
	authRole,
	preferredKodTypu,
	tableOnly = false,
	title = "Arkusz słowników",
	subtitle = "Wybierz typ słownika, przeglądaj pozycje i dodawaj nowe wpisy.",
	canEdit = true,
}: DictionariesSheetPanelProps) {
	const {
		types,
		entries,
		selectedKodTypu,
		selectedType,
		setSelectedKodTypu,
		isTypesLoading,
		isEntriesLoading,
		typesError,
		entriesError,
		loadTypes,
		loadEntries,
		loadTeamLeaders,
		isAddModalOpen,
		openAddModal,
		closeAddModal,
		isAddingEntry,
		addEntryError,
		addEntryForm,
		setAddEntryForm,
		teamLeaders,
		isTeamLeadersLoading,
		isTeamsType,
		submitAddEntry,
	} = useDictionariesSheet({ operatorLogin });

	const [editingTeamEntry, setEditingTeamEntry] =
		useState<DictionaryEntry | null>(null);
	const [editingDictionaryEntry, setEditingDictionaryEntry] =
		useState<DictionaryEntry | null>(null);
	const [editDictionaryForm, setEditDictionaryForm] = useState({
		nazwaPozycji: "",
		nazwaUzytkowa: "",
		skrotPozycji: "",
		aktywny: true,
	});
	const [editDictionaryError, setEditDictionaryError] = useState<string | null>(
		null,
	);
	const [isSubmittingDictionaryEdit, setIsSubmittingDictionaryEdit] =
		useState(false);
	const [editTeamCode, setEditTeamCode] = useState("");
	const [editTeamName, setEditTeamName] = useState("");
	const [editTeamLeaderId, setEditTeamLeaderId] = useState<number | null>(null);
	const [editTeamError, setEditTeamError] = useState<string | null>(null);
	const [isSubmittingTeamEdit, setIsSubmittingTeamEdit] = useState(false);
	const [selectedCategoryKey, setSelectedCategoryKey] = useState("");

	const sortedTypes = useMemo(() => {
		const orderByCode: Record<string, number> = {
			nazwy_podmiotow: 10,
			typy_inspekcji: 20,
			zakresy_inspekcji: 30,
			rynki: 40,
			rodzaje_podmiotu: 50,
			statusy_inspekcji: 60,
			statusy_zalecen: 70,
			department_ogolne: 75,
			zespoly: 80,
			department: 210,
			sankcja: 220,
			podstawa_prawna_sankcji: 230,
			naruszenia_skutkujace_sankcja: 240,
			informacja_o_wszczeciu_postepowania_sankcyjnego: 250,
			rozstrzygniecie_wniosku_sankcyjnego_i: 260,
			nazwy_podmiotow_sankcje: 270,
			rozstrzygniecie_decyzji_i: 310,
			rozstrzygniecie_decyzji_ii: 320,
		};

		return types
			.filter((type) => {
				const normalizedCode = type.kodTypu.trim().toLowerCase();
				const hideTeamsInGeneralDictionaryView = !tableOnly;

				return (
					normalizedCode !== "osoby" &&
					normalizedCode !== "rozstrzygniecie_wniosku_sankcyjnego_ii" &&
					(!hideTeamsInGeneralDictionaryView || normalizedCode !== "zespoly")
				);
			})
			.sort((left, right) => {
				const leftCode = left.kodTypu.trim().toLowerCase();
				const rightCode = right.kodTypu.trim().toLowerCase();
				const leftOrder = orderByCode[leftCode] ?? Number.MAX_SAFE_INTEGER;
				const rightOrder = orderByCode[rightCode] ?? Number.MAX_SAFE_INTEGER;

				if (leftOrder !== rightOrder) {
					return leftOrder - rightOrder;
				}

				return getDictionaryTypeLabel(left).localeCompare(
					getDictionaryTypeLabel(right),
					"pl",
					{
						sensitivity: "base",
					},
				);
			});
	}, [tableOnly, types]);

	const categoryOptions = useMemo(() => {
		const categoryMap = new Map<string, DictionaryCategoryOption>();

		for (const type of sortedTypes) {
			const category = resolveCategoryOption(type);
			if (!categoryMap.has(category.key)) {
				categoryMap.set(category.key, category);
			}
		}

		return Array.from(categoryMap.values()).sort((left, right) => {
			if (left.sortOrder !== right.sortOrder) {
				return left.sortOrder - right.sortOrder;
			}

			return left.label.localeCompare(right.label, "pl", { sensitivity: "base" });
		});
	}, [sortedTypes]);

	const visibleTypes = useMemo(() => {
		if (tableOnly || !selectedCategoryKey) {
			return sortedTypes;
		}

		return sortedTypes.filter(
			(type) => resolveCategoryOption(type).key === selectedCategoryKey,
		);
	}, [selectedCategoryKey, sortedTypes, tableOnly]);

	const visibleSelectedType = useMemo(
		() => visibleTypes.find((type) => type.kodTypu === selectedKodTypu) ?? null,
		[selectedKodTypu, visibleTypes],
	);

	const handleCategorySelect = (categoryKey: string) => {
		setSelectedCategoryKey(categoryKey);

		const selectedStillVisible = sortedTypes.some(
			(type) =>
				type.kodTypu === selectedKodTypu &&
				resolveCategoryOption(type).key === categoryKey,
		);

		if (selectedStillVisible) {
			return;
		}

		const firstTypeInCategory = sortedTypes.find(
			(type) => resolveCategoryOption(type).key === categoryKey,
		);

		setSelectedKodTypu(firstTypeInCategory?.kodTypu ?? "");
	};

	const isTeamsSelected = selectedKodTypu.trim().toLowerCase() === "zespoly";
	const normalizedSelectedKodTypu = selectedKodTypu.trim().toLowerCase();
	const canEditCurrentType =
		canEdit &&
		(authRole !== "team_lead" ||
			TEAM_LEAD_EDITABLE_DICTIONARY_TYPE_CODES.has(normalizedSelectedKodTypu));
	const tableColumnCount = isTeamsSelected ? 5 : 4;

	const openTeamEditModal = (entry: DictionaryEntry) => {
		if (!canEditCurrentType) {
			return;
		}

		if (!entry.teamId) {
			return;
		}

		setEditingTeamEntry(entry);
		setEditTeamCode(entry.kodPozycji);
		setEditTeamName(entry.nazwaPozycji);
		setEditTeamLeaderId(entry.kierownikUserId ?? null);
		setEditTeamError(null);
		void loadTeamLeaders();
	};

	const openDictionaryEditModal = (entry: DictionaryEntry) => {
		if (!canEditCurrentType) {
			return;
		}

		setEditingDictionaryEntry(entry);
		setEditDictionaryForm({
			nazwaPozycji: entry.nazwaPozycji,
			nazwaUzytkowa: entry.nazwaUzytkowa ?? "",
			skrotPozycji: entry.skrotPozycji ?? "",
			aktywny: entry.aktywny,
		});
		setEditDictionaryError(null);
	};

	const closeDictionaryEditModal = () => {
		setEditingDictionaryEntry(null);
		setEditDictionaryError(null);
		setIsSubmittingDictionaryEdit(false);
	};

	const handleSubmitDictionaryEdit = async (
		event: React.FormEvent<HTMLFormElement>,
	) => {
		event.preventDefault();

		if (!canEditCurrentType) {
			setEditDictionaryError("Brak uprawnień do edycji słownika.");
			return;
		}

		if (!editingDictionaryEntry) {
			return;
		}

		if (!editDictionaryForm.nazwaPozycji.trim()) {
			setEditDictionaryError("Uzupełnij wymagane pola.");
			return;
		}

		setIsSubmittingDictionaryEdit(true);
		setEditDictionaryError(null);

		try {
			const result = await updateDictionaryEntry({
				operatorLogin,
				kodTypu: selectedKodTypu,
				entryId: editingDictionaryEntry.id,
				form: {
					kodPozycji: editingDictionaryEntry.kodPozycji,
					...editDictionaryForm,
					kierownikUserId: null,
				},
			});

			if (!result.ok) {
				setEditDictionaryError(result.error);
				return;
			}

			await loadEntries(selectedKodTypu, { forceRefresh: true });
			closeDictionaryEditModal();
		} catch {
			setEditDictionaryError("Nie udało się zaktualizować pozycji słownika.");
		} finally {
			setIsSubmittingDictionaryEdit(false);
		}
	};

	const closeTeamEditModal = () => {
		setEditingTeamEntry(null);
		setEditTeamCode("");
		setEditTeamName("");
		setEditTeamLeaderId(null);
		setEditTeamError(null);
		setIsSubmittingTeamEdit(false);
	};

	const handleSubmitTeamEdit = async (
		event: React.FormEvent<HTMLFormElement>,
	) => {
		event.preventDefault();

		if (!canEditCurrentType) {
			setEditTeamError("Brak uprawnień do edycji słownika.");
			return;
		}

		if (!editingTeamEntry?.teamId) {
			return;
		}

		if (!editTeamName.trim()) {
			setEditTeamError("Nazwa zespołu jest wymagana.");
			return;
		}

		if (!editTeamCode.trim()) {
			setEditTeamError("Kod zespołu jest wymagany.");
			return;
		}

		setIsSubmittingTeamEdit(true);
		setEditTeamError(null);

		try {
			const result = await updateTeamEntry({
				operatorLogin,
				teamId: editingTeamEntry.teamId,
				kod: editTeamCode,
				nazwa: editTeamName,
				kierownikUserId: editTeamLeaderId,
			});

			if (!result.ok) {
				setEditTeamError(result.error);
				return;
			}

			await loadEntries(selectedKodTypu, { forceRefresh: true });
			closeTeamEditModal();
		} catch {
			setEditTeamError("Nie udało się zaktualizować zespołu.");
		} finally {
			setIsSubmittingTeamEdit(false);
		}
	};

	useEffect(() => {
		void loadTypes();
	}, [loadTypes]);

	useEffect(() => {
		if (!selectedKodTypu) {
			return;
		}

		void loadEntries(selectedKodTypu);
	}, [loadEntries, selectedKodTypu]);

	useEffect(() => {
		if (tableOnly) {
			return;
		}

		if (categoryOptions.length === 0) {
			if (selectedCategoryKey) {
				setSelectedCategoryKey("");
			}
			return;
		}

		const isSelectedCategoryVisible = categoryOptions.some(
			(category) => category.key === selectedCategoryKey,
		);

		if (!isSelectedCategoryVisible) {
			setSelectedCategoryKey(categoryOptions[0]?.key ?? "");
		}
	}, [categoryOptions, selectedCategoryKey, tableOnly]);

	useEffect(() => {
		if (visibleTypes.length === 0) {
			setSelectedKodTypu("");
			return;
		}

		const selectedIsVisible = visibleTypes.some(
			(type) => type.kodTypu === selectedKodTypu,
		);
		if (!selectedIsVisible) {
			const firstVisibleType = visibleTypes[0];
			if (firstVisibleType) {
				setSelectedKodTypu(firstVisibleType.kodTypu);
			}
		}
	}, [selectedKodTypu, setSelectedKodTypu, visibleTypes]);

	useEffect(() => {
		const normalizedPreferred = preferredKodTypu?.trim();
		if (!normalizedPreferred) {
			return;
		}

		const preferredType = sortedTypes.find(
			(type) => type.kodTypu === normalizedPreferred,
		);
		if (!preferredType) {
			return;
		}

		const preferredCategoryKey = resolveCategoryOption(preferredType).key;
		if (preferredCategoryKey !== selectedCategoryKey) {
			setSelectedCategoryKey(preferredCategoryKey);
		}

		if (selectedKodTypu !== normalizedPreferred) {
			setSelectedKodTypu(normalizedPreferred);
		}
	}, [
		preferredKodTypu,
		selectedCategoryKey,
		selectedKodTypu,
		setSelectedKodTypu,
		sortedTypes,
	]);

	const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();
		if (!canEditCurrentType) {
			return;
		}
		await submitAddEntry();
	};

	return (
		<section
			className={`rounded-2xl border border-slate-700/70 bg-[#101f39] p-4 sm:p-5 ${
				tableOnly
					? "relative flex h-[calc(100vh-2.2rem)] min-h-[40rem] flex-col"
					: ""
			}`}
		>
			<div className="mb-4 border-slate-700/70 border-b pb-3">
				<div>
					<h2 className="font-semibold text-lg text-slate-100">
						{title}
					</h2>
					{subtitle.trim() ? (
						<p className="mt-1 text-slate-300/85 text-sm">
							{subtitle}
						</p>
					) : null}
				</div>
			</div>

			{!tableOnly ? (
				<div className="mb-4 rounded-xl border border-slate-700/70 bg-[#0f1c34] p-2">
					<p className="mb-2 px-1 font-semibold text-slate-300/90 text-xs uppercase tracking-[0.08em]">
						Kategoria słowników
					</p>
					<div className="flex flex-wrap gap-2">
						{categoryOptions.map((category) => {
							const isActive = selectedCategoryKey === category.key;

							return (
								<button
									key={category.key}
									type="button"
									onClick={() => handleCategorySelect(category.key)}
									className={`inline-flex items-center whitespace-nowrap rounded-lg border px-3 py-2 font-semibold text-sm transition-colors ${
										isActive
											? "border-[#84b0f2] bg-[#345689] text-white"
											: "border-slate-600/50 bg-slate-900/40 text-slate-200 hover:bg-slate-800/70"
									}`}
								>
									{category.label}
								</button>
							);
						})}
					</div>
				</div>
			) : null}

			<div
				className={
					tableOnly
						? "flex min-h-0 flex-1 flex-col"
						: "grid gap-4 lg:grid-cols-[minmax(220px,260px)_1fr]"
				}
			>
				{!tableOnly ? (
					<aside className="rounded-xl border border-slate-700/70 bg-[#0f1c34] p-3">
						<p className="mb-2 font-semibold text-slate-300/90 text-xs uppercase tracking-[0.08em]">
							Typ słownika
						</p>

						{isTypesLoading ? (
							<p className="text-slate-300 text-sm">Ładowanie typów...</p>
						) : null}
						{typesError ? (
							<p className="font-medium text-rose-300 text-sm">{typesError}</p>
						) : null}

						<div className="subtle-vertical-scroll min-h-64 max-h-[calc(100vh-24rem)] space-y-1.5 overflow-y-auto pr-1">
							{visibleTypes.length === 0 ? (
								<p className="rounded-lg border border-slate-600/40 bg-slate-900/35 px-2.5 py-2 text-slate-300 text-sm">
									Brak typów słowników w tej kategorii.
								</p>
							) : null}
							{visibleTypes.map((type) => {
								const isActive = type.kodTypu === selectedKodTypu;

								return (
									<button
										key={type.kodTypu}
										type="button"
										onClick={() => setSelectedKodTypu(type.kodTypu)}
										className={`w-full rounded-lg border px-2.5 py-2 text-left text-sm transition-colors ${
											isActive
												? "border-[#84b0f2] bg-[#345689] text-white"
												: "border-slate-600/50 bg-slate-900/40 text-slate-200 hover:bg-slate-800/70"
										}`}
									>
										<p className="font-semibold">
											{getDictionaryTypeLabel(type)}
										</p>
									</button>
								);
							})}
						</div>
					</aside>
				) : null}

				<div className={tableOnly ? "flex min-h-0 flex-1 flex-col" : ""}>
					<div className="mb-3 flex flex-wrap justify-end gap-2">
						{canEditCurrentType ? (
							<button
								type="button"
								onClick={openAddModal}
								disabled={!selectedKodTypu}
								className="inline-flex h-10 items-center gap-2 rounded-lg border border-[#8ec5a1] bg-[#b9e8c9] px-3.5 font-semibold text-[#1f5130] text-sm shadow-[inset_0_1px_0_rgba(255,255,255,0.45)] transition-colors hover:bg-[#a5debb] disabled:cursor-not-allowed disabled:opacity-60"
							>
								<Plus size={15} />
								Dodaj pozycję słownika
							</button>
						) : (
							<span className="inline-flex h-10 items-center rounded-lg border border-slate-300 bg-slate-100 px-3.5 font-semibold text-slate-600 text-sm">
								Tryb tylko do odczytu
							</span>
						)}
					</div>

					<TableSurface
						isLoading={isEntriesLoading}
						loadingMessage="Ładowanie pozycji..."
						errorMessage={entriesError}
						containerClassName={tableOnly ? "min-h-0 flex-1" : ""}
						scrollAreaClassName={
							tableOnly ? "h-full min-h-0 pr-2" : "h-[calc(100vh-19rem)] min-h-96 pr-2"
						}
					>
					<table className="min-w-full table-fixed border-collapse text-slate-900 text-sm">
						<thead className="sticky top-0 z-10">
							<tr className="bg-slate-100 text-slate-800">
								<th className="w-[48%] border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">
									{isTeamsSelected ? "Nazwa zespołu" : "Nazwa pełna"}
								</th>
								<th className="w-[22%] border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">
									{isTeamsSelected ? "Skrót nazwy zespołu" : "Nazwa skrócona"}
								</th>
								{isTeamsSelected ? (
									<th className="w-[18%] border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">
										Kierownik
									</th>
								) : null}
								<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">
									Status
								</th>
								<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">
									
								</th>
							</tr>
						</thead>

						<tbody>
							{entries.map((entry) => (
								<tr
									key={`${entry.kodTypu}-${entry.kodPozycji}`}
									className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
								>
									<td
										className="break-words px-3 py-2.5 align-top whitespace-normal"
										title={entry.nazwaPozycji}
									>
										{entry.nazwaPozycji}
									</td>
									<td
										className="break-words px-3 py-2.5 align-top whitespace-normal"
										title={entry.skrotPozycji || "-"}
									>
										{entry.skrotPozycji || "-"}
									</td>
									{isTeamsSelected ? (
										<td
											className="break-words px-3 py-2.5 align-top whitespace-normal"
											title={entry.kierownikDisplayName || "-"}
										>
											{entry.kierownikDisplayName || "-"}
										</td>
									) : null}
									<td className="whitespace-nowrap px-3 py-2.5">
										<span
											className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${
												entry.aktywny
													? "bg-emerald-100 text-emerald-800"
													: "bg-slate-200 text-slate-700"
											}`}
										>
											{entry.aktywny ? "Aktywny" : "Nieaktywny"}
										</span>
									</td>
									<td className="whitespace-nowrap px-3 py-2.5">
										<button
											type="button"
											onClick={() =>
												isTeamsSelected
													? openTeamEditModal(entry)
													: openDictionaryEditModal(entry)
											}
											disabled={!canEditCurrentType || (isTeamsSelected ? !entry.teamId : false)}
											className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
										>
											<Pencil size={12} />
											Edytuj
										</button>
									</td>
								</tr>
							))}

							{!isEntriesLoading && entries.length === 0 ? (
								<tr>
									<td
										colSpan={tableColumnCount}
										className="px-3 py-8 text-center text-slate-500"
									>
										Brak pozycji dla wybranego typu słownika.
									</td>
								</tr>
							) : null}
						</tbody>
					</table>
					</TableSurface>
				</div>
			</div>

			{canEditCurrentType ? (
				<AddDictionaryEntryModal
					isOpen={isAddModalOpen}
					isSubmitting={isAddingEntry}
					error={addEntryError}
					form={addEntryForm}
					isTeamsType={isTeamsType}
					teamLeaders={teamLeaders}
					isTeamLeadersLoading={isTeamLeadersLoading}
					onClose={closeAddModal}
					onSubmit={handleSubmit}
					onFormChange={setAddEntryForm}
				/>
			) : null}

			{editingDictionaryEntry ? (
				<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
					<div
						aria-hidden="true"
						className="absolute inset-0 bg-slate-950/65"
					/>

					<div
						role="dialog"
						aria-modal="true"
						aria-label="Edytuj pozycję słownika"
						className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
					>
						<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
							<div>
								<h3 className="font-semibold text-base text-slate-900">
									Edytuj pozycję słownika
								</h3>
							</div>

							<button
								type="button"
								onClick={closeDictionaryEditModal}
								className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
							>
								<X size={14} />
							</button>
						</div>

						<form className="space-y-4" onSubmit={handleSubmitDictionaryEdit}>
							<div className="grid gap-3 sm:grid-cols-2">
								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">Nazwa pełna *</span>
									<input
										required
										value={editDictionaryForm.nazwaPozycji}
										onChange={(event) =>
											setEditDictionaryForm((previous) => ({
												...previous,
												nazwaPozycji: event.target.value,
											}))
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>

								<label className="text-slate-700 text-sm">
									<span className="mb-1 block">Nazwa skrócona</span>
									<input
										value={editDictionaryForm.skrotPozycji}
										onChange={(event) =>
											setEditDictionaryForm((previous) => ({
												...previous,
												skrotPozycji: event.target.value,
											}))
										}
										className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									/>
								</label>
							</div>

							<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
								<input
									type="checkbox"
									checked={editDictionaryForm.aktywny}
									onChange={(event) =>
										setEditDictionaryForm((previous) => ({
											...previous,
											aktywny: event.target.checked,
										}))
									}
								/>
								Aktywny
							</label>

							{editDictionaryError ? (
								<p className="font-medium text-rose-600 text-sm">
									{editDictionaryError}
								</p>
							) : null}

							<div className="flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
								<button
									type="button"
									onClick={closeDictionaryEditModal}
									className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
								>
									Anuluj
								</button>

								<button
									type="submit"
									disabled={isSubmittingDictionaryEdit}
									className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
								>
									{isSubmittingDictionaryEdit
										? "Zapisywanie..."
										: "Zapisz zmiany"}
								</button>
							</div>
						</form>
					</div>
				</div>
			) : null}

			{editingTeamEntry ? (
				<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
					<div
						aria-hidden="true"
						className="absolute inset-0 bg-slate-950/65"
					/>

					<div
						role="dialog"
						aria-modal="true"
						aria-label="Edytuj zespół"
						className="relative z-10 w-full max-w-xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
					>
						<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
							<div>
								<h3 className="font-semibold text-base text-slate-900">
									Edytuj zespół
								</h3>
								<p className="mt-1 text-slate-600 text-sm">
									Skrót nazwy zespołu: {editingTeamEntry.kodPozycji}
								</p>
							</div>

							<button
								type="button"
								onClick={closeTeamEditModal}
								className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
							>
								<X size={14} />
							</button>
						</div>

						<form className="space-y-4" onSubmit={handleSubmitTeamEdit}>
							<label className="block text-slate-700 text-sm">
								<span className="mb-1 block">Skrót nazwy zespołu *</span>
								<input
									required
									value={editTeamCode}
									onChange={(event) =>
										setEditTeamCode(event.target.value.toUpperCase())
									}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm uppercase outline-none transition-colors focus:border-blue-400"
								/>
							</label>

							<label className="block text-slate-700 text-sm">
								<span className="mb-1 block">Nazwa zespołu *</span>
								<input
									required
									value={editTeamName}
									onChange={(event) => setEditTeamName(event.target.value)}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>

							<div className="block">
								<SingleSelectPortalField
									label="Kierownik zespołu (opcjonalnie)"
									value={editTeamLeaderId ? String(editTeamLeaderId) : ""}
									options={teamLeaders.map((leader) => ({
										value: String(leader.id),
										label: leader.displayName,
									}))}
									placeholder="Bez kierownika"
									onChange={(next) => setEditTeamLeaderId(next ? Number(next) : null)}
									disabled={isTeamLeadersLoading}
								/>
								{isTeamLeadersLoading ? (
									<p className="mt-1 text-slate-500 text-xs">
										Ładowanie użytkowników...
									</p>
								) : null}
							</div>

							{editTeamError ? (
								<p className="font-medium text-rose-600 text-sm">
									{editTeamError}
								</p>
							) : null}

							<div className="flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
								<button
									type="button"
									onClick={closeTeamEditModal}
									className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
								>
									Anuluj
								</button>

								<button
									type="submit"
									disabled={isSubmittingTeamEdit}
									className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
								>
									{isSubmittingTeamEdit ? "Zapisywanie..." : "Zapisz zmiany"}
								</button>
							</div>
						</form>
					</div>
				</div>
			) : null}
		</section>
	);
}

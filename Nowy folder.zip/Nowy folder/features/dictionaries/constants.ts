import type { AddDictionaryEntryForm } from "@/features/dictionaries/types";

export const DEFAULT_ADD_DICTIONARY_ENTRY_FORM: AddDictionaryEntryForm = {
	kodPozycji: "",
	nazwaPozycji: "",
	nazwaUzytkowa: "",
	skrotPozycji: "",
	aktywny: true,
	kierownikUserId: null,
};

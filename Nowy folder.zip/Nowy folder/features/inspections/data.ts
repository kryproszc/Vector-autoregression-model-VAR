import type {
	InspectionColumn,
	InspectionColumnKey,
	InspectionRow,
	InspectionViewOption,
} from "@/features/inspections/types";

export const INSPECTION_ROWS: InspectionRow[] = [];

export const INSPECTION_COLUMNS: InspectionColumn[] = [
	{ key: "lp", label: "Lp." },
	{ key: "kodInspekcji", label: "Id inspekcji" },
	{ key: "nazwaPodmiotu", label: "Nazwa podmiotu" },
	{ key: "typInspekcji", label: "Typ inspekcji" },
	{ key: "zakresInspekcji", label: "Zakres inspekcji według upoważnienia" },
	{
		key: "szczegolyDotyczaceZakresu",
		label: "Szczegóły dotyczące zakresu",
	},
	{ key: "aspektKonsumencki", label: "Aspekt konsumencki" },
	{ key: "poczatekInspekcji", label: "Początek inspekcji" },
	{ key: "koniecInspekcji", label: "Koniec inspekcji" },
	{
		key: "osobaKierujaca",
		label: "Osoba kierująca kontrolą / wizytą",
	},
	{ key: "skladZespolu", label: "Skład zespołu inspekcyjnego" },
	{ key: "rynek", label: "Rynek" },
	{ key: "rodzajPodmiotu", label: "Rodzaj podmiotu" },
	{
		key: "dataProtokolu",
		label: "Data protokołu / sprawozdania",
	},
	{ key: "dataDoreczeniaProtokolu", label: "Data doręczenia protokołu" },
	{
		key: "dataAkceptacjiSprawozdania",
		label: "Data akceptacji sprawozdania z wizyty",
	},
	{ key: "dataDoreczeniaPisma", label: "Data doręczenia pisma po wizycie" },
	{
		key: "dataPismaZastrzezenia",
		label:
			"Data pisma z zastrzeżeniami do protokołu / pisma po wizycie",
	},
	{
		key: "dataWyslaniaPismaZZastrzezeniami",
		label: "Data wysłania pisma z zastrzeżeniami",
	},
	{
		key: "dataWplywuPisma",
		label:
			"Data wpływu pisma z zastrzeżeniami do protokołu / pisma po wizycie",
	},
	{
		key: "dataPismaZOdpowiedzia",
		label: "Data pisma z odpowiedzią na zastrzeżenia",
	},
	{
		key: "dataWyslaniaPismaZOdpowiedzia",
		label: "Data wysłania pisma z odpowiedzią na zastrzeżenia",
	},
	{ key: "dataAkceptacjiNoty", label: "Data akceptacji noty" },
	{ key: "dataZalecen", label: "Data zaleceń" },
	{ key: "status", label: "Status" },
	{ key: "komentarz", label: "Komentarz" },
];

export const INSPECTION_COLUMN_TOOLTIPS: Partial<
	Record<InspectionColumnKey, string>
> = {
	kodInspekcji: "Unikalne id inspekcji",
	osobaKierujaca:
		"K: Osoba kierująca kontrolą\nWN: Osoba koordynująca wizytę nadzorczą",
	dataProtokolu:
		"K: Data protokołu kontroli\nWN: Data sprawozdania z wizyty nadzorczej",
	dataDoreczeniaProtokolu:
		"K: Data doręczenia protokołu kontroli\nWN: Nie dotyczy (pole tylko dla kontroli)",
	dataAkceptacjiSprawozdania:
		"K: Nie dotyczy (pole tylko dla wizyty nadzorczej)\nWN: Data akceptacji sprawozdania z wizyty nadzorczej",
	dataDoreczeniaPisma:
		"K: Nie dotyczy (pole tylko dla wizyty nadzorczej)\nWN: Data doręczenia pisma do podmiotu z ustaleniami wizyty nadzorczej",
	dataPismaZastrzezenia:
		"K: Data pisma podmiotu z zastrzeżeniami do protokołu kontroli\nWN: Data uwag do pisma po wizycie nadzorczej",
	dataWyslaniaPismaZZastrzezeniami:
		"K: Data wysłania pisma podmiotu z zastrzeżeniami do protokołu kontroli\nWN: Data wysłania uwag do pisma po wizycie nadzorczej",
	dataWplywuPisma:
		"K: Data wpływu pisma podmiotu z zastrzeżeniami do protokołu kontroli\nWN: Data wpływu uwag do pisma po wizycie nadzorczej",
	dataPismaZOdpowiedzia:
		"K: Data pisma z odpowiedzią na zastrzeżenia do protokołu kontroli\nWN: Nie dotyczy (pole tylko dla kontroli)",
	dataWyslaniaPismaZOdpowiedzia:
		"K: Data wysłania pisma z odpowiedzią na zastrzeżenia do protokołu kontroli\nWN: Data wysłania pisma z odpowiedzią na uwagi do pisma po wizycie nadzorczej",
	dataAkceptacjiNoty:
		"K: Data akceptacji noty z rekomendacjami dalszych działań nadzorczych\nWN: Data akceptacji noty z rekomendacjami dalszych działań nadzorczych",
	dataZalecen:
		"K: Data zaleceń (wartość z arkusza Zaleceń)\nWN: Data zaleceń (wartość z arkusza Zaleceń)",
};

export const ALL_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] =
	INSPECTION_COLUMNS.map((column) => column.key);

export const PODSTAWOWE_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] = [
	"nazwaPodmiotu",
	"typInspekcji",
	"zakresInspekcji",
	"poczatekInspekcji",
	"koniecInspekcji",
	"osobaKierujaca",
	"dataDoreczeniaProtokolu",
	"dataAkceptacjiSprawozdania",
	"dataDoreczeniaPisma",
	"dataWplywuPisma",
	"dataWyslaniaPismaZOdpowiedzia",
	"dataAkceptacjiNoty",
	"dataZalecen",
	"status",
];

export const TERMINY_INSPECTION_COLUMN_KEYS: InspectionColumnKey[] =
	ALL_INSPECTION_COLUMN_KEYS.filter(
		(columnKey) =>
			columnKey !== "kodInspekcji" &&
			columnKey !== "aspektKonsumencki" &&
			columnKey !== "skladZespolu" &&
			columnKey !== "rynek",
	);

export const INSPECTION_VIEW_OPTIONS: InspectionViewOption[] = [
	{
		id: "calosc",
		label: "Całość",
		description: "",
	},
	{
		id: "terminy",
		label: "Szczegółowy",
		description: "",
	},
	{
		id: "podstawowe",
		label: "Podstawowy",
		description: "",
	},
];

import type { ReactNode } from "react";

import { TableHeaderWithFilters } from "@/shared/components/table/TableHeaderWithFilters";
import { TableSurface } from "@/shared/components/table/TableSurface";
import type { TableSortDirection } from "@/shared/types/table";

type RegistryTableColumn<TColumnKey extends string> = {
	key: TColumnKey;
	label: string;
	tooltip?: string;
};

type RegistryDataTableProps<TColumnKey extends string> = {
	isLoading?: boolean;
	errorMessage?: string | null;
	footer?: ReactNode;
	containerClassName?: string;
	scrollAreaClassName?: string;
	tableClassName?: string;
	visibleColumns: RegistryTableColumn<TColumnKey>[];
	sortColumnKey: TColumnKey | null;
	sortDirection: TableSortDirection | null;
	advancedFilters: Partial<Record<TColumnKey, string[]>>;
	columnFilters: Partial<Record<TColumnKey, string>>;
	onSortByColumn: (columnKey: TColumnKey) => void;
	onOpenAdvancedFilter: (columnKey: TColumnKey, triggerElement: HTMLElement) => void;
	onFilterChange: (columnKey: TColumnKey, value: string) => void;
	columnWidths?: Partial<Record<TColumnKey, number>>;
	columnMinWidths?: Partial<Record<TColumnKey, number>>;
	onResizeColumn?: (columnKey: TColumnKey, width: number) => void;
	minColumnWidth?: number;
	compact?: boolean;
	wrapHeaderLabels?: boolean;
	controlsInFilterRow?: boolean;
	showInfoIcon?: boolean;
	infoIconSize?: number;
	children: ReactNode;
};

export function RegistryDataTable<TColumnKey extends string>({
	isLoading = false,
	errorMessage = null,
	footer,
	containerClassName,
	scrollAreaClassName,
	tableClassName = "min-w-full border-collapse text-slate-900 text-sm",
	visibleColumns,
	sortColumnKey,
	sortDirection,
	advancedFilters,
	columnFilters,
	onSortByColumn,
	onOpenAdvancedFilter,
	onFilterChange,
	columnWidths,
	columnMinWidths,
	onResizeColumn,
	minColumnWidth,
	compact = false,
	wrapHeaderLabels = false,
	controlsInFilterRow = false,
	showInfoIcon = true,
	infoIconSize,
	children,
}: RegistryDataTableProps<TColumnKey>) {
	return (
		<TableSurface
			isLoading={isLoading}
			errorMessage={errorMessage}
			footer={footer}
			containerClassName={containerClassName}
			scrollAreaClassName={scrollAreaClassName}
		>
			<table className={tableClassName}>
				<TableHeaderWithFilters
					visibleColumns={visibleColumns}
					sortColumnKey={sortColumnKey}
					sortDirection={sortDirection}
					advancedFilters={advancedFilters}
					columnFilters={columnFilters}
					onSortByColumn={onSortByColumn}
					onOpenAdvancedFilter={onOpenAdvancedFilter}
					onFilterChange={onFilterChange}
					columnWidths={columnWidths}
					columnMinWidths={columnMinWidths}
					onResizeColumn={onResizeColumn}
					minColumnWidth={minColumnWidth}
					compact={compact}
					wrapHeaderLabels={wrapHeaderLabels}
					controlsInFilterRow={controlsInFilterRow}
					showInfoIcon={showInfoIcon}
					infoIconSize={infoIconSize}
				/>
				{children}
			</table>
		</TableSurface>
	);
}

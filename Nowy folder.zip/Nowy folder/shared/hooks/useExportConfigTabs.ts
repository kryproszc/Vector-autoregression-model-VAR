import { useMemo } from "react";

export type ExportConfigRelationTabState = {
	id: string;
	enabled: boolean;
};

export function useExportConfigTabs(
	relations: ExportConfigRelationTabState[],
	activeTabId: string,
) {
	const enabledTabIds = useMemo(
		() => relations.filter((relation) => relation.enabled).map((relation) => relation.id),
		[relations],
	);

	const resolvedTabId = useMemo(() => {
		if (enabledTabIds.length === 0) {
			return null;
		}

		if (enabledTabIds.includes(activeTabId)) {
			return activeTabId;
		}

		return enabledTabIds[0];
	}, [activeTabId, enabledTabIds]);

	return {
		enabledTabIds,
		resolvedTabId,
	};
}
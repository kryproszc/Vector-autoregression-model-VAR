export type RecordLockOwner = {
	userId: string;
	login: string;
	displayName: string;
};

export type RecordLockDetails = {
	module: string;
	recordId: string;
	owner: RecordLockOwner | null;
	acquiredAt: string | null;
	expiresAt: string | null;
	lockToken: string | null;
};

type RecordLockApiSuccess = {
	ok: true;
	data: RecordLockDetails;
};

type RecordLockApiError = {
	ok: false;
	status: number;
	error: string;
	lockDetails: RecordLockDetails | null;
	errorCode?: string;
	reason?: string;
};

export type RecordLockApiResult = RecordLockApiSuccess | RecordLockApiError;

const LOCKS_BASE_PATH = "/api/locks";

function toStringValue(value: unknown) {
	return typeof value === "string" ? value.trim() : "";
}

function parseLockDetails(payload: unknown, fallback: { module: string; recordId: string }): RecordLockDetails {
	const source = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
	const ownerDisplayName = toStringValue(source.ownerDisplayName);
	const ownerLogin = toStringValue(source.ownerLogin);
	const ownerUserId = toStringValue(source.ownerUserId);

	return {
		module: toStringValue(source.module) || fallback.module,
		recordId: toStringValue(source.recordId) || fallback.recordId,
		owner:
			ownerDisplayName || ownerLogin || ownerUserId
				? {
					userId: ownerUserId,
					login: ownerLogin,
					displayName: ownerDisplayName,
				}
				: null,
		acquiredAt: toStringValue(source.acquiredAt) || null,
		expiresAt: toStringValue(source.expiresAt) || null,
		lockToken: toStringValue(source.lockToken) || null,
	};
}

async function readResponseDetails(response: Response, fallback: { module: string; recordId: string }) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return {
			detail: "",
			lockDetails: null,
		};
	}

	try {
		const payload = (await response.json()) as unknown;
		const source = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
		const detailRaw = source.detail ?? source.message;
		const detail = typeof detailRaw === "string" ? detailRaw.trim() : "";
		const hasLockPayload =
			typeof source.ownerDisplayName === "string" ||
			typeof source.ownerLogin === "string" ||
			typeof source.ownerUserId === "string" ||
			typeof source.lockToken === "string" ||
			typeof source.acquiredAt === "string";

		return {
			detail,
			lockDetails: hasLockPayload ? parseLockDetails(payload, fallback) : null,
			errorCode: toStringValue(source.code) || undefined,
			reason: toStringValue(source.reason) || undefined,
		};
	} catch {
		return {
			detail: "",
			lockDetails: null,
			errorCode: undefined,
			reason: undefined,
		};
	}
}

function createErrorMessage(
	status: number,
	detail: string,
	errorCode?: string,
	reason?: string,
) {
	const base =
		status === 401
			? "Brak sesji lub sesja wygasła."
			: status === 403
				? "Brak uprawnień do edycji wpisu."
				: status === 404
					? "Rekord nie istnieje."
					: status === 423
						? errorCode === "LOCK_REQUIRED" || reason === "lock_required"
							? "Aby zapisać, najpierw musisz posiadać aktywną blokadę rekordu."
							: errorCode === "LOCK_TOKEN_INVALID" || reason === "lock_token_invalid"
								? "Blokada edycji wygasła lub jest nieprawidłowa."
								: "Rekord jest aktualnie edytowany przez innego użytkownika."
						: `Błąd blokady rekordu (${status}).`;

	return detail ? `${base} ${detail}` : base;
}

async function performLockRequest(params: {
	module: string;
	recordId: string;
	operatorLogin: string;
	action: "acquire" | "heartbeat" | "release";
	lockToken?: string;
}): Promise<RecordLockApiResult> {
	const recordId = params.recordId.trim();
	const moduleName = params.module.trim();
	const endpoint = `${LOCKS_BASE_PATH}/${encodeURIComponent(moduleName)}/${encodeURIComponent(recordId)}/${params.action}`;
	const bodyPayload = params.lockToken ? { lockToken: params.lockToken } : {};

	console.log(`[record-lock] ${params.action.toUpperCase()} ${endpoint}`, { recordId, module: moduleName });

	const response = await fetch(endpoint, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": params.operatorLogin,
		},
		body: JSON.stringify(bodyPayload),
	});

	if (!response.ok) {
		const { detail, lockDetails, errorCode, reason } = await readResponseDetails(response, {
			module: moduleName,
			recordId,
		});
		return {
			ok: false,
			status: response.status,
			error: createErrorMessage(response.status, detail, errorCode, reason),
			lockDetails,
			errorCode,
			reason,
		};
	}

	const fallback = {
		module: moduleName,
		recordId,
	};
	const contentType = response.headers.get("content-type") ?? "";
	const payload = contentType.includes("application/json") ? ((await response.json()) as unknown) : {};
	const parsed = parseLockDetails(payload, fallback);

	if (params.lockToken && !parsed.lockToken) {
		parsed.lockToken = params.lockToken;
	}

	return {
		ok: true,
		data: parsed,
	};
}

export function acquireRecordLock(params: {
	module: string;
	recordId: string;
	operatorLogin: string;
}) {
	return performLockRequest({ ...params, action: "acquire" });
}

export function heartbeatRecordLock(params: {
	module: string;
	recordId: string;
	operatorLogin: string;
	lockToken: string;
}) {
	return performLockRequest({ ...params, action: "heartbeat" });
}

export function releaseRecordLock(params: {
	module: string;
	recordId: string;
	operatorLogin: string;
	lockToken: string;
}) {
	return performLockRequest({ ...params, action: "release" });
}

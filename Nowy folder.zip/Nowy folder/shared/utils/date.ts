const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const ISO_DATE_IN_TEXT_PATTERN =
	/(^|[^0-9])(\d{4})-(\d{2})-(\d{2})(?=[^0-9T]|$)/g;

function isValidIsoDate(value: string) {
	if (!ISO_DATE_PATTERN.test(value)) {
		return false;
	}

	const [yearText, monthText, dayText] = value.split("-");
	const year = Number(yearText);
	const month = Number(monthText);
	const day = Number(dayText);
	const date = new Date(year, month - 1, day);

	return (
		Number.isInteger(year) &&
		Number.isInteger(month) &&
		Number.isInteger(day) &&
		date.getFullYear() === year &&
		date.getMonth() === month - 1 &&
		date.getDate() === day
	);
}

function normalizeDateList(values: string[]) {
	const normalized = values
		.map((item) => item.trim())
		.filter((item) => ISO_DATE_PATTERN.test(item));

	return Array.from(new Set(normalized)).sort((left, right) =>
		left.localeCompare(right),
	);
}

export function toDateInputValue(value: unknown) {
	const normalized =
		value === null || value === undefined ? "" : String(value).trim();

	if (!normalized) {
		return "";
	}

	if (ISO_DATE_PATTERN.test(normalized)) {
		return normalized;
	}

	const extractedDate = normalized.slice(0, 10);
	return ISO_DATE_PATTERN.test(extractedDate) ? extractedDate : "";
}

export function toDateList(value: unknown) {
	if (!Array.isArray(value)) {
		return [];
	}

	return normalizeDateList(
		value.map((item) => toDateInputValue(item)).filter(Boolean),
	);
}

export function parseIsoDateListFromText(value: string) {
	return normalizeDateList(value.split(/[\n,;]/));
}

export function formatIsoDateForDisplay(value: unknown) {
	const isoDate = toDateInputValue(value);
	if (!isoDate || !isValidIsoDate(isoDate)) {
		return "";
	}

	const [year, month, day] = isoDate.split("-");
	return `${day}.${month}.${year}`;
}

export function formatDatesInDisplayText(value: string) {
	if (!value) {
		return value;
	}

	return value.replace(
		ISO_DATE_IN_TEXT_PATTERN,
		(_match, prefix: string, year: string, month: string, day: string) => {
			const isoDate = `${year}-${month}-${day}`;
			if (!isValidIsoDate(isoDate)) {
				return `${prefix}${isoDate}`;
			}

			return `${prefix}${day}.${month}.${year}`;
		},
	);
}

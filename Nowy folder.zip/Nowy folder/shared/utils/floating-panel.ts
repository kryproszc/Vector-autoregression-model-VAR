type FloatingPanelAnchor = {
	top: number;
	left: number;
};

type FloatingPanelOptions = {
	panelWidth?: number;
	panelHeight?: number;
	margin?: number;
	offsetY?: number;
};

export function getFloatingPanelAnchor(
	triggerElement: HTMLElement,
	options: FloatingPanelOptions = {},
): FloatingPanelAnchor {
	const {
		panelWidth = 340,
		panelHeight = 420,
		margin = 8,
		offsetY = 6,
	} = options;

	const rect = triggerElement.getBoundingClientRect();
	const viewportWidth = window.innerWidth;
	const viewportHeight = window.innerHeight;

	const left = Math.max(
		margin,
		Math.min(rect.left, viewportWidth - panelWidth - margin),
	);
	const top = Math.max(
		margin,
		Math.min(rect.bottom + offsetY, viewportHeight - panelHeight - margin),
	);

	return { top, left };
}

import type {
	AddDictionaryEntryForm,
	DictionaryColorPalette,
	DictionaryColorShade,
	DictionaryEntry,
	DictionaryType,
	TeamLeaderOption,
} from "@/features/dictionaries/types";

const ALLOWED_COLOR_PALETTES: DictionaryColorPalette[] = [
	"emerald",
	"green",
	"teal",
	"lime",
	"sky",
	"cyan",
	"blue",
	"indigo",
	"rose",
	"red",
	"pink",
	"fuchsia",
	"yellow",
	"amber",
	"orange",
];

const ALLOWED_COLOR_SHADES: DictionaryColorShade[] = [
	50,
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900,
	950,
];

type Result<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
	  };

function asRecord(value: unknown): Record<string, unknown> | null {
	if (!value || typeof value !== "object" || Array.isArray(value)) {
		return null;
	}

	return value as Record<string, unknown>;
}

function readString(value: unknown): string | null {
	if (typeof value !== "string") {
		return null;
	}

	return value;
}

function readNumber(value: unknown): number | null {
	if (typeof value === "number" && Number.isFinite(value)) {
		return value;
	}

	if (typeof value === "string") {
		const parsed = Number(value);
		if (Number.isFinite(parsed)) {
			return parsed;
		}
	}

	return null;
}

function readBoolean(value: unknown): boolean {
	if (typeof value === "boolean") {
		return value;
	}

	if (typeof value === "number") {
		return value !== 0;
	}

	if (typeof value === "string") {
		const normalized = value.trim().toLowerCase();
		return normalized === "1" || normalized === "true" || normalized === "t";
	}

	return false;
}

function normalizeColorPalette(value: string | null): DictionaryColorPalette | null {
	if (!value) {
		return null;
	}

	const normalized = value.trim().toLowerCase();
	return ALLOWED_COLOR_PALETTES.find((item) => item === normalized) ?? null;
}

function normalizeColorShade(value: number | null): DictionaryColorShade | null {
	if (value === null) {
		return null;
	}

	const normalized = Math.round(value);
	return ALLOWED_COLOR_SHADES.find((item) => item === normalized) ?? null;
}

function normalizeDictionaryEntry(item: unknown): DictionaryEntry {
	const record = asRecord(item) ?? {};
	const style =
		asRecord(record.styl) ??
		asRecord(record.style) ??
		asRecord(record.statusStyle) ??
		asRecord(record.status_style) ??
		asRecord(record.stylStatusu) ??
		{};
	const nestedDictionaryEntry =
		asRecord(record.slownikPozycja) ??
		asRecord(record.slownik_pozycja) ??
		asRecord(record.pozycja) ??
		asRecord(record.dictionaryEntry) ??
		{};

	const kolor = normalizeColorPalette(
		readString(record.kolor) ??
		readString(record.color) ??
		readString(style.kolor) ??
		readString(style.color),
	);
	const odcien = normalizeColorShade(
		readNumber(record.odcien) ??
		readNumber(record.shade) ??
		readNumber(style.odcien) ??
		readNumber(style.shade),
	);
	const intensywnosc =
		readNumber(record.intensywnosc) ??
		readNumber(record.intensity) ??
		readNumber(style.intensywnosc) ??
		readNumber(style.intensity);
	const resolvedKodPozycji =
		readString(record.kodPozycji) ??
		readString(record.kod_pozycji) ??
		readString(record.statusCode) ??
		readString(record.status_code) ??
		readString(nestedDictionaryEntry.kodPozycji) ??
		readString(nestedDictionaryEntry.kod_pozycji) ??
		readString(nestedDictionaryEntry.statusCode) ??
		readString(nestedDictionaryEntry.status_code) ??
		"";

	return {
		id:
			readNumber(record.id) ??
			readNumber(record.slownikPozycjaId) ??
			readNumber(record.slownik_pozycja_id) ??
			readNumber(nestedDictionaryEntry.id) ??
			readNumber(nestedDictionaryEntry.slownikPozycjaId) ??
			readNumber(nestedDictionaryEntry.slownik_pozycja_id) ??
			undefined,
		teamId: readNumber(record.teamId) ?? readNumber(record.team_id) ?? undefined,
		kodTypu: readString(record.kodTypu) ?? readString(record.kod_typu) ?? "",
		kodPozycji: resolvedKodPozycji,
		nazwaPozycji:
			readString(record.nazwaPozycji) ?? readString(record.nazwa_pozycji) ?? "",
		nazwaUzytkowa:
			readString(record.nazwaUzytkowa) ?? readString(record.nazwa_uzytkowa),
		skrotPozycji:
			readString(record.skrotPozycji) ?? readString(record.skrot_pozycji),
		kolejnosc: readNumber(record.kolejnosc),
		aktywny: readBoolean(record.aktywny),
		kierownikUserId:
			readNumber(record.kierownikUserId) ??
			readNumber(record.kierownik_user_id) ??
			null,
		kierownikDisplayName:
			readString(record.kierownikDisplayName) ??
			readString(record.kierownik_display_name) ??
			null,
		kolor,
		odcien,
		intensywnosc,
	};
}

function resolveDictionaryEntryIdFromPayload(payload: unknown): number | undefined {
	const payloadRecord = asRecord(payload) ?? {};
	const nestedDictionaryEntry =
		asRecord(payloadRecord.slownikPozycja) ??
		asRecord(payloadRecord.slownik_pozycja) ??
		asRecord(payloadRecord.pozycja) ??
		asRecord(payloadRecord.dictionaryEntry) ??
		{};

	return (
		readNumber(payloadRecord.id) ??
		readNumber(payloadRecord.slownikPozycjaId) ??
		readNumber(payloadRecord.slownik_pozycja_id) ??
		readNumber(nestedDictionaryEntry.id) ??
		readNumber(nestedDictionaryEntry.slownikPozycjaId) ??
		readNumber(nestedDictionaryEntry.slownik_pozycja_id) ??
		undefined
	);
}

export async function fetchDictionaryTypes(): Promise<
	Result<DictionaryType[]>
> {
	const response = await fetch("/api/slowniki/typy", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać typów słowników (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const data = Array.isArray(payload) ? (payload as DictionaryType[]) : [];
	return { ok: true, data };
}

export async function fetchDictionaryEntries(
	kodTypu: string,
	operatorLogin?: string,
): Promise<Result<DictionaryEntry[]>> {
	const normalizedKodTypu = kodTypu.trim().toLowerCase();
	const customEndpointByKodTypu: Record<string, string> = {
		rozstrzygniecie_wniosku_sankcyjnego_i:
			"/api/slowniki/wnioski-sankcyjne/rozstrzygniecie-i",
	};

	const endpoint =
		customEndpointByKodTypu[normalizedKodTypu] ??
		`/api/slowniki/pozycje?${new URLSearchParams({ kodTypu }).toString()}`;

	const response = await fetch(endpoint, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			...(operatorLogin?.trim()
				? { "X-Operator-Login": operatorLogin.trim() }
				: {}),
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać pozycji słownika (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const rawItems = Array.isArray(payload)
		? payload
		: (Array.isArray((payload as { items?: unknown[] })?.items)
			? ((payload as { items?: unknown[] }).items ?? [])
			: []);
	const data = rawItems.map((item) => normalizeDictionaryEntry(item));
	return { ok: true, data };
}

type TeamRead = {
	id: number;
	kod: string;
	nazwa: string;
	kierownikUserId: number | null;
	kierownikDisplayName?: string | null;
};

type AdminUserRead = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	rolaId: number;
	aktywny: boolean;
	zespolId?: number | null;
};

type FetchTeamsAsDictionaryEntriesParams = {
	operatorLogin: string;
};

export async function fetchTeamsAsDictionaryEntries({
	operatorLogin,
}: FetchTeamsAsDictionaryEntriesParams): Promise<Result<DictionaryEntry[]>> {
	const response = await fetch("/api/admin/teams", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać listy zespołów (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const teams = Array.isArray(payload) ? (payload as TeamRead[]) : [];

	let userDisplayNameById: Record<number, string> = {};
	try {
		const usersResponse = await fetch("/api/admin/users", {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (usersResponse.ok) {
			const usersPayload = (await usersResponse.json()) as unknown;
			const users = Array.isArray(usersPayload)
				? (usersPayload as AdminUserRead[])
				: [];
			userDisplayNameById = users.reduce<Record<number, string>>(
				(acc, user) => {
					const fullName = `${user.imie ?? ""} ${user.nazwisko ?? ""}`.trim();
					acc[user.id] = fullName || user.login;
					return acc;
				},
				{},
			);

			const fallbackLeaderByTeamId = users.reduce<
				Record<number, { id: number; displayName: string }>
			>((acc, user) => {
				if (
					!user.aktywny ||
					user.rolaId !== 2 ||
					typeof user.zespolId !== "number" ||
					!Number.isFinite(user.zespolId)
				) {
					return acc;
				}

				if (acc[user.zespolId]) {
					return acc;
				}

				acc[user.zespolId] = {
					id: user.id,
					displayName: userDisplayNameById[user.id] ?? user.login,
				};
				return acc;
			}, {});

			const mapped: DictionaryEntry[] = teams.map((team) => {
				const fallbackLeader = fallbackLeaderByTeamId[team.id];
				const resolvedLeaderId =
					typeof team.kierownikUserId === "number"
						? team.kierownikUserId
						: (fallbackLeader?.id ?? null);

				const displayNameFromTeam =
					typeof team.kierownikDisplayName === "string" &&
					team.kierownikDisplayName.trim()
						? team.kierownikDisplayName
						: null;
				const displayNameFromUserId =
					typeof resolvedLeaderId === "number"
						? (userDisplayNameById[resolvedLeaderId] ?? null)
						: null;

				const resolvedLeaderDisplayName =
					displayNameFromTeam ??
					displayNameFromUserId ??
					fallbackLeader?.displayName ??
					null;

				return {
					teamId: team.id,
					kodTypu: "zespoly",
					kodPozycji: team.kod,
					nazwaPozycji: team.nazwa,
					skrotPozycji: team.kod,
					kolejnosc: null,
					aktywny: true,
					kierownikUserId: resolvedLeaderId,
					kierownikDisplayName: resolvedLeaderDisplayName,
				};
			});

			return { ok: true, data: mapped };
		}
	} catch {
		userDisplayNameById = {};
	}

	const mapped: DictionaryEntry[] = teams.map((team) => ({
		teamId: team.id,
		kodTypu: "zespoly",
		kodPozycji: team.kod,
		nazwaPozycji: team.nazwa,
		skrotPozycji: team.kod,
		kolejnosc: null,
		aktywny: true,
		kierownikUserId: team.kierownikUserId,
		kierownikDisplayName:
			team.kierownikDisplayName ??
			(typeof team.kierownikUserId === "number"
				? (userDisplayNameById[team.kierownikUserId] ?? null)
				: null),
	}));

	return { ok: true, data: mapped };
}

type FetchTeamLeadersParams = {
	operatorLogin: string;
};

export async function fetchTeamLeaders({
	operatorLogin,
}: FetchTeamLeadersParams): Promise<Result<TeamLeaderOption[]>> {
	const response = await fetch("/api/admin/users", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać listy kierowników (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const users = Array.isArray(payload) ? (payload as AdminUserRead[]) : [];

	const leaders = users
		.filter((user) => user.aktywny)
		.map((user) => {
			const fullName = `${user.imie ?? ""} ${user.nazwisko ?? ""}`.trim();
			return {
				id: user.id,
				displayName: fullName || user.login,
			};
		})
		.sort((left, right) =>
			left.displayName.localeCompare(right.displayName, "pl", {
				sensitivity: "base",
			}),
		);

	return { ok: true, data: leaders };
}

type CreateDictionaryEntryParams = {
	operatorLogin: string;
	kodTypu: string;
	form: AddDictionaryEntryForm;
};

export async function createDictionaryEntry({
	operatorLogin,
	kodTypu,
	form,
}: CreateDictionaryEntryParams) {
	const normalizedKodPozycji = form.kodPozycji.trim().toUpperCase();
	const response = await fetch("/api/slowniki/pozycje", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kodTypu,
			...(normalizedKodPozycji ? { kodPozycji: normalizedKodPozycji } : {}),
			nazwaPozycji: form.nazwaPozycji.trim(),
			nazwaUzytkowa: form.nazwaUzytkowa.trim() || null,
			skrotPozycji: form.skrotPozycji.trim() || null,
			kolejnosc: null,
			aktywny: form.aktywny,
				kolor: form.kolor,
				odcien: form.odcien,
				intensywnosc: form.intensywnosc,
		}),
	});

	if (response.status === 400) {
		return {
			ok: false as const,
			error: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return { ok: false as const, error: "Brak uprawnień.", status: 403 };
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: "Kod pozycji już istnieje w tym słowniku.",
			status: 409,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się dodać pozycji (${response.status}).`,
			status: response.status,
		};
	}

	let createdEntryId: number | undefined;
	const contentType = response.headers.get("content-type") ?? "";
	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as unknown;
			createdEntryId = resolveDictionaryEntryIdFromPayload(payload);
		} catch {
			createdEntryId = undefined;
		}
	}

	return { ok: true as const, entryId: createdEntryId };
}

type UpdateDictionaryEntryParams = {
	operatorLogin: string;
	kodTypu: string;
	entryId?: number;
	form: AddDictionaryEntryForm;
};

type UpsertInspectionStatusStyleParams = {
	operatorLogin: string;
	slownikPozycjaId: number;
	kolor: string | null;
	odcien: number | null;
	intensywnosc: number | null;
};

type DeleteInspectionStatusStyleParams = {
	operatorLogin: string;
	slownikPozycjaId: number;
};

export async function upsertInspectionStatusStyle({
	operatorLogin,
	slownikPozycjaId,
	kolor,
	odcien,
	intensywnosc,
}: UpsertInspectionStatusStyleParams) {
	const response = await fetch("/api/slowniki/statusy-inspekcji/styl", {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			slownikPozycjaId,
			kolor,
			odcien,
			intensywnosc,
		}),
	});

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;
			if (typeof detail === "string") {
				apiDetail = detail;
			}
		} catch {
			apiDetail = "";
		}
	}

	if (response.status === 400 || response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane stylu: ${apiDetail}`
				: "Błędne dane stylu statusu.",
			status: response.status,
		};
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail ? `Brak uprawnień: ${apiDetail}` : "Brak uprawnień.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono statusu: ${apiDetail}`
				: "Nie znaleziono pozycji statusu.",
			status: 404,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się zapisać stylu statusu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

export async function deleteInspectionStatusStyle({
	operatorLogin,
	slownikPozycjaId,
}: DeleteInspectionStatusStyleParams) {
	const response = await fetch(
		`/api/slowniki/statusy-inspekcji/styl/${slownikPozycjaId}`,
		{
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
		},
	);

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;
			if (typeof detail === "string") {
				apiDetail = detail;
			}
		} catch {
			apiDetail = "";
		}
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail ? `Brak uprawnień: ${apiDetail}` : "Brak uprawnień.",
			status: 403,
		};
	}

	if (response.status === 404) {
		// DELETE is treated as idempotent for UI flows: missing style means it is already cleared.
		return { ok: true as const };
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się usunąć stylu statusu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

export async function clearInspectionStatusStyle({
	operatorLogin,
	slownikPozycjaId,
}: DeleteInspectionStatusStyleParams) {
	const deleteResult = await deleteInspectionStatusStyle({
		operatorLogin,
		slownikPozycjaId,
	});

	if (deleteResult.ok) {
		return deleteResult;
	}

	const putNullsResult = await upsertInspectionStatusStyle({
		operatorLogin,
		slownikPozycjaId,
		kolor: null,
		odcien: null,
		intensywnosc: null,
	});

	if (putNullsResult.ok) {
		return putNullsResult;
	}

	return deleteResult;
}

export async function updateDictionaryEntry({
	operatorLogin,
	kodTypu,
	entryId,
	form,
}: UpdateDictionaryEntryParams) {
	const isIdBasedUpdate =
		typeof entryId === "number" && Number.isFinite(entryId);
	const requestUrl = isIdBasedUpdate
		? `/api/slowniki/pozycje/${entryId}`
		: "/api/slowniki/pozycje";

	const response = await fetch(requestUrl, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify(
			isIdBasedUpdate
				? {
						nazwaPozycji: form.nazwaPozycji.trim(),
						nazwaUzytkowa: form.nazwaUzytkowa.trim() || null,
						skrotPozycji: form.skrotPozycji.trim() || null,
						aktywny: form.aktywny,
						kolor: form.kolor,
						odcien: form.odcien,
						intensywnosc: form.intensywnosc,
					}
				: {
						kodTypu,
						kodPozycji: form.kodPozycji.trim().toUpperCase(),
						nazwaPozycji: form.nazwaPozycji.trim(),
						nazwaUzytkowa: form.nazwaUzytkowa.trim() || null,
						skrotPozycji: form.skrotPozycji.trim() || null,
						aktywny: form.aktywny,
						kolor: form.kolor,
						odcien: form.odcien,
						intensywnosc: form.intensywnosc,
					},
		),
	});

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";
	let responsePayload: unknown = null;

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			responsePayload = payload;
			const detail = payload.detail ?? payload.message;
			if (typeof detail === "string") {
				apiDetail = detail;
			}
		} catch {
			apiDetail = "";
			responsePayload = null;
		}
	}

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail ? `Brak uprawnień: ${apiDetail}` : "Brak uprawnień.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono pozycji: ${apiDetail}`
				: "Nie znaleziono pozycji słownika.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Konflikt danych: ${apiDetail}`
				: "Kod pozycji już istnieje w tym słowniku.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się zaktualizować pozycji (${response.status}).`,
			status: response.status,
		};
	}

	const payloadRecord = asRecord(responsePayload) ?? {};
	const nestedDictionaryEntry =
		asRecord(payloadRecord.slownikPozycja) ??
		asRecord(payloadRecord.slownik_pozycja) ??
		asRecord(payloadRecord.pozycja) ??
		asRecord(payloadRecord.dictionaryEntry) ??
		{};
	const resolvedEntryId =
		readNumber(payloadRecord.id) ??
		readNumber(payloadRecord.slownikPozycjaId) ??
		readNumber(payloadRecord.slownik_pozycja_id) ??
		readNumber(nestedDictionaryEntry.id) ??
		readNumber(nestedDictionaryEntry.slownikPozycjaId) ??
		readNumber(nestedDictionaryEntry.slownik_pozycja_id) ??
		undefined;

	return { ok: true as const, entryId: resolvedEntryId };
}

type CreateTeamParams = {
	operatorLogin: string;
	form: AddDictionaryEntryForm;
};

export async function createTeamEntry({
	operatorLogin,
	form,
}: CreateTeamParams) {
	const readApiDetail = async () => {
		const contentType = response.headers.get("content-type") ?? "";
		if (!contentType.includes("application/json")) {
			return "";
		}

		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;

			if (typeof detail === "string") {
				return detail;
			}

			if (Array.isArray(detail)) {
				const joined = detail
					.map((item) => {
						if (typeof item === "string") {
							return item;
						}

						if (item && typeof item === "object") {
							const maybeMsg = (item as { msg?: unknown }).msg;
							return typeof maybeMsg === "string"
								? maybeMsg
								: JSON.stringify(item);
						}

						return "";
					})
					.filter(Boolean)
					.join("; ");

				return joined;
			}

			return "";
		} catch {
			return "";
		}
	};

	const response = await fetch("/api/admin/teams", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kod: form.kodPozycji.trim().toUpperCase(),
			nazwa: form.nazwaPozycji.trim(),
			kierownikUserId: form.kierownikUserId,
		}),
	});

	const apiDetail = await readApiDetail();

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return {
			ok: false as const,
			error: "Brak autoryzacji operatora.",
			status: 401,
		};
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail
				? `Brak uprawnień do zarządzania zespołami: ${apiDetail}`
				: "Brak uprawnień do zarządzania zespołami.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono wskazanego kierownika zespołu: ${apiDetail}`
				: "Nie znaleziono wskazanego kierownika zespołu.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Kod lub nazwa zespołu już istnieje: ${apiDetail}`
				: "Kod lub nazwa zespołu już istnieje.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych wejściowych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się dodać zespołu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

type UpdateTeamParams = {
	operatorLogin: string;
	teamId: number;
	kod: string;
	nazwa: string;
	kierownikUserId: number | null;
};

export async function updateTeamEntry({
	operatorLogin,
	teamId,
	kod,
	nazwa,
	kierownikUserId,
}: UpdateTeamParams) {
	const response = await fetch(`/api/admin/teams/${teamId}`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kod: kod.trim().toUpperCase(),
			nazwa: nazwa.trim(),
			kierownikUserId,
		}),
	});

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;

			if (typeof detail === "string") {
				apiDetail = detail;
			} else if (Array.isArray(detail)) {
				apiDetail = detail
					.map((item) => {
						if (typeof item === "string") {
							return item;
						}

						if (item && typeof item === "object") {
							const maybeMsg = (item as { msg?: unknown }).msg;
							return typeof maybeMsg === "string"
								? maybeMsg
								: JSON.stringify(item);
						}

						return "";
					})
					.filter(Boolean)
					.join("; ");
			}
		} catch {
			apiDetail = "";
		}
	}

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return {
			ok: false as const,
			error: "Brak autoryzacji operatora.",
			status: 401,
		};
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail
				? `Brak uprawnień do zarządzania zespołami: ${apiDetail}`
				: "Brak uprawnień do zarządzania zespołami.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono zespołu lub użytkownika: ${apiDetail}`
				: "Nie znaleziono zespołu lub użytkownika.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Konflikt danych: ${apiDetail}`
				: "Konflikt danych zespołu.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych wejściowych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się zaktualizować zespołu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

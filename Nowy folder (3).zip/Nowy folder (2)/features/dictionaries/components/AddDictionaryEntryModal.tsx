import { X } from "lucide-react";

import {
	findInspectionStatusPresetKeyByValues,
	INSPECTION_STATUS_COLOR_PRESETS,
} from "@/features/dictionaries/constants";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";
import type {
	AddDictionaryEntryForm,
	TeamLeaderOption,
} from "@/features/dictionaries/types";

type AddDictionaryEntryModalProps = {
	isOpen: boolean;
	isSubmitting: boolean;
	error: string | null;
	form: AddDictionaryEntryForm;
	isTeamsType: boolean;
	isInspectionStatusesType: boolean;
	teamLeaders: TeamLeaderOption[];
	isTeamLeadersLoading: boolean;
	onClose: () => void;
	onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
	onFormChange: (
		updater: (previous: AddDictionaryEntryForm) => AddDictionaryEntryForm,
	) => void;
};

export function AddDictionaryEntryModal({
	isOpen,
	isSubmitting,
	error,
	form,
	isTeamsType,
	isInspectionStatusesType,
	teamLeaders,
	isTeamLeadersLoading,
	onClose,
	onSubmit,
	onFormChange,
}: AddDictionaryEntryModalProps) {
	if (!isOpen) {
		return null;
	}

	const selectedInspectionPresetKey = findInspectionStatusPresetKeyByValues(
		form.kolor,
		form.odcien,
		form.intensywnosc,
	);
	const isNoColorSelected =
		form.kolor === null &&
		form.odcien === null &&
		form.intensywnosc === null;

	const PRESET_SWATCH_CLASS_BY_KEY: Record<string, string> = {
		si2: "bg-green-500/75",
		si3: "bg-cyan-500/75",
		si4: "bg-rose-300/75",
		si5to9: "bg-yellow-300/75",
	};

	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
			<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Dodaj pozycję słownika"
				className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">
							Dodaj pozycję słownika
						</h3>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				<form className="space-y-4" onSubmit={onSubmit}>
					<div className="grid gap-3 sm:grid-cols-2">
						{isTeamsType ? (
							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Nazwa zespołu *</span>
								<input
									required
									value={form.nazwaPozycji}
									onChange={(event) =>
										onFormChange((previous) => ({
											...previous,
											nazwaPozycji: event.target.value,
										}))
									}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>
						) : null}

						{isTeamsType ? (
							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Skrót nazwy zespołu *</span>
								<input
									required
									value={form.skrotPozycji}
									onChange={(event) =>
										onFormChange((previous) => ({
											...previous,
											skrotPozycji: event.target.value,
										}))
									}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
									placeholder="NP. AA"
								/>
							</label>
						) : (
							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Nazwa pełna *</span>
								<input
									required
									value={form.nazwaPozycji}
									onChange={(event) =>
										onFormChange((previous) => ({
											...previous,
											nazwaPozycji: event.target.value,
										}))
									}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>
						)}

						{isTeamsType ? (
							<div className="sm:col-span-2">
								<SingleSelectPortalField
									label="Kierownik zespołu (opcjonalnie)"
									value={form.kierownikUserId ? String(form.kierownikUserId) : ""}
									options={teamLeaders.map((leader) => ({
										value: String(leader.id),
										label: leader.displayName,
									}))}
									placeholder="Bez kierownika (ustawię później)"
									onChange={(next) =>
										onFormChange((previous) => ({
											...previous,
											kierownikUserId: next ? Number(next) : null,
										}))
									}
									disabled={isTeamLeadersLoading}
								/>
								{isTeamLeadersLoading ? (
									<p className="mt-1 text-slate-500 text-xs">
										Ładowanie kierowników...
									</p>
								) : null}
							</div>
						) : (
							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Nazwa skrócona</span>
								<input
									value={form.skrotPozycji}
									onChange={(event) =>
										onFormChange((previous) => ({
											...previous,
											skrotPozycji: event.target.value,
										}))
									}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>
						)}

					</div>

					{!isTeamsType && isInspectionStatusesType ? (
						<div className="text-slate-700 text-sm">
							<span className="mb-1 block">Schemat koloru</span>
							<div className="flex items-center gap-2">
								<button
									type="button"
									onClick={() =>
										onFormChange((previous) => ({
											...previous,
											kolor: null,
											odcien: null,
											intensywnosc: null,
										}))
									}
									className={`inline-flex h-8 items-center rounded border px-2 text-xs transition-colors ${
										isNoColorSelected
											? "border-blue-600 ring-2 ring-blue-200"
											: "border-slate-300"
									}`}
								>
									Brak
								</button>
								{INSPECTION_STATUS_COLOR_PRESETS.map((preset) => {
									const isActive = selectedInspectionPresetKey === preset.key;

									return (
										<button
											key={preset.key}
											type="button"
											onClick={() =>
												onFormChange((previous) => ({
													...previous,
													kolor: preset.kolor,
													odcien: preset.odcien,
													intensywnosc: preset.intensywnosc,
												}))
											}
											className={`h-8 w-8 rounded border transition-colors ${
												isActive
													? "border-blue-600 ring-2 ring-blue-200"
													: "border-slate-300"
											} ${PRESET_SWATCH_CLASS_BY_KEY[preset.key] ?? "bg-slate-300"}`}
											aria-label={preset.label}
										/>
									);
								})}
							</div>
						</div>
					) : null}

					{!isTeamsType ? (
						<label className="inline-flex items-center gap-2 text-slate-700 text-sm">
							<input
								type="checkbox"
								checked={form.aktywny}
								onChange={(event) =>
									onFormChange((previous) => ({
										...previous,
										aktywny: event.target.checked,
									}))
								}
							/>
							Aktywny
						</label>
					) : null}

					{error ? (
						<p className="font-medium text-rose-600 text-sm">{error}</p>
					) : null}

					<div className="flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
						<button
							type="button"
							onClick={onClose}
							className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
						>
							Anuluj
						</button>

						<button
							type="submit"
							disabled={isSubmitting}
							className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
						>
							{isSubmitting ? "Dodawanie..." : "Dodaj"}
						</button>
					</div>
				</form>
			</div>
		</div>
	);
}

$ErrorActionPreference = 'Stop'

$python = 'C:/Users/szczesnk/AppData/Local/Programs/Python/Python312/python.exe'
$script = 'scripts/run_full_matrix_and_export_excel.py'

& $python $script --c5-seconds 15 --c7-seconds 30 --c6-baseline-seconds 8 --c6-with-scheduler-seconds 10 --c10-seconds 30 --output docs/test-matrix-results-smoke.xlsx

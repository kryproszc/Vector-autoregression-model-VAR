param(
    [ValidateRange(1, 720)]
    [int]$Minutes = 10,
    [string]$TeamCodes = 'A,B,C,D',
    [ValidateRange(1, 20)]
    [int]$WorkersPerTeam = 2,
    [string]$Output = ''
)

$ErrorActionPreference = 'Stop'

$python = 'C:/Users/szczesnk/AppData/Local/Programs/Python/Python312/python.exe'
$script = 'scripts/run_cross_module_soak.py'

$durationSeconds = $Minutes * 60
if ([string]::IsNullOrWhiteSpace($Output)) {
    $Output = "docs/cross-module-soak-${Minutes}min.json"
}

Write-Host "[INFO] Running cross-module soak"
Write-Host "[INFO] Minutes=$Minutes DurationSeconds=$durationSeconds"
Write-Host "[INFO] TeamCodes=$TeamCodes WorkersPerTeam=$WorkersPerTeam"
Write-Host "[INFO] Output=$Output"

& $python $script --duration-seconds $durationSeconds --team-codes $TeamCodes --workers-per-team $WorkersPerTeam --output $Output

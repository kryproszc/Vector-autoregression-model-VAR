from __future__ import annotations

import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.database import get_connection, init_db


def main() -> None:
    init_db()
    with get_connection() as conn:
        conn.execute("UPDATE inspections SET zakres_inspekcji_id = NULL")
        conn.execute("DELETE FROM inspection_scopes")
        conn.execute("DELETE FROM slownik_pozycje WHERE kod_typu = 'zakresy_inspekcji'")
        conn.commit()
    print("OK: usunieto wpisy zakresy_inspekcji i wyczyszczono powiazania zakresow")


if __name__ == "__main__":
    main()

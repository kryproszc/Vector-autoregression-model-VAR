from __future__ import annotations

import argparse
import json
import random
from datetime import date, timedelta
from typing import Any
from urllib import error, request

from app.api.reports.generation_data import build_subject_name

BASE_URL = "http://127.0.0.1:8002"
ADMIN_LOGIN = "admin"


def _url(path: str) -> str:
    return f"{BASE_URL.rstrip('/')}{path}"


def _request_json(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
) -> tuple[int, Any]:
    req_headers = {"Accept": "application/json"}
    if headers:
        req_headers.update(headers)

    body: bytes | None = None
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        req_headers["Content-Type"] = "application/json"

    req = request.Request(_url(path), data=body, method=method.upper(), headers=req_headers)

    try:
        with request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode("utf-8")
            if not raw:
                return resp.status, None
            try:
                return resp.status, json.loads(raw)
            except json.JSONDecodeError:
                return resp.status, raw
    except error.HTTPError as exc:
        raw = exc.read().decode("utf-8")
        try:
            body_obj = json.loads(raw) if raw else None
        except json.JSONDecodeError:
            body_obj = raw
        return exc.code, body_obj


def _must_request_json(
    method: str,
    path: str,
    payload: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    expected_status: int | tuple[int, ...] = 200,
) -> Any:
    status, body = _request_json(method, path, payload=payload, headers=headers)
    allowed = (expected_status,) if isinstance(expected_status, int) else expected_status
    if status not in allowed:
        raise RuntimeError(f"HTTP {status} for {method} {path}: {body}")
    return body


def _operator_headers(login: str) -> dict[str, str]:
    return {"X-Operator-Login": login}


def _list_teams() -> list[dict[str, Any]]:
    body = _must_request_json("GET", "/api/admin/teams", headers=_operator_headers(ADMIN_LOGIN), expected_status=200)
    if not isinstance(body, list):
        raise RuntimeError("Invalid teams response")
    return [dict(item) for item in body if isinstance(item, dict)]


def _ensure_team(code: str) -> int:
    code_up = code.strip().upper()
    for team in _list_teams():
        if str(team.get("kod") or "").upper() == code_up:
            return int(team["id"])

    created = _must_request_json(
        "POST",
        "/api/admin/teams",
        payload={"kod": code_up, "nazwa": f"Zespol-{code_up}"},
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=201,
    )
    return int(created["id"])


def _list_users() -> list[dict[str, Any]]:
    body = _must_request_json("GET", "/api/admin/users", headers=_operator_headers(ADMIN_LOGIN), expected_status=200)
    if not isinstance(body, list):
        raise RuntimeError("Invalid users response")
    return [dict(item) for item in body if isinstance(item, dict)]


def _ensure_user(login: str, team_id: int, role_id: int = 1) -> int:
    login_l = login.lower()
    for user in _list_users():
        if str(user.get("login") or "").lower() == login_l:
            return int(user["id"])

    payload = {
        "login": login,
        "imie": login,
        "nazwisko": login,
        "email": f"{login}@example.local",
        "rolaId": role_id,
        "zespolId": team_id,
        "aktywny": True,
    }
    created = _must_request_json(
        "POST",
        "/api/admin/users",
        payload=payload,
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    return int(created["id"])


def _list_scope_ids() -> list[int]:
    body = _must_request_json(
        "GET",
        "/api/slowniki/pozycje?kodTypu=zakresy_inspekcji",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    if not isinstance(body, list):
        raise RuntimeError("Invalid scope dictionary response")
    ids = [int(item["id"]) for item in body if isinstance(item, dict) and item.get("id") is not None]
    return ids


def _ensure_dictionary_items(kod_typu: str, names: list[str]) -> list[int]:
    existing_items = _must_request_json(
        "GET",
        f"/api/slowniki/pozycje?kodTypu={kod_typu}",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    if not isinstance(existing_items, list):
        raise RuntimeError(f"Invalid dictionary response for {kod_typu}")

    existing_names = {
        str(item.get("nazwaPozycji") or "").strip().lower()
        for item in existing_items
        if isinstance(item, dict)
    }

    for name in names:
        normalized = str(name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in existing_names:
            continue
        _must_request_json(
            "POST",
            "/api/slowniki/pozycje",
            payload={
                "kodTypu": kod_typu,
                "nazwaPozycji": normalized,
                "aktywny": True,
            },
            headers=_operator_headers(ADMIN_LOGIN),
            expected_status=200,
        )
        existing_names.add(normalized.lower())

    refreshed_items = _must_request_json(
        "GET",
        f"/api/slowniki/pozycje?kodTypu={kod_typu}",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    if not isinstance(refreshed_items, list):
        raise RuntimeError(f"Invalid dictionary response for {kod_typu} after ensure")

    return [
        int(item["id"])
        for item in refreshed_items
        if isinstance(item, dict)
        and item.get("id") is not None
        and int(item.get("aktywny") or 0) == 1
    ]


def _ensure_seed_dictionaries() -> list[int]:
    _ensure_dictionary_items("typy_inspekcji", ["Kontrola", "Wizyta nadzorcza"])
    scope_ids = _ensure_dictionary_items(
        "zakresy_inspekcji",
        [
            "RTU",
            "SCR",
            "Bezpieczenstwo systemow",
        ],
    )
    if not scope_ids:
        raise RuntimeError("Brak aktywnych pozycji slownika zakresy_inspekcji")
    return scope_ids


def _create_inspection(
    idx: int,
    member_login: str,
    leader_user_id: int,
    start_day: date,
    inspection_type: str,
    scope_id: int,
    subject_name: str,
) -> dict[str, Any]:
    poczatek = start_day.isoformat()
    koniec = (start_day + timedelta(days=2)).isoformat()
    data_protokolu = (date.fromisoformat(koniec) + timedelta(days=random.randint(10, 50))).isoformat()

    payload = {
        "nazwaPodmiotu": subject_name,
        "typInspekcji": inspection_type,
        "zakresInspekcjiIds": [scope_id],
        "poczatekInspekcji": poczatek,
        "koniecInspekcji": koniec,
        "osobaKierujacaUserId": leader_user_id,
        "teamMemberUserIds": [leader_user_id],
        "dataProtokolu": data_protokolu,
        "komentarz": f"Seed inspection #{idx} ({inspection_type}, {member_login})",
    }

    created = _must_request_json(
        "POST",
        "/api/structure/inspections",
        payload=payload,
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=201,
    )
    if not isinstance(created, dict):
        raise RuntimeError("Invalid inspection create response")
    return created


def _update_inspection_scope_and_protocol(inspection_id: int, scope_id: int) -> None:
    detail = _must_request_json(
        "GET",
        f"/api/structure/inspections/{inspection_id}",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    if not isinstance(detail, dict):
        raise RuntimeError(f"Invalid inspection detail for id={inspection_id}")

    end_raw = str(detail.get("koniecInspekcji") or "").strip()
    if not end_raw:
        raise RuntimeError(f"Brak koniecInspekcji dla inspection {inspection_id}")

    new_protocol_date = (date.fromisoformat(end_raw) + timedelta(days=random.randint(10, 50))).isoformat()

    lock = _must_request_json(
        "POST",
        f"/api/locks/inspections/{inspection_id}/acquire",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    lock_token = str(lock.get("lockToken") or "")
    if not lock_token:
        raise RuntimeError(f"Brak lockToken dla inspection {inspection_id}")

    try:
        _must_request_json(
            "PUT",
            f"/api/structure/inspections/{inspection_id}",
            payload={
                "lockToken": lock_token,
                "expectedUpdatedAt": detail.get("zaktualizowanoO"),
                "zakresInspekcjiIds": [scope_id],
                "dataProtokolu": new_protocol_date,
            },
            headers=_operator_headers(ADMIN_LOGIN),
            expected_status=200,
        )
    finally:
        _request_json(
            "POST",
            f"/api/locks/inspections/{inspection_id}/release",
            payload={"lockToken": lock_token},
            headers=_operator_headers(ADMIN_LOGIN),
        )


def _backfill_seed_scopes_and_protocol(scope_ids: list[int], subject_prefix: str) -> tuple[int, int]:
    listed = _must_request_json(
        "GET",
        "/api/structure/inspections?sortBy=id&sortOrder=asc",
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=200,
    )
    if not isinstance(listed, dict):
        raise RuntimeError("Invalid inspections list response")

    items = listed.get("items")
    if not isinstance(items, list):
        raise RuntimeError("Invalid inspections list items")

    total_seed = 0
    updated = 0
    prefix_clean = (subject_prefix or "").strip()
    generated_prefix = f"{prefix_clean}_" if prefix_clean else "Podmiot_"
    for item in items:
        if not isinstance(item, dict):
            continue
        name = str(item.get("nazwaPodmiotu") or "")
        if not (name.startswith("SEED-") or name.startswith(generated_prefix)):
            continue

        total_seed += 1
        inspection_id = int(item["id"])
        random_scope_id = random.choice(scope_ids)
        _update_inspection_scope_and_protocol(inspection_id, random_scope_id)
        updated += 1

    return total_seed, updated


def _create_sanction_request(idx: int, inspection_id: int, data_wniosku: str) -> dict[str, Any]:
    payload = {
        "inspectionId": inspection_id,
        "dataWniosku": data_wniosku,
        "komentarz": f"Seed sanction request #{idx}",
    }
    created = _must_request_json(
        "POST",
        "/api/sanction-requests",
        payload=payload,
        headers=_operator_headers(ADMIN_LOGIN),
        expected_status=201,
    )
    if not isinstance(created, dict):
        raise RuntimeError("Invalid sanction create response")
    return created


def _random_start_day_in_year(year: int) -> date:
    jan_1 = date(year, 1, 1)
    # Keep enough margin for koniec (+2) and dataProtokolu (+10..50) to stay in same year.
    day_offset = random.randint(0, 300)
    return jan_1 + timedelta(days=day_offset)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Seed inspections/sanctions for 3 teams and backfill scope/protocol dates for SEED records."
    )
    parser.add_argument(
        "--backfill-only",
        action="store_true",
        help="Do not create new records, only backfill existing SEED inspections.",
    )
    parser.add_argument("--from-year", type=int, default=2016, help="First year for random seeded data.")
    parser.add_argument(
        "--to-year",
        type=int,
        default=date.today().year - 1,
        help="Last year for random seeded data (inclusive). Default: previous year.",
    )
    parser.add_argument(
        "--per-member-per-type-per-year",
        type=int,
        default=5,
        help="How many inspections to create for each member and type in each year.",
    )
    parser.add_argument(
        "--subject-pool-size",
        type=int,
        default=30,
        help="How many subject names to rotate through (e.g. Podmiot_1..Podmiot_N).",
    )
    parser.add_argument(
        "--subject-prefix",
        type=str,
        default="Podmiot",
        help="Prefix used for generated subject names.",
    )
    args = parser.parse_args()

    if args.from_year > args.to_year:
        raise RuntimeError("from-year nie moze byc wiekszy niz to-year")
    if args.per_member_per_type_per_year < 1:
        raise RuntimeError("per-member-per-type-per-year musi byc >= 1")
    if args.subject_pool_size < 1:
        raise RuntimeError("subject-pool-size musi byc >= 1")

    _must_request_json("POST", "/api/auth/login", payload={"login": ADMIN_LOGIN}, expected_status=200)
    random.seed()

    team_a_id = _ensure_team("A")
    team_b_id = _ensure_team("B")
    team_c_id = _ensure_team("C")
    team_d_id = _ensure_team("D")
    scope_ids = _list_scope_ids()
    if not scope_ids:
        scope_ids = _ensure_seed_dictionaries()

    _ensure_user("a-kier", team_a_id, role_id=2)
    _ensure_user("b-kier", team_b_id, role_id=2)
    _ensure_user("c-kier", team_c_id, role_id=2)
    _ensure_user("d-kier", team_d_id, role_id=2)

    user_b1_id = _ensure_user("b-user1", team_b_id)
    user_b2_id = _ensure_user("b-user2", team_b_id)
    user_c1_id = _ensure_user("c-user1", team_c_id)
    user_c2_id = _ensure_user("c-user2", team_c_id)
    user_d1_id = _ensure_user("d-user1", team_d_id)
    user_d2_id = _ensure_user("d-user2", team_d_id)
    user_a1_id = _ensure_user("a-user1", team_a_id)

    members = {
        "a-user1": user_a1_id,
        "b-user1": user_b1_id,
        "b-user2": user_b2_id,
        "c-user1": user_c1_id,
        "c-user2": user_c2_id,
        "d-user1": user_d1_id,
        "d-user2": user_d2_id,
    }
    inspection_types = ["Kontrola", "Wizyta nadzorcza"]
    per_member_per_type = int(args.per_member_per_type_per_year)
    years = list(range(int(args.from_year), int(args.to_year) + 1))

    inspections: list[dict[str, Any]] = []
    sanctions: list[dict[str, Any]] = []
    created_by_member_and_type: dict[str, dict[str, int]] = {
        login: {"Kontrola": 0, "Wizyta nadzorcza": 0} for login in members
    }
    created_by_year: dict[str, int] = {str(y): 0 for y in years}

    if not args.backfill_only:
        global_idx = 0
        for year in years:
            for member_login, member_id in members.items():
                for inspection_type in inspection_types:
                    for _ in range(per_member_per_type):
                        global_idx += 1
                        start_day = _random_start_day_in_year(year)

                        inspection = _create_inspection(
                            idx=global_idx,
                            member_login=member_login,
                            leader_user_id=member_id,
                            start_day=start_day,
                            inspection_type=inspection_type,
                            scope_id=random.choice(scope_ids),
                            subject_name=build_subject_name(global_idx, int(args.subject_pool_size), str(args.subject_prefix)),
                        )
                        inspections.append(inspection)
                        created_by_member_and_type[member_login][inspection_type] += 1
                        created_by_year[str(year)] += 1

                        sanction = _create_sanction_request(
                            global_idx,
                            int(inspection["id"]),
                            str(inspection.get("dataProtokolu") or inspection.get("koniecInspekcji")),
                        )
                        sanctions.append(sanction)

    total_seed, updated_seed = _backfill_seed_scopes_and_protocol(scope_ids, str(args.subject_prefix))

    summary = {
        "teams": {"A": team_a_id, "B": team_b_id, "C": team_c_id, "D": team_d_id},
        "members": members,
        "perMemberPerType": per_member_per_type,
        "inspectionTypes": inspection_types,
        "yearsRequested": years,
        "createdByMemberAndType": created_by_member_and_type,
        "createdByYear": created_by_year,
        "totals": {
            "inspections": len(inspections),
            "sanctionRequests": len(sanctions),
        },
        "backfillOnly": bool(args.backfill_only),
        "scopeBackfill": {
            "totalSeedInspectionsSeen": total_seed,
            "updatedSeedInspections": updated_seed,
        },
        "createdInspections": [
            {
                "id": int(item["id"]),
                "kodInspekcji": item.get("kodInspekcji"),
                "typInspekcji": item.get("typInspekcji"),
                "koniecInspekcji": item.get("koniecInspekcji"),
                "dataProtokolu": item.get("dataProtokolu"),
                "osobaKierujacaUserId": item.get("osobaKierujacaUserId"),
            }
            for item in inspections
        ],
        "createdSanctionRequests": [
            {
                "id": int(item["id"]),
                "kodSankcji": item.get("kodSankcji"),
                "inspectionId": item.get("inspectionId"),
                "dataWniosku": item.get("dataWniosku"),
            }
            for item in sanctions
        ],
    }

    print(json.dumps(summary, ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

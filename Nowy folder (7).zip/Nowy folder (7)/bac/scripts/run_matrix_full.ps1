$ErrorActionPreference = 'Stop'

$python = 'C:/Users/szczesnk/AppData/Local/Programs/Python/Python312/python.exe'
$script = 'scripts/run_full_matrix_and_export_excel.py'

& $python $script --c5-seconds 180 --c7-seconds 600 --c6-baseline-seconds 25 --c6-with-scheduler-seconds 35 --c10-seconds 180 --output docs/test-matrix-results.xlsx

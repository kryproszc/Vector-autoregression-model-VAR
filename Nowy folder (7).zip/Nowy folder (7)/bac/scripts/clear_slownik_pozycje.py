from __future__ import annotations

from pathlib import Path
import sys

try:
    from app.database import get_connection
except ModuleNotFoundError:
    # Allow running this file directly from scripts/.
    sys.path.append(str(Path(__file__).resolve().parents[1]))
    from app.database import get_connection


def clear_slownik_positions() -> dict[str, int]:
    with get_connection() as conn:
        result: dict[str, int] = {}

        # Teams keep their rows, but dictionary link must be cleared.
        conn.execute("UPDATE teams SET slownik_pozycja_id = NULL")

        # Children first, then parents, to keep FK constraints satisfied.
        delete_order = [
            "obligating_decisions_persons_i",
            "obligating_decisions_persons_ii",
            "obligating_decisions",
            "risk_exposure_sanction_subjects",
            "risk_exposure_sanctions",
            "risk_exposure_legal_bases",
            "risk_exposure_violations",
            "risk_exposure_requests",
            "recommendation_multi_dates",
            "recommendations",
            "inspection_multi_dates",
            "inspection_scopes",
            "inspection_members",
            "inspections",
            "slownik_pozycje",
        ]

        for table in delete_order:
            before = conn.execute(f"SELECT COUNT(1) AS cnt FROM {table}").fetchone()
            count_before = int(before["cnt"]) if before is not None else 0
            conn.execute(f"DELETE FROM {table}")
            result[table] = count_before

        conn.commit()
        return result


if __name__ == "__main__":
    deleted = clear_slownik_positions()
    print("Deleted rows:")
    for table_name, row_count in deleted.items():
        print(f"- {table_name}: {row_count}")
    print("Kept table slownik_typy unchanged.")
import os
import sqlite3

DB_PATH = r"D:\rejestr\backend\Baza\rejestr.db"


def _connect() -> sqlite3.Connection:
    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(DB_PATH, timeout=max(1.0, busy_timeout_ms / 1000.0))
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute(f"PRAGMA journal_mode={journal_mode}")
    conn.execute(f"PRAGMA busy_timeout={busy_timeout_ms}")
    if journal_mode == "WAL":
        conn.execute("PRAGMA synchronous=NORMAL")
    return conn

con = _connect()
cur = con.cursor()

cur.execute("UPDATE users SET zespol_id = NULL WHERE zespol_id IS NOT NULL")
cur.execute("UPDATE teams SET kierownik_user_id = NULL, slownik_pozycja_id = NULL")
cur.execute("DELETE FROM teams")
cur.execute("DELETE FROM slownik_pozycje WHERE lower(kod_typu)=lower('zespoly')")

con.commit()

teams_count = cur.execute("SELECT COUNT(*) FROM teams").fetchone()[0]
slownik_zespoly_count = cur.execute(
    "SELECT COUNT(*) FROM slownik_pozycje WHERE lower(kod_typu)=lower('zespoly')"
).fetchone()[0]

print("teams_count=", teams_count)
print("slownik_zespoly_count=", slownik_zespoly_count)

con.close()

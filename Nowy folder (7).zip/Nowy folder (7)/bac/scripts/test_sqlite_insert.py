from __future__ import annotations

import os
import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DB_DIR = BASE_DIR / "Baza"
DB_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DB_DIR / "rejestr.db"


def _connect() -> sqlite3.Connection:
    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(DB_PATH, timeout=max(1.0, busy_timeout_ms / 1000.0))
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(f"PRAGMA journal_mode = {journal_mode}")
    conn.execute(f"PRAGMA busy_timeout = {busy_timeout_ms}")
    if journal_mode == "WAL":
        conn.execute("PRAGMA synchronous = NORMAL")
    return conn


CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nazwa_podmiotu TEXT NOT NULL,
    typ_inspekcji TEXT,
    zakres_inspekcji TEXT,
    poczatek_inspekcji TEXT NOT NULL,
    koniec_inspekcji TEXT NOT NULL,
    osoba_kierujaca TEXT NOT NULL,
    rynek TEXT,
    rodzaj_podmiotu TEXT,
    sklad_zespolu TEXT NOT NULL,
    komentarz TEXT,
    status TEXT,
    data_protokolu_sprawozdania TEXT,
    data_doreczenia_protokolu TEXT,
    data_akceptacji_sprawozdania TEXT,
    data_doreczenia_pisma TEXT,
    data_pisma_zastrzezenia TEXT,
    data_wplywu_pisma TEXT,
    data_pisma_z_odpowiedzia TEXT,
    data_akceptacji_noty TEXT,
    data_zalecen TEXT,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
"""


def main() -> None:
    conn = _connect()
    try:
        cursor = conn.cursor()

        has_table = cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='inspections'"
        ).fetchone()

        if has_table is not None:
            columns = {
                row[1] for row in cursor.execute("PRAGMA table_info(inspections)").fetchall()
            }
            if "nazwa_podmiotu" not in columns:
                cursor.execute("DROP TABLE inspections")

        cursor.execute(CREATE_TABLE_SQL)

        now = datetime.now().isoformat(timespec="seconds")
        subject_name = f"Podmiot testowy {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        cursor.execute(
            """
            INSERT INTO inspections (
                nazwa_podmiotu,
                typ_inspekcji,
                zakres_inspekcji,
                poczatek_inspekcji,
                koniec_inspekcji,
                osoba_kierujaca,
                rynek,
                rodzaj_podmiotu,
                sklad_zespolu,
                komentarz,
                status,
                data_protokolu_sprawozdania,
                data_doreczenia_protokolu,
                data_akceptacji_sprawozdania,
                data_doreczenia_pisma,
                data_pisma_zastrzezenia,
                data_wplywu_pisma,
                data_pisma_z_odpowiedzia,
                data_akceptacji_noty,
                data_zalecen
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                subject_name,
                "Planowa",
                "Pelna",
                "2026-03-24",
                "2026-04-05",
                "Jan Kowalski",
                "Rynek lokalny",
                "Spolka",
                "Anna Nowak, Piotr Zielinski",
                "Rekord testowy dodany ze skryptu.",
                "in_progress",
                now,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
                None,
            ),
        )
        conn.commit()

        row_id = cursor.lastrowid
        cursor.execute(
            "SELECT id, nazwa_podmiotu, typ_inspekcji, poczatek_inspekcji, koniec_inspekcji, utworzono_o FROM inspections ORDER BY id DESC LIMIT 1"
        )
        latest_row = cursor.fetchone()

        cursor.execute("SELECT COUNT(*) FROM inspections")
        total_count = cursor.fetchone()[0]

        print(f"DB file: {DB_PATH}")
        print(f"Inserted row id: {row_id}")
        print(f"Latest row: {latest_row}")
        print(f"Total rows in inspections: {total_count}")
    finally:
        conn.close()


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import importlib.util
import json
import random
import sys
import threading
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import median
from typing import Any

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

BASE_HELPER_PATH = ROOT_DIR / "scripts" / "run_concurrency_checks.py"
_spec = importlib.util.spec_from_file_location("run_concurrency_checks", BASE_HELPER_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError(f"Cannot load helper module from {BASE_HELPER_PATH}")
base = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = base
_spec.loader.exec_module(base)


@dataclass
class Attempt:
    module: str
    status_code: int
    elapsed_ms: float


class Stats:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.status_counts: dict[str, dict[int, int]] = {
            "inspections": {},
            "recommendations": {},
            "sanction_requests": {},
            "obligating_decisions": {},
            "reads": {},
            "creates": {},
        }
        self.latencies: dict[str, list[float]] = {
            "inspections": [],
            "recommendations": [],
            "sanction_requests": [],
            "obligating_decisions": [],
            "reads": [],
            "creates": [],
        }
        self.errors_5xx: dict[str, int] = {
            "inspections": 0,
            "recommendations": 0,
            "sanction_requests": 0,
            "obligating_decisions": 0,
            "reads": 0,
            "creates": 0,
        }

    def add(self, module: str, status_code: int, elapsed_ms: float) -> None:
        with self.lock:
            module_counts = self.status_counts[module]
            module_counts[status_code] = module_counts.get(status_code, 0) + 1
            self.latencies[module].append(elapsed_ms)
            if status_code >= 500:
                self.errors_5xx[module] += 1


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _percentile_ms(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = int((len(ordered) - 1) * p)
    return ordered[idx]


def _safe_recommendation_code_by_id(recommendation_id: int, login: str) -> str | None:
    status, body = base._request_json(
        "GET",
        f"/api/recommendations/{recommendation_id}",
        headers=base._operator_headers(login),
    )
    if status != 200 or not isinstance(body, dict):
        return None
    value = body.get("kodZalecenia")
    return str(value) if value else None


def _team_name_from_code(code: str) -> str:
    return f"Zespol-{code.upper()}"


def _list_teams(admin_login: str) -> list[dict[str, Any]]:
    status, body = base._request_json("GET", "/api/admin/teams", headers=base._operator_headers(admin_login))
    if status != 200 or not isinstance(body, list):
        raise RuntimeError(f"Unable to list teams: HTTP {status} {body}")
    return [dict(item) for item in body if isinstance(item, dict)]


def _ensure_team(admin_login: str, code: str) -> int:
    code_up = code.strip().upper()
    if not code_up:
        raise RuntimeError("Empty team code")

    for row in _list_teams(admin_login):
        if str(row.get("kod") or "").upper() == code_up:
            return int(row["id"])

    status, body = base._request_json(
        "POST",
        "/api/admin/teams",
        payload={"kod": code_up, "nazwa": _team_name_from_code(code_up)},
        headers=base._operator_headers(admin_login),
    )
    if status != 201 or not isinstance(body, dict):
        raise RuntimeError(f"Unable to create team {code_up}: HTTP {status} {body}")
    return int(body["id"])


def _list_users(operator_login: str) -> list[dict[str, Any]]:
    status, body = base._request_json("GET", "/api/admin/users", headers=base._operator_headers(operator_login))
    if status != 200 or not isinstance(body, list):
        raise RuntimeError(f"Unable to list users as {operator_login}: HTTP {status} {body}")
    return [dict(item) for item in body if isinstance(item, dict)]


def _find_user_by_login(operator_login: str, login: str) -> dict[str, Any] | None:
    login_lower = login.strip().lower()
    for row in _list_users(operator_login):
        if str(row.get("login") or "").lower() == login_lower:
            return row
    return None


def _ensure_user(
    operator_login: str,
    *,
    login: str,
    role_id: int,
    team_id: int | None,
    first_name: str,
    last_name: str,
    email: str,
) -> int:
    existing = _find_user_by_login(operator_login, login)
    if existing is not None:
        return int(existing["id"])

    status, body = base._request_json(
        "POST",
        "/api/admin/users",
        payload={
            "login": login,
            "imie": first_name,
            "nazwisko": last_name,
            "email": email,
            "rolaId": role_id,
            "zespolId": team_id,
            "aktywny": True,
        },
        headers=base._operator_headers(operator_login),
    )
    if status == 200 and isinstance(body, dict):
        return int(body["id"])

    # Retry read path in case another process created the user concurrently.
    existing_after = _find_user_by_login(operator_login, login)
    if existing_after is not None:
        return int(existing_after["id"])

    raise RuntimeError(f"Unable to create user {login} as {operator_login}: HTTP {status} {body}")


def _assign_team_leader(admin_login: str, team_id: int, leader_user_id: int) -> None:
    status, body = base._request_json(
        "PUT",
        f"/api/admin/teams/{team_id}",
        payload={"kierownikUserId": leader_user_id},
        headers=base._operator_headers(admin_login),
    )
    if status != 200:
        raise RuntimeError(f"Unable to assign leader to team {team_id}: HTTP {status} {body}")


def _bootstrap_hierarchy(
    *,
    admin_login: str,
    team_codes: list[str],
    workers_per_team: int,
) -> tuple[dict[str, int], dict[str, str], list[str]]:
    team_ids: dict[str, int] = {}
    leaders_by_team: dict[str, str] = {}
    workers: list[str] = []

    for raw_code in team_codes:
        code = raw_code.strip().upper()
        if not code:
            continue

        team_id = _ensure_team(admin_login, code)
        team_ids[code] = team_id

        leader_login = f"{code.lower()}-kier1"
        leader_id = _ensure_user(
            admin_login,
            login=leader_login,
            role_id=2,
            team_id=team_id,
            first_name=leader_login,
            last_name=leader_login,
            email=f"{leader_login}@example.local",
        )
        _assign_team_leader(admin_login, team_id, leader_id)
        leaders_by_team[code] = leader_login

        for i in range(1, workers_per_team + 1):
            worker_login = f"{code.lower()}-user{i}"
            _ensure_user(
                admin_login,
                login=worker_login,
                role_id=1,
                team_id=team_id,
                first_name=worker_login,
                last_name=worker_login,
                email=f"{worker_login}@example.local",
            )
            workers.append(worker_login)

    if not team_ids:
        raise RuntimeError("No teams prepared for soak bootstrap")

    return team_ids, leaders_by_team, workers


def _update_inspection_once(inspection_id: int, login: str, idx: int) -> Attempt:
    started = time.perf_counter()
    lock_token: str | None = None
    try:
        st_detail, detail = base._request_json(
            "GET",
            f"/api/structure/inspections/{inspection_id}",
            headers=base._operator_headers(login),
        )
        if st_detail != 200 or not isinstance(detail, dict):
            return Attempt("inspections", st_detail, (time.perf_counter() - started) * 1000.0)

        st_lock, body_lock = base._request_json(
            "POST",
            f"/api/locks/inspections/{inspection_id}/acquire",
            headers=base._operator_headers(login),
        )
        if st_lock != 200 or not isinstance(body_lock, dict):
            return Attempt("inspections", st_lock, (time.perf_counter() - started) * 1000.0)

        lock_token = str(body_lock.get("lockToken") or "")
        st_upd, _ = base._request_json(
            "PUT",
            f"/api/structure/inspections/{inspection_id}",
            payload={
                "komentarz": f"soak-ins-{idx}-{base._random_suffix(4)}",
                "lockToken": lock_token,
                "expectedUpdatedAt": detail.get("zaktualizowanoO"),
            },
            headers=base._operator_headers(login),
        )
        return Attempt("inspections", st_upd, (time.perf_counter() - started) * 1000.0)
    finally:
        if lock_token:
            base._release_lock("inspections", inspection_id, login, lock_token)


def _update_recommendation_once(recommendation_id: int, login: str, idx: int) -> Attempt:
    attempt = base._update_recommendation_once(recommendation_id, login, idx)
    return Attempt("recommendations", attempt.status_code, attempt.elapsed_ms)


def _update_sanction_request_once(risk_id: int, login: str, idx: int) -> Attempt:
    started = time.perf_counter()
    lock_token: str | None = None
    try:
        st_detail, detail = base._request_json(
            "GET",
            f"/api/sanction-requests/{risk_id}",
            headers=base._operator_headers(login),
        )
        if st_detail != 200 or not isinstance(detail, dict):
            return Attempt("sanction_requests", st_detail, (time.perf_counter() - started) * 1000.0)

        st_lock, body_lock = base._request_json(
            "POST",
            f"/api/locks/sanction-requests/{risk_id}/acquire",
            headers=base._operator_headers(login),
        )
        if st_lock != 200 or not isinstance(body_lock, dict):
            return Attempt("sanction_requests", st_lock, (time.perf_counter() - started) * 1000.0)

        lock_token = str(body_lock.get("lockToken") or "")
        st_upd, _ = base._request_json(
            "PUT",
            f"/api/sanction-requests/{risk_id}",
            payload={
                "komentarz": f"soak-risk-{idx}-{base._random_suffix(4)}",
                "lockToken": lock_token,
                "expectedUpdatedAt": detail.get("zaktualizowanoO"),
            },
            headers=base._operator_headers(login),
        )
        return Attempt("sanction_requests", st_upd, (time.perf_counter() - started) * 1000.0)
    finally:
        if lock_token:
            base._release_lock("sanction-requests", risk_id, login, lock_token)


def _update_decision_once(decision_id: int, login: str, idx: int) -> Attempt:
    started = time.perf_counter()
    lock_token: str | None = None
    try:
        st_detail, detail = base._request_json(
            "GET",
            f"/api/obligating-decisions/{decision_id}",
            headers=base._operator_headers(login),
        )
        if st_detail != 200 or not isinstance(detail, dict):
            return Attempt("obligating_decisions", st_detail, (time.perf_counter() - started) * 1000.0)

        st_lock, body_lock = base._request_json(
            "POST",
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=base._operator_headers(login),
        )
        if st_lock != 200 or not isinstance(body_lock, dict):
            return Attempt("obligating_decisions", st_lock, (time.perf_counter() - started) * 1000.0)

        lock_token = str(body_lock.get("lockToken") or "")
        st_upd, _ = base._request_json(
            "PUT",
            f"/api/obligating-decisions/{decision_id}",
            payload={
                "komentarz": f"soak-dec-{idx}-{base._random_suffix(4)}",
                "lockToken": lock_token,
                "expectedUpdatedAt": detail.get("zaktualizowanoO"),
            },
            headers=base._operator_headers(login),
        )
        return Attempt("obligating_decisions", st_upd, (time.perf_counter() - started) * 1000.0)
    finally:
        if lock_token:
            base._release_lock("obligating-decisions", decision_id, login, lock_token)


def _seed_chain(admin_login: str, admin_id: int, chain_idx: int) -> tuple[int, int, int, int] | None:
    inspection_id = base._create_inspection(admin_id=admin_id, label=f"SOAK-{chain_idx}-{base._random_suffix(5)}")

    recommendation_id = base._create_recommendation(
        inspection_id=inspection_id,
        pozycja=1000 + (chain_idx % 800),
    )

    st_risk, body_risk = base._request_json(
        "POST",
        "/api/sanction-requests",
        payload={"inspectionId": inspection_id, "komentarz": f"seed-risk-{chain_idx}"},
        headers=base._operator_headers(admin_login),
    )
    if st_risk != 201 or not isinstance(body_risk, dict):
        return None
    risk_id = int(body_risk["id"])

    rec_code = _safe_recommendation_code_by_id(recommendation_id, admin_login)
    if not rec_code:
        return None

    st_dec, body_dec = base._request_json(
        "POST",
        "/api/obligating-decisions",
        payload={"recommendationKodZalecenia": rec_code, "komentarz": f"seed-dec-{chain_idx}"},
        headers=base._operator_headers(admin_login),
    )
    if st_dec != 201 or not isinstance(body_dec, dict):
        return None
    decision_id = int(body_dec["id"])

    return inspection_id, recommendation_id, risk_id, decision_id


def _read_once(module: str, record_id: int, login: str) -> Attempt:
    started = time.perf_counter()
    endpoint_by_module = {
        "inspections": f"/api/structure/inspections/{record_id}",
        "recommendations": f"/api/recommendations/{record_id}",
        "sanction_requests": f"/api/sanction-requests/{record_id}",
        "obligating_decisions": f"/api/obligating-decisions/{record_id}",
    }
    status, _ = base._request_json("GET", endpoint_by_module[module], headers=base._operator_headers(login))
    return Attempt("reads", status, (time.perf_counter() - started) * 1000.0)


def main() -> int:
    parser = argparse.ArgumentParser(description="Cross-module scalable soak test for inspections/recommendations/sanctions/decisions.")
    parser.add_argument("--duration-seconds", type=int, default=600)
    parser.add_argument("--write-workers", type=int, default=8)
    parser.add_argument("--read-workers", type=int, default=8)
    parser.add_argument("--seed-chains", type=int, default=12)
    parser.add_argument("--creator-interval-seconds", type=int, default=45)
    parser.add_argument("--max-per-module", type=int, default=150)
    parser.add_argument("--team-codes", type=str, default="A,B,C,D")
    parser.add_argument("--workers-per-team", type=int, default=2)
    parser.add_argument("--writer-affinity-mode", type=str, default="random", choices=["random", "segmented"])
    parser.add_argument("--output", type=str, default="docs/cross-module-soak-report.json")
    args = parser.parse_args()

    random.seed()
    print(f"[INFO] Start cross-module soak at {base.BASE_URL}")
    print(f"[INFO] Duration={args.duration_seconds}s writeWorkers={args.write_workers} readWorkers={args.read_workers}")

    admin_id = base._bootstrap_admin_id()
    admin_login = base.ADMIN_LOGIN

    team_codes = [item.strip().upper() for item in str(args.team_codes).split(",") if item.strip()]
    team_ids, leaders_by_team, workers = _bootstrap_hierarchy(
        admin_login=admin_login,
        team_codes=team_codes,
        workers_per_team=max(1, args.workers_per_team),
    )
    operators = [admin_login] + sorted(set(leaders_by_team.values())) + sorted(set(workers))

    print("[INFO] Bootstrap hierarchy ready")
    print("[INFO] Teams:", team_ids)
    print("[INFO] Leaders:", leaders_by_team)
    print(f"[INFO] Workers prepared={len(workers)}")

    ids_lock = threading.Lock()
    inspections: list[int] = []
    recommendations: list[int] = []
    sanctions: list[int] = []
    decisions: list[int] = []

    created_chains = 0
    for i in range(args.seed_chains):
        seeded = _seed_chain(admin_login, admin_id, i + 1)
        if seeded is None:
            continue
        ins_id, rec_id, risk_id, dec_id = seeded
        inspections.append(ins_id)
        recommendations.append(rec_id)
        sanctions.append(risk_id)
        decisions.append(dec_id)
        created_chains += 1

    if not inspections or not recommendations or not sanctions or not decisions:
        print("[ERROR] Failed to seed all modules")
        return 2

    stats = Stats()
    stop_event = threading.Event()

    def write_worker(worker_idx: int, fixed_module: str | None = None) -> None:
        local_idx = 0
        while not stop_event.is_set():
            local_idx += 1
            login = random.choice(operators)
            module = fixed_module or random.choice(["inspections", "recommendations", "sanction_requests", "obligating_decisions"])

            with ids_lock:
                if module == "inspections":
                    record_id = random.choice(inspections)
                elif module == "recommendations":
                    record_id = random.choice(recommendations)
                elif module == "sanction_requests":
                    record_id = random.choice(sanctions)
                else:
                    record_id = random.choice(decisions)

            if module == "inspections":
                attempt = _update_inspection_once(record_id, login, worker_idx * 1_000_000 + local_idx)
            elif module == "recommendations":
                attempt = _update_recommendation_once(record_id, login, worker_idx * 1_000_000 + local_idx)
            elif module == "sanction_requests":
                attempt = _update_sanction_request_once(record_id, login, worker_idx * 1_000_000 + local_idx)
            else:
                attempt = _update_decision_once(record_id, login, worker_idx * 1_000_000 + local_idx)

            stats.add(attempt.module, attempt.status_code, attempt.elapsed_ms)
            time.sleep(0.01)

    def read_worker() -> None:
        while not stop_event.is_set():
            login = random.choice(operators)
            module = random.choice(["inspections", "recommendations", "sanction_requests", "obligating_decisions"])
            with ids_lock:
                if module == "inspections":
                    record_id = random.choice(inspections)
                elif module == "recommendations":
                    record_id = random.choice(recommendations)
                elif module == "sanction_requests":
                    record_id = random.choice(sanctions)
                else:
                    record_id = random.choice(decisions)
            attempt = _read_once(module, record_id, login)
            stats.add("reads", attempt.status_code, attempt.elapsed_ms)
            time.sleep(0.01)

    def creator_worker() -> None:
        nonlocal created_chains
        idx = created_chains
        while not stop_event.is_set():
            time.sleep(max(5, args.creator_interval_seconds))
            if stop_event.is_set():
                return

            idx += 1
            started = time.perf_counter()
            seeded = _seed_chain(admin_login, admin_id, idx)
            if seeded is None:
                stats.add("creates", 500, (time.perf_counter() - started) * 1000.0)
                continue

            ins_id, rec_id, risk_id, dec_id = seeded
            with ids_lock:
                inspections.append(ins_id)
                recommendations.append(rec_id)
                sanctions.append(risk_id)
                decisions.append(dec_id)

                if len(inspections) > args.max_per_module:
                    inspections.pop(0)
                if len(recommendations) > args.max_per_module:
                    recommendations.pop(0)
                if len(sanctions) > args.max_per_module:
                    sanctions.pop(0)
                if len(decisions) > args.max_per_module:
                    decisions.pop(0)

            stats.add("creates", 201, (time.perf_counter() - started) * 1000.0)

    threads: list[threading.Thread] = []
    if args.writer_affinity_mode == "segmented":
        module_cycle = ["inspections", "recommendations", "sanction_requests", "obligating_decisions"]
        for i in range(args.write_workers):
            fixed_module = module_cycle[i % len(module_cycle)]
            threads.append(threading.Thread(target=write_worker, args=(i + 1, fixed_module), daemon=True))
    else:
        for i in range(args.write_workers):
            threads.append(threading.Thread(target=write_worker, args=(i + 1,), daemon=True))
    for _ in range(args.read_workers):
        threads.append(threading.Thread(target=read_worker, daemon=True))

    creator = threading.Thread(target=creator_worker, daemon=True)

    started = time.perf_counter()
    for t in threads:
        t.start()
    creator.start()

    checkpoints: list[dict[str, Any]] = []
    checkpoint_count = 6
    checkpoint_interval = max(10, args.duration_seconds // checkpoint_count)

    while (time.perf_counter() - started) < args.duration_seconds:
        time.sleep(checkpoint_interval)
        with stats.lock:
            snapshot = {
                "at": _now(),
                "counts": {k: sum(v.values()) for k, v in stats.status_counts.items()},
                "errors5xx": dict(stats.errors_5xx),
                "p95": {k: round(_percentile_ms(v, 0.95), 2) for k, v in stats.latencies.items()},
            }
        checkpoints.append(snapshot)
        print("[CHECKPOINT]", snapshot["at"], snapshot["counts"])

    stop_event.set()
    for t in threads:
        t.join(timeout=3)
    creator.join(timeout=3)

    elapsed = time.perf_counter() - started

    with stats.lock:
        summary: dict[str, Any] = {
            "startedAt": _now(),
            "durationSeconds": args.duration_seconds,
            "actualElapsedSeconds": round(elapsed, 2),
            "baseUrl": base.BASE_URL,
            "bootstrap": {
                "teamCodes": team_codes,
                "teamIds": team_ids,
                "leaders": leaders_by_team,
                "workersCount": len(workers),
                "operatorsCount": len(operators),
                "writerAffinityMode": args.writer_affinity_mode,
            },
            "seedChainsRequested": args.seed_chains,
            "seedChainsEffective": created_chains,
            "recordsTracked": {
                "inspections": len(inspections),
                "recommendations": len(recommendations),
                "sanction_requests": len(sanctions),
                "obligating_decisions": len(decisions),
            },
            "statusCounts": stats.status_counts,
            "errors5xx": stats.errors_5xx,
            "latency": {
                module: {
                    "p50Ms": round(median(values), 2) if values else 0.0,
                    "p95Ms": round(_percentile_ms(values, 0.95), 2),
                    "p99Ms": round(_percentile_ms(values, 0.99), 2),
                }
                for module, values in stats.latencies.items()
            },
            "checkpoints": checkpoints,
        }

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(summary, ensure_ascii=True, indent=2), encoding="utf-8")

    print(f"[INFO] Report saved to {output_path}")

    # PASS condition: no 5xx on core domain writes and reads.
    pass_modules = ["inspections", "recommendations", "sanction_requests", "obligating_decisions", "reads"]
    has_5xx = any(summary["errors5xx"].get(m, 0) > 0 for m in pass_modules)
    if has_5xx:
        print("[WARN] Soak detected 5xx errors")
        return 1

    print("[INFO] Soak PASS (no 5xx on core modules)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

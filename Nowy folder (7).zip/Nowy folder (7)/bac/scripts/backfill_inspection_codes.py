from __future__ import annotations

import re
import sys
from datetime import date
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.database import get_connection, init_db

CODE_RE = re.compile(r"^([A-Z]{1,2})/(\d{4})/(\d+)$")


def _prefix_from_typ(typ_inspekcji: str | None) -> str:
    normalized = (typ_inspekcji or "").strip().lower()
    if normalized.startswith("kontrola"):
        return "K"
    if normalized.startswith("wizyta"):
        return "WN"
    return "I"


def _year_from_date(value: str | None) -> str | None:
    if value is None:
        return None
    try:
        return str(date.fromisoformat(value).year)
    except ValueError:
        return None


def main() -> None:
    init_db()

    with get_connection() as conn:
        existing_rows = conn.execute(
            "SELECT kod_inspekcji FROM inspections WHERE kod_inspekcji IS NOT NULL AND trim(kod_inspekcji) <> ''"
        ).fetchall()

        max_by_bucket: dict[tuple[str, str], int] = {}
        for row in existing_rows:
            raw_code = str(row["kod_inspekcji"] or "").strip()
            match = CODE_RE.match(raw_code)
            if not match:
                continue
            prefix, year, seq_raw = match.groups()
            seq = int(seq_raw)
            key = (prefix, year)
            max_by_bucket[key] = max(max_by_bucket.get(key, 0), seq)

        rows_to_fill = conn.execute(
            """
            SELECT
                i.id,
                i.poczatek_inspekcji,
                sp.nazwa_pozycji AS typ_inspekcji
            FROM inspections i
            LEFT JOIN slownik_pozycje sp ON sp.id = i.typ_inspekcji_id
            WHERE i.kod_inspekcji IS NULL OR trim(i.kod_inspekcji) = ''
            ORDER BY i.poczatek_inspekcji ASC, i.id ASC
            """
        ).fetchall()

        updated = 0
        skipped = 0

        for row in rows_to_fill:
            inspection_id = int(row["id"])
            year = _year_from_date(row["poczatek_inspekcji"])
            if year is None:
                skipped += 1
                print(f"SKIP id={inspection_id}: niepoprawna data poczatek_inspekcji")
                continue

            prefix = _prefix_from_typ(row["typ_inspekcji"])
            key = (prefix, year)
            next_seq = max_by_bucket.get(key, 0) + 1
            max_by_bucket[key] = next_seq
            code = f"{prefix}/{year}/{next_seq}"

            conn.execute(
                "UPDATE inspections SET kod_inspekcji = ?, zaktualizowano_o = CURRENT_TIMESTAMP WHERE id = ?",
                (code, inspection_id),
            )
            updated += 1
            print(f"UPDATE id={inspection_id} -> {code}")

        conn.commit()

    print(f"Zakonczono. Ustawiono kod_inspekcji dla {updated} rekordow. Pominieto: {skipped}.")


if __name__ == "__main__":
    main()

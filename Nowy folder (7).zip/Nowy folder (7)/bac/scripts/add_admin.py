import os
import sqlite3

DB_PATH = r"D:\rejestr\backend\Baza\rejestr.db"


def _connect() -> sqlite3.Connection:
    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(DB_PATH, timeout=max(1.0, busy_timeout_ms / 1000.0))
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute(f"PRAGMA journal_mode={journal_mode}")
    conn.execute(f"PRAGMA busy_timeout={busy_timeout_ms}")
    if journal_mode == "WAL":
        conn.execute("PRAGMA synchronous=NORMAL")
    return conn

con = _connect()
cur = con.cursor()

cur.execute(
    """
    INSERT INTO users (login, imie, nazwisko, email, rola_id, zespol_id, aktywny)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """,
    ("admin", "Admin", "Systemu", "admin@rejestr.local", 3, None, 1),
)
con.commit()

cur.execute("SELECT id, login, rola_id, aktywny FROM users WHERE login = ? LIMIT 1", ("admin",))
print(cur.fetchone())
con.close()

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import random
import subprocess
import sys
import threading
import time
from tempfile import NamedTemporaryFile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import median
from typing import Any

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

BASE_HELPER_PATH = ROOT_DIR / "scripts" / "run_concurrency_checks.py"
_spec = importlib.util.spec_from_file_location("run_concurrency_checks", BASE_HELPER_PATH)
if _spec is None or _spec.loader is None:
    raise RuntimeError(f"Cannot load helper module from {BASE_HELPER_PATH}")
base = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = base
_spec.loader.exec_module(base)


@dataclass
class MatrixResult:
    id: str
    name: str
    goal: str
    what_test_did: str
    metrics: dict[str, Any]
    conclusion: str
    passed: bool
    duration_seconds: float


def _metric_descriptions_for_result(result: MatrixResult) -> list[tuple[str, str]]:
    common: dict[str, str] = {
        "attempts": "Liczba wszystkich prob wykonania operacji.",
        "statusCounts": "Rozklad kodow HTTP (ile odpowiedzi 200, 409, 423 itd.).",
        "successes": "Liczba zakonczonych powodzeniem operacji (HTTP 200).",
        "successRate": "Skutecznosc operacji w procentach.",
        "p50Ms": "Mediana czasu odpowiedzi w milisekundach.",
        "p95Ms": "95 percentyl czasu odpowiedzi w milisekundach.",
        "p99Ms": "99 percentyl czasu odpowiedzi w milisekundach.",
        "duration_seconds": "Czas trwania danego testu (sekundy).",
        "total_calls": "Laczna liczba wywolan API w tescie.",
        "get_count": "Liczba operacji odczytu GET.",
        "write_count": "Liczba operacji zapisu (PUT/POST).",
        "get_status_counts": "Rozklad kodow HTTP dla GET.",
        "write_status_counts": "Rozklad kodow HTTP dla zapisow.",
        "server_error_rate_percent": "Odsetek bledow 5xx (procent).",
        "get_p95_ms": "95 percentyl czasu GET (ms).",
        "write_p95_ms": "95 percentyl czasu zapisu (ms).",
        "baseline_seconds": "Czas czesci bazowej bez schedulera (sekundy).",
        "with_scheduler_seconds": "Czas czesci z aktywnym schedulerem (sekundy).",
        "baseline_calls": "Liczba operacji w czesci bazowej.",
        "with_scheduler_calls": "Liczba operacji przy aktywnym schedulerze.",
        "baseline_p95_ms": "P95 zapisu bez schedulera (ms).",
        "with_scheduler_p95_ms": "P95 zapisu przy aktywnym schedulerze (ms).",
        "delta_p95_ms": "Roznica p95: (z schedulerem - bez) w ms.",
        "baseline_status_counts": "Rozklad statusow HTTP bez schedulera.",
        "with_scheduler_status_counts": "Rozklad statusow HTTP z schedulerem.",
        "run_now_statuses": "Kody HTTP z wywolan /api/admin/schedules/run-now.",
        "run_now_payloads": "Odpowiedzi JSON z wywolan run-now.",
        "ttl_wait_seconds": "Ile sekund czekano na wygasniecie locka TTL.",
        "pre_ttl_acquire_status": "Kod HTTP proby przejecia locka przed TTL.",
        "post_ttl_acquire_status": "Kod HTTP proby przejecia locka po TTL.",
        "post_ttl_update_status": "Kod HTTP zapisu po przejeciu locka po TTL.",
        "checkpoints": "Punkty kontrolne trendu latencji i bledow w czasie testu.",
        "final_get_p95_ms": "Koncowy p95 dla GET (ms).",
        "final_write_p95_ms": "Koncowy p95 dla zapisow (ms).",
        "case_missing_lock_status": "Kod HTTP dla zapisu bez lockToken.",
        "case_invalid_lock_status": "Kod HTTP dla zapisu z niepoprawnym lockToken.",
        "case_stale_version_status": "Kod HTTP dla zapisu ze starym expectedUpdatedAt.",
        "intermediate_update_updatedAt": "Nowa wersja zaktualizowanoO po poprawnym zapisie posrednim.",
        "pytest_exit_code": "Kod wyjscia pytest dla testu regresji ról.",
        "pytest_stdout_tail": "Koncowka stdout pytest (diagnostyka).",
        "pytest_stderr_tail": "Koncowka stderr pytest (diagnostyka).",
        "soak_exit_code": "Kod wyjscia runnera cross-module soak.",
        "affinity_mode": "Tryb przypisania workerow do modulow (random/segmented).",
        "statusCounts": "Rozklad kodow HTTP per modul dla cross-module soak.",
        "errors5xx": "Liczba bledow 5xx per modul.",
        "latency": "Podsumowanie p50/p95/p99 per modul.",
        "recordsTracked": "Liczba aktywnie sledzonych rekordow per modul.",
        "operatorsCount": "Liczba operatorow bioracych udzial w ruchu.",
        "workersCount": "Liczba uzytkownikow roboczych przygotowanych w bootstrapie.",
        "seedChainsEffective": "Liczba skutecznie utworzonych lancuchow danych testowych.",
        "soak_stdout_tail": "Koncowka stdout uruchomienia soak.",
        "soak_stderr_tail": "Koncowka stderr uruchomienia soak.",
    }

    ordered_descriptions: list[tuple[str, str]] = []
    for key in result.metrics.keys():
        ordered_descriptions.append((key, common.get(key, "Szczegol metryki zapisany w JSON powyzej.")))
    return ordered_descriptions


def _write_metric_legend(ws: Any, result: MatrixResult, start_row: int = 14) -> int:
    ws[f"A{start_row}"] = "Legenda metryk"
    ws[f"A{start_row}"].font = Font(bold=True)

    row = start_row + 1
    descriptions = _metric_descriptions_for_result(result)
    for key, desc in descriptions:
        ws[f"A{row}"] = str(key)
        ws[f"B{row}"] = str(desc)
        ws[f"A{row}"].font = Font(bold=True)
        ws[f"B{row}"].alignment = Alignment(wrap_text=True, vertical="top")
        row += 1

    return row + 1


def _percentile_ms(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    idx = int((len(ordered) - 1) * p)
    return ordered[idx]


def _safe_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=True, indent=2)


def _now_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _create_shared_context() -> dict[str, Any]:
    admin_id = base._bootstrap_admin_id()
    team_id = base._team_id("A")

    # Use director role for synthetic load users to avoid permission-side noise in concurrency metrics.
    operators = [base._create_user(team_id=team_id, role_id=3) for _ in range(16)]

    inspection_id = base._create_inspection(admin_id=admin_id, label=f"MATRIX-{base._random_suffix(6)}")
    shared_rec_id = base._create_recommendation(inspection_id, pozycja=1)

    return {
        "admin_id": admin_id,
        "team_id": team_id,
        "operators": operators,
        "inspection_id": inspection_id,
        "shared_rec_id": shared_rec_id,
    }


def run_c1(context: dict[str, Any]) -> MatrixResult:
    started = time.perf_counter()
    raw = base.test_same_record_write_collision(
        operators=context["operators"][:12],
        recommendation_id=context["shared_rec_id"],
    )
    duration = time.perf_counter() - started

    conclusion = (
        "Mechanizm lock/version dziala poprawnie dla rownoleglego zapisu tego samego rekordu."
        if raw.passed
        else "Wykryto ryzyko niepoprawnej obslugi konfliktow rownoleglego zapisu."
    )

    return MatrixResult(
        id="C1",
        name="Kolizja zapisu tego samego rekordu",
        goal="Sprawdzenie lockToken + expectedUpdatedAt przy rownoleglym zapisie.",
        what_test_did="12 operatorow rownoczesnie probowalo zaktualizowac to samo zalecenie.",
        metrics=raw.details,
        conclusion=conclusion,
        passed=raw.passed,
        duration_seconds=duration,
    )


def run_c2(context: dict[str, Any]) -> MatrixResult:
    started = time.perf_counter()
    raw = base.test_parallel_writes_different_records(
        operators=context["operators"][:12],
        inspection_id=context["inspection_id"],
        records_to_create=40,
    )
    duration = time.perf_counter() - started

    conclusion = (
        "Rownolegly zapis na roznych rekordach utrzymuje zakladana skutecznosc."
        if raw.passed
        else "Skutecznosc zapisu na roznych rekordach jest ponizej progu lub wystepuja bledy 5xx."
    )

    return MatrixResult(
        id="C2",
        name="Rownolegle zapisy na roznych rekordach",
        goal="Ocena write contention dla SQLite przy wielu jednoczesnych zapisach.",
        what_test_did="40 rownoleglych aktualizacji na 40 roznych rekordach zalecen.",
        metrics=raw.details,
        conclusion=conclusion,
        passed=raw.passed,
        duration_seconds=duration,
    )


def run_c3(context: dict[str, Any]) -> MatrixResult:
    started = time.perf_counter()
    rec_id = context["shared_rec_id"]
    op = context["operators"][0]

    detail = base._must_request_json(
        "GET",
        f"/api/recommendations/{rec_id}",
        headers=base._operator_headers(op),
        expected_status=200,
    )

    # 1) missing lockToken
    st1, body1 = base._request_json(
        "PUT",
        f"/api/recommendations/{rec_id}",
        payload={
            "komentarz": f"c3-missing-lock-{base._random_suffix(4)}",
            "expectedUpdatedAt": detail["zaktualizowanoO"],
        },
        headers=base._operator_headers(op),
    )

    # 2) invalid lockToken
    st2, body2 = base._request_json(
        "PUT",
        f"/api/recommendations/{rec_id}",
        payload={
            "komentarz": f"c3-invalid-lock-{base._random_suffix(4)}",
            "lockToken": "invalid-token",
            "expectedUpdatedAt": detail["zaktualizowanoO"],
        },
        headers=base._operator_headers(op),
    )

    # 3) stale expectedUpdatedAt
    lock = base._must_request_json(
        "POST",
        f"/api/locks/recommendations/{rec_id}/acquire",
        headers=base._operator_headers(op),
        expected_status=200,
    )
    lock_token = str(lock["lockToken"])

    first_update = base._must_request_json(
        "PUT",
        f"/api/recommendations/{rec_id}",
        payload={
            "komentarz": f"c3-baseline-update-{base._random_suffix(4)}",
            "lockToken": lock_token,
            "expectedUpdatedAt": detail["zaktualizowanoO"],
        },
        headers=base._operator_headers(op),
        expected_status=200,
    )

    st3, body3 = base._request_json(
        "PUT",
        f"/api/recommendations/{rec_id}",
        payload={
            "komentarz": f"c3-stale-version-{base._random_suffix(4)}",
            "lockToken": lock_token,
            "expectedUpdatedAt": detail["zaktualizowanoO"],
        },
        headers=base._operator_headers(op),
    )

    base._release_lock("recommendations", rec_id, op, lock_token)

    passed = st1 == 423 and st2 == 423 and st3 == 409

    duration = time.perf_counter() - started
    metrics = {
        "case_missing_lock_status": st1,
        "case_invalid_lock_status": st2,
        "case_stale_version_status": st3,
        "missing_lock_body": body1,
        "invalid_lock_body": body2,
        "stale_version_body": body3,
        "intermediate_update_updatedAt": first_update.get("zaktualizowanoO"),
    }

    conclusion = (
        "API poprawnie odrzuca zapisy bez locka, ze zlym lockiem i ze stara wersja."
        if passed
        else "Wykryto odchylenie od oczekiwanej walidacji lock/version."
    )

    return MatrixResult(
        id="C3",
        name="Walidacja lockToken i expectedUpdatedAt",
        goal="Potwierdzenie kodow 423/409 dla blednych scenariuszy zapisu.",
        what_test_did="Wykonal 3 kontrolowane proby: brak lockToken, zly lockToken, stale expectedUpdatedAt.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=duration,
    )


def run_c4(context: dict[str, Any]) -> MatrixResult:
    started = time.perf_counter()
    rec_id = context["shared_rec_id"]
    owner = context["operators"][0]
    contender = context["operators"][1]

    lock = base._must_request_json(
        "POST",
        f"/api/locks/recommendations/{rec_id}/acquire",
        headers=base._operator_headers(owner),
        expected_status=200,
    )
    owner_token = str(lock["lockToken"])

    # Try takeover before TTL expires.
    pre_status, pre_body = base._request_json(
        "POST",
        f"/api/locks/recommendations/{rec_id}/acquire",
        headers=base._operator_headers(contender),
    )

    wait_seconds = 65
    time.sleep(wait_seconds)

    post_status, post_body = base._request_json(
        "POST",
        f"/api/locks/recommendations/{rec_id}/acquire",
        headers=base._operator_headers(contender),
    )

    new_token = None
    if post_status == 200 and isinstance(post_body, dict):
        new_token = str(post_body.get("lockToken") or "")

    detail_after = base._must_request_json(
        "GET",
        f"/api/recommendations/{rec_id}",
        headers=base._operator_headers(contender),
        expected_status=200,
    )

    update_status, update_body = base._request_json(
        "PUT",
        f"/api/recommendations/{rec_id}",
        payload={
            "komentarz": f"c4-after-ttl-{base._random_suffix(4)}",
            "lockToken": new_token,
            "expectedUpdatedAt": detail_after["zaktualizowanoO"],
        },
        headers=base._operator_headers(contender),
    )

    base._release_lock("recommendations", rec_id, owner, owner_token)
    base._release_lock("recommendations", rec_id, contender, new_token)

    passed = pre_status == 423 and post_status == 200 and update_status == 200
    duration = time.perf_counter() - started

    metrics = {
        "ttl_wait_seconds": wait_seconds,
        "pre_ttl_acquire_status": pre_status,
        "post_ttl_acquire_status": post_status,
        "post_ttl_update_status": update_status,
        "pre_ttl_body": pre_body,
        "post_ttl_body": post_body,
        "post_ttl_update_body": update_body,
    }

    conclusion = (
        "Lock poprawnie wygasa po TTL i moze zostac przejety przez innego operatora."
        if passed
        else "Wygaszanie locka po TTL nie zachowalo sie zgodnie z oczekiwaniem."
    )

    return MatrixResult(
        id="C4",
        name="Wygasanie locka TTL",
        goal="Sprawdzenie czy lock zwalnia rekord po czasie i pozwala kontynuowac prace.",
        what_test_did="Przed TTL takeover byl blokowany, po 65 s takeover i zapis zostaly ponowione.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=duration,
    )


def _writer_cycle(rec_id: int, operator: str, stop_event: threading.Event, stats: dict[str, Any]) -> None:
    while not stop_event.is_set():
        attempt = base._update_recommendation_once(rec_id, operator, random.randint(1, 10_000))
        stats["count"] += 1
        stats["status_counts"][attempt.status_code] = stats["status_counts"].get(attempt.status_code, 0) + 1
        stats["latencies"].append(attempt.elapsed_ms)
        if attempt.status_code >= 500:
            stats["server_errors"] += 1
        time.sleep(0.01)


def _mixed_worker(rec_ids: list[int], operators: list[str], stop_event: threading.Event, stats: dict[str, Any]) -> None:
    while not stop_event.is_set():
        operator = random.choice(operators)
        rec_id = random.choice(rec_ids)
        if random.random() < 0.8:
            start = time.perf_counter()
            status, _body = base._request_json("GET", f"/api/recommendations/{rec_id}", headers=base._operator_headers(operator))
            elapsed_ms = (time.perf_counter() - start) * 1000.0
            stats["get_count"] += 1
            stats["get_status_counts"][status] = stats["get_status_counts"].get(status, 0) + 1
            stats["get_latencies"].append(elapsed_ms)
            if status >= 500:
                stats["server_errors"] += 1
        else:
            attempt = base._update_recommendation_once(rec_id, operator, random.randint(1, 10_000))
            stats["write_count"] += 1
            stats["write_status_counts"][attempt.status_code] = stats["write_status_counts"].get(attempt.status_code, 0) + 1
            stats["write_latencies"].append(attempt.elapsed_ms)
            if attempt.status_code >= 500:
                stats["server_errors"] += 1
        time.sleep(0.01)


def run_c5(context: dict[str, Any], duration_seconds: int) -> MatrixResult:
    started = time.perf_counter()
    rec_ids = [base._create_recommendation(context["inspection_id"], pozycja=300 + i) for i in range(20)]

    stop_event = threading.Event()
    stats: dict[str, Any] = {
        "get_count": 0,
        "write_count": 0,
        "get_status_counts": {},
        "write_status_counts": {},
        "get_latencies": [],
        "write_latencies": [],
        "server_errors": 0,
    }

    threads = [
        threading.Thread(target=_mixed_worker, args=(rec_ids, context["operators"][:10], stop_event, stats), daemon=True)
        for _ in range(10)
    ]

    for t in threads:
        t.start()

    time.sleep(duration_seconds)
    stop_event.set()
    for t in threads:
        t.join(timeout=2)

    elapsed = time.perf_counter() - started
    total_calls = stats["get_count"] + stats["write_count"]
    error_rate = (stats["server_errors"] / total_calls) * 100.0 if total_calls else 0.0

    get_p95 = _percentile_ms(stats["get_latencies"], 0.95)
    write_p95 = _percentile_ms(stats["write_latencies"], 0.95)
    passed = error_rate < 1.0

    metrics = {
        "duration_seconds": duration_seconds,
        "total_calls": total_calls,
        "get_count": stats["get_count"],
        "write_count": stats["write_count"],
        "get_status_counts": stats["get_status_counts"],
        "write_status_counts": stats["write_status_counts"],
        "server_error_rate_percent": round(error_rate, 2),
        "get_p95_ms": round(get_p95, 2),
        "write_p95_ms": round(write_p95, 2),
    }

    conclusion = (
        "Ruch mieszany utrzymal stabilny poziom bledow 5xx ponizej 1%."
        if passed
        else "Ruch mieszany przekroczyl akceptowalny prog bledow 5xx."
    )

    return MatrixResult(
        id="C5",
        name="Ruch mieszany odczyt i zapis",
        goal="Ocena stabilnosci API przy profilu 80% GET i 20% write.",
        what_test_did=f"10 watkow generowalo ruch mieszany przez {duration_seconds} s.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=elapsed,
    )


def run_c6(context: dict[str, Any], baseline_seconds: int, with_scheduler_seconds: int) -> MatrixResult:
    started = time.perf_counter()
    rec_ids = [base._create_recommendation(context["inspection_id"], pozycja=500 + i) for i in range(6)]
    operator = context["operators"][0]

    # Baseline writes without scheduler trigger.
    baseline_stats = {"count": 0, "status_counts": {}, "latencies": [], "server_errors": 0}
    stop_baseline = threading.Event()
    t_base = threading.Thread(target=_writer_cycle, args=(rec_ids[0], operator, stop_baseline, baseline_stats), daemon=True)
    t_base.start()
    time.sleep(baseline_seconds)
    stop_baseline.set()
    t_base.join(timeout=2)

    baseline_p95 = _percentile_ms(baseline_stats["latencies"], 0.95)

    # Prepare and trigger scheduler.
    now = datetime.now()
    send_hour = now.hour
    send_minute = now.minute

    schedule_payload = {
        "name": f"PERF-SCHED-{base._random_suffix(5)}",
        "dateFieldA": "recommendation.data_zalecen",
        "dateFieldB": "recommendation.termin_wykonania_zalecen",
        "daysDifference": 0,
        "subjectTemplate": "[TEST] {{scheduleName}} {{recordId}}",
        "bodyTemplate": "Diff={{daysDifference}} Rec={{recommendationId}}",
        "sendHour": send_hour,
        "sendMinute": send_minute,
        "targetInspectionLeader": False,
        "targetInspectionTeam": False,
        "enabled": True,
    }
    schedule = base._must_request_json(
        "POST",
        "/api/admin/schedules",
        payload=schedule_payload,
        headers=base._admin_headers(),
        expected_status=201,
    )
    schedule_id = int(schedule["id"])

    with_sched_stats = {"count": 0, "status_counts": {}, "latencies": [], "server_errors": 0}
    stop_with_sched = threading.Event()
    t_sched = threading.Thread(target=_writer_cycle, args=(rec_ids[0], operator, stop_with_sched, with_sched_stats), daemon=True)
    t_sched.start()

    trigger_statuses: list[int] = []
    trigger_payloads: list[Any] = []
    for _ in range(3):
        st, body = base._request_json("POST", "/api/admin/schedules/run-now", headers=base._admin_headers())
        trigger_statuses.append(st)
        trigger_payloads.append(body)
        time.sleep(max(1.0, with_scheduler_seconds / 3))

    time.sleep(max(1, with_scheduler_seconds // 2))
    stop_with_sched.set()
    t_sched.join(timeout=2)

    base._request_json("DELETE", f"/api/admin/schedules/{schedule_id}", headers=base._admin_headers())

    with_sched_p95 = _percentile_ms(with_sched_stats["latencies"], 0.95)
    delta_p95 = with_sched_p95 - baseline_p95

    passed = with_sched_stats["server_errors"] == 0 and baseline_stats["server_errors"] == 0

    metrics = {
        "baseline_seconds": baseline_seconds,
        "with_scheduler_seconds": with_scheduler_seconds,
        "baseline_calls": baseline_stats["count"],
        "with_scheduler_calls": with_sched_stats["count"],
        "baseline_p95_ms": round(baseline_p95, 2),
        "with_scheduler_p95_ms": round(with_sched_p95, 2),
        "delta_p95_ms": round(delta_p95, 2),
        "baseline_status_counts": baseline_stats["status_counts"],
        "with_scheduler_status_counts": with_sched_stats["status_counts"],
        "run_now_statuses": trigger_statuses,
        "run_now_payloads": trigger_payloads,
    }

    conclusion = (
        "Scheduler nie spowodowal bledow 5xx podczas rownoleglych zapisow."
        if passed
        else "W trakcie rownoleglego uruchamiania schedulera pojawily sie bledy 5xx."
    )

    return MatrixResult(
        id="C6",
        name="Wplyw schedulera na zapisy",
        goal="Porownanie write latency i bledow z i bez uruchomien schedulera.",
        what_test_did="Wykonal baseline write, potem write + 3x /run-now harmonogramow.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=time.perf_counter() - started,
    )


def run_c7(context: dict[str, Any], duration_seconds: int) -> MatrixResult:
    started = time.perf_counter()
    rec_ids = [base._create_recommendation(context["inspection_id"], pozycja=800 + i) for i in range(25)]
    stats: dict[str, Any] = {
        "get_count": 0,
        "write_count": 0,
        "get_status_counts": {},
        "write_status_counts": {},
        "get_latencies": [],
        "write_latencies": [],
        "server_errors": 0,
    }

    stop_event = threading.Event()
    threads = [
        threading.Thread(target=_mixed_worker, args=(rec_ids, context["operators"][:12], stop_event, stats), daemon=True)
        for _ in range(12)
    ]

    for t in threads:
        t.start()

    checkpoints: list[dict[str, Any]] = []
    for _ in range(5):
        time.sleep(duration_seconds / 5)
        get_p95 = _percentile_ms(stats["get_latencies"], 0.95)
        write_p95 = _percentile_ms(stats["write_latencies"], 0.95)
        total = stats["get_count"] + stats["write_count"]
        err_rate = (stats["server_errors"] / total) * 100.0 if total else 0.0
        checkpoints.append(
            {
                "at": _now_stamp(),
                "total_calls": total,
                "get_p95_ms": round(get_p95, 2),
                "write_p95_ms": round(write_p95, 2),
                "server_error_rate_percent": round(err_rate, 2),
            }
        )

    stop_event.set()
    for t in threads:
        t.join(timeout=2)

    elapsed = time.perf_counter() - started
    total_calls = stats["get_count"] + stats["write_count"]
    error_rate = (stats["server_errors"] / total_calls) * 100.0 if total_calls else 0.0
    passed = error_rate < 1.0

    metrics = {
        "duration_seconds": duration_seconds,
        "total_calls": total_calls,
        "get_count": stats["get_count"],
        "write_count": stats["write_count"],
        "get_status_counts": stats["get_status_counts"],
        "write_status_counts": stats["write_status_counts"],
        "final_get_p95_ms": round(_percentile_ms(stats["get_latencies"], 0.95), 2),
        "final_write_p95_ms": round(_percentile_ms(stats["write_latencies"], 0.95), 2),
        "server_error_rate_percent": round(error_rate, 2),
        "checkpoints": checkpoints,
    }

    conclusion = (
        "Soak test nie pokazal narastajacej awaryjnosci powyzej zalozonego progu."
        if passed
        else "W soak tescie przekroczono prog bledow 5xx."
    )

    return MatrixResult(
        id="C7",
        name="Soak test stabilnosci",
        goal="Ocena stabilnosci dluzszego ruchu i trendu latencji oraz bledow.",
        what_test_did=f"12 watkow ruchu mieszanego przez {duration_seconds} s, z checkpointami postepu.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=elapsed,
    )


def build_c8_placeholder() -> MatrixResult:
    return MatrixResult(
        id="C8",
        name="Restart pod obciazeniem",
        goal="Ocena spojnosci i dostepnosci podczas restartu procesu backendu.",
        what_test_did="Test wymaga kontrolowanego restartu procesu uvicorn i ponownego health-check.",
        metrics={
            "status": "PENDING_MANUAL_STEP",
            "note": "Uzupelniane po wykonaniu restartu sterowanego przez runner/agenta.",
        },
        conclusion="Test oczekuje na wykonanie kroku restartu.",
        passed=False,
        duration_seconds=0.0,
    )


def run_c9_role_transition_regression() -> MatrixResult:
    started = time.perf_counter()

    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "tests/test_api_e2e.py",
        "-k",
        "role_transition_user_teamlead_director_across_main_modules",
        "-q",
    ]
    proc = subprocess.run(
        cmd,
        cwd=str(ROOT_DIR),
        capture_output=True,
        text=True,
        timeout=300,
        env=os.environ.copy(),
    )
    passed = proc.returncode == 0

    stdout_tail = "\n".join((proc.stdout or "").splitlines()[-20:])
    stderr_tail = "\n".join((proc.stderr or "").splitlines()[-20:])
    metrics = {
        "pytest_exit_code": proc.returncode,
        "pytest_stdout_tail": stdout_tail,
        "pytest_stderr_tail": stderr_tail,
    }
    conclusion = (
        "Regresja przejscia ról user->kierownik->dyrektor przeszla poprawnie."
        if passed
        else "Regresja przejscia ról nie przeszla - sprawdz tail logu pytest."
    )

    return MatrixResult(
        id="C9",
        name="Regresja przejscia ról",
        goal="Weryfikacja uprawnien po zmianie roli user/kierownik/dyrektor.",
        what_test_did="Uruchomil dedykowany test e2e roli na 4 glownych modulach.",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=time.perf_counter() - started,
    )


def run_c10_cross_module_segmented(duration_seconds: int) -> MatrixResult:
    started = time.perf_counter()

    with NamedTemporaryFile(prefix="cross-module-soak-", suffix=".json", delete=False) as tmp:
        tmp_report_path = Path(tmp.name)

    cmd = [
        sys.executable,
        str(ROOT_DIR / "scripts" / "run_cross_module_soak.py"),
        "--duration-seconds",
        str(duration_seconds),
        "--write-workers",
        "8",
        "--read-workers",
        "8",
        "--seed-chains",
        "8",
        "--creator-interval-seconds",
        "45",
        "--team-codes",
        "A,B,C,D",
        "--workers-per-team",
        "2",
        "--writer-affinity-mode",
        "segmented",
        "--output",
        str(tmp_report_path),
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(ROOT_DIR),
        capture_output=True,
        text=True,
        timeout=max(300, duration_seconds + 180),
        env=os.environ.copy(),
    )

    report: dict[str, Any] = {}
    if tmp_report_path.exists():
        try:
            report = json.loads(tmp_report_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            report = {}
        try:
            tmp_report_path.unlink()
        except OSError:
            pass

    passed = proc.returncode == 0
    stdout_tail = "\n".join((proc.stdout or "").splitlines()[-25:])
    stderr_tail = "\n".join((proc.stderr or "").splitlines()[-25:])

    metrics = {
        "soak_exit_code": proc.returncode,
        "duration_seconds": duration_seconds,
        "affinity_mode": (
            report.get("bootstrap", {}).get("writerAffinityMode")
            if isinstance(report, dict)
            else "segmented"
        ),
        "statusCounts": report.get("statusCounts") if isinstance(report, dict) else {},
        "errors5xx": report.get("errors5xx") if isinstance(report, dict) else {},
        "latency": report.get("latency") if isinstance(report, dict) else {},
        "recordsTracked": report.get("recordsTracked") if isinstance(report, dict) else {},
        "operatorsCount": report.get("bootstrap", {}).get("operatorsCount") if isinstance(report, dict) else None,
        "workersCount": report.get("bootstrap", {}).get("workersCount") if isinstance(report, dict) else None,
        "seedChainsEffective": report.get("seedChainsEffective") if isinstance(report, dict) else None,
        "soak_stdout_tail": stdout_tail,
        "soak_stderr_tail": stderr_tail,
    }

    conclusion = (
        "Cross-module soak z segmentacja workerow przeszedl bez bledow krytycznych."
        if passed
        else "Cross-module soak z segmentacja wykryl problemy - sprawdz tail logow i metryki."
    )

    return MatrixResult(
        id="C10",
        name="Cross-module segmented soak",
        goal="Sprawdzenie stabilnosci przy podziale operatorow na stale obszary modulow.",
        what_test_did="Uruchomil run_cross_module_soak.py w trybie segmented (affinity per worker-group).",
        metrics=metrics,
        conclusion=conclusion,
        passed=passed,
        duration_seconds=time.perf_counter() - started,
    )


def _write_result_sheet(wb: Workbook, result: MatrixResult) -> None:
    ws = wb.create_sheet(title=result.id)

    ws["A1"] = "ID"
    ws["B1"] = result.id
    ws["A2"] = "Nazwa testu"
    ws["B2"] = result.name
    ws["A3"] = "Cel"
    ws["B3"] = result.goal
    ws["A4"] = "Co test zrobil"
    ws["B4"] = result.what_test_did
    ws["A5"] = "Wynik"
    ws["B5"] = "PASS" if result.passed else "FAIL/PENDING"
    ws["A6"] = "Czas [s]"
    ws["B6"] = round(result.duration_seconds, 2)
    ws["A8"] = "Metryki (JSON)"
    ws["A9"] = _safe_json(result.metrics)
    ws["A11"] = "Wnioski"
    ws["A12"] = result.conclusion

    for cell in ["A1", "A2", "A3", "A4", "A5", "A6", "A8", "A11"]:
        ws[cell].font = Font(bold=True)

    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 120
    ws.row_dimensions[9].height = 240

    ws["A9"].alignment = Alignment(wrap_text=True, vertical="top")
    ws["B3"].alignment = Alignment(wrap_text=True)
    ws["B4"].alignment = Alignment(wrap_text=True)
    ws["A12"].alignment = Alignment(wrap_text=True)

    next_row = _write_metric_legend(ws, result, start_row=14)

    if result.id == "C7":
        _add_c7_checkpoint_chart(ws, result, start_row=max(24, next_row))


def _add_c7_checkpoint_chart(ws: Any, result: MatrixResult, start_row: int) -> None:
    checkpoints = result.metrics.get("checkpoints") if isinstance(result.metrics, dict) else None
    if not isinstance(checkpoints, list) or not checkpoints:
        return

    ws[f"A{start_row}"] = "Checkpoint"
    ws[f"B{start_row}"] = "Total calls"
    ws[f"C{start_row}"] = "GET p95 [ms]"
    ws[f"D{start_row}"] = "WRITE p95 [ms]"
    ws[f"E{start_row}"] = "Error rate [%]"
    for col in ("A", "B", "C", "D", "E"):
        ws[f"{col}{start_row}"].font = Font(bold=True)

    for idx, cp in enumerate(checkpoints, start=1):
        row = start_row + idx
        ws[f"A{row}"] = idx
        ws[f"B{row}"] = cp.get("total_calls")
        ws[f"C{row}"] = cp.get("get_p95_ms")
        ws[f"D{row}"] = cp.get("write_p95_ms")
        ws[f"E{row}"] = cp.get("server_error_rate_percent")

    end_row = start_row + len(checkpoints)

    chart = LineChart()
    chart.title = "C7 trend: p95 i error rate"
    chart.y_axis.title = "Wartosc"
    chart.x_axis.title = "Checkpoint"
    data = Reference(ws, min_col=3, min_row=start_row, max_col=5, max_row=end_row)
    cats = Reference(ws, min_col=1, min_row=start_row + 1, max_row=end_row)
    chart.add_data(data, titles_from_data=True)
    chart.set_categories(cats)
    chart.height = 8
    chart.width = 13
    ws.add_chart(chart, "G15")


def _add_summary_charts(summary: Any, result_count: int) -> None:
    first_row = 2
    last_row = 1 + result_count

    # Helper table for chart data.
    summary["G1"] = "ID"
    summary["H1"] = "PASS_FLAG"
    summary["I1"] = "Czas [s]"
    summary["K1"] = "Status"
    summary["L1"] = "Count"

    for row in range(first_row, last_row + 1):
        summary[f"G{row}"] = summary[f"A{row}"].value
        summary[f"H{row}"] = 1 if str(summary[f"C{row}"].value) == "PASS" else 0
        summary[f"I{row}"] = summary[f"D{row}"].value

    summary["K2"] = "PASS"
    summary["L2"] = f"=SUM(H{first_row}:H{last_row})"
    summary["K3"] = "FAIL/PENDING"
    summary["L3"] = f"=COUNT(H{first_row}:H{last_row})-L2"

    bar = BarChart()
    bar.title = "Czas testow [s]"
    bar.y_axis.title = "Sekundy"
    bar.x_axis.title = "ID testu"
    bar_data = Reference(summary, min_col=9, min_row=1, max_row=last_row)
    bar_cats = Reference(summary, min_col=7, min_row=2, max_row=last_row)
    bar.add_data(bar_data, titles_from_data=True)
    bar.set_categories(bar_cats)
    bar.height = 8
    bar.width = 14
    summary.add_chart(bar, "G5")

    pie = PieChart()
    pie.title = "PASS vs FAIL/PENDING"
    pie_data = Reference(summary, min_col=12, min_row=1, max_row=3)
    pie_cats = Reference(summary, min_col=11, min_row=2, max_row=3)
    pie.add_data(pie_data, titles_from_data=True)
    pie.set_categories(pie_cats)
    pie.height = 8
    pie.width = 10
    summary.add_chart(pie, "N5")

    summary.column_dimensions["G"].width = 12
    summary.column_dimensions["H"].width = 12
    summary.column_dimensions["I"].width = 12
    summary.column_dimensions["K"].width = 16
    summary.column_dimensions["L"].width = 12


def write_excel(results: list[MatrixResult], output_path: Path) -> None:
    wb = Workbook()
    summary = wb.active
    summary.title = "Podsumowanie"

    headers = ["ID", "Nazwa", "Wynik", "Czas [s]", "Wnioski"]
    for idx, header in enumerate(headers, start=1):
        cell = summary.cell(row=1, column=idx, value=header)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")

    for row_idx, result in enumerate(results, start=2):
        summary.cell(row=row_idx, column=1, value=result.id)
        summary.cell(row=row_idx, column=2, value=result.name)
        summary.cell(row=row_idx, column=3, value="PASS" if result.passed else "FAIL/PENDING")
        summary.cell(row=row_idx, column=4, value=round(result.duration_seconds, 2))
        summary.cell(row=row_idx, column=5, value=result.conclusion)

        status_cell = summary.cell(row=row_idx, column=3)
        if result.passed:
            status_cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        else:
            status_cell.fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")

    summary.column_dimensions["A"].width = 8
    summary.column_dimensions["B"].width = 42
    summary.column_dimensions["C"].width = 14
    summary.column_dimensions["D"].width = 12
    summary.column_dimensions["E"].width = 100

    summary["A11"] = "Uruchomiono"
    summary["B11"] = _now_stamp()
    summary["A12"] = "Backend URL"
    summary["B12"] = base.BASE_URL
    summary["A13"] = "Opis"
    summary["B13"] = "Raport wygenerowany automatycznie przez scripts/run_full_matrix_and_export_excel.py"

    summary["A11"].font = Font(bold=True)
    summary["A12"].font = Font(bold=True)
    summary["A13"].font = Font(bold=True)

    _add_summary_charts(summary, result_count=len(results))

    for result in results:
        _write_result_sheet(wb, result)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run C1-C10 matrix tests and export Excel report.")
    parser.add_argument("--c5-seconds", type=int, default=180)
    parser.add_argument("--c7-seconds", type=int, default=600)
    parser.add_argument("--c6-baseline-seconds", type=int, default=25)
    parser.add_argument("--c6-with-scheduler-seconds", type=int, default=35)
    parser.add_argument("--c10-seconds", type=int, default=180)
    parser.add_argument("--output", type=str, default="docs/test-matrix-results.xlsx")
    args = parser.parse_args()

    random.seed()
    print("[INFO] Starting full matrix run against", base.BASE_URL)
    context = _create_shared_context()
    print(
        "[INFO] Prepared data:",
        f"operators={len(context['operators'])}",
        f"inspectionId={context['inspection_id']}",
        f"sharedRecommendationId={context['shared_rec_id']}",
    )

    results: list[MatrixResult] = []
    for runner in (run_c1, run_c2, run_c3, run_c4):
        result = runner(context)
        results.append(result)
        print(f"[{result.id}] {'PASS' if result.passed else 'FAIL'}", result.name)

    c5 = run_c5(context, duration_seconds=args.c5_seconds)
    results.append(c5)
    print(f"[{c5.id}] {'PASS' if c5.passed else 'FAIL'}", c5.name)

    c6 = run_c6(
        context,
        baseline_seconds=args.c6_baseline_seconds,
        with_scheduler_seconds=args.c6_with_scheduler_seconds,
    )
    results.append(c6)
    print(f"[{c6.id}] {'PASS' if c6.passed else 'FAIL'}", c6.name)

    c7 = run_c7(context, duration_seconds=args.c7_seconds)
    results.append(c7)
    print(f"[{c7.id}] {'PASS' if c7.passed else 'FAIL'}", c7.name)

    c8 = build_c8_placeholder()
    results.append(c8)
    print(f"[{c8.id}] PENDING", c8.name)

    c9 = run_c9_role_transition_regression()
    results.append(c9)
    print(f"[{c9.id}] {'PASS' if c9.passed else 'FAIL'}", c9.name)

    c10 = run_c10_cross_module_segmented(duration_seconds=args.c10_seconds)
    results.append(c10)
    print(f"[{c10.id}] {'PASS' if c10.passed else 'FAIL'}", c10.name)

    output_path = Path(args.output)
    write_excel(results, output_path=output_path)
    print("[INFO] Excel report saved to", str(output_path))

    overall_pass = all(r.passed for r in results if r.id != "C8")
    if overall_pass:
        print("[INFO] C1-C7 + C9-C10: PASS")
        return 0

    print("[WARN] C1-C7 + C9-C10 has failures")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

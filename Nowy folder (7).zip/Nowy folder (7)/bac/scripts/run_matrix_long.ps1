$ErrorActionPreference = 'Stop'

param(
    [ValidateRange(1, 24)]
    [int]$Hours = 4,
    [string]$Output = ''
)

$python = 'C:/Users/szczesnk/AppData/Local/Programs/Python/Python312/python.exe'
$script = 'scripts/run_full_matrix_and_export_excel.py'

$c7Seconds = $Hours * 3600
# C5 zostawiamy krotsze od C7, ale wystarczajaco dlugie do oceny stabilnosci ruchu mieszanego.
$c5Seconds = [Math]::Max(900, [int]($Hours * 900))
$c6BaselineSeconds = 60
$c6WithSchedulerSeconds = 120

if ([string]::IsNullOrWhiteSpace($Output)) {
    $Output = "docs/test-matrix-results-soak-${Hours}h.xlsx"
}

Write-Host "[INFO] Running long matrix profile"
Write-Host "[INFO] Hours=$Hours C5=${c5Seconds}s C6Baseline=${c6BaselineSeconds}s C6WithScheduler=${c6WithSchedulerSeconds}s C7=${c7Seconds}s"
Write-Host "[INFO] Output=$Output"

& $python $script `
    --c5-seconds $c5Seconds `
    --c7-seconds $c7Seconds `
    --c6-baseline-seconds $c6BaselineSeconds `
    --c6-with-scheduler-seconds $c6WithSchedulerSeconds `
    --output $Output

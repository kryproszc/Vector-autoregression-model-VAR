from __future__ import annotations

import os
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
DB_DIR = BASE_DIR / "Baza"
DB_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DB_DIR / "rejestr.db"


def get_connection() -> sqlite3.Connection:
    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(DB_PATH, timeout=max(1.0, busy_timeout_ms / 1000.0))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(f"PRAGMA journal_mode = {journal_mode}")
    conn.execute(f"PRAGMA busy_timeout = {busy_timeout_ms}")
    if journal_mode == "WAL":
        conn.execute("PRAGMA synchronous = NORMAL")
    return conn

from __future__ import annotations

import os
import smtplib
from email.message import EmailMessage
from typing import Any

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel

from app.db import get_connection


router = APIRouter()


class SendTestEmailRequest(BaseModel):
    smtpHost: str | None = None
    smtpPort: int | None = None
    smtpLogin: str | None = None
    smtpLoginMail: str | None = None
    smtpPass: str | None = None
    fromEmail: str | None = None
    toEmail: str | None = None
    subject: str = "Test SMTP"
    body: str = "To jest testowa wiadomosc wyslana z backendu."


class SendTestEmailResponse(BaseModel):
    ok: bool
    message: str
    toEmail: str


def _resolve_operator(operator_login: str | None) -> dict[str, Any]:
    login = (operator_login or "").strip()
    if not login:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT id, login, aktywny
            FROM users
            WHERE lower(login)=lower(?)
            LIMIT 1
            """,
            (login,),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    operator = dict(row)
    if int(operator["aktywny"]) != 1:
        raise HTTPException(status_code=403, detail="Operator jest nieaktywny")

    return operator


@router.post("/api/notifications/test-email", response_model=SendTestEmailResponse)
def send_test_email(
    payload: SendTestEmailRequest,
    x_operator_login: str | None = Header(default=None, alias="X-Operator-Login"),
) -> dict[str, Any]:
    _resolve_operator(x_operator_login)

    SMTP_HOST = (payload.smtpHost or os.getenv("SMTP_HOST") or "").strip()
    if payload.smtpPort is not None:
        SMTP_PORT = int(payload.smtpPort)
    else:
        smtp_port_raw = (os.getenv("SMTP_PORT") or "465").strip()
        try:
            SMTP_PORT = int(smtp_port_raw)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="SMTP_PORT ma niepoprawna wartosc") from exc

    SMTP_LOGIN = (payload.smtpLogin or os.getenv("SMTP_LOGIN") or "").strip()
    SMTP_PASS = payload.smtpPass or os.getenv("SMTP_PASS") or ""
    SMTP_LOGIN_MAIL = (payload.smtpLoginMail or os.getenv("SMTP_LOGIN_MAIL") or "").strip()

    FROM_EMAIL = (payload.fromEmail or SMTP_LOGIN_MAIL or os.getenv("FROM_EMAIL") or "").strip()
    TO_EMAIL = (payload.toEmail or os.getenv("TO_EMAIL") or "").strip()

    if SMTP_PORT <= 0:
        raise HTTPException(status_code=400, detail="smtpPort musi byc dodatni")
    if not SMTP_HOST:
        raise HTTPException(status_code=400, detail="Brak SMTP_HOST")
    if not SMTP_LOGIN:
        raise HTTPException(status_code=400, detail="Brak SMTP_LOGIN")
    if not SMTP_PASS:
        raise HTTPException(status_code=400, detail="Brak SMTP_PASS")
    if not FROM_EMAIL:
        raise HTTPException(status_code=400, detail="Brak FROM_EMAIL")
    if not TO_EMAIL:
        raise HTTPException(status_code=400, detail="Brak adresu docelowego (toEmail/TO_EMAIL)")
    if "@" not in TO_EMAIL:
        raise HTTPException(status_code=400, detail="Niepoprawny adres toEmail")

    msg = EmailMessage()
    msg["Subject"] = payload.subject
    msg["From"] = FROM_EMAIL
    msg["To"] = TO_EMAIL
    msg.set_content(payload.body)

    try:
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30) as server:
            server.login(SMTP_LOGIN, SMTP_PASS)
            server.send_message(msg)
    except smtplib.SMTPAuthenticationError as exc:
        raise HTTPException(status_code=502, detail="Blad logowania SMTP") from exc
    except smtplib.SMTPException as exc:
        raise HTTPException(status_code=502, detail="Blad SMTP podczas wysylki") from exc
    except OSError as exc:
        raise HTTPException(status_code=502, detail="Brak polaczenia z serwerem SMTP") from exc

    return {
        "ok": True,
        "message": "Mail wyslany poprawnie",
        "toEmail": TO_EMAIL,
    }

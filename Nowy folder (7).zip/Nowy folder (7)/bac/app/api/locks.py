from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request
from pydantic import BaseModel

from app.database import get_connection
from app.permissions import require_write_access
from app.record_locks import acquire_lock, canonical_module, heartbeat_lock, release_lock

router = APIRouter()


class LockTokenPayload(BaseModel):
    lockToken: str | None = None


def _resolve_operator(conn: Any, operator_login: str | None) -> dict[str, Any]:
    login = (operator_login or "").strip()
    if not login:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    row = conn.execute(
        """
        SELECT id, login, rola_id, zespol_id, aktywny, imie, nazwisko
        FROM users
        WHERE lower(login)=lower(?)
        LIMIT 1
        """,
        (login,),
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    operator = dict(row)
    if int(operator["aktywny"]) != 1:
        raise HTTPException(status_code=403, detail="Operator jest nieaktywny")

    display_name = str((operator.get("imie") or "")).strip()
    last_name = str((operator.get("nazwisko") or "")).strip()
    full_name = f"{display_name} {last_name}".strip()

    return {
        "id": int(operator["id"]),
        "login": str(operator["login"]),
        "rola_id": int(operator["rola_id"]),
        "zespol_id": operator["zespol_id"],
        "displayName": full_name or str(operator["login"]),
    }


@router.post("/api/locks/{module}/{record_id}/acquire")
def acquire_record_lock(
    module: str,
    record_id: str,
    x_operator_login: str | None = Header(default=None, alias="X-Operator-Login"),
) -> dict[str, Any]:
    module_name = canonical_module(module)

    with get_connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        operator = _resolve_operator(conn, x_operator_login)
        require_write_access(conn, operator)
        payload = acquire_lock(conn, module_name, record_id, operator)
        conn.commit()
        return payload


@router.post("/api/locks/{module}/{record_id}/heartbeat")
def heartbeat_record_lock(
    module: str,
    record_id: str,
    payload: LockTokenPayload,
    x_operator_login: str | None = Header(default=None, alias="X-Operator-Login"),
) -> dict[str, Any]:
    module_name = canonical_module(module)

    with get_connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        operator = _resolve_operator(conn, x_operator_login)
        require_write_access(conn, operator)
        result = heartbeat_lock(conn, module_name, record_id, operator, payload.lockToken)
        conn.commit()
        return result


@router.post("/api/locks/{module}/{record_id}/release")
async def release_record_lock(
    module: str,
    record_id: str,
    request: Request,
    x_operator_login: str | None = Header(default=None, alias="X-Operator-Login"),
) -> dict[str, Any]:
    module_name = canonical_module(module)

    # Parse body regardless of Content-Type.
    # sendBeacon wysyła Content-Type: text/plain z JSON string w body
    # i nie może ustawić niestandardowych nagłówków (np. X-Operator-Login).
    lock_token: str | None = None
    operator_login_from_body: str | None = None
    try:
        body_bytes = await request.body()
        if body_bytes:
            body_data = json.loads(body_bytes)
            lock_token = body_data.get("lockToken") or None
            operator_login_from_body = body_data.get("operatorLogin") or None
    except Exception:
        pass

    # Nagłówek X-Operator-Login ma pierwszeństwo; body fallback dla sendBeacon.
    effective_operator_login = x_operator_login or operator_login_from_body

    with get_connection() as conn:
        conn.execute("BEGIN IMMEDIATE")
        operator = _resolve_operator(conn, effective_operator_login)
        require_write_access(conn, operator)
        result = release_lock(conn, module_name, record_id, operator, lock_token)
        conn.commit()
        return result

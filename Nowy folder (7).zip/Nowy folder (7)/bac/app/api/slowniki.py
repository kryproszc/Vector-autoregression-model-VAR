from __future__ import annotations

import re
import unicodedata
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Query
from pydantic import BaseModel

from app.database import get_connection
from app.permissions import PERMISSION_MANAGEMENT_DICTIONARIES_WRITE, require_permission

router = APIRouter()

_ALLOWED_INSPECTION_TYPE_NAMES = {
    "kontrola",
    "wizyta nadzorcza",
}

_DECISION_RESOLUTION_KOD_TYPY = {
    "rozstrzygniecie_decyzji_i",
    "rozstrzygniecie_decyzji_ii",
}


class SlownikTypRead(BaseModel):
    id: int
    kodTypu: str
    nazwaTypu: str
    kategoria: int
    kategoriaNazwa: str
    opis: str | None = None
    aktywny: bool


class SlownikPozycjaRead(BaseModel):
    id: int
    typId: int
    kodTypu: str
    kodPozycji: str
    nazwaPozycji: str
    nazwaUzytkowa: str | None = None
    skrotPozycji: str | None = None
    nazwaPozycjiSkrocona: str | None = None
    nazwaPozycjiSkrot: str | None = None
    kolejnosc: int
    aktywny: bool


class SlownikPozycjaCreate(BaseModel):
    kodTypu: str
    kodPozycji: str | None = None
    nazwaPozycji: str
    nazwaUzytkowa: str | None = None
    skrotPozycji: str | None = None
    kolejnosc: int | None = None
    aktywny: bool = True


class SlownikPozycjaUpdate(BaseModel):
    kodTypu: str
    kodPozycji: str | None = None
    nazwaPozycji: str
    nazwaUzytkowa: str | None = None
    skrotPozycji: str | None = None
    aktywny: bool


class SlownikPozycjaUpdateById(BaseModel):
    nazwaPozycji: str
    nazwaUzytkowa: str | None = None
    skrotPozycji: str | None = None
    aktywny: bool


def _get_operator(conn: Any, operator_login: str) -> dict[str, Any]:
    row = conn.execute(
        """
        SELECT id, login, rola_id, aktywny
        FROM users
        WHERE lower(login) = lower(?)
        LIMIT 1
        """,
        (operator_login.strip(),),
    ).fetchone()

    if row is None:
        raise HTTPException(status_code=401, detail="Operator nie istnieje")

    data = dict(row)
    if int(data["aktywny"]) != 1:
        raise HTTPException(status_code=403, detail="Operator jest nieaktywny")

    if int(data["rola_id"]) not in (2, 3):
        raise HTTPException(status_code=403, detail="Brak uprawnien do zarzadzania slownikami")

    require_permission(conn, data, PERMISSION_MANAGEMENT_DICTIONARIES_WRITE)

    return data


def _map_slownik_pozycja_row(row: dict[str, Any]) -> dict[str, Any]:
    skrot = row["skrot_pozycji"]
    if isinstance(skrot, str):
        skrot = skrot.strip() or None

    nazwa_uzytkowa = row.get("nazwa_uzytkowa")
    if isinstance(nazwa_uzytkowa, str):
        nazwa_uzytkowa = nazwa_uzytkowa.strip() or None

    kod_typu = str(row["kod_typu"] or "").strip().lower()
    aktywny = bool(row["aktywny"])
    if skrot is None and aktywny and kod_typu in _DECISION_RESOLUTION_KOD_TYPY:
        skrot = str(row["nazwa_pozycji"] or "").strip() or None
    if kod_typu != "zakresy_inspekcji":
        nazwa_uzytkowa = None

    return {
        "id": row["id"],
        "typId": row["typ_id"],
        "kodTypu": row["kod_typu"],
        "kodPozycji": row["kod_pozycji"],
        "nazwaPozycji": row["nazwa_pozycji"],
        "nazwaUzytkowa": nazwa_uzytkowa,
        "skrotPozycji": skrot,
        "nazwaPozycjiSkrocona": skrot,
        "nazwaPozycjiSkrot": skrot,
        "kolejnosc": row["kolejnosc"],
        "aktywny": bool(row["aktywny"]),
    }


def _validate_inspection_type_name(raw_name: str) -> None:
    normalized = " ".join(raw_name.casefold().split())
    if normalized not in _ALLOWED_INSPECTION_TYPE_NAMES:
        raise HTTPException(status_code=400, detail="Dozwolone typy inspekcji: Kontrola, Wizyta nadzorcza")


def _kategoria_nazwa(kategoria: int) -> str:
    if kategoria == 3:
        return "Ogolne"
    if kategoria == 1:
        return "Zalecenia"
    if kategoria == 2:
        return "Wnioski sankcyjne"
    return "Inspekcje"


def _list_items_by_kod_typu(conn: Any, kod_typu: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT
            p.id,
            t.id AS typ_id,
            t.kod_typu,
            p.kod_pozycji,
            p.nazwa_pozycji,
            p.nazwa_uzytkowa,
            p.skrot_pozycji,
            p.kolejnosc,
            p.aktywny
        FROM slownik_pozycje p
        JOIN slownik_typy t ON t.kod_typu = p.kod_typu
        WHERE lower(p.kod_typu) = lower(?)
          AND (
              lower(?) <> 'osoby'
                            OR EXISTS (
                  SELECT 1
                  FROM users u
                                    WHERE lower(p.kod_pozycji) = lower('OSOBA_' || CAST(u.id AS TEXT))
                                        AND u.aktywny = 1
                                        AND u.rola_id <> 4
                                        AND lower(COALESCE(u.list_visibility, 'visible')) <> 'hidden'
              )
          )
                    AND (
                            lower(?) <> 'typy_inspekcji'
                            OR lower(trim(p.nazwa_pozycji)) IN ('kontrola', 'wizyta nadzorcza')
                    )
        ORDER BY COALESCE(p.kolejnosc, 2147483647) ASC, p.id ASC
        """,
                (kod_typu, kod_typu, kod_typu),
    ).fetchall()

    return [_map_slownik_pozycja_row(dict(row)) for row in rows]


def _normalize_auto_code(raw_name: str, max_len: int = 12) -> str:
    normalized = unicodedata.normalize("NFKD", raw_name)
    ascii_only = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^A-Za-z0-9]+", "_", ascii_only).strip("_").upper()
    slug = re.sub(r"_+", "_", slug)
    if not slug:
        slug = "POZYCJA"
    return slug[:max_len].rstrip("_") or "POZYCJA"


def _resolve_unique_code(
    conn: Any,
    kod_typu: str,
    nazwa_pozycji: str,
    explicit_code: str | None,
    exclude_id: int | None = None,
) -> str:
    if explicit_code is not None and explicit_code.strip():
        candidate = explicit_code.strip().upper()
        if not re.fullmatch(r"[A-Z0-9_]+", candidate):
            raise HTTPException(status_code=400, detail="kodPozycji musi byc uppercase i bez spacji")

        if exclude_id is None:
            exists = conn.execute(
                """
                SELECT id FROM slownik_pozycje
                WHERE lower(kod_typu) = lower(?) AND lower(kod_pozycji) = lower(?)
                LIMIT 1
                """,
                (kod_typu, candidate),
            ).fetchone()
        else:
            exists = conn.execute(
                """
                SELECT id FROM slownik_pozycje
                WHERE lower(kod_typu) = lower(?) AND lower(kod_pozycji) = lower(?) AND id <> ?
                LIMIT 1
                """,
                (kod_typu, candidate, exclude_id),
            ).fetchone()

        if exists is not None:
            raise HTTPException(status_code=409, detail="kodPozycji juz istnieje w tym slowniku")
        return candidate

    base_code = _normalize_auto_code(nazwa_pozycji)
    candidate = base_code
    suffix = 2
    while True:
        params: tuple[Any, ...]
        sql: str
        if exclude_id is None:
            sql = (
                "SELECT id FROM slownik_pozycje "
                "WHERE lower(kod_typu) = lower(?) AND lower(kod_pozycji) = lower(?) LIMIT 1"
            )
            params = (kod_typu, candidate)
        else:
            sql = (
                "SELECT id FROM slownik_pozycje "
                "WHERE lower(kod_typu) = lower(?) AND lower(kod_pozycji) = lower(?) AND id <> ? LIMIT 1"
            )
            params = (kod_typu, candidate, exclude_id)

        exists = conn.execute(sql, params).fetchone()
        if exists is None:
            return candidate
        candidate = f"{base_code}_{suffix}"
        suffix += 1


@router.get("/api/slowniki/typy", response_model=list[SlownikTypRead])
def list_slownik_types() -> list[dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT id, kod_typu, nazwa_typu, kategoria, opis, aktywny
            FROM slownik_typy
            ORDER BY kategoria ASC, id ASC
            """
        ).fetchall()

    return [
        {
            "id": row["id"],
            "kodTypu": row["kod_typu"],
            "nazwaTypu": row["nazwa_typu"],
            "kategoria": int(row["kategoria"]),
            "kategoriaNazwa": _kategoria_nazwa(int(row["kategoria"])),
            "opis": row["opis"],
            "aktywny": bool(row["aktywny"]),
        }
        for row in rows
    ]


@router.get("/api/slowniki/pozycje", response_model=list[SlownikPozycjaRead])
def list_slownik_items(
    kod_typu: str = Query(..., alias="kodTypu"),
) -> list[dict[str, Any]]:
    with get_connection() as conn:
        return _list_items_by_kod_typu(conn, kod_typu)


@router.get(
    "/api/slowniki/wnioski-sankcyjne/rozstrzygniecie-i",
    response_model=list[SlownikPozycjaRead],
)
def list_sanction_decisions_i() -> list[dict[str, Any]]:
    with get_connection() as conn:
        return _list_items_by_kod_typu(conn, "rozstrzygniecie_wniosku_sankcyjnego_I")


@router.post("/api/slowniki/pozycje", response_model=SlownikPozycjaRead)
def create_slownik_item(
    payload: SlownikPozycjaCreate,
    x_operator_login: str = Header(..., alias="X-Operator-Login"),
) -> dict[str, Any]:
    kod_typu = payload.kodTypu.strip().lower()
    nazwa_pozycji = payload.nazwaPozycji.strip()

    if not kod_typu:
        raise HTTPException(status_code=400, detail="kodTypu jest wymagane")
    if not nazwa_pozycji:
        raise HTTPException(status_code=400, detail="nazwaPozycji jest wymagane")

    nazwa_uzytkowa = payload.nazwaUzytkowa.strip() if payload.nazwaUzytkowa else None
    if nazwa_uzytkowa == "":
        nazwa_uzytkowa = None
    if kod_typu != "zakresy_inspekcji":
        nazwa_uzytkowa = None

    if kod_typu == "typy_inspekcji":
        _validate_inspection_type_name(nazwa_pozycji)

    with get_connection() as conn:
        _get_operator(conn, x_operator_login)

        typ = conn.execute(
            "SELECT id, kod_typu FROM slownik_typy WHERE lower(kod_typu) = lower(?) LIMIT 1",
            (kod_typu,),
        ).fetchone()
        if typ is None:
            raise HTTPException(status_code=400, detail="Nie znaleziono kodTypu")

        resolved_kod_typu = str(typ["kod_typu"])
        default_kod_pozycji = payload.kodPozycji
        if default_kod_pozycji is None and payload.skrotPozycji and payload.skrotPozycji.strip():
            default_kod_pozycji = _normalize_auto_code(payload.skrotPozycji, max_len=32)
        resolved_kod_pozycji = _resolve_unique_code(
            conn,
            resolved_kod_typu,
            nazwa_pozycji,
            default_kod_pozycji,
        )

        resolved_kolejnosc = payload.kolejnosc
        if resolved_kolejnosc is None:
            max_row = conn.execute(
                "SELECT COALESCE(MAX(kolejnosc), 0) AS max_kolejnosc FROM slownik_pozycje WHERE lower(kod_typu) = lower(?)",
                (resolved_kod_typu,),
            ).fetchone()
            resolved_kolejnosc = int(max_row["max_kolejnosc"]) + 1

        cursor = conn.execute(
            """
            INSERT INTO slownik_pozycje
            (kod_typu, kod_pozycji, nazwa_pozycji, nazwa_uzytkowa, skrot_pozycji, kolejnosc, aktywny)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                resolved_kod_typu,
                resolved_kod_pozycji,
                nazwa_pozycji,
                nazwa_uzytkowa,
                payload.skrotPozycji.strip() if payload.skrotPozycji else None,
                resolved_kolejnosc,
                1 if payload.aktywny else 0,
            ),
        )
        conn.commit()

        row = conn.execute(
            """
            SELECT
                p.id,
                t.id AS typ_id,
                t.kod_typu,
                p.kod_pozycji,
                p.nazwa_pozycji,
                p.nazwa_uzytkowa,
                p.skrot_pozycji,
                p.kolejnosc,
                p.aktywny
            FROM slownik_pozycje p
            JOIN slownik_typy t ON t.kod_typu = p.kod_typu
            WHERE p.id = ?
            LIMIT 1
            """,
            (cursor.lastrowid,),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=500, detail="Nie udalo sie pobrac zapisanej pozycji")

    return _map_slownik_pozycja_row(dict(row))


@router.put("/api/slowniki/pozycje", response_model=SlownikPozycjaRead)
def update_slownik_item(
    payload: SlownikPozycjaUpdate,
    x_operator_login: str = Header(..., alias="X-Operator-Login"),
) -> dict[str, Any]:
    kod_typu = payload.kodTypu.strip().lower()
    nazwa_pozycji = payload.nazwaPozycji.strip()

    if not kod_typu:
        raise HTTPException(status_code=400, detail="kodTypu jest wymagane")
    if not nazwa_pozycji:
        raise HTTPException(status_code=400, detail="nazwaPozycji jest wymagane")

    nazwa_uzytkowa = payload.nazwaUzytkowa.strip() if payload.nazwaUzytkowa else None
    if nazwa_uzytkowa == "":
        nazwa_uzytkowa = None
    if kod_typu != "zakresy_inspekcji":
        nazwa_uzytkowa = None

    if kod_typu == "typy_inspekcji":
        _validate_inspection_type_name(nazwa_pozycji)

    with get_connection() as conn:
        _get_operator(conn, x_operator_login)

        typ = conn.execute(
            "SELECT id, kod_typu FROM slownik_typy WHERE lower(kod_typu) = lower(?) LIMIT 1",
            (kod_typu,),
        ).fetchone()
        if typ is None:
            raise HTTPException(status_code=400, detail="Nie znaleziono kodTypu")

        resolved_kod_typu = str(typ["kod_typu"])

        if payload.kodPozycji is None:
            raise HTTPException(status_code=400, detail="Dla tego endpointu kodPozycji jest wymagane (lub uzyj PUT /api/slowniki/pozycje/{id})")

        kod_pozycji = payload.kodPozycji.strip().upper()
        if not kod_pozycji:
            raise HTTPException(status_code=400, detail="kodPozycji jest wymagane")
        if not re.fullmatch(r"[A-Z0-9_]+", kod_pozycji):
            raise HTTPException(status_code=400, detail="kodPozycji musi byc uppercase i bez spacji")

        current = conn.execute(
            """
            SELECT id
            FROM slownik_pozycje
            WHERE lower(kod_typu) = lower(?) AND lower(kod_pozycji) = lower(?)
            LIMIT 1
            """,
            (resolved_kod_typu, kod_pozycji),
        ).fetchone()
        if current is None:
            raise HTTPException(status_code=404, detail="Pozycja slownika nie istnieje")

        conn.execute(
            """
            UPDATE slownik_pozycje
            SET nazwa_pozycji = ?,
                nazwa_uzytkowa = ?,
                skrot_pozycji = ?,
                aktywny = ?,
                zaktualizowano_o = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                nazwa_pozycji,
                nazwa_uzytkowa,
                payload.skrotPozycji.strip() if payload.skrotPozycji else None,
                1 if payload.aktywny else 0,
                int(current["id"]),
            ),
        )
        conn.commit()

        row = conn.execute(
            """
            SELECT
                p.id,
                t.id AS typ_id,
                t.kod_typu,
                p.kod_pozycji,
                p.nazwa_pozycji,
                p.nazwa_uzytkowa,
                p.skrot_pozycji,
                p.kolejnosc,
                p.aktywny
            FROM slownik_pozycje p
            JOIN slownik_typy t ON t.kod_typu = p.kod_typu
            WHERE p.id = ?
            LIMIT 1
            """,
            (int(current["id"]),),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=500, detail="Nie udalo sie pobrac zaktualizowanej pozycji")

    return _map_slownik_pozycja_row(dict(row))


@router.put("/api/slowniki/pozycje/{pozycja_id}", response_model=SlownikPozycjaRead)
def update_slownik_item_by_id(
    pozycja_id: int,
    payload: SlownikPozycjaUpdateById,
    x_operator_login: str = Header(..., alias="X-Operator-Login"),
) -> dict[str, Any]:
    nazwa_pozycji = payload.nazwaPozycji.strip()
    if not nazwa_pozycji:
        raise HTTPException(status_code=400, detail="nazwaPozycji jest wymagane")

    nazwa_uzytkowa = payload.nazwaUzytkowa.strip() if payload.nazwaUzytkowa else None
    if nazwa_uzytkowa == "":
        nazwa_uzytkowa = None

    with get_connection() as conn:
        _get_operator(conn, x_operator_login)

        current = conn.execute(
            """
            SELECT p.id, p.kod_typu
            FROM slownik_pozycje p
            WHERE p.id = ?
            LIMIT 1
            """,
            (pozycja_id,),
        ).fetchone()
        if current is None:
            raise HTTPException(status_code=404, detail="Pozycja slownika nie istnieje")

        if str(current["kod_typu"]).strip().lower() == "typy_inspekcji":
            _validate_inspection_type_name(nazwa_pozycji)
        if str(current["kod_typu"]).strip().lower() != "zakresy_inspekcji":
            nazwa_uzytkowa = None

        conn.execute(
            """
            UPDATE slownik_pozycje
            SET nazwa_pozycji = ?,
                nazwa_uzytkowa = ?,
                skrot_pozycji = ?,
                aktywny = ?,
                zaktualizowano_o = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (
                nazwa_pozycji,
                nazwa_uzytkowa,
                payload.skrotPozycji.strip() if payload.skrotPozycji else None,
                1 if payload.aktywny else 0,
                pozycja_id,
            ),
        )
        conn.commit()

        row = conn.execute(
            """
            SELECT
                p.id,
                t.id AS typ_id,
                t.kod_typu,
                p.kod_pozycji,
                p.nazwa_pozycji,
                p.nazwa_uzytkowa,
                p.skrot_pozycji,
                p.kolejnosc,
                p.aktywny
            FROM slownik_pozycje p
            JOIN slownik_typy t ON t.kod_typu = p.kod_typu
            WHERE p.id = ?
            LIMIT 1
            """,
            (pozycja_id,),
        ).fetchone()

    if row is None:
        raise HTTPException(status_code=500, detail="Nie udalo sie pobrac zaktualizowanej pozycji")

    return _map_slownik_pozycja_row(dict(row))

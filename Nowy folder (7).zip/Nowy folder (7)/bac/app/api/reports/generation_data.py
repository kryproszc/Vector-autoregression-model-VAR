from __future__ import annotations

import argparse
from collections import defaultdict
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any


def build_subject_name(idx: int, pool_size: int, prefix: str) -> str:
    safe_pool = max(1, int(pool_size))
    safe_prefix = (prefix or "").strip() or "Podmiot"
    number = ((int(idx) - 1) % safe_pool) + 1
    return f"{safe_prefix}_{number}"


def build_year_count_sections(rows_for_counts: list[dict[str, Any]], inspection_type: str) -> tuple[list[str], list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    year_type_counts: dict[str, dict[str, int]] = defaultdict(lambda: {"K": 0, "W": 0})
    for row in rows_for_counts:
        year_value = str(row.get("rokPoczatku") or "").strip()
        row_type = str(row.get("inspekcja") or "").strip().upper()
        if not year_value or row_type not in {"K", "W"}:
            continue
        year_type_counts[year_value][row_type] += 1

    year_count_columns = sorted(year_type_counts.keys())
    year_count_rows = [
        {
            "label": "Kontrola",
            "values": {year: int(year_type_counts[year]["K"]) for year in year_count_columns},
        },
        {
            "label": "Wizyta nadzorcza",
            "values": {year: int(year_type_counts[year]["W"]) for year in year_count_columns},
        },
        {
            "label": "Razem",
            "values": {year: int(year_type_counts[year]["K"] + year_type_counts[year]["W"]) for year in year_count_columns},
        },
    ]

    team_year_type_counts: dict[str, dict[str, dict[str, int]]] = defaultdict(lambda: defaultdict(lambda: {"K": 0, "W": 0}))
    for row in rows_for_counts:
        team_name = str(row.get("zespol") or "").strip()
        year_value = str(row.get("rokPoczatku") or "").strip()
        row_type = str(row.get("inspekcja") or "").strip().upper()
        if not team_name or not year_value or row_type not in {"K", "W"}:
            continue
        team_year_type_counts[team_name][year_value][row_type] += 1

    teams_in_counts = sorted(
        [team for team in team_year_type_counts.keys() if team not in {"", "-"}],
        key=lambda value: value.lower(),
    )
    year_count_by_team_columns = list(year_count_columns)
    year_count_by_team_rows: list[dict[str, Any]] = []

    for team_name in teams_in_counts:
        team_values_k = {
            year: int(team_year_type_counts[team_name].get(year, {}).get("K", 0))
            for year in year_count_by_team_columns
        }
        team_values_w = {
            year: int(team_year_type_counts[team_name].get(year, {}).get("W", 0))
            for year in year_count_by_team_columns
        }
        year_count_by_team_rows.append(
            {
                "label": f"{team_name} - Kontrola",
                "zespol": team_name,
                "inspekcja": "K",
                "values": team_values_k,
            }
        )
        year_count_by_team_rows.append(
            {
                "label": f"{team_name} - Wizyta nadzorcza",
                "zespol": team_name,
                "inspekcja": "W",
                "values": team_values_w,
            }
        )

    department_values_k = {year: int(year_type_counts[year]["K"]) for year in year_count_by_team_columns}
    department_values_w = {year: int(year_type_counts[year]["W"]) for year in year_count_by_team_columns}

    year_count_by_team_rows.append(
        {
            "label": "Departament - Kontrola",
            "zespol": "Departament",
            "inspekcja": "K",
            "values": department_values_k,
        }
    )
    year_count_by_team_rows.append(
        {
            "label": "Departament - Wizyta nadzorcza",
            "zespol": "Departament",
            "inspekcja": "W",
            "values": department_values_w,
        }
    )

    year_count_by_team_rows = [
        row for row in year_count_by_team_rows if str(row.get("inspekcja") or "").upper() == inspection_type
    ]

    return year_count_columns, year_count_rows, year_count_by_team_columns, year_count_by_team_rows


def _run_seed(
    *,
    from_year: int,
    to_year: int,
    per_member_per_type_per_year: int,
    subject_pool_size: int,
    subject_prefix: str,
) -> int:
    project_root = Path(__file__).resolve().parents[3]
    script_path = project_root / "scripts" / "seed_inspections_and_sanctions_three_teams.py"

    cmd = [
        sys.executable,
        str(script_path),
        "--from-year",
        str(from_year),
        "--to-year",
        str(to_year),
        "--per-member-per-type-per-year",
        str(per_member_per_type_per_year),
        "--subject-pool-size",
        str(subject_pool_size),
        "--subject-prefix",
        str(subject_prefix),
    ]

    env = dict(os.environ)
    env["PYTHONPATH"] = str(project_root)

    proc = subprocess.run(cmd, cwd=str(project_root), env=env, text=True)
    return int(proc.returncode)


def _main() -> int:
    parser = argparse.ArgumentParser(description="Standalone helpers for generation_data")
    sub = parser.add_subparsers(dest="command", required=False)

    subject_cmd = sub.add_parser("subject", help="Generate one subject name")
    subject_cmd.add_argument("--idx", type=int, default=1, help="1-based item index")
    subject_cmd.add_argument("--pool-size", type=int, default=30, help="Pool size")
    subject_cmd.add_argument("--prefix", type=str, default="Podmiot", help="Name prefix")

    counts_cmd = sub.add_parser("counts", help="Generate count sections from rows JSON")
    counts_cmd.add_argument("--inspection-type", choices=["K", "W"], required=True, help="Inspection type")
    counts_cmd.add_argument(
        "--rows-file",
        type=str,
        required=True,
        help="Path to JSON file with rows_for_counts list",
    )

    seed_cmd = sub.add_parser("seed", help="Run seeding script that writes data to DB")
    seed_cmd.add_argument("--from-year", type=int, default=2016)
    seed_cmd.add_argument("--to-year", type=int, default=2026)
    seed_cmd.add_argument("--per-member-per-type-per-year", type=int, default=7)
    seed_cmd.add_argument("--subject-pool-size", type=int, default=30)
    seed_cmd.add_argument("--subject-prefix", type=str, default="Podmiot")

    args = parser.parse_args()

    if args.command is None:
        # VS Code Run button starts file without args; default to DB seeding.
        return _run_seed(
            from_year=2016,
            to_year=2026,
            per_member_per_type_per_year=7,
            subject_pool_size=30,
            subject_prefix="Podmiot",
        )

    if args.command == "subject":
        idx = getattr(args, "idx", 1)
        pool_size = getattr(args, "pool_size", 30)
        prefix = getattr(args, "prefix", "Podmiot")
        print(build_subject_name(idx, pool_size, prefix))
        return 0

    if args.command == "seed":
        return _run_seed(
            from_year=int(args.from_year),
            to_year=int(args.to_year),
            per_member_per_type_per_year=int(args.per_member_per_type_per_year),
            subject_pool_size=int(args.subject_pool_size),
            subject_prefix=str(args.subject_prefix),
        )

    with open(args.rows_file, encoding="utf-8") as fp:
        rows = json.load(fp)
    if not isinstance(rows, list):
        raise RuntimeError("rows-file must contain a JSON list")

    year_count_columns, year_count_rows, year_count_by_team_columns, year_count_by_team_rows = build_year_count_sections(rows, args.inspection_type)
    print(
        json.dumps(
            {
                "yearCountColumns": year_count_columns,
                "yearCountRows": year_count_rows,
                "yearCountByTeamColumns": year_count_by_team_columns,
                "yearCountByTeamRows": year_count_by_team_rows,
            },
            ensure_ascii=True,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())

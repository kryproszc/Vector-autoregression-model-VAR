from __future__ import annotations

from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import os
import secrets
import sqlite3


PBKDF2_ALGO = "sha256"
PBKDF2_ITERATIONS = 210_000
SALT_BYTES = 16
TOKEN_BYTES = 48


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def hash_password(password: str) -> str:
    raw = str(password or "")
    if len(raw) < 8:
        raise ValueError("Haslo musi miec co najmniej 8 znakow")

    salt = secrets.token_bytes(SALT_BYTES)
    digest = hashlib.pbkdf2_hmac(PBKDF2_ALGO, raw.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_{PBKDF2_ALGO}${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored_hash: str | None) -> bool:
    if not stored_hash:
        return False

    try:
        scheme, iter_raw, salt_hex, digest_hex = stored_hash.split("$", 3)
    except ValueError:
        return False

    if scheme != f"pbkdf2_{PBKDF2_ALGO}":
        return False

    try:
        iterations = int(iter_raw)
        salt = bytes.fromhex(salt_hex)
        expected = bytes.fromhex(digest_hex)
    except (ValueError, TypeError):
        return False

    candidate = hashlib.pbkdf2_hmac(PBKDF2_ALGO, str(password or "").encode("utf-8"), salt, iterations)
    return hmac.compare_digest(candidate, expected)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _session_ttl_hours() -> int:
    raw = (os.getenv("AUTH_SESSION_TTL_HOURS") or "12").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return 12
    return parsed if parsed > 0 else 12


def _max_login_attempts() -> int:
    raw = (os.getenv("AUTH_MAX_LOGIN_ATTEMPTS") or "5").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return 5
    return parsed if parsed > 0 else 5


def _login_window_minutes() -> int:
    raw = (os.getenv("AUTH_LOGIN_WINDOW_MINUTES") or "15").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return 15
    return parsed if parsed > 0 else 15


def _lockout_minutes() -> int:
    raw = (os.getenv("AUTH_LOCKOUT_MINUTES") or "15").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return 15
    return parsed if parsed > 0 else 15


def _password_reset_min_interval_seconds() -> int:
    raw = (os.getenv("AUTH_PASSWORD_RESET_MIN_INTERVAL_SECONDS") or "60").strip()
    try:
        parsed = int(raw)
    except ValueError:
        return 60
    return parsed if parsed > 0 else 60


def _cleanup_expired_sessions(conn: sqlite3.Connection) -> None:
    now_iso = _utc_now().isoformat(timespec="seconds")
    conn.execute("DELETE FROM auth_sessions WHERE expires_at <= ?", (now_iso,))


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


def issue_session_token(conn: sqlite3.Connection, user_id: int) -> tuple[str, str]:
    _cleanup_expired_sessions(conn)
    token = secrets.token_urlsafe(TOKEN_BYTES)
    expires_at = (_utc_now() + timedelta(hours=_session_ttl_hours())).isoformat(timespec="seconds")
    conn.execute(
        """
        INSERT INTO auth_sessions (user_id, token_hash, expires_at)
        VALUES (?, ?, ?)
        """,
        (int(user_id), hash_token(token), expires_at),
    )
    return token, expires_at


def extract_bearer_token(authorization: str | None) -> str | None:
    raw = (authorization or "").strip()
    if not raw:
        return None
    parts = raw.split(" ", 1)
    if len(parts) != 2:
        return None
    if parts[0].lower() != "bearer":
        return None
    token = parts[1].strip()
    return token or None


def get_user_id_by_token(conn: sqlite3.Connection, token: str | None) -> int | None:
    if not token:
        return None

    _cleanup_expired_sessions(conn)
    now_iso = _utc_now().isoformat(timespec="seconds")
    row = conn.execute(
        """
        SELECT user_id
        FROM auth_sessions
        WHERE token_hash = ? AND revoked_at IS NULL AND expires_at > ?
        LIMIT 1
        """,
        (hash_token(token), now_iso),
    ).fetchone()
    if row is None:
        return None
    return int(row["user_id"])


def revoke_token(conn: sqlite3.Connection, token: str | None) -> None:
    if not token:
        return

    conn.execute(
        """
        UPDATE auth_sessions
        SET revoked_at = CURRENT_TIMESTAMP
        WHERE token_hash = ? AND revoked_at IS NULL
        """,
        (hash_token(token),),
    )


def revoke_user_sessions(conn: sqlite3.Connection, user_id: int) -> None:
    conn.execute(
        """
        UPDATE auth_sessions
        SET revoked_at = CURRENT_TIMESTAMP
        WHERE user_id = ? AND revoked_at IS NULL
        """,
        (int(user_id),),
    )


def ensure_login_allowed(conn: sqlite3.Connection, login: str) -> tuple[bool, str | None]:
    key = str(login or "").strip().lower()
    if not key:
        return True, None

    now = _utc_now()
    now_iso = now.isoformat(timespec="seconds")
    row = conn.execute(
        """
        SELECT failed_count, first_failed_at, locked_until
        FROM auth_login_attempts
        WHERE login_key = ?
        LIMIT 1
        """,
        (key,),
    ).fetchone()
    if row is None:
        return True, None

    data = dict(row)
    locked_until = _parse_iso(data.get("locked_until"))
    if locked_until is not None and locked_until > now:
        return False, locked_until.isoformat(timespec="seconds")

    first_failed_at = _parse_iso(data.get("first_failed_at"))
    if first_failed_at is not None:
        window_limit = now - timedelta(minutes=_login_window_minutes())
        if first_failed_at <= window_limit:
            conn.execute(
                """
                UPDATE auth_login_attempts
                SET failed_count = 0,
                    first_failed_at = NULL,
                    locked_until = NULL,
                    updated_at = ?
                WHERE login_key = ?
                """,
                (now_iso, key),
            )
            return True, None

    return True, None


def register_login_failure(conn: sqlite3.Connection, login: str) -> str | None:
    key = str(login or "").strip().lower()
    if not key:
        return None

    now = _utc_now()
    now_iso = now.isoformat(timespec="seconds")
    row = conn.execute(
        """
        SELECT failed_count, first_failed_at
        FROM auth_login_attempts
        WHERE login_key = ?
        LIMIT 1
        """,
        (key,),
    ).fetchone()

    if row is None:
        failed_count = 1
        first_failed_at = now
        conn.execute(
            """
            INSERT INTO auth_login_attempts (login_key, failed_count, first_failed_at, updated_at)
            VALUES (?, ?, ?, ?)
            """,
            (key, failed_count, now_iso, now_iso),
        )
    else:
        data = dict(row)
        first_failed_at = _parse_iso(data.get("first_failed_at")) or now
        window_limit = now - timedelta(minutes=_login_window_minutes())
        if first_failed_at <= window_limit:
            failed_count = 1
            first_failed_at = now
        else:
            failed_count = int(data.get("failed_count") or 0) + 1

        conn.execute(
            """
            UPDATE auth_login_attempts
            SET failed_count = ?,
                first_failed_at = ?,
                updated_at = ?
            WHERE login_key = ?
            """,
            (failed_count, first_failed_at.isoformat(timespec="seconds"), now_iso, key),
        )

    if failed_count >= _max_login_attempts():
        locked_until = (now + timedelta(minutes=_lockout_minutes())).isoformat(timespec="seconds")
        conn.execute(
            """
            UPDATE auth_login_attempts
            SET locked_until = ?,
                updated_at = ?
            WHERE login_key = ?
            """,
            (locked_until, now_iso, key),
        )
        return locked_until

    return None


def clear_login_failures(conn: sqlite3.Connection, login: str) -> None:
    key = str(login or "").strip().lower()
    if not key:
        return

    now_iso = _utc_now().isoformat(timespec="seconds")
    conn.execute(
        """
        UPDATE auth_login_attempts
        SET failed_count = 0,
            first_failed_at = NULL,
            locked_until = NULL,
            updated_at = ?
        WHERE login_key = ?
        """,
        (now_iso, key),
    )


def ensure_password_reset_allowed(conn: sqlite3.Connection, request_key: str) -> tuple[bool, str | None]:
    key = str(request_key or "").strip().lower()
    if not key:
        return True, None

    row = conn.execute(
        """
        SELECT last_requested_at
        FROM auth_password_reset_throttle
        WHERE request_key = ?
        LIMIT 1
        """,
        (key,),
    ).fetchone()
    if row is None:
        return True, None

    last_requested_at = _parse_iso(dict(row).get("last_requested_at"))
    if last_requested_at is None:
        return True, None

    now = _utc_now()
    next_allowed = last_requested_at + timedelta(seconds=_password_reset_min_interval_seconds())
    if now < next_allowed:
        return False, next_allowed.isoformat(timespec="seconds")

    return True, None


def register_password_reset_request(conn: sqlite3.Connection, request_key: str) -> None:
    key = str(request_key or "").strip().lower()
    if not key:
        return

    now_iso = _utc_now().isoformat(timespec="seconds")
    conn.execute(
        """
        INSERT INTO auth_password_reset_throttle (request_key, last_requested_at)
        VALUES (?, ?)
        ON CONFLICT(request_key)
        DO UPDATE SET last_requested_at = excluded.last_requested_at
        """,
        (key, now_iso),
    )

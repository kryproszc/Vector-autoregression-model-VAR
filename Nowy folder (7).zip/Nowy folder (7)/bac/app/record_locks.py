from __future__ import annotations

from datetime import datetime, timedelta, timezone
import logging
import uuid
from typing import Any

from fastapi import HTTPException

LOCK_TTL_SECONDS = 60

logger = logging.getLogger(__name__)

MODULE_INSPECTIONS = "inspections"
MODULE_RECOMMENDATIONS = "recommendations"
MODULE_OBLIGATING_DECISIONS = "obligating-decisions"
MODULE_SANCTION_REQUESTS = "sanction-requests"

_MODULE_ALIASES: dict[str, str] = {
    "risk_exposure": MODULE_SANCTION_REQUESTS,
    "risk-exposure": MODULE_SANCTION_REQUESTS,
}

_MODULE_TABLES: dict[str, str] = {
    MODULE_INSPECTIONS: "inspections",
    MODULE_RECOMMENDATIONS: "recommendations",
    MODULE_OBLIGATING_DECISIONS: "obligating_decisions",
    MODULE_SANCTION_REQUESTS: "risk_exposure_requests",
}


def now_rfc3339_utc_ms() -> str:
    value = datetime.now(timezone.utc)
    return value.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def canonical_module(raw_module: str) -> str:
    cleaned = (raw_module or "").strip().lower()
    mapped = _MODULE_ALIASES.get(cleaned, cleaned)
    if mapped not in _MODULE_TABLES:
        raise HTTPException(status_code=400, detail="Nieznany modul")
    return mapped


def _table_for_module(module_name: str) -> str:
    table = _MODULE_TABLES.get(module_name)
    if table is None:
        raise HTTPException(status_code=400, detail="Nieznany modul")
    return table


def _coerce_numeric_record_id(raw_record_id: str | int) -> int | None:
    if isinstance(raw_record_id, int):
        return int(raw_record_id)
    text = str(raw_record_id or "").strip()
    if not text:
        return None
    if text.isdigit() or (text.startswith("-") and text[1:].isdigit()):
        return int(text)
    return None


def _resolve_existing_record_id(conn: Any, module_name: str, record_id: str | int) -> int:
    numeric_record_id = _coerce_numeric_record_id(record_id)
    if numeric_record_id is not None:
        table_name = _table_for_module(module_name)
        row = conn.execute(f"SELECT id FROM {table_name} WHERE id = ? LIMIT 1", (int(numeric_record_id),)).fetchone()
        if row is not None:
            if module_name == MODULE_INSPECTIONS:
                logger.info(
                    "[LOCK-ACQUIRE-MAP] module=%s inputRecordId=%s resolvedRecordId=%s mapping=id",
                    module_name,
                    str(record_id),
                    int(row["id"]),
                )
            return int(row["id"])

    # Compatibility fallback for inspections: LP and kod_inspekcji mapping.
    if module_name == MODULE_INSPECTIONS:
        if numeric_record_id is not None:
            by_lp = conn.execute("SELECT id FROM inspections WHERE lp = ? LIMIT 1", (int(numeric_record_id),)).fetchone()
            if by_lp is not None:
                logger.info(
                    "[LOCK-ACQUIRE-MAP] module=%s inputRecordId=%s resolvedRecordId=%s mapping=lp",
                    module_name,
                    str(record_id),
                    int(by_lp["id"]),
                )
                return int(by_lp["id"])

        by_code = conn.execute(
            "SELECT id FROM inspections WHERE lower(kod_inspekcji) = lower(?) LIMIT 1",
            (str(record_id or "").strip(),),
        ).fetchone()
        if by_code is not None:
            logger.info(
                "[LOCK-ACQUIRE-MAP] module=%s inputRecordId=%s resolvedRecordId=%s mapping=kod_inspekcji",
                module_name,
                str(record_id),
                int(by_code["id"]),
            )
            return int(by_code["id"])

        logger.warning(
            "[LOCK-ACQUIRE-MAP] module=%s inputRecordId=%s mapping=not_found",
            module_name,
            str(record_id),
        )
        raise HTTPException(status_code=404, detail="Record not found")

    if numeric_record_id is None:
        raise HTTPException(status_code=400, detail="Niepoprawny recordId")

    table_name = _table_for_module(module_name)
    row = conn.execute(f"SELECT id FROM {table_name} WHERE id = ? LIMIT 1", (int(numeric_record_id),)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Record not found")
    return int(row["id"])


def _parse_rfc3339_utc_ms(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _is_lock_active(lock_row: dict[str, Any], now_dt: datetime) -> bool:
    expires_dt = _parse_rfc3339_utc_ms(str(lock_row.get("expires_at") or ""))
    if expires_dt is None:
        return False
    return expires_dt > now_dt


def _owner_payload(lock_row: dict[str, Any] | None) -> dict[str, Any]:
    if lock_row is None:
        return {
            "ownerUserId": None,
            "ownerLogin": None,
            "ownerDisplayName": None,
            "acquiredAt": None,
            "expiresAt": None,
        }

    owner_user_id = lock_row.get("owner_user_id")
    return {
        "ownerUserId": int(owner_user_id) if owner_user_id is not None else None,
        "ownerLogin": lock_row.get("owner_login"),
        "ownerDisplayName": lock_row.get("owner_display_name"),
        "acquiredAt": lock_row.get("acquired_at"),
        "expiresAt": lock_row.get("expires_at"),
    }


def _record_locked_detail(module_name: str, record_id: int, lock_row: dict[str, Any]) -> dict[str, Any]:
    detail = {
        "code": "RECORD_LOCKED",
        "module": module_name,
        "recordId": int(record_id),
    }
    detail.update(_owner_payload(lock_row))
    return detail


def _lock_token_error_detail(
    module_name: str,
    record_id: int,
    code: str,
    reason: str,
    lock_row: dict[str, Any] | None,
) -> dict[str, Any]:
    detail = {
        "code": code,
        "reason": reason,
        "module": module_name,
        "recordId": int(record_id),
    }
    detail.update(_owner_payload(lock_row))
    return detail


def _raise_record_locked(module_name: str, record_id: int, lock_row: dict[str, Any]) -> None:
    logger.warning(
        "[LOCK-ERROR] code=RECORD_LOCKED module=%s recordId=%s ownerUserId=%s",
        module_name,
        int(record_id),
        lock_row.get("owner_user_id"),
    )
    raise HTTPException(status_code=423, detail=_record_locked_detail(module_name, record_id, lock_row))


def _raise_lock_required(module_name: str, record_id: int, lock_row: dict[str, Any] | None = None) -> None:
    logger.warning(
        "[LOCK-ERROR] code=LOCK_REQUIRED reason=lock_required module=%s recordId=%s",
        module_name,
        int(record_id),
    )
    raise HTTPException(
        status_code=423,
        detail=_lock_token_error_detail(module_name, record_id, "LOCK_REQUIRED", "lock_required", lock_row),
    )


def _raise_lock_token_invalid(module_name: str, record_id: int, lock_row: dict[str, Any] | None = None) -> None:
    logger.warning(
        "[LOCK-ERROR] code=LOCK_TOKEN_INVALID reason=lock_token_invalid module=%s recordId=%s",
        module_name,
        int(record_id),
    )
    raise HTTPException(
        status_code=423,
        detail=_lock_token_error_detail(
            module_name,
            record_id,
            "LOCK_TOKEN_INVALID",
            "lock_token_invalid",
            lock_row,
        ),
    )


def _to_lock_response(module_name: str, record_id: int, lock_row: dict[str, Any]) -> dict[str, Any]:
    return {
        "module": module_name,
        "recordId": int(record_id),
        "lockToken": lock_row["lock_token"],
        "acquiredAt": lock_row["acquired_at"],
        "expiresAt": lock_row["expires_at"],
        "ownerUserId": int(lock_row["owner_user_id"]),
        "ownerLogin": lock_row["owner_login"],
        "ownerDisplayName": lock_row["owner_display_name"],
    }


def ensure_record_exists(conn: Any, module_name: str, record_id: str | int) -> None:
    _resolve_existing_record_id(conn, module_name, record_id)


def _get_lock_row(conn: Any, module_name: str, record_id: int) -> dict[str, Any] | None:
    row = conn.execute(
        """
        SELECT module_name, record_id, lock_token, owner_user_id, owner_login, owner_display_name,
               acquired_at, heartbeat_at, expires_at
        FROM record_edit_locks
        WHERE module_name = ? AND record_id = ?
        LIMIT 1
        """,
        (module_name, int(record_id)),
    ).fetchone()
    return dict(row) if row is not None else None


def acquire_lock(conn: Any, module_name: str, record_id: str | int, operator: dict[str, Any]) -> dict[str, Any]:
    logger.info(
        "[LOCK-ACQUIRE] module=%s inputRecordId=%s operatorId=%s operatorLogin=%s",
        module_name,
        str(record_id),
        int(operator["id"]),
        str(operator.get("login") or ""),
    )
    resolved_record_id = _resolve_existing_record_id(conn, module_name, record_id)

    now_dt = datetime.now(timezone.utc)
    now_text = now_rfc3339_utc_ms()
    expires_text = (now_dt + timedelta(seconds=LOCK_TTL_SECONDS)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    existing = _get_lock_row(conn, module_name, resolved_record_id)
    if existing is not None and _is_lock_active(existing, now_dt):
        if int(existing["owner_user_id"]) != int(operator["id"]):
            _raise_record_locked(module_name, resolved_record_id, existing)

        conn.execute(
            """
            UPDATE record_edit_locks
            SET heartbeat_at = ?, expires_at = ?
            WHERE module_name = ? AND record_id = ?
            """,
            (now_text, expires_text, module_name, int(resolved_record_id)),
        )
        updated = _get_lock_row(conn, module_name, resolved_record_id)
        if updated is None:
            raise HTTPException(status_code=500, detail="Lock acquire failed")
        return _to_lock_response(module_name, resolved_record_id, updated)

    token = uuid.uuid4().hex
    owner_display_name = str(operator.get("displayName") or operator.get("login") or "").strip()
    if existing is None:
        conn.execute(
            """
            INSERT INTO record_edit_locks (
                module_name, record_id, lock_token, owner_user_id, owner_login, owner_display_name,
                acquired_at, heartbeat_at, expires_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                module_name,
                int(resolved_record_id),
                token,
                int(operator["id"]),
                str(operator["login"]),
                owner_display_name,
                now_text,
                now_text,
                expires_text,
            ),
        )
    else:
        conn.execute(
            """
            UPDATE record_edit_locks
            SET lock_token = ?,
                owner_user_id = ?,
                owner_login = ?,
                owner_display_name = ?,
                acquired_at = ?,
                heartbeat_at = ?,
                expires_at = ?
            WHERE module_name = ? AND record_id = ?
            """,
            (
                token,
                int(operator["id"]),
                str(operator["login"]),
                owner_display_name,
                now_text,
                now_text,
                expires_text,
                module_name,
                int(resolved_record_id),
            ),
        )

    created = _get_lock_row(conn, module_name, resolved_record_id)
    if created is None:
        raise HTTPException(status_code=500, detail="Lock acquire failed")
    return _to_lock_response(module_name, resolved_record_id, created)


def heartbeat_lock(
    conn: Any,
    module_name: str,
    record_id: str | int,
    operator: dict[str, Any],
    lock_token: str | None,
) -> dict[str, Any]:
    resolved_record_id = _resolve_existing_record_id(conn, module_name, record_id)
    if not (lock_token or "").strip():
        _raise_lock_required(module_name, resolved_record_id)

    now_dt = datetime.now(timezone.utc)
    now_text = now_rfc3339_utc_ms()
    expires_text = (now_dt + timedelta(seconds=LOCK_TTL_SECONDS)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    existing = _get_lock_row(conn, module_name, resolved_record_id)
    if existing is None or not _is_lock_active(existing, now_dt):
        _raise_lock_token_invalid(module_name, resolved_record_id)

    if int(existing["owner_user_id"]) != int(operator["id"]):
        _raise_record_locked(module_name, resolved_record_id, existing)

    if str(existing["lock_token"]) != str(lock_token):
        _raise_lock_token_invalid(module_name, resolved_record_id, existing)

    conn.execute(
        """
        UPDATE record_edit_locks
        SET heartbeat_at = ?, expires_at = ?
        WHERE module_name = ? AND record_id = ?
        """,
        (now_text, expires_text, module_name, int(resolved_record_id)),
    )

    updated = _get_lock_row(conn, module_name, resolved_record_id)
    if updated is None:
        raise HTTPException(status_code=500, detail="Lock heartbeat failed")
    return _to_lock_response(module_name, resolved_record_id, updated)


def release_lock(
    conn: Any,
    module_name: str,
    record_id: str | int,
    operator: dict[str, Any],
    lock_token: str | None,
) -> dict[str, Any]:
    resolved_record_id = _resolve_existing_record_id(conn, module_name, record_id)
    if not (lock_token or "").strip():
        _raise_lock_required(module_name, resolved_record_id)

    now_dt = datetime.now(timezone.utc)
    existing = _get_lock_row(conn, module_name, resolved_record_id)

    if existing is None or not _is_lock_active(existing, now_dt):
        conn.execute(
            "DELETE FROM record_edit_locks WHERE module_name = ? AND record_id = ?",
            (module_name, int(resolved_record_id)),
        )
        return {"module": module_name, "recordId": int(resolved_record_id), "released": True}

    if int(existing["owner_user_id"]) != int(operator["id"]):
        _raise_record_locked(module_name, resolved_record_id, existing)

    if str(existing["lock_token"]) != str(lock_token):
        _raise_lock_token_invalid(module_name, resolved_record_id, existing)

    conn.execute(
        "DELETE FROM record_edit_locks WHERE module_name = ? AND record_id = ?",
        (module_name, int(resolved_record_id)),
    )
    return {"module": module_name, "recordId": int(resolved_record_id), "released": True}


def assert_lock_for_save(
    conn: Any,
    module_name: str,
    record_id: int,
    operator: dict[str, Any],
    lock_token: str | None,
) -> None:
    logger.info(
        "[LOCK-SAVE-CHECK] module=%s recordId=%s operatorId=%s",
        module_name,
        int(record_id),
        int(operator["id"]),
    )
    if not (lock_token or "").strip():
        _raise_lock_required(module_name, record_id)

    now_dt = datetime.now(timezone.utc)
    now_text = now_rfc3339_utc_ms()
    expires_text = (now_dt + timedelta(seconds=LOCK_TTL_SECONDS)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    existing = _get_lock_row(conn, module_name, record_id)

    if existing is not None and _is_lock_active(existing, now_dt) and int(existing["owner_user_id"]) != int(operator["id"]):
        _raise_record_locked(module_name, record_id, existing)

    if existing is None or not _is_lock_active(existing, now_dt):
        _raise_lock_token_invalid(module_name, record_id)

    if int(existing["owner_user_id"]) != int(operator["id"]):
        _raise_lock_token_invalid(module_name, record_id, existing)

    if str(existing["lock_token"]) != str(lock_token):
        _raise_lock_token_invalid(module_name, record_id, existing)

    conn.execute(
        """
        UPDATE record_edit_locks
        SET heartbeat_at = ?, expires_at = ?
        WHERE module_name = ? AND record_id = ?
        """,
        (now_text, expires_text, module_name, int(record_id)),
    )


def assert_expected_updated_at(expected_updated_at: str | None, current_updated_at: str | None) -> None:
    expected = str(expected_updated_at or "").strip()
    if not expected:
        raise HTTPException(status_code=400, detail="expectedUpdatedAt is required")

    current = str(current_updated_at or "")
    if expected != current:
        logger.warning(
            "[LOCK-SAVE-CHECK] code=VERSION_CONFLICT expectedUpdatedAt=%s currentUpdatedAt=%s",
            expected,
            current,
        )
        raise HTTPException(
            status_code=409,
            detail={
                "code": "VERSION_CONFLICT",
                "currentUpdatedAt": current,
            },
        )

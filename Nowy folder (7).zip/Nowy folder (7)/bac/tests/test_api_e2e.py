from __future__ import annotations

import io
import os
import re
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import datetime
from urllib.parse import parse_qs, urlsplit
import uuid
from pathlib import Path
from typing import Any

from fastapi.testclient import TestClient

from app.database import connection as db_connection
from app.db import get_connection


class ApiE2ETestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp_dir_path = Path(tempfile.mkdtemp(prefix="rejestr-tests-"))
        cls._original_db_path = db_connection.DB_PATH
        db_connection.DB_PATH = cls._tmp_dir_path / "bootstrap_rejestr_test.db"

        from app.main import app

        cls.client = TestClient(app)

    def setUp(self) -> None:
        # Fresh DB per test keeps tests deterministic and independent.
        db_connection.DB_PATH = self._tmp_dir_path / f"rejestr_test_{uuid.uuid4().hex}.db"

        from app.db import init_db

        init_db()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.client.close()
        db_connection.DB_PATH = cls._original_db_path
        # Intentionally do not delete temp directory on Windows to avoid sqlite file-lock flakiness.

    def _admin_headers(self) -> dict[str, str]:
        return {"X-Operator-Login": "admin"}

    def _operator_headers(self, login: str) -> dict[str, str]:
        return {"X-Operator-Login": login}

    def _auth_headers(self, token: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {token}"}

    def _team_id(self, code: str = "A") -> int:
        teams = self.client.get("/api/admin/teams").json()
        for team in teams:
            if team["kod"] == code:
                return int(team["id"])
        raise AssertionError(f"Team code {code} not found")

    def _create_user(self, role_id: int, team_id: int | None) -> dict:
        suffix = uuid.uuid4().hex[:8]
        payload = {
            "login": f"user_{suffix}",
            "imie": "Test",
            "nazwisko": f"User{suffix}",
            "email": f"user_{suffix}@example.local",
            "rolaId": role_id,
            "zespolId": team_id,
            "aktywny": True,
        }
        response = self.client.post(
            "/api/admin/users",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def _set_user_password(self, user_id: int, password: str) -> None:
        response = self.client.put(
            f"/api/admin/users/{user_id}/password",
            json={"password": password},
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

    def _update_user_role(self, user_id: int, role_id: int, team_id: int | None) -> None:
        payload: dict[str, Any] = {"rolaId": role_id}
        payload["zespolId"] = team_id
        response = self.client.put(
            f"/api/admin/users/{user_id}",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

    def _ensure_person_slownik_id(self, user: dict[str, Any]) -> int:
        person_code = f"OSOBA_{int(user['id'])}"
        ensure_person = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "osoby",
                "kodPozycji": person_code,
                "nazwaPozycji": f"{user['imie']} {user['nazwisko']}",
                "skrotPozycji": user["login"],
            },
            headers=self._admin_headers(),
        )
        self.assertIn(ensure_person.status_code, {200, 409}, ensure_person.text)
        if ensure_person.status_code == 200:
            return int(ensure_person.json()["id"])

        with get_connection() as conn:
            person_row = conn.execute(
                """
                SELECT id
                FROM slownik_pozycje
                WHERE lower(kod_typu) = 'osoby'
                  AND lower(kod_pozycji) = lower(?)
                LIMIT 1
                """,
                (person_code,),
            ).fetchone()

        self.assertIsNotNone(person_row)
        assert person_row is not None
        return int(person_row["id"])

    def _update_recommendation_with_lock(self, recommendation_id: int, login: str, payload: dict[str, Any]) -> Any:
        headers = self._operator_headers(login)
        detail = self.client.get(f"/api/recommendations/{recommendation_id}", headers=headers)
        self.assertEqual(detail.status_code, 200, detail.text)

        lock_acquire = self.client.post(
            f"/api/locks/recommendations/{recommendation_id}/acquire",
            headers=headers,
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        update_payload = dict(payload)
        update_payload["lockToken"] = lock_token
        update_payload["expectedUpdatedAt"] = detail.json()["zaktualizowanoO"]
        response = self.client.put(
            f"/api/recommendations/{recommendation_id}",
            json=update_payload,
            headers=headers,
        )

        release = self.client.post(
            f"/api/locks/recommendations/{recommendation_id}/release",
            json={"lockToken": lock_token},
            headers=headers,
        )
        self.assertEqual(release.status_code, 200, release.text)
        return response

    def _update_inspection_with_lock(self, inspection_id: int, login: str, payload: dict[str, Any]) -> Any:
        headers = self._operator_headers(login)
        detail = self.client.get(f"/api/structure/inspections/{inspection_id}", headers=headers)
        self.assertEqual(detail.status_code, 200, detail.text)

        lock_acquire = self.client.post(
            f"/api/locks/inspections/{inspection_id}/acquire",
            headers=headers,
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        update_payload = dict(payload)
        update_payload["lockToken"] = lock_token
        update_payload["expectedUpdatedAt"] = detail.json()["zaktualizowanoO"]
        response = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json=update_payload,
            headers=headers,
        )

        release = self.client.post(
            f"/api/locks/inspections/{inspection_id}/release",
            json={"lockToken": lock_token},
            headers=headers,
        )
        self.assertEqual(release.status_code, 200, release.text)
        return response

    def test_slownik_types_include_department_in_general_category(self) -> None:
        response = self.client.get("/api/slowniki/typy")
        self.assertEqual(response.status_code, 200, response.text)
        types = response.json()

        sanctions_department = next((item for item in types if item["kodTypu"] == "department"), None)
        self.assertIsNotNone(sanctions_department)
        assert sanctions_department is not None
        self.assertEqual(int(sanctions_department["kategoria"]), 2)
        self.assertEqual(sanctions_department["kategoriaNazwa"], "Wnioski sankcyjne")

        general_department = next((item for item in types if item["kodTypu"] == "department_ogolne"), None)
        self.assertIsNotNone(general_department)
        assert general_department is not None
        self.assertEqual(int(general_department["kategoria"]), 3)
        self.assertEqual(general_department["kategoriaNazwa"], "Ogolne")
        self.assertEqual(general_department["nazwaTypu"], "Departament")

    def _update_sanction_with_lock(self, sanction_id: int, login: str, payload: dict[str, Any]) -> Any:
        headers = self._operator_headers(login)
        detail = self.client.get(f"/api/sanction-requests/{sanction_id}", headers=headers)
        self.assertEqual(detail.status_code, 200, detail.text)

        lock_acquire = self.client.post(
            f"/api/locks/sanction-requests/{sanction_id}/acquire",
            headers=headers,
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        update_payload = dict(payload)
        update_payload["lockToken"] = lock_token
        update_payload["expectedUpdatedAt"] = detail.json()["zaktualizowanoO"]
        response = self.client.put(
            f"/api/sanction-requests/{sanction_id}",
            json=update_payload,
            headers=headers,
        )

        release = self.client.post(
            f"/api/locks/sanction-requests/{sanction_id}/release",
            json={"lockToken": lock_token},
            headers=headers,
        )
        self.assertEqual(release.status_code, 200, release.text)
        return response

    def _update_decision_with_lock(self, decision_id: int, login: str, payload: dict[str, Any]) -> Any:
        headers = self._operator_headers(login)
        detail = self.client.get(f"/api/obligating-decisions/{decision_id}", headers=headers)
        self.assertEqual(detail.status_code, 200, detail.text)

        lock_acquire = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=headers,
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        update_payload = dict(payload)
        update_payload["lockToken"] = lock_token
        update_payload["expectedUpdatedAt"] = detail.json()["zaktualizowanoO"]
        response = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json=update_payload,
            headers=headers,
        )

        release = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_token},
            headers=headers,
        )
        self.assertEqual(release.status_code, 200, release.text)
        return response

    def test_team_creation_without_leader_then_assign_and_unset(self) -> None:
        base_team_id = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=base_team_id)

        code = f"T{uuid.uuid4().hex[:5]}".upper()
        create_team_payload = {
            "kod": code,
            "nazwa": f"Team {code}",
        }
        created_team = self.client.post(
            "/api/admin/teams",
            json=create_team_payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(created_team.status_code, 201, created_team.text)
        team_obj = created_team.json()
        self.assertIsNone(team_obj["kierownikUserId"])

        team_id = int(team_obj["id"])
        assign = self.client.put(
            f"/api/admin/teams/{team_id}",
            json={"kierownikUserId": inspector["id"]},
            headers=self._admin_headers(),
        )
        self.assertEqual(assign.status_code, 200, assign.text)
        self.assertEqual(assign.json()["kierownikUserId"], inspector["id"])

        users = self.client.get("/api/admin/users", headers=self._admin_headers()).json()
        assigned_user = next(u for u in users if int(u["id"]) == int(inspector["id"]))
        self.assertEqual(int(assigned_user["rolaId"]), 2)
        self.assertEqual(int(assigned_user["zespolId"]), team_id)

        unset = self.client.put(
            f"/api/admin/teams/{team_id}",
            json={"kierownikUserId": None},
            headers=self._admin_headers(),
        )
        self.assertEqual(unset.status_code, 200, unset.text)
        self.assertIsNone(unset.json()["kierownikUserId"])

    def test_team_lead_user_list_uses_managed_team_fallback(self) -> None:
        team_a = self._team_id("A")
        leader = self._create_user(role_id=1, team_id=team_a)
        member = self._create_user(role_id=1, team_id=team_a)

        assign_leader = self.client.put(
            f"/api/admin/teams/{team_a}",
            json={"kierownikUserId": int(leader["id"])},
            headers=self._admin_headers(),
        )
        self.assertEqual(assign_leader.status_code, 200, assign_leader.text)

        # Simulate stale profile mismatch: leader still manages team, but own team id was cleared.
        clear_leader_team = self.client.put(
            f"/api/admin/users/{int(leader['id'])}",
            json={"accountType": "observer"},
            headers=self._admin_headers(),
        )
        self.assertEqual(clear_leader_team.status_code, 200, clear_leader_team.text)

        as_leader = self.client.get(
            "/api/admin/users",
            headers=self._operator_headers(str(leader["login"])),
        )
        self.assertEqual(as_leader.status_code, 200, as_leader.text)
        visible_ids = {int(item["id"]) for item in as_leader.json()}
        self.assertIn(int(member["id"]), visible_ids)

    def test_admin_users_list_includes_created_by_metadata(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        users = self.client.get("/api/admin/users", headers=self._admin_headers())
        self.assertEqual(users.status_code, 200, users.text)
        inspector_row = next(item for item in users.json() if int(item["id"]) == int(inspector["id"]))
        self.assertEqual(inspector_row["createdByLogin"], "admin")
        self.assertTrue(bool(inspector_row["createdByOperator"]))

    def test_user_profile_fields_and_history(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        users = self.client.get("/api/admin/users", headers=self._admin_headers())
        self.assertEqual(users.status_code, 200, users.text)
        inspector_row = next(item for item in users.json() if int(item["id"]) == int(inspector["id"]))
        self.assertEqual(inspector_row["accountType"], "diu")
        self.assertEqual(inspector_row["departmentCode"], "DIU")
        self.assertEqual(inspector_row["listVisibility"], "visible")
        self.assertIn("profileChangedAt", inspector_row)
        self.assertIn("profileChangedBy", inspector_row)

        switch_to_observer = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={
                "accountType": "observer",
                "listVisibility": "hidden",
                "rolaId": 1,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(switch_to_observer.status_code, 200, switch_to_observer.text)
        switched_payload = switch_to_observer.json()
        self.assertEqual(switched_payload["accountType"], "observer")
        self.assertEqual(switched_payload["listVisibility"], "hidden")
        self.assertIsNone(switched_payload["zespolId"])
        self.assertIsNone(switched_payload["zespolSkroconaNazwa"])
        self.assertIsNone(switched_payload["zespolPelnaNazwa"])

        history = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history",
            headers=self._admin_headers(),
        )
        self.assertEqual(history.status_code, 200, history.text)
        history_rows = history.json()
        self.assertGreaterEqual(len(history_rows), 2)
        self.assertEqual(history_rows[0]["accountType"], "diu")
        self.assertEqual(int(history_rows[0]["zespolId"]), int(team_a))
        self.assertEqual(history_rows[-1]["accountType"], "observer")
        self.assertIsNone(history_rows[-1]["zespolId"])
        self.assertIsNone(history_rows[-1]["validTo"])
        self.assertIsNotNone(history_rows[-1]["changedBy"])
        self.assertEqual(history_rows[-1]["changedBy"]["login"], "admin")

        events = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history/events",
            headers=self._admin_headers(),
        )
        self.assertEqual(events.status_code, 200, events.text)
        event_rows = events.json()
        self.assertGreaterEqual(len(event_rows), 1)
        latest = event_rows[0]
        self.assertIn("eventId", latest)
        self.assertIn("changedAt", latest)
        self.assertIn("changedBy", latest)
        self.assertIn("changes", latest)
        self.assertTrue(bool(latest["changes"]))
        changed_fields = {str(change["field"]) for change in latest["changes"]}
        self.assertIn("accountType", changed_fields)
        self.assertIn("listVisibility", changed_fields)

        deactivate_observer = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={"aktywny": False},
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate_observer.status_code, 422, deactivate_observer.text)

        technical_active_forbidden = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={
                "accountType": "technical",
                "aktywny": True,
                "email": None,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(technical_active_forbidden.status_code, 422, technical_active_forbidden.text)

        technical_email_forbidden = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={
                "accountType": "technical",
                "aktywny": False,
                "email": "tech@example.local",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(technical_email_forbidden.status_code, 422, technical_email_forbidden.text)

        technical_ok = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={
                "accountType": "technical",
                "aktywny": False,
                "email": None,
                "login": "",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(technical_ok.status_code, 200, technical_ok.text)
        technical_payload = technical_ok.json()
        self.assertEqual(technical_payload["accountType"], "technical")
        self.assertFalse(bool(technical_payload["aktywny"]))
        self.assertIsNone(technical_payload["email"])

        send_invite_technical_forbidden = self.client.post(
            f"/api/admin/users/{int(inspector['id'])}/send-invite",
            headers=self._admin_headers(),
        )
        self.assertEqual(send_invite_technical_forbidden.status_code, 422)

    def test_admin_users_list_returns_department_code_fallback_for_diu(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        with get_connection() as conn:
            conn.execute(
                "UPDATE users SET department_code = NULL WHERE id = ?",
                (int(inspector["id"]),),
            )
            conn.commit()

        users = self.client.get("/api/admin/users", headers=self._admin_headers())
        self.assertEqual(users.status_code, 200, users.text)
        inspector_row = next(item for item in users.json() if int(item["id"]) == int(inspector["id"]))
        self.assertEqual(inspector_row["accountType"], "diu")
        self.assertEqual(inspector_row["departmentCode"], "DIU")

    def test_login_blank_rules_for_inactive_and_technical(self) -> None:
        team_a = self._team_id("A")

        create_active_blank_login = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Aktywny",
                "nazwisko": "BezLoginu",
                "email": "aktywny@example.local",
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": True,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_active_blank_login.status_code, 422, create_active_blank_login.text)
        self.assertIn("login", str(create_active_blank_login.json().get("detail", "")).lower())

        create_inactive_blank_login = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Nieaktywny",
                "nazwisko": "BezLoginu",
                "email": None,
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": False,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_inactive_blank_login.status_code, 200, create_inactive_blank_login.text)
        inactive_payload = create_inactive_blank_login.json()
        self.assertEqual(inactive_payload["login"], "")
        self.assertFalse(bool(inactive_payload["aktywny"]))

        create_technical_blank_login = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Tech",
                "nazwisko": "Konto",
                "email": None,
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": None,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_technical_blank_login.status_code, 200, create_technical_blank_login.text)
        technical_payload = create_technical_blank_login.json()
        self.assertEqual(technical_payload["login"], "")
        self.assertEqual(technical_payload["accountType"], "technical")

        update_active_blank_login = self.client.put(
            f"/api/admin/users/{int(inactive_payload['id'])}",
            json={
                "aktywny": True,
                "accountType": "diu",
                "departmentCode": "DIU",
                "login": "",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(update_active_blank_login.status_code, 422, update_active_blank_login.text)
        self.assertIn("login", str(update_active_blank_login.json().get("detail", "")).lower())

    def test_internal_login_is_regenerated_for_inactive_and_technical(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        inspector_id = int(inspector["id"])
        original_login = str(inspector["login"])

        deactivate = self.client.put(
            f"/api/admin/users/{inspector_id}",
            json={
                "aktywny": False,
                "accountType": "diu",
                "departmentCode": "DIU",
                "email": None,
                "login": "",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate.status_code, 200, deactivate.text)

        with get_connection() as conn:
            row_after_inactive = conn.execute("SELECT login FROM users WHERE id = ?", (inspector_id,)).fetchone()
        self.assertIsNotNone(row_after_inactive)
        assert row_after_inactive is not None
        inactive_login = str(row_after_inactive["login"])
        self.assertNotEqual(inactive_login, original_login)
        self.assertTrue(inactive_login.startswith("__inactive_"))

        reactivate_observer = self.client.put(
            f"/api/admin/users/{inspector_id}",
            json={
                "aktywny": True,
                "accountType": "observer",
                "rolaId": 1,
                "login": f"observer_{uuid.uuid4().hex[:8]}",
                "email": f"observer_{uuid.uuid4().hex[:8]}@example.local",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(reactivate_observer.status_code, 200, reactivate_observer.text)

        with get_connection() as conn:
            row_after_observer = conn.execute("SELECT login FROM users WHERE id = ?", (inspector_id,)).fetchone()
        self.assertIsNotNone(row_after_observer)
        assert row_after_observer is not None
        observer_login = str(row_after_observer["login"])

        switch_to_technical = self.client.put(
            f"/api/admin/users/{inspector_id}",
            json={
                "accountType": "technical",
                "aktywny": False,
                "email": None,
                "login": "",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(switch_to_technical.status_code, 200, switch_to_technical.text)

        with get_connection() as conn:
            row_after_technical = conn.execute("SELECT login FROM users WHERE id = ?", (inspector_id,)).fetchone()
        self.assertIsNotNone(row_after_technical)
        assert row_after_technical is not None
        technical_login = str(row_after_technical["login"])
        self.assertNotEqual(technical_login, observer_login)
        self.assertTrue(technical_login.startswith("__technical_"))

    def test_profile_history_appended_on_every_user_update_and_permissions_update(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        history_before = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history",
            headers=self._admin_headers(),
        )
        self.assertEqual(history_before.status_code, 200, history_before.text)
        count_before = len(history_before.json())

        no_effect_update = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={"imie": inspector["imie"]},
            headers=self._admin_headers(),
        )
        self.assertEqual(no_effect_update.status_code, 200, no_effect_update.text)

        history_after_put = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history",
            headers=self._admin_headers(),
        )
        self.assertEqual(history_after_put.status_code, 200, history_after_put.text)
        count_after_put = len(history_after_put.json())
        self.assertEqual(count_after_put, count_before + 1)

        events_before = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history/events",
            headers=self._admin_headers(),
        )
        self.assertEqual(events_before.status_code, 200, events_before.text)
        count_events_before = len(events_before.json())

        no_effect_update_2 = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}",
            json={"imie": inspector["imie"]},
            headers=self._admin_headers(),
        )
        self.assertEqual(no_effect_update_2.status_code, 200, no_effect_update_2.text)

        events_after = self.client.get(
            f"/api/admin/users/{int(inspector['id'])}/profile-history/events",
            headers=self._admin_headers(),
        )
        self.assertEqual(events_after.status_code, 200, events_after.text)
        self.assertEqual(len(events_after.json()), count_events_before)

        external = self.client.post(
            "/api/admin/users/external",
            json={
                "login": f"observer_{uuid.uuid4().hex[:8]}",
                "imie": "Obs",
                "nazwisko": "Erver",
                "email": f"observer_{uuid.uuid4().hex[:8]}@example.local",
                "permissions": [
                    "registry.inspections.read",
                    "registry.recommendations.read",
                ],
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(external.status_code, 201, external.text)
        external_id = int(external.json()["user"]["id"])

        ext_history_before = self.client.get(
            f"/api/admin/users/{external_id}/profile-history",
            headers=self._admin_headers(),
        )
        self.assertEqual(ext_history_before.status_code, 200, ext_history_before.text)
        ext_count_before = len(ext_history_before.json())

        update_permissions = self.client.put(
            f"/api/admin/users/{external_id}/permissions",
            json={
                "permissions": [
                    "registry.inspections.read",
                    "registry.recommendations.read",
                    "registry.risk_exposure.read",
                ]
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(update_permissions.status_code, 200, update_permissions.text)

        ext_history_after = self.client.get(
            f"/api/admin/users/{external_id}/profile-history",
            headers=self._admin_headers(),
        )
        self.assertEqual(ext_history_after.status_code, 200, ext_history_after.text)
        ext_count_after = len(ext_history_after.json())
        self.assertEqual(ext_count_after, ext_count_before + 1)

    def test_auth_capabilities_login_and_me(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        self.assertTrue(bool(admin_login.json()["user"]["canViewTimeReports"]))
        self.assertFalse(bool(admin_login.json()["user"]["canViewOwnTimeReport"]))

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        inspector_login = self.client.post("/api/auth/login", json={"login": inspector["login"]})
        self.assertEqual(inspector_login.status_code, 200, inspector_login.text)
        self.assertFalse(bool(inspector_login.json()["user"]["canViewTimeReports"]))
        self.assertTrue(bool(inspector_login.json()["user"]["canViewOwnTimeReport"]))

        me = self.client.get("/api/auth/me", headers=self._operator_headers(inspector["login"]))
        self.assertEqual(me.status_code, 200, me.text)
        self.assertEqual(me.json()["user"]["login"], inspector["login"])
        self.assertFalse(bool(me.json()["user"]["canViewTimeReports"]))
        self.assertTrue(bool(me.json()["user"]["canViewOwnTimeReport"]))

        me_missing_header = self.client.get("/api/auth/me")
        self.assertEqual(me_missing_header.status_code, 401)

    def test_auth_team_lead_team_scope_fallback(self) -> None:
        team_a = self._team_id("A")
        leader = self._create_user(role_id=1, team_id=team_a)

        assign_leader = self.client.put(
            f"/api/admin/teams/{team_a}",
            json={"kierownikUserId": int(leader["id"])},
            headers=self._admin_headers(),
        )
        self.assertEqual(assign_leader.status_code, 200, assign_leader.text)

        clear_profile_team = self.client.put(
            f"/api/admin/users/{int(leader['id'])}",
            json={"accountType": "observer"},
            headers=self._admin_headers(),
        )
        self.assertEqual(clear_profile_team.status_code, 200, clear_profile_team.text)

        as_operator = self.client.get(
            "/api/auth/me",
            headers=self._operator_headers(str(leader["login"])),
        )
        self.assertEqual(as_operator.status_code, 200, as_operator.text)
        payload = as_operator.json()["user"]
        self.assertEqual(int(payload["rolaId"]), 2)
        self.assertEqual(int(payload["zespolId"]), int(team_a))

    def test_auth_password_login_token_me_and_logout(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        self._set_user_password(admin_id, "AdminPass!2026")

        bad = self.client.post(
            "/api/auth/password-login",
            json={"login": "admin", "password": "wrong-password"},
        )
        self.assertEqual(bad.status_code, 401)

        ok = self.client.post(
            "/api/auth/password-login",
            json={"login": "admin", "password": "AdminPass!2026"},
        )
        self.assertEqual(ok.status_code, 200, ok.text)
        payload = ok.json()
        self.assertIn("token", payload)
        self.assertIn("expiresAt", payload)
        token = str(payload["token"])

        me = self.client.get("/api/auth/me-token", headers=self._auth_headers(token))
        self.assertEqual(me.status_code, 200, me.text)
        self.assertEqual(me.json()["user"]["login"], "admin")

        logout = self.client.post("/api/auth/logout-token", headers=self._auth_headers(token))
        self.assertEqual(logout.status_code, 200, logout.text)
        self.assertTrue(bool(logout.json()["ok"]))

        me_after_logout = self.client.get("/api/auth/me-token", headers=self._auth_headers(token))
        self.assertEqual(me_after_logout.status_code, 401)

    def test_auth_change_password_revokes_existing_sessions(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        self._set_user_password(admin_id, "AdminPass!2026")

        login = self.client.post(
            "/api/auth/password-login",
            json={"login": "admin", "password": "AdminPass!2026"},
        )
        self.assertEqual(login.status_code, 200, login.text)
        token = str(login.json()["token"])

        bad_change = self.client.post(
            "/api/auth/change-password",
            json={"oldPassword": "wrong-old", "newPassword": "AdminPass!2027"},
            headers=self._auth_headers(token),
        )
        self.assertEqual(bad_change.status_code, 401)

        ok_change = self.client.post(
            "/api/auth/change-password",
            json={"oldPassword": "AdminPass!2026", "newPassword": "AdminPass!2027"},
            headers=self._auth_headers(token),
        )
        self.assertEqual(ok_change.status_code, 200, ok_change.text)
        self.assertTrue(bool(ok_change.json()["ok"]))

        old_token_check = self.client.get("/api/auth/me-token", headers=self._auth_headers(token))
        self.assertEqual(old_token_check.status_code, 401)

        old_login = self.client.post(
            "/api/auth/password-login",
            json={"login": "admin", "password": "AdminPass!2026"},
        )
        self.assertEqual(old_login.status_code, 401)

        new_login = self.client.post(
            "/api/auth/password-login",
            json={"login": "admin", "password": "AdminPass!2027"},
        )
        self.assertEqual(new_login.status_code, 200, new_login.text)

    def test_admin_password_reset_is_director_only(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        forbidden = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}/password",
            json={"password": "InspectorPass!2026"},
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden.status_code, 403)

        allowed = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}/password",
            json={"password": "InspectorPass!2026"},
            headers=self._admin_headers(),
        )
        self.assertEqual(allowed.status_code, 200, allowed.text)

        issued = self.client.post(
            "/api/auth/password-login",
            json={"login": inspector["login"], "password": "InspectorPass!2026"},
        )
        self.assertEqual(issued.status_code, 200, issued.text)
        token = str(issued.json()["token"])

        second_reset = self.client.put(
            f"/api/admin/users/{int(inspector['id'])}/password",
            json={"password": "InspectorPass!2027"},
            headers=self._admin_headers(),
        )
        self.assertEqual(second_reset.status_code, 200, second_reset.text)

        me_after_reset = self.client.get("/api/auth/me-token", headers=self._auth_headers(token))
        self.assertEqual(me_after_reset.status_code, 401)

        login = self.client.post(
            "/api/auth/password-login",
            json={"login": inspector["login"], "password": "InspectorPass!2027"},
        )
        self.assertEqual(login.status_code, 200, login.text)

    def test_password_login_rate_limit_and_lockout(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])
        self._set_user_password(admin_id, "AdminPass!2026")

        prev_max = os.environ.get("AUTH_MAX_LOGIN_ATTEMPTS")
        prev_window = os.environ.get("AUTH_LOGIN_WINDOW_MINUTES")
        prev_lockout = os.environ.get("AUTH_LOCKOUT_MINUTES")
        os.environ["AUTH_MAX_LOGIN_ATTEMPTS"] = "2"
        os.environ["AUTH_LOGIN_WINDOW_MINUTES"] = "15"
        os.environ["AUTH_LOCKOUT_MINUTES"] = "10"
        try:
            first = self.client.post(
                "/api/auth/password-login",
                json={"login": "admin", "password": "wrong-1"},
            )
            self.assertEqual(first.status_code, 401)

            second = self.client.post(
                "/api/auth/password-login",
                json={"login": "admin", "password": "wrong-2"},
            )
            self.assertEqual(second.status_code, 429)

            blocked = self.client.post(
                "/api/auth/password-login",
                json={"login": "admin", "password": "AdminPass!2026"},
            )
            self.assertEqual(blocked.status_code, 429)
        finally:
            if prev_max is None:
                os.environ.pop("AUTH_MAX_LOGIN_ATTEMPTS", None)
            else:
                os.environ["AUTH_MAX_LOGIN_ATTEMPTS"] = prev_max

            if prev_window is None:
                os.environ.pop("AUTH_LOGIN_WINDOW_MINUTES", None)
            else:
                os.environ["AUTH_LOGIN_WINDOW_MINUTES"] = prev_window

            if prev_lockout is None:
                os.environ.pop("AUTH_LOCKOUT_MINUTES", None)
            else:
                os.environ["AUTH_LOCKOUT_MINUTES"] = prev_lockout

    def test_invitation_flow_send_validate_set_password(self) -> None:
        team_a = self._team_id("A")
        invited = self._create_user(role_id=1, team_id=team_a)

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            send = self.client.post(
                f"/api/admin/users/{int(invited['id'])}/send-invite",
                json={"frontendInviteUrl": "http://localhost:3002/set-password"},
                headers=self._admin_headers(),
            )
            self.assertEqual(send.status_code, 200, send.text)
            payload = send.json()
            self.assertEqual(payload["delivery"], "log")
            self.assertIn("inviteLink", payload)

            invite_link = str(payload["inviteLink"])
            token = parse_qs(urlsplit(invite_link).query).get("token", [""])[0]
            self.assertTrue(token)

            validate = self.client.get("/api/auth/invitations/validate", params={"token": token})
            self.assertEqual(validate.status_code, 200, validate.text)
            self.assertEqual(validate.json()["login"], invited["login"])

            set_password = self.client.post(
                "/api/auth/invitations/set-password",
                json={"token": token, "password": "InvitedPass!2026"},
            )
            self.assertEqual(set_password.status_code, 200, set_password.text)
            self.assertTrue(bool(set_password.json()["ok"]))

            login = self.client.post(
                "/api/auth/password-login",
                json={"login": invited["login"], "password": "InvitedPass!2026"},
            )
            self.assertEqual(login.status_code, 200, login.text)

            token_reuse = self.client.post(
                "/api/auth/invitations/set-password",
                json={"token": token, "password": "AnotherPass!2026"},
            )
            self.assertEqual(token_reuse.status_code, 400)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_send_invite_allowed_for_observer_after_reactivation_and_is_idempotent(self) -> None:
        team_a = self._team_id("A")
        create_inactive = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Reaktyw",
                "nazwisko": "Observer",
                "email": None,
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": False,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_inactive.status_code, 200, create_inactive.text)
        user_id = int(create_inactive.json()["id"])

        reactivated = self.client.put(
            f"/api/admin/users/{user_id}",
            json={
                "accountType": "observer",
                "aktywny": True,
                "login": f"observer_{uuid.uuid4().hex[:8]}",
                "email": f"observer_{uuid.uuid4().hex[:8]}@example.local",
                "rolaId": 1,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(reactivated.status_code, 200, reactivated.text)

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            first = self.client.post(
                f"/api/admin/users/{user_id}/send-invite",
                headers=self._admin_headers(),
            )
            self.assertEqual(first.status_code, 200, first.text)
            first_payload = first.json()
            self.assertEqual(first_payload["delivery"], "log")
            self.assertIn("inviteLink", first_payload)
            first_expires = datetime.fromisoformat(str(first_payload["expiresAt"]).replace("Z", "+00:00"))

            second = self.client.post(
                f"/api/admin/users/{user_id}/send-invite",
                headers=self._admin_headers(),
            )
            self.assertEqual(second.status_code, 200, second.text)
            second_payload = second.json()
            self.assertEqual(second_payload["delivery"], "log")
            self.assertIn("inviteLink", second_payload)
            second_expires = datetime.fromisoformat(str(second_payload["expiresAt"]).replace("Z", "+00:00"))
            self.assertGreaterEqual(second_expires, first_expires)

            with get_connection() as conn:
                active = conn.execute(
                    "SELECT COUNT(1) AS c FROM user_invites WHERE user_id = ? AND used_at IS NULL",
                    (user_id,),
                ).fetchone()
                total = conn.execute(
                    "SELECT COUNT(1) AS c FROM user_invites WHERE user_id = ?",
                    (user_id,),
                ).fetchone()
            self.assertEqual(int(active["c"]), 1)
            self.assertGreaterEqual(int(total["c"]), 2)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_team_lead_send_invite_for_team_member_and_created_user(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        leader = self._create_user(role_id=1, team_id=team_a)
        assign_leader = self.client.put(
            f"/api/admin/teams/{team_a}",
            json={"kierownikUserId": int(leader["id"])},
            headers=self._admin_headers(),
        )
        self.assertEqual(assign_leader.status_code, 200, assign_leader.text)

        team_member = self._create_user(role_id=1, team_id=team_a)

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            invite_team_member = self.client.post(
                f"/api/admin/users/{int(team_member['id'])}/send-invite",
                headers=self._operator_headers(str(leader["login"])),
            )
            self.assertEqual(invite_team_member.status_code, 200, invite_team_member.text)

            created_external = self.client.post(
                "/api/admin/users/external",
                json={
                    "login": f"ext_{uuid.uuid4().hex[:8]}",
                    "imie": "Ext",
                    "nazwisko": "User",
                    "email": f"ext_{uuid.uuid4().hex[:8]}@example.local",
                    "permissions": ["registry.inspections.read"],
                },
                headers=self._operator_headers(str(leader["login"])),
            )
            self.assertEqual(created_external.status_code, 201, created_external.text)
            created_user_id = int(created_external.json()["user"]["id"])

            with get_connection() as conn:
                conn.execute("UPDATE users SET zespol_id = ? WHERE id = ?", (team_b, created_user_id))
                conn.commit()

            invite_created_by_leader = self.client.post(
                f"/api/admin/users/{created_user_id}/send-invite",
                headers=self._operator_headers(str(leader["login"])),
            )
            self.assertEqual(invite_created_by_leader.status_code, 200, invite_created_by_leader.text)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_team_lead_send_invite_denied_for_out_of_scope_user(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        leader = self._create_user(role_id=1, team_id=team_a)
        assign_leader = self.client.put(
            f"/api/admin/teams/{team_a}",
            json={"kierownikUserId": int(leader["id"])} ,
            headers=self._admin_headers(),
        )
        self.assertEqual(assign_leader.status_code, 200, assign_leader.text)

        out_of_scope_user = self._create_user(role_id=1, team_id=team_b)

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            denied = self.client.post(
                f"/api/admin/users/{int(out_of_scope_user['id'])}/send-invite",
                headers=self._operator_headers(str(leader["login"])),
            )
            self.assertEqual(denied.status_code, 403, denied.text)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_password_reset_flow_forgot_validate_confirm(self) -> None:
        team_a = self._team_id("A")
        user = self._create_user(role_id=1, team_id=team_a)
        self._set_user_password(int(user["id"]), "InspectorPass!2026")

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            stream = io.StringIO()
            with redirect_stdout(stream):
                forgot = self.client.post(
                    "/api/auth/forgot-password",
                    json={"loginOrEmail": user["login"]},
                )
            self.assertEqual(forgot.status_code, 200, forgot.text)
            forgot_payload = forgot.json()
            self.assertEqual(forgot_payload["delivery"], "accepted")

            output = stream.getvalue()
            match = re.search(r"link=(\S+)", output)
            self.assertIsNotNone(match, output)
            reset_link = str(match.group(1))
            token = parse_qs(urlsplit(reset_link).query).get("token", [""])[0]
            self.assertTrue(token)

            validate = self.client.get("/api/auth/password-reset/validate", params={"token": token})
            self.assertEqual(validate.status_code, 200, validate.text)
            self.assertEqual(validate.json()["login"], user["login"])

            confirm = self.client.post(
                "/api/auth/password-reset/confirm",
                json={"token": token, "password": "InspectorPass!2027"},
            )
            self.assertEqual(confirm.status_code, 200, confirm.text)
            self.assertTrue(bool(confirm.json()["ok"]))

            old_login = self.client.post(
                "/api/auth/password-login",
                json={"login": user["login"], "password": "InspectorPass!2026"},
            )
            self.assertEqual(old_login.status_code, 401)

            new_login = self.client.post(
                "/api/auth/password-login",
                json={"login": user["login"], "password": "InspectorPass!2027"},
            )
            self.assertEqual(new_login.status_code, 200, new_login.text)

            token_reuse = self.client.post(
                "/api/auth/password-reset/confirm",
                json={"token": token, "password": "InspectorPass!2028"},
            )
            self.assertEqual(token_reuse.status_code, 400)

            missing = self.client.post(
                "/api/auth/forgot-password",
                json={"loginOrEmail": "does-not-exist@example.local"},
            )
            self.assertEqual(missing.status_code, 200, missing.text)
            self.assertEqual(missing.json()["delivery"], "accepted")
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_password_reset_forgot_is_throttled_neutrally(self) -> None:
        team_a = self._team_id("A")
        user = self._create_user(role_id=1, team_id=team_a)

        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        previous_interval = os.environ.get("AUTH_PASSWORD_RESET_MIN_INTERVAL_SECONDS")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        os.environ["AUTH_PASSWORD_RESET_MIN_INTERVAL_SECONDS"] = "600"
        try:
            first = self.client.post(
                "/api/auth/forgot-password",
                json={"loginOrEmail": user["login"]},
            )
            self.assertEqual(first.status_code, 200, first.text)
            self.assertEqual(first.json()["delivery"], "accepted")

            second = self.client.post(
                "/api/auth/forgot-password",
                json={"loginOrEmail": user["login"]},
            )
            self.assertEqual(second.status_code, 200, second.text)
            self.assertEqual(second.json()["delivery"], "accepted")

            with get_connection() as conn:
                cnt = conn.execute(
                    "SELECT COUNT(1) AS c FROM user_password_resets WHERE user_id = ?",
                    (int(user["id"]),),
                ).fetchone()
            self.assertEqual(int(cnt["c"]), 1)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

            if previous_interval is None:
                os.environ.pop("AUTH_PASSWORD_RESET_MIN_INTERVAL_SECONDS", None)
            else:
                os.environ["AUTH_PASSWORD_RESET_MIN_INTERVAL_SECONDS"] = previous_interval

    def test_external_user_permissions_visibility(self) -> None:
        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            create = self.client.post(
                "/api/admin/users/external",
                json={
                    "login": "external_anna",
                    "imie": "Anna",
                    "nazwisko": "External",
                    "email": "external.anna@example.local",
                    "permissions": [
                        "registry.inspections.read",
                        "registry.risk_exposure.read",
                    ],
                    "frontendInviteUrl": "http://localhost:3002/set-password",
                },
                headers=self._admin_headers(),
            )
            self.assertEqual(create.status_code, 201, create.text)
            payload = create.json()
            self.assertEqual(payload["user"]["rola"], "external_user")
            self.assertEqual(payload["invite"]["delivery"], "log")

            user_id = int(payload["user"]["id"])

            set_password = self.client.put(
                f"/api/admin/users/{user_id}/password",
                json={"password": "ExternalPass!2026"},
                headers=self._admin_headers(),
            )
            self.assertEqual(set_password.status_code, 200, set_password.text)

            login = self.client.post(
                "/api/auth/password-login",
                json={"login": "external_anna", "password": "ExternalPass!2026"},
            )
            self.assertEqual(login.status_code, 200, login.text)
            self.assertEqual(
                login.json()["user"]["effectivePermissions"],
                ["registry.inspections.read", "registry.risk_exposure.read"],
            )

            inspections = self.client.get(
                "/api/structure/inspections",
                headers=self._operator_headers("external_anna"),
            )
            self.assertEqual(inspections.status_code, 200, inspections.text)

            risk_exposure = self.client.get(
                "/api/risk-exposure",
                headers=self._operator_headers("external_anna"),
            )
            self.assertEqual(risk_exposure.status_code, 200, risk_exposure.text)

            recommendations = self.client.get(
                "/api/recommendations",
                headers=self._operator_headers("external_anna"),
            )
            self.assertEqual(recommendations.status_code, 403)
            self.assertEqual(recommendations.json().get("detail"), "Brak uprawnien")

            create_inspection_denied = self.client.post(
                "/api/structure/inspections",
                json={
                    "nazwaPodmiotu": "External Podmiot",
                    "typInspekcji": "Kontrola",
                    "zakresInspekcji": "RTU",
                    "poczatekInspekcji": "2026-01-10",
                    "koniecInspekcji": "2026-01-11",
                },
                headers=self._operator_headers("external_anna"),
            )
            self.assertEqual(create_inspection_denied.status_code, 403)
            self.assertEqual(create_inspection_denied.json().get("detail"), "Brak uprawnien")

            update_permissions = self.client.put(
                f"/api/admin/users/{user_id}/permissions",
                json={
                    "permissions": [
                        "registry.inspections.read",
                        "registry.risk_exposure.read",
                        "registry.recommendations.read",
                    ]
                },
                headers=self._admin_headers(),
            )
            self.assertEqual(update_permissions.status_code, 200, update_permissions.text)

            recommendations_after = self.client.get(
                "/api/recommendations",
                headers=self._operator_headers("external_anna"),
            )
            self.assertEqual(recommendations_after.status_code, 200, recommendations_after.text)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_observer_permissions_effective_permissions_and_session_refresh(self) -> None:
        team_a = self._team_id("A")
        user = self._create_user(role_id=1, team_id=team_a)
        user_id = int(user["id"])
        login_name = str(user["login"])

        self._set_user_password(user_id, "ObserverPass!2026")

        login_before = self.client.post(
            "/api/auth/password-login",
            json={"login": login_name, "password": "ObserverPass!2026"},
        )
        self.assertEqual(login_before.status_code, 200, login_before.text)
        token_before = str(login_before.json()["token"])

        switch_to_observer = self.client.put(
            f"/api/admin/users/{user_id}",
            json={
                "accountType": "observer",
                "rolaId": 1,
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(switch_to_observer.status_code, 200, switch_to_observer.text)

        stale_after_profile_change = self.client.get("/api/auth/me-token", headers=self._auth_headers(token_before))
        self.assertEqual(stale_after_profile_change.status_code, 401, stale_after_profile_change.text)

        people_options_denied = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(people_options_denied.status_code, 403)
        self.assertEqual(people_options_denied.json().get("detail"), "Brak uprawnien")

        set_observer_permissions = self.client.put(
            f"/api/admin/users/{user_id}/permissions",
            json={
                "permissions": [
                    "registry.inspections.read",
                    "registry.risk_exposure.read",
                ]
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(set_observer_permissions.status_code, 200, set_observer_permissions.text)

        read_observer_permissions = self.client.get(
            f"/api/admin/users/{user_id}/permissions",
            headers=self._admin_headers(),
        )
        self.assertEqual(read_observer_permissions.status_code, 200, read_observer_permissions.text)
        self.assertEqual(
            read_observer_permissions.json()["permissions"],
            ["registry.inspections.read", "registry.risk_exposure.read"],
        )

        login_after = self.client.post(
            "/api/auth/password-login",
            json={"login": login_name, "password": "ObserverPass!2026"},
        )
        self.assertEqual(login_after.status_code, 200, login_after.text)
        login_after_payload = login_after.json()
        token_after = str(login_after_payload["token"])
        self.assertEqual(login_after_payload["user"]["accountType"], "observer")
        self.assertEqual(
            login_after_payload["user"]["effectivePermissions"],
            ["registry.inspections.read", "registry.risk_exposure.read"],
        )

        me_token = self.client.get("/api/auth/me-token", headers=self._auth_headers(token_after))
        self.assertEqual(me_token.status_code, 200, me_token.text)
        self.assertEqual(
            me_token.json()["user"]["effectivePermissions"],
            ["registry.inspections.read", "registry.risk_exposure.read"],
        )

        inspections = self.client.get(
            "/api/structure/inspections",
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(inspections.status_code, 200, inspections.text)

        people_options_allowed = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(people_options_allowed.status_code, 200, people_options_allowed.text)

        recommendations = self.client.get(
            "/api/recommendations",
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(recommendations.status_code, 403)
        self.assertEqual(recommendations.json().get("detail"), "Brak uprawnien")

        create_recommendation_denied = self.client.post(
            "/api/recommendations",
            json={
                "pozycja": 1,
                "nazwaPodmiotu": "Observer Recommendation",
                "status": "W toku",
            },
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(create_recommendation_denied.status_code, 403)
        self.assertEqual(create_recommendation_denied.json().get("detail"), "Brak uprawnien")

        create_inspection_denied = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": "Observer Podmiot",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-11",
            },
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(create_inspection_denied.status_code, 403)
        self.assertEqual(create_inspection_denied.json().get("detail"), "Brak uprawnien")

        create_sanction_denied = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": None,
                "komentarz": "Observer sanction write blocked",
            },
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(create_sanction_denied.status_code, 403)
        self.assertEqual(create_sanction_denied.json().get("detail"), "Brak uprawnien")

        create_decision_denied = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": "ZALECENIE/TEST/OBSERVER",
            },
            headers=self._operator_headers(login_name),
        )
        self.assertEqual(create_decision_denied.status_code, 403)
        self.assertEqual(create_decision_denied.json().get("detail"), "Brak uprawnien")

        update_observer_permissions = self.client.put(
            f"/api/admin/users/{user_id}/permissions",
            json={
                "permissions": [
                    "registry.inspections.read",
                    "registry.recommendations.read",
                    "registry.risk_exposure.read",
                ]
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(update_observer_permissions.status_code, 200, update_observer_permissions.text)

        stale_after_permissions_change = self.client.get("/api/auth/me-token", headers=self._auth_headers(token_after))
        self.assertEqual(stale_after_permissions_change.status_code, 401, stale_after_permissions_change.text)

        login_after_refresh = self.client.post(
            "/api/auth/password-login",
            json={"login": login_name, "password": "ObserverPass!2026"},
        )
        self.assertEqual(login_after_refresh.status_code, 200, login_after_refresh.text)
        self.assertEqual(
            login_after_refresh.json()["user"]["effectivePermissions"],
            ["registry.inspections.read", "registry.recommendations.read", "registry.risk_exposure.read"],
        )

    def test_permissions_endpoint_returns_relogin_friendly_401_detail(self) -> None:
        team_a = self._team_id("A")
        user = self._create_user(role_id=1, team_id=team_a)
        user_id = int(user["id"])

        missing_operator = self.client.get(f"/api/admin/users/{user_id}/permissions")
        self.assertEqual(missing_operator.status_code, 422)

        unknown_operator = self.client.get(
            f"/api/admin/users/{user_id}/permissions",
            headers=self._operator_headers("ghost"),
        )
        self.assertEqual(unknown_operator.status_code, 401)
        self.assertIn("Wymagany re-login", str(unknown_operator.json().get("detail", "")))

    def test_team_lead_can_update_observer_permissions_within_scope(self) -> None:
        team_a = self._team_id("A")
        lead = self._create_user(role_id=2, team_id=team_a)
        observer_create = self.client.post(
            "/api/admin/users",
            json={
                "login": f"lead_obs_{uuid.uuid4().hex[:8]}",
                "imie": "Lead",
                "nazwisko": "Observer",
                "email": f"lead_obs_{uuid.uuid4().hex[:8]}@example.local",
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": True,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(observer_create.status_code, 200, observer_create.text)
        observer = observer_create.json()
        observer_id = int(observer["id"])
        observer_login = str(observer["login"])

        self._set_user_password(observer_id, "ObserverTeamLeadPass!2026")

        to_observer = self.client.put(
            f"/api/admin/users/{observer_id}",
            json={
                "accountType": "observer",
                "rolaId": 1,
                "aktywny": True,
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(to_observer.status_code, 200, to_observer.text)

        catalog = self.client.get(
            "/api/admin/permissions/catalog",
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(catalog.status_code, 200, catalog.text)
        catalog_codes = {item["code"] for item in catalog.json()}
        self.assertIn("registry.inspections.read", catalog_codes)
        self.assertIn("reports.executed_inspections.read", catalog_codes)

        set_permissions = self.client.put(
            f"/api/admin/users/{observer_id}/permissions",
            json={
                "permissions": [
                    "registry.inspections.read",
                    "reports.executed_inspections.read",
                ]
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(set_permissions.status_code, 200, set_permissions.text)

        login = self.client.post(
            "/api/auth/password-login",
            json={"login": observer_login, "password": "ObserverTeamLeadPass!2026"},
        )
        self.assertEqual(login.status_code, 200, login.text)
        effective_permissions = set(login.json()["user"]["effectivePermissions"])
        self.assertIn("registry.inspections.read", effective_permissions)
        self.assertIn("reports.executed_inspections.read", effective_permissions)

    def test_team_lead_can_create_external_observer_with_allowed_permissions(self) -> None:
        previous_mode = os.environ.get("INVITE_EMAIL_MODE")
        os.environ["INVITE_EMAIL_MODE"] = "log"
        try:
            team_a = self._team_id("A")
            lead = self._create_user(role_id=2, team_id=team_a)
            login_value = f"tl_external_{uuid.uuid4().hex[:8]}"

            create = self.client.post(
                "/api/admin/users/external",
                json={
                    "login": login_value,
                    "imie": "Lead",
                    "nazwisko": "External",
                    "email": f"{login_value}@example.local",
                    "permissions": [
                        "registry.inspections.read",
                        "reports.executed_inspections.read",
                    ],
                    "frontendInviteUrl": "http://localhost:3002/set-password",
                },
                headers=self._operator_headers(lead["login"]),
            )
            self.assertEqual(create.status_code, 201, create.text)
            payload = create.json()
            self.assertEqual(payload["user"]["accountType"], "observer")

            user_id = int(payload["user"]["id"])
            self._set_user_password(user_id, "TLExternalPass!2026")

            login = self.client.post(
                "/api/auth/password-login",
                json={"login": login_value, "password": "TLExternalPass!2026"},
            )
            self.assertEqual(login.status_code, 200, login.text)
            effective_permissions = set(login.json()["user"]["effectivePermissions"])
            self.assertIn("registry.inspections.read", effective_permissions)
            self.assertIn("reports.executed_inspections.read", effective_permissions)
        finally:
            if previous_mode is None:
                os.environ.pop("INVITE_EMAIL_MODE", None)
            else:
                os.environ["INVITE_EMAIL_MODE"] = previous_mode

    def test_schedule_crud_and_director_only_access(self) -> None:
        date_fields = self.client.get(
            "/api/admin/schedules/date-fields",
            headers=self._admin_headers(),
        )
        self.assertEqual(date_fields.status_code, 200, date_fields.text)
        self.assertTrue(any(item["code"] == "inspection.koniec_inspekcji" for item in date_fields.json()))
        self.assertTrue(any(item["label"].startswith("I - ") for item in date_fields.json()))
        self.assertTrue(any(item["label"].startswith("Z - ") for item in date_fields.json()))
        self.assertTrue(any(item["label"].startswith("WN - ") for item in date_fields.json()))

        template_vars = self.client.get(
            "/api/admin/schedules/template-variables",
            params={
                "dateFieldA": "inspection.koniec_inspekcji",
                "checkEmptyField": "recommendation.termin_wykonania_zalecen",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(template_vars.status_code, 200, template_vars.text)
        self.assertTrue(any(item["token"] == "inspectionId" for item in template_vars.json()))
        self.assertTrue(any(item["token"] == "recommendationId" for item in template_vars.json()))

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        forbidden = self.client.get(
            "/api/admin/schedules",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden.status_code, 403)

        create = self.client.post(
            "/api/admin/schedules",
            json={
                "name": "Terminy zalecen",
                "dateFieldA": "inspection.koniec_inspekcji",
                "checkEmptyField": "recommendation.termin_wykonania_zalecen",
                "daysDifference": 5,
                "subjectTemplate": "5 dni",
                "bodyTemplate": "Pozostalo 5 dni",
                "sendHour": 7,
                "sendMinute": 40,
                "targetInspectionLeader": True,
                "targetInspectionTeam": False,
                "fallbackRecipient": "author",
                "enabled": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create.status_code, 201, create.text)
        schedule = create.json()
        self.assertEqual(schedule["moduleType"], "recommendations")
        self.assertEqual(schedule["recipientStrategy"], "inspection_context")
        self.assertEqual(int(schedule["daysDifference"]), 5)
        self.assertEqual(int(schedule["sendMinute"]), 40)
        schedule_id = int(schedule["id"])

        no_targets = self.client.post(
            "/api/admin/schedules",
            json={
                "name": "Bez odbiorcow I+Z",
                "dateFieldA": "inspection.koniec_inspekcji",
                "checkEmptyField": "recommendation.termin_wykonania_zalecen",
                "daysDifference": 5,
                "subjectTemplate": "s",
                "bodyTemplate": "b",
                "sendHour": 7,
                "sendMinute": 40,
                "targetInspectionLeader": False,
                "targetInspectionTeam": False,
                "fallbackRecipient": "author",
                "enabled": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(no_targets.status_code, 400, no_targets.text)

        reco_only = self.client.post(
            "/api/admin/schedules",
            json={
                "name": "Tylko zalecenia",
                "dateFieldA": "recommendation.termin_wykonania_zalecen",
                "checkEmptyField": "recommendation.termin_wykonania_zalecen",
                "daysDifference": 2,
                "subjectTemplate": "z",
                "bodyTemplate": "z",
                "sendHour": 7,
                "sendMinute": 40,
                "targetInspectionLeader": True,
                "targetInspectionTeam": True,
                "fallbackRecipient": "author",
                "enabled": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(reco_only.status_code, 201, reco_only.text)
        reco_payload = reco_only.json()
        self.assertEqual(reco_payload["recipientStrategy"], "author_only")
        self.assertFalse(bool(reco_payload["targetInspectionLeader"]))
        self.assertFalse(bool(reco_payload["targetInspectionTeam"]))

        risk_only = self.client.post(
            "/api/admin/schedules",
            json={
                "name": "Tylko wnioski sankcyjne",
                "dateFieldA": "risk_exposure.data_wniosku",
                "checkEmptyField": "risk_exposure.data_wniosku",
                "daysDifference": 2,
                "subjectTemplate": "wn",
                "bodyTemplate": "wn",
                "sendHour": 7,
                "sendMinute": 40,
                "targetInspectionLeader": True,
                "targetInspectionTeam": True,
                "fallbackRecipient": "author",
                "enabled": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(risk_only.status_code, 201, risk_only.text)
        risk_payload = risk_only.json()
        self.assertEqual(risk_payload["recipientStrategy"], "author_only")
        self.assertFalse(bool(risk_payload["targetInspectionLeader"]))
        self.assertFalse(bool(risk_payload["targetInspectionTeam"]))

        bad_token_schedule = self.client.post(
            "/api/admin/schedules",
            json={
                "name": "Bad tokens",
                "dateFieldA": "inspection.koniec_inspekcji",
                "checkEmptyField": "recommendation.termin_wykonania_zalecen",
                "daysDifference": 11,
                "subjectTemplate": "Bad {{unknownToken}}",
                "bodyTemplate": "Body",
                "sendHour": 7,
                "sendMinute": 40,
                "targetInspectionLeader": True,
                "targetInspectionTeam": False,
                "fallbackRecipient": "author",
                "enabled": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(bad_token_schedule.status_code, 400, bad_token_schedule.text)

        update = self.client.put(
            f"/api/admin/schedules/{schedule_id}",
            json={"sendHour": 8, "sendMinute": 5, "enabled": False},
            headers=self._admin_headers(),
        )
        self.assertEqual(update.status_code, 200, update.text)
        self.assertEqual(int(update.json()["sendHour"]), 8)
        self.assertEqual(int(update.json()["sendMinute"]), 5)
        self.assertFalse(bool(update.json()["enabled"]))

        listed = self.client.get(
            "/api/admin/schedules",
            headers=self._admin_headers(),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        self.assertTrue(any(int(item["id"]) == schedule_id for item in listed.json()))

        rules_disabled = self.client.get(
            f"/api/admin/schedules/{schedule_id}/rules",
            headers=self._admin_headers(),
        )
        self.assertEqual(rules_disabled.status_code, 410, rules_disabled.text)

        dispatches = self.client.get(
            f"/api/admin/schedules/{schedule_id}/dispatches",
            headers=self._admin_headers(),
        )
        self.assertEqual(dispatches.status_code, 200, dispatches.text)

        filtered_dispatches = self.client.get(
            f"/api/admin/schedules/{schedule_id}/dispatches",
            params={
                "period": "month",
                "status": "sent",
                "recipientType": "inspection_team",
                "recipientEmail": "gmail.com",
                "dateFrom": "2026-01-01",
                "dateTo": "2026-12-31",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(filtered_dispatches.status_code, 200, filtered_dispatches.text)
        if filtered_dispatches.json():
            first_row = filtered_dispatches.json()[0]
            self.assertIn("inspectionId", first_row)
            self.assertIn("recommendationId", first_row)
            self.assertIn("sanctionRequestId", first_row)

        kpi = self.client.get(
            f"/api/admin/schedules/{schedule_id}/dispatches/kpi",
            params={
                "period": "month",
                "dateFrom": "2026-01-01",
                "dateTo": "2026-12-31",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(kpi.status_code, 200, kpi.text)
        kpi_payload = kpi.json()
        self.assertIn("total", kpi_payload)
        self.assertIn("sent", kpi_payload)
        self.assertIn("failed", kpi_payload)
        self.assertIn("successRate", kpi_payload)

        run_now = self.client.post(
            "/api/admin/schedules/run-now",
            headers=self._admin_headers(),
        )
        self.assertEqual(run_now.status_code, 200, run_now.text)
        self.assertTrue(bool(run_now.json()["ok"]))

        delete = self.client.delete(
            f"/api/admin/schedules/{schedule_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(delete.status_code, 200, delete.text)
        self.assertTrue(bool(delete.json()["ok"]))

    def test_reports_inspections_matrix(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        podmiot = f"MATRIX-{uuid.uuid4().hex[:6]}"
        rodzaj_target = f"RODZAJ-MATRIX-{uuid.uuid4().hex[:6]}"
        rodzaj_other = f"RODZAJ-MATRIX-{uuid.uuid4().hex[:6]}"
        podmiot_other = f"MATRIX-OTHER-{uuid.uuid4().hex[:6]}"

        first = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "rodzajPodmiotu": rodzaj_target,
                "poczatekInspekcji": "2024-05-10",
                "koniecInspekcji": "2024-05-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(first.status_code, 201, first.text)

        second = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU",
                "rodzajPodmiotu": rodzaj_target,
                "poczatekInspekcji": "2024-10-10",
                "koniecInspekcji": "2024-10-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(second.status_code, 201, second.text)

        third = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "rodzajPodmiotu": rodzaj_target,
                "poczatekInspekcji": "2025-01-01",
                "koniecInspekcji": "2025-01-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(third.status_code, 201, third.text)

        other = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot_other,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "rodzajPodmiotu": rodzaj_other,
                "poczatekInspekcji": "2024-06-01",
                "koniecInspekcji": "2024-06-10",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(other.status_code, 201, other.text)

        response = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

        payload = response.json()
        self.assertIn("lata", payload)
        self.assertIn("rows", payload)
        self.assertEqual(payload["lata"], ["2024", "2025"])
        self.assertTrue(all("rodzaj_podmiotu" in item for item in payload["rows"]))
        self.assertTrue(all(isinstance(item["rodzaj_podmiotu"], str) for item in payload["rows"]))

        row = next(item for item in payload["rows"] if item["nazwa_podmiotu"] == podmiot)
        self.assertEqual(row["rodzaj_podmiotu"], rodzaj_target)
        self.assertEqual(row["wartosci"]["2024"], "K_RTU, W_RTU")
        self.assertEqual(row["wartosci"]["2025"], "K_SCR")

        filtered = self.client.get(
            "/api/reports/inspections-matrix",
            params={"rodzajPodmiotu": rodzaj_target},
            headers=self._admin_headers(),
        )
        self.assertEqual(filtered.status_code, 200, filtered.text)
        filtered_rows = filtered.json()["rows"]
        self.assertTrue(any(item["nazwa_podmiotu"] == podmiot for item in filtered_rows))
        self.assertFalse(any(item["nazwa_podmiotu"] == podmiot_other for item in filtered_rows))
        self.assertTrue(all(item["rodzaj_podmiotu"] == rodzaj_target for item in filtered_rows))

    def test_reports_inspections_matrix_multi_zakres(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        podmiot = f"MATRIX-MULTI-{uuid.uuid4().hex[:6]}"

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU1; SCR",
                "poczatekInspekcji": "2024-02-10",
                "koniecInspekcji": "2024-02-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)

        response = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

        row = next(item for item in response.json()["rows"] if item["nazwa_podmiotu"] == podmiot)
        self.assertEqual(row["wartosci"]["2024"], "W_RTU1, W_SCR")

    def test_reports_inspections_matrix_cells_contract_v2(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        podmiot = f"MATRIX-CELL-{uuid.uuid4().hex[:6]}"
        rodzaj = f"RODZAJ-CELL-{uuid.uuid4().hex[:6]}"

        first_k = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "rodzajPodmiotu": rodzaj,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR; life; SCR",
                "poczatekInspekcji": "2026-01-05",
                "koniecInspekcji": "2026-01-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(first_k.status_code, 201, first_k.text)

        second_k = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "rodzajPodmiotu": rodzaj,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "market",
                "poczatekInspekcji": "2026-02-10",
                "koniecInspekcji": "2026-02-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(second_k.status_code, 201, second_k.text)

        one_wn = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "rodzajPodmiotu": rodzaj,
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU_S2",
                "poczatekInspekcji": "2026-03-01",
                "koniecInspekcji": "2026-03-08",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(one_wn.status_code, 201, one_wn.text)

        response = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

        payload = response.json()
        self.assertEqual(payload["formatVersion"], "2.0")

        row = next(item for item in payload["rows"] if item["nazwa_podmiotu"] == podmiot)
        self.assertEqual(row["rodzaj_podmiotu"], rodzaj)
        self.assertIn("cells", row)
        self.assertIn("2026", row["cells"])

        entries = row["cells"]["2026"]
        self.assertEqual(len(entries), 3)
        self.assertEqual([item["type"] for item in entries], ["K", "K", "WN"])
        self.assertEqual([item["date"] for item in entries], ["2026-01-05", "2026-02-10", "2026-03-01"])

        self.assertTrue(all(isinstance(item["scopes"], list) for item in entries))
        self.assertEqual(entries[0]["scopes"], ["life", "SCR"])
        self.assertEqual(entries[1]["scopes"], ["market"])
        self.assertEqual(entries[2]["scopes"], ["RTU_S2"])

        self.assertTrue(all(isinstance(item["inspectionId"], int) for item in entries))
        self.assertTrue(all(str(item["kodInspekcji"]).strip() for item in entries))

        # Legacy field remains during migration period.
        self.assertIn("wartosci", row)
        self.assertTrue(isinstance(row["wartosci"]["2026"], str))

    def test_reports_inspections_matrix_acceptance_no_loss_by_status(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        podmiot = f"ACCEPT-MAP-{uuid.uuid4().hex[:6]}"

        k_hidden = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "status": "Zamknieta wydano zalecenia",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-20",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(k_hidden.status_code, 201, k_hidden.text)

        wn_hidden = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU_S2",
                "status": "Zamknieta bez zalecen",
                "poczatekInspekcji": "2026-02-05",
                "koniecInspekcji": "2026-02-12",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(wn_hidden.status_code, 201, wn_hidden.text)

        k_open = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "life",
                "status": "Trwa",
                "poczatekInspekcji": "2026-03-01",
                "koniecInspekcji": "2026-03-08",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(k_open.status_code, 201, k_open.text)

        structure = self.client.get(
            "/api/structure/inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(structure.status_code, 200, structure.text)

        structure_items = [
            item
            for item in structure.json()["items"]
            if item.get("nazwaPodmiotu") == podmiot
            and str(item.get("poczatekInspekcji") or "").startswith("2026-")
            and str(item.get("typInspekcji") or "").strip().lower() in {"kontrola", "wizyta nadzorcza"}
        ]
        structure_codes = {str(item.get("kodInspekcji") or "").strip() for item in structure_items}
        self.assertEqual(len(structure_codes), 3)

        matrix = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._admin_headers(),
        )
        self.assertEqual(matrix.status_code, 200, matrix.text)

        row = next(item for item in matrix.json()["rows"] if item["nazwa_podmiotu"] == podmiot)
        matrix_entries = row["cells"]["2026"]
        matrix_codes = {str(item["kodInspekcji"]).strip() for item in matrix_entries}

        self.assertEqual(len(matrix_entries), len(structure_codes))
        self.assertEqual(matrix_codes, structure_codes)
        self.assertIn(str(k_hidden.json()["kodInspekcji"]), matrix_codes)
        self.assertIn(str(wn_hidden.json()["kodInspekcji"]), matrix_codes)
        self.assertIn(str(k_open.json()["kodInspekcji"]), matrix_codes)

    def test_reports_inspections_detailed(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        podmiot = f"DETAIL-{uuid.uuid4().hex[:6]}"

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU1; SCR",
                "poczatekInspekcji": "2025-03-01",
                "koniecInspekcji": "2025-03-10",
                "dataProtokolu": "2025-03-14",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)

        response = self.client.get(
            "/api/reports/inspections-detailed",
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)

        row = next(item for item in response.json()["rows"] if item["nazwa_podmiotu"] == podmiot)
        self.assertRegex(str(row["kod_inspekcji"]), r"^WN/2025/\d+$")
        self.assertEqual(row["inspekcja"], "W")
        self.assertEqual(row["typ_zakres_inspekcji"], "W_RTU1, W_SCR")
        self.assertEqual(row["rok_poczatku"], "2025")
        self.assertEqual(row["poczatek_inspekcji"], "2025-03-01")
        self.assertEqual(row["koniec_inspekcji"], "2025-03-10")
        self.assertEqual(row["data_protokolu_sprawozdania"], "2025-03-14")
        self.assertEqual(row["roznica_dni_miedzy_data_protokolu_a_koncem"], 4)

    def test_reports_inspections_stage_summary_status_mode_and_manager_filter(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager_a = self._create_user(role_id=2, team_id=team_a)
        manager_b = self._create_user(role_id=2, team_id=team_b)

        ins_a = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"STAGE-A-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "status": "Plan",
                "poczatekInspekcji": "2026-01-01",
                "koniecInspekcji": "2026-01-05",
                "osobaKierujacaUserId": int(manager_a["id"]),
                "teamMemberUserIds": [int(manager_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_a.status_code, 201, ins_a.text)

        ins_b = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"STAGE-B-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "status": "Trwa",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-15",
                "osobaKierujacaUserId": int(manager_b["id"]),
                "teamMemberUserIds": [int(manager_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_b.status_code, 201, ins_b.text)

        summary_all = self.client.get(
            "/api/reports/inspections-stage-summary",
            headers=self._admin_headers(),
        )
        self.assertEqual(summary_all.status_code, 200, summary_all.text)
        summary_payload = summary_all.json()

        self.assertTrue(isinstance(summary_payload["statuses"], list))
        self.assertGreater(len(summary_payload["statuses"]), 0)
        self.assertNotIn("groups", summary_payload)
        self.assertNotIn("subgroups", summary_payload)
        self.assertNotIn("flat", summary_payload)

        status_codes = [item["stageGroupCode"] for item in summary_payload["statuses"]]
        self.assertEqual(len(status_codes), len(set(status_codes)))

        ordered_values = [int(item["stageGroupOrder"]) for item in summary_payload["statuses"]]
        self.assertEqual(ordered_values, sorted(ordered_values))

        plan_row = next(item for item in summary_payload["statuses"] if item["stageGroupCode"] == "plan")
        trwa_row = next(item for item in summary_payload["statuses"] if item["stageGroupCode"] == "trwa")
        self.assertEqual(int(plan_row["count"]), 1)
        self.assertEqual(int(trwa_row["count"]), 1)

        summary_for_manager_a = self.client.get(
            "/api/reports/inspections-stage-summary",
            params={"managerUserId": int(manager_a["id"])},
            headers=self._admin_headers(),
        )
        self.assertEqual(summary_for_manager_a.status_code, 200, summary_for_manager_a.text)
        manager_payload = summary_for_manager_a.json()

        self.assertEqual(int(manager_payload["totalInspections"]), 1)

        manager_plan_row = next(item for item in manager_payload["statuses"] if item["stageGroupCode"] == "plan")
        manager_trwa_row = next(item for item in manager_payload["statuses"] if item["stageGroupCode"] == "trwa")
        self.assertEqual(int(manager_plan_row["count"]), 1)
        self.assertEqual(int(manager_trwa_row["count"]), 0)

    def test_reports_inspections_stage_summary_counts_match_detailed_rows(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager_a = self._create_user(role_id=2, team_id=team_a)
        manager_b = self._create_user(role_id=2, team_id=team_b)

        visible_plan = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"SYNC-P-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "status": "Plan",
                "poczatekInspekcji": "2026-02-01",
                "koniecInspekcji": "2026-02-05",
                "osobaKierujacaUserId": int(manager_a["id"]),
                "teamMemberUserIds": [int(manager_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(visible_plan.status_code, 201, visible_plan.text)

        visible_trwa = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"SYNC-T-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "status": "Trwa",
                "poczatekInspekcji": "2026-02-10",
                "koniecInspekcji": "2026-02-15",
                "osobaKierujacaUserId": int(manager_b["id"]),
                "teamMemberUserIds": [int(manager_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(visible_trwa.status_code, 201, visible_trwa.text)

        hidden_closed = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"SYNC-H-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "status": "Zamknieta bez zalecen",
                "poczatekInspekcji": "2026-02-20",
                "koniecInspekcji": "2026-02-25",
                "osobaKierujacaUserId": int(manager_a["id"]),
                "teamMemberUserIds": [int(manager_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(hidden_closed.status_code, 201, hidden_closed.text)

        summary_all = self.client.get(
            "/api/reports/inspections-stage-summary",
            headers=self._admin_headers(),
        )
        detailed_all = self.client.get(
            "/api/reports/inspections-detailed",
            headers=self._admin_headers(),
        )
        self.assertEqual(summary_all.status_code, 200, summary_all.text)
        self.assertEqual(detailed_all.status_code, 200, detailed_all.text)

        summary_all_count = sum(int(item["count"]) for item in summary_all.json()["statuses"])
        detailed_all_count = len(detailed_all.json()["rows"])
        self.assertEqual(summary_all_count, detailed_all_count)

        summary_manager = self.client.get(
            "/api/reports/inspections-stage-summary",
            params={"managerUserId": int(manager_a["id"])},
            headers=self._admin_headers(),
        )
        detailed_manager = self.client.get(
            "/api/reports/inspections-detailed",
            params={"managerUserId": int(manager_a["id"])},
            headers=self._admin_headers(),
        )
        self.assertEqual(summary_manager.status_code, 200, summary_manager.text)
        self.assertEqual(detailed_manager.status_code, 200, detailed_manager.text)

        summary_manager_count = sum(int(item["count"]) for item in summary_manager.json()["statuses"])
        detailed_manager_count = len(detailed_manager.json()["rows"])
        self.assertEqual(summary_manager_count, detailed_manager_count)

    def test_reports_wykonane_inspekcje_inspector_sees_all(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        inspector = self._create_user(role_id=1, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        podmiot = f"ALL-INS-{uuid.uuid4().hex[:6]}"
        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-06-01",
                "koniecInspekcji": "2025-06-10",
                "dataProtokolu": "2025-06-12",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)

        matrix = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(matrix.status_code, 200, matrix.text)
        self.assertTrue(any(row["nazwa_podmiotu"] == podmiot for row in matrix.json()["rows"]))

        detailed = self.client.get(
            "/api/reports/inspections-detailed",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(detailed.status_code, 200, detailed.text)
        self.assertTrue(any(row["nazwa_podmiotu"] == podmiot for row in detailed.json()["rows"]))

    def test_reports_wykonane_inspekcje_manager_sees_all(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        podmiot = f"ALL-MGR-{uuid.uuid4().hex[:6]}"
        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": podmiot,
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-07-01",
                "koniecInspekcji": "2025-07-10",
                "dataProtokolu": "2025-07-12",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)

        matrix = self.client.get(
            "/api/reports/inspections-matrix",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(matrix.status_code, 200, matrix.text)
        self.assertTrue(any(row["nazwa_podmiotu"] == podmiot for row in matrix.json()["rows"]))

        detailed = self.client.get(
            "/api/reports/inspections-detailed",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(detailed.status_code, 200, detailed.text)
        self.assertTrue(any(row["nazwa_podmiotu"] == podmiot for row in detailed.json()["rows"]))

    def test_reports_inspections_time_analytics_rbac_and_filters(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager_a = self._create_user(role_id=2, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)
        member_a = self._create_user(role_id=1, team_id=team_a)

        ins_visible_lead = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AN-L-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-01-01",
                "koniecInspekcji": "2025-01-10",
                "dataProtokolu": "2025-01-15",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_visible_lead.status_code, 201, ins_visible_lead.text)
        code_visible_lead = str(ins_visible_lead.json()["kodInspekcji"])

        ins_visible_member = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AN-M-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "poczatekInspekcji": "2025-02-01",
                "koniecInspekcji": "2025-02-10",
                "dataProtokolu": "2025-02-20",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_b["id"]), int(member_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_visible_member.status_code, 201, ins_visible_member.text)
        code_visible_member = str(ins_visible_member.json()["kodInspekcji"])

        ins_hidden = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AN-H-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "status": "Zamknieta bez zalecen",
                "poczatekInspekcji": "2025-03-01",
                "koniecInspekcji": "2025-03-10",
                "dataProtokolu": "2025-03-20",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_hidden.status_code, 201, ins_hidden.text)
        code_hidden = str(ins_hidden.json()["kodInspekcji"])

        ins_missing_time = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AN-M-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-04-01",
                "koniecInspekcji": "2025-04-10",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_missing_time.status_code, 201, ins_missing_time.text)
        code_missing_time = str(ins_missing_time.json()["kodInspekcji"])

        analytics = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(analytics.status_code, 200, analytics.text)
        payload = analytics.json()

        self.assertEqual(payload["inspectionType"], "K")
        self.assertEqual(payload["trendMode"], "median")
        self.assertEqual(payload["selectedMetric"], "median")
        self.assertEqual(payload["selectedMetricLabel"], "Mediana")
        self.assertEqual(int(payload["baseCount"]), 4)
        self.assertEqual(int(payload["filteredCount"]), 4)
        self.assertEqual(payload["yearOptions"], ["2025"])
        self.assertIn("A", payload["teamOptions"])

        self.assertTrue(payload["summaryRows"])
        self.assertTrue(all("metric" in row for row in payload["summaryRows"]))
        self.assertTrue(all("rok" in row and "zespol" in row for row in payload["summaryRows"]))
        self.assertTrue(any(row["zespol"] == "A" and row["rok"] == "2025" for row in payload["summaryRows"]))
        self.assertTrue(any(row["zespol"] == "Departament" and row["count"] == 3 for row in payload["summaryRows"]))
        self.assertEqual(payload["summaryPivotYears"], ["2025"])
        self.assertTrue(payload["summaryPivotRows"])
        self.assertTrue(any(row["zespol"] == "A" and row["values"].get("2025") is not None for row in payload["summaryPivotRows"]))

        self.assertTrue(payload["trendRows"])
        self.assertTrue(all("trend" in row and "min" in row and "max" in row for row in payload["trendRows"]))

        self.assertTrue(payload["scatterRows"])
        scatter_sample = payload["scatterRows"][0]
        self.assertIn("year", scatter_sample)
        self.assertIn("time", scatter_sample)
        self.assertIn("nazwaPodmiotu", scatter_sample)
        self.assertIn("kontrola", scatter_sample)
        self.assertIn("osobaKierujaca", scatter_sample)
        self.assertIn("zespol", scatter_sample)

        detail_codes = {row["kodInspekcji"] for row in payload["detailRows"]}
        self.assertIn(code_visible_lead, detail_codes)
        self.assertIn(code_visible_member, detail_codes)
        self.assertIn(code_hidden, detail_codes)
        self.assertIn(code_missing_time, detail_codes)

        filtered_by_team = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "teams": "A"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(filtered_by_team.status_code, 200, filtered_by_team.text)
        payload_team = filtered_by_team.json()
        self.assertEqual(int(payload_team["baseCount"]), 4)
        self.assertEqual(int(payload_team["filteredCount"]), 3)

        team_filtered_codes = {row["kodInspekcji"] for row in payload_team["detailRows"]}
        self.assertIn(code_visible_lead, team_filtered_codes)
        self.assertIn(code_hidden, team_filtered_codes)
        self.assertIn(code_missing_time, team_filtered_codes)
        self.assertNotIn(code_visible_member, team_filtered_codes)

        bad_operator = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K"},
            headers=self._operator_headers("no-such-user"),
        )
        self.assertEqual(bad_operator.status_code, 401)

        missing_header = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K"},
        )
        self.assertEqual(missing_header.status_code, 401)

        inspector = self._create_user(role_id=1, team_id=team_a)
        inspector_view = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K"},
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(inspector_view.status_code, 200, inspector_view.text)

    def test_reports_inspections_time_analytics_for_inspector_own_and_benchmarks(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        inspector = self._create_user(role_id=1, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        ins_my_a = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INS-MY-A-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-01-01",
                "koniecInspekcji": "2025-01-10",
                "dataProtokolu": "2025-01-15",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"]), int(inspector["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_my_a.status_code, 201, ins_my_a.text)
        my_a_code = str(ins_my_a.json()["kodInspekcji"])

        ins_my_b = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INS-MY-B-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "poczatekInspekcji": "2025-02-01",
                "koniecInspekcji": "2025-02-10",
                "dataProtokolu": "2025-02-25",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_b["id"]), int(inspector["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_my_b.status_code, 201, ins_my_b.text)
        my_b_code = str(ins_my_b.json()["kodInspekcji"])

        ins_team_only = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INS-TEAM-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-03-01",
                "koniecInspekcji": "2025-03-10",
                "dataProtokolu": "2025-04-04",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_team_only.status_code, 201, ins_team_only.text)
        team_only_code = str(ins_team_only.json()["kodInspekcji"])

        analytics = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median"},
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(analytics.status_code, 200, analytics.text)
        payload = analytics.json()

        detail_codes = {row["kodInspekcji"] for row in payload["detailRows"]}
        self.assertIn(my_a_code, detail_codes)
        self.assertIn(my_b_code, detail_codes)
        self.assertNotIn(team_only_code, detail_codes)

        self.assertTrue(any(row["zespol"] == "Moj czas" and int(row["count"]) == 2 for row in payload["summaryRows"]))
        self.assertTrue(any(row["zespol"] == "A" for row in payload["summaryRows"]))
        self.assertTrue(any(row["zespol"] == "Departament" for row in payload["summaryRows"]))
        self.assertEqual(payload["summaryPivotYears"], ["2025", "allYears"])
        self.assertTrue(any(row["zespol"] == "Moj czas" and row["values"].get("2025") is not None for row in payload["summaryPivotRows"]))

        self.assertTrue(payload["overallRows"])
        self.assertTrue(any(row["zespol"] == "Moj czas" and int(row["count"]) == 2 for row in payload["overallRows"]))
        self.assertTrue(all("rok" not in row for row in payload["overallRows"]))
        self.assertEqual(
            payload["overallColumns"],
            [
                {"key": "zespol", "label": "Zespol"},
                {"key": "metric", "label": "Mediana"},
                {"key": "count", "label": "Liczba"},
            ],
        )

    def test_reports_inspections_time_analytics_years_filter(self) -> None:
        team_a = self._team_id("A")
        manager_a = self._create_user(role_id=2, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)

        ins_2025_k = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"YR-K25-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2025-01-01",
                "koniecInspekcji": "2025-01-10",
                "dataProtokolu": "2025-01-20",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_2025_k.status_code, 201, ins_2025_k.text)
        code_2025_k = str(ins_2025_k.json()["kodInspekcji"])

        ins_2026_k = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"YR-K26-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "SCR",
                "poczatekInspekcji": "2026-02-01",
                "koniecInspekcji": "2026-02-11",
                "dataProtokolu": "2026-02-26",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_2026_k.status_code, 201, ins_2026_k.text)
        code_2026_k = str(ins_2026_k.json()["kodInspekcji"])

        ins_2026_w = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"YR-W26-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Wizyta nadzorcza",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-03-01",
                "koniecInspekcji": "2026-03-10",
                "dataProtokolu": "2026-03-20",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_2026_w.status_code, 201, ins_2026_w.text)

        no_year_filter = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(no_year_filter.status_code, 200, no_year_filter.text)
        no_year_payload = no_year_filter.json()

        no_year_codes = {row["kodInspekcji"] for row in no_year_payload["detailRows"]}
        self.assertIn(code_2025_k, no_year_codes)
        self.assertIn(code_2026_k, no_year_codes)
        self.assertEqual(no_year_payload["yearOptions"], ["2026", "2025"])

        year_2026 = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median", "years": "2026"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(year_2026.status_code, 200, year_2026.text)
        payload_2026 = year_2026.json()

        codes_2026 = {row["kodInspekcji"] for row in payload_2026["detailRows"]}
        self.assertEqual(codes_2026, {code_2026_k})
        self.assertEqual(int(payload_2026["filteredCount"]), 1)
        self.assertEqual(payload_2026["yearOptions"], ["2026", "2025"])
        self.assertTrue(all(str(row.get("rok")) == "2026" for row in payload_2026["summaryRows"]))
        self.assertTrue(all(str(row.get("year")) == "2026" for row in payload_2026["trendRows"]))
        self.assertTrue(all(str(row.get("year")) == "2026" for row in payload_2026["scatterRows"]))
        self.assertEqual(payload_2026["summaryPivotYears"], ["2026", "allYears"])
        self.assertTrue(all("2025" not in row.get("values", {}) for row in payload_2026["summaryPivotRows"]))
        self.assertEqual(payload_2026["yearCountColumns"], ["2026"])
        self.assertEqual(payload_2026["yearCountByTeamColumns"], ["2026"])

        year_csv = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median", "years": "2025,2026"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(year_csv.status_code, 200, year_csv.text)
        payload_csv = year_csv.json()
        codes_csv = {row["kodInspekcji"] for row in payload_csv["detailRows"]}
        self.assertEqual(codes_csv, {code_2025_k, code_2026_k})

        year_multi_param = self.client.get(
            "/api/reports/inspections-time-analytics",
            params=[("inspectionType", "K"), ("trendMode", "median"), ("years", "2025"), ("years", "2026")],
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(year_multi_param.status_code, 200, year_multi_param.text)
        payload_multi = year_multi_param.json()
        codes_multi = {row["kodInspekcji"] for row in payload_multi["detailRows"]}
        self.assertEqual(codes_multi, {code_2025_k, code_2026_k})

        year_outside = self.client.get(
            "/api/reports/inspections-time-analytics",
            params={"inspectionType": "K", "trendMode": "median", "years": "2030"},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(year_outside.status_code, 200, year_outside.text)
        payload_outside = year_outside.json()
        self.assertEqual(int(payload_outside["filteredCount"]), 0)
        self.assertEqual(payload_outside["detailRows"], [])
        self.assertEqual(payload_outside["scatterRows"], [])
        self.assertEqual(payload_outside["trendRows"], [])
        self.assertEqual(payload_outside["summaryRows"], [])
        self.assertEqual(payload_outside["summaryPivotRows"], [])
        self.assertEqual(payload_outside["overallRows"], [])
        self.assertEqual(payload_outside["yearCountColumns"], [])
        self.assertEqual(payload_outside["yearCountByTeamColumns"], [])
        self.assertTrue(all(row.get("values") == {} for row in payload_outside["yearCountRows"]))

    def test_inspection_code_generation_and_linked_views(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"KOD-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-01",
                "koniecInspekcji": "2026-06-10",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection = created_inspection.json()
        inspection_id = int(inspection["id"])
        inspection_code = str(inspection["kodInspekcji"])
        self.assertRegex(inspection_code, r"^K/2026/\d+$")

        available_for_recommendations = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(available_for_recommendations.status_code, 200, available_for_recommendations.text)
        rec_option = next(item for item in available_for_recommendations.json() if int(item["id"]) == inspection_id)
        self.assertEqual(rec_option["kodInspekcji"], inspection_code)
        self.assertIn("nazwaPodmiotuSkrocona", rec_option)
        self.assertIn("nazwaPodmiotuSkrot", rec_option)

        available_for_risk = self.client.get(
            "/api/risk-exposure/available-inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(available_for_risk.status_code, 200, available_for_risk.text)
        risk_option = next(item for item in available_for_risk.json() if int(item["id"]) == inspection_id)
        self.assertEqual(risk_option["kodInspekcji"], inspection_code)

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-06-12"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)
        recommendation_id = int(created_recommendation.json()["id"])

        recommendations_list = self.client.get(
            "/api/recommendations",
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendations_list.status_code, 200, recommendations_list.text)
        recommendation_row = next(item for item in recommendations_list.json()["items"] if int(item["id"]) == recommendation_id)
        self.assertEqual(recommendation_row["inspectionKod"], inspection_code)

        created_risk = self.client.post(
            "/api/risk-exposure",
            json={
                "inspectionId": inspection_id,
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot test",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_risk.status_code, 201, created_risk.text)
        risk_id = int(created_risk.json()["id"])

        risk_list = self.client.get(
            "/api/risk-exposure",
            headers=self._admin_headers(),
        )
        self.assertEqual(risk_list.status_code, 200, risk_list.text)
        risk_row = next(item for item in risk_list.json()["items"] if int(item["id"]) == risk_id)
        self.assertEqual(risk_row["inspectionKod"], inspection_code)

    def test_delete_inspection_removes_linked_records(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"DEL-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-01",
                "koniecInspekcji": "2026-01-10",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-01-12"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)

        created_risk = self.client.post(
            "/api/risk-exposure",
            json={
                "inspectionId": inspection_id,
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot X",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_risk.status_code, 201, created_risk.text)

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        forbidden_delete = self.client.delete(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden_delete.status_code, 403)

        deleted = self.client.delete(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)
        body = deleted.json()
        self.assertEqual(int(body["id"]), inspection_id)
        self.assertIsInstance(body["deletedRecommendations"], int)
        self.assertIsInstance(body["deletedSanctionRequests"], int)
        self.assertEqual(int(body["deletedRecommendations"]), 1)
        self.assertEqual(int(body["deletedSanctionRequests"]), 1)

        with get_connection() as conn:
            inspection_left = conn.execute(
                "SELECT COUNT(*) AS total FROM inspections WHERE id = ?",
                (inspection_id,),
            ).fetchone()
            recommendations_left = conn.execute(
                "SELECT COUNT(*) AS total FROM recommendations WHERE inspection_id = ?",
                (inspection_id,),
            ).fetchone()
            risks_left = conn.execute(
                "SELECT COUNT(*) AS total FROM risk_exposure_requests WHERE inspection_id = ?",
                (inspection_id,),
            ).fetchone()

        self.assertEqual(int(inspection_left["total"]), 0)
        self.assertEqual(int(recommendations_left["total"]), 0)
        self.assertEqual(int(risks_left["total"]), 0)

    def test_delete_recommendation_removes_only_recommendation_row(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"REC-DEL-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-02-01",
                "koniecInspekcji": "2026-02-10",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-02-12"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)
        recommendation_id = int(created_recommendation.json()["id"])

        created_risk = self.client.post(
            "/api/risk-exposure",
            json={
                "inspectionId": inspection_id,
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot test",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_risk.status_code, 201, created_risk.text)

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        forbidden_delete = self.client.delete(
            f"/api/recommendations/{recommendation_id}",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden_delete.status_code, 403)

        deleted = self.client.delete(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)
        self.assertTrue(bool(deleted.json().get("ok")))

        with get_connection() as conn:
            recommendation_left = conn.execute(
                "SELECT COUNT(*) AS total FROM recommendations WHERE id = ?",
                (recommendation_id,),
            ).fetchone()
            inspection_left = conn.execute(
                "SELECT COUNT(*) AS total FROM inspections WHERE id = ?",
                (inspection_id,),
            ).fetchone()
            risks_left = conn.execute(
                "SELECT COUNT(*) AS total FROM risk_exposure_requests WHERE inspection_id = ?",
                (inspection_id,),
            ).fetchone()

        self.assertEqual(int(recommendation_left["total"]), 0)
        self.assertEqual(int(inspection_left["total"]), 1)
        self.assertEqual(int(risks_left["total"]), 1)

    def test_delete_risk_exposure_removes_only_risk_row(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RISK-DEL-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Wizyta Nadzorcza",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-03-01",
                "koniecInspekcji": "2026-03-10",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-03-12"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)
        recommendation_id = int(created_recommendation.json()["id"])

        created_risk = self.client.post(
            "/api/risk-exposure",
            json={
                "inspectionId": inspection_id,
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot test",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_risk.status_code, 201, created_risk.text)
        risk_id = int(created_risk.json()["id"])

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        forbidden_delete = self.client.delete(
            f"/api/risk-exposure/{risk_id}",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden_delete.status_code, 403)

        deleted = self.client.delete(
            f"/api/risk-exposure/{risk_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)
        self.assertTrue(bool(deleted.json().get("ok")))

        with get_connection() as conn:
            risk_left = conn.execute(
                "SELECT COUNT(*) AS total FROM risk_exposure_requests WHERE id = ?",
                (risk_id,),
            ).fetchone()
            inspection_left = conn.execute(
                "SELECT COUNT(*) AS total FROM inspections WHERE id = ?",
                (inspection_id,),
            ).fetchone()
            recommendation_left = conn.execute(
                "SELECT COUNT(*) AS total FROM recommendations WHERE id = ?",
                (recommendation_id,),
            ).fetchone()

        self.assertEqual(int(risk_left["total"]), 0)
        self.assertEqual(int(inspection_left["total"]), 1)
        self.assertEqual(int(recommendation_left["total"]), 1)

    def test_sanction_code_generation(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"WS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-04-01",
                "koniecInspekcji": "2026-04-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_risk = self.client.post(
            "/api/risk-exposure",
            json={
                "inspectionId": inspection_id,
                "dataWniosku": "2026-04-11",
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot test",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_risk.status_code, 201, created_risk.text)
        risk_payload = created_risk.json()
        self.assertRegex(str(risk_payload["kodSankcji"]), r"^WS/2026/\d+$")

        risk_id = int(risk_payload["id"])
        detail = self.client.get(f"/api/risk-exposure/{risk_id}", headers=self._admin_headers())
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertEqual(detail.json()["kodSankcji"], risk_payload["kodSankcji"])

        listing = self.client.get("/api/risk-exposure", headers=self._admin_headers())
        self.assertEqual(listing.status_code, 200, listing.text)
        listed_row = next(item for item in listing.json()["items"] if int(item["id"]) == risk_id)
        self.assertEqual(listed_row["kodSankcji"], risk_payload["kodSankcji"])

    def test_inspection_multi_dates_roundtrip(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        payload = {
            "nazwaPodmiotu": f"PODMIOT-{uuid.uuid4().hex[:6]}",
            "poczatekInspekcji": "2026-07-01",
            "koniecInspekcji": "2026-07-10",
            "osobaKierujacaUserId": admin_id,
            "teamMemberUserIds": [admin_id],
            "dataZalecenList": ["2026-07-02", "2026-07-03"],
            "dataAkceptacjiNotyList": ["2026-07-04", "2026-07-05"],
        }
        created = self.client.post(
            "/api/structure/inspections",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        body = created.json()
        # dataZalecenList jest pochodne z recommendations, wiec create inspection je ignoruje.
        self.assertEqual(body["dataZalecenList"], [])
        self.assertEqual(body["dataAkceptacjiNotyList"], ["2026-07-04", "2026-07-05"])
        self.assertFalse(body["brakDatAkceptacjiNoty"])

        inspection_id = int(body["id"])
        rec_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-07-02", "2026-07-03"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_created.status_code, 201, rec_created.text)
        rec_id = int(rec_created.json()["id"])

        rec_updated = self._update_recommendation_with_lock(
            rec_id,
            "admin",
            {"dataZalecenList": ["2026-07-02", "2026-07-08"]},
        )
        self.assertEqual(rec_updated.status_code, 200, rec_updated.text)

        detail = self.client.get(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        # Pole inspection.dataZalecenList jest wyliczane z recommendations.data_zalecen
        # (pojedyncza data), a nie z recommendation_multi_dates.
        self.assertEqual(detail.json()["dataZalecenList"], [])
        self.assertEqual(detail.json()["dataAkceptacjiNotyList"], ["2026-07-04", "2026-07-05"])
        self.assertFalse(detail.json()["brakDatAkceptacjiNoty"])

    def test_inspection_aspekt_konsumencki_roundtrip(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ASPEKT-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-05",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
                "aspektKonsumencki": "Wysoki",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])
        self.assertEqual(created.json()["aspektKonsumencki"], "Wysoki")

        updated = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json={"aspektKonsumencki": "Sredni"},
            headers=self._admin_headers(),
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        self.assertEqual(updated.json()["aspektKonsumencki"], "Sredni")

        detail = self.client.get(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertEqual(detail.json()["aspektKonsumencki"], "Sredni")

    def test_inspection_szczegoly_dotyczace_zakresu_roundtrip_and_validation(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('typy_inspekcji', 'KONTROLA', 'Kontrola', 'K', 1, 1)
                """
            )
            conn.commit()

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"SZCZ-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-08-10",
                "koniecInspekcji": "2026-08-15",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
                "szczegolyDotyczaceZakresu": "  Dodatkowe szczegoly zakresu testowe.  ",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])
        self.assertEqual(created.json()["szczegolyDotyczaceZakresu"], "Dodatkowe szczegoly zakresu testowe.")

        updated = self._update_inspection_with_lock(
            inspection_id,
            "admin",
            {"szczegolyDotyczaceZakresu": " Zmienione szczegoly zakresu "},
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        self.assertEqual(updated.json()["szczegolyDotyczaceZakresu"], "Zmienione szczegoly zakresu")

        detail = self.client.get(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertEqual(detail.json()["szczegolyDotyczaceZakresu"], "Zmienione szczegoly zakresu")

        too_long = "x" * 2001
        invalid = self._update_inspection_with_lock(
            inspection_id,
            "admin",
            {"szczegolyDotyczaceZakresu": too_long},
        )
        self.assertEqual(invalid.status_code, 422, invalid.text)

    def test_structure_inspections_list_returns_short_variant_fields(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('typy_inspekcji', 'KONTROLA', 'Kontrola', 'K', 1, 1)
                """
            )
            conn.commit()

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"SKROT-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-09-01",
                "koniecInspekcji": "2026-09-05",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])

        listed = self.client.get(
            "/api/structure/inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        item = next(row for row in listed.json()["items"] if int(row["id"]) == inspection_id)

        self.assertIn("nazwaPodmiotuSkrocona", item)
        self.assertIn("typInspekcjiSkrocona", item)
        self.assertIn("zakresInspekcjiSkrocona", item)
        self.assertIn("rodzajPodmiotuSkrocona", item)
        self.assertIn("statusSkrocona", item)

    def test_recommendations_available_inspections_and_rbac_matrix(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        user_team_a = self._create_user(role_id=1, team_id=team_a)
        member_team_a = self._create_user(role_id=1, team_id=team_a)
        lead_team_a = self._create_user(role_id=2, team_id=team_a)
        lead_team_d = self._create_user(role_id=2, team_id=team_d)

        ins_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RBAC-A-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-10-01",
                "koniecInspekcji": "2026-10-05",
                "osobaKierujacaUserId": int(lead_team_a["id"]),
                "teamMemberUserIds": [
                    int(user_team_a["id"]),
                    int(member_team_a["id"]),
                    int(lead_team_a["id"]),
                ],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_a_resp.status_code, 201, ins_a_resp.text)
        ins_a = int(ins_a_resp.json()["id"])

        ins_d_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RBAC-D-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-10-10",
                "koniecInspekcji": "2026-10-15",
                "osobaKierujacaUserId": int(lead_team_d["id"]),
                "teamMemberUserIds": [int(lead_team_d["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_d_resp.status_code, 201, ins_d_resp.text)
        ins_d = int(ins_d_resp.json()["id"])

        ins_member_team_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RBAC-M-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-10-16",
                "koniecInspekcji": "2026-10-18",
                "osobaKierujacaUserId": int(lead_team_d["id"]),
                "teamMemberUserIds": [int(member_team_a["id"]), int(lead_team_d["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_member_team_a_resp.status_code, 201, ins_member_team_a_resp.text)
        ins_member_team_a = int(ins_member_team_a_resp.json()["id"])

        available_user = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(available_user.status_code, 200, available_user.text)
        user_available_ids = {int(item["id"]) for item in available_user.json()}
        self.assertIn(ins_a, user_available_ids)
        self.assertNotIn(ins_d, user_available_ids)
        self.assertNotIn(ins_member_team_a, user_available_ids)

        available_lead = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._operator_headers(lead_team_a["login"]),
        )
        self.assertEqual(available_lead.status_code, 200, available_lead.text)
        lead_available_ids = {int(item["id"]) for item in available_lead.json()}
        self.assertIn(ins_a, lead_available_ids)
        self.assertNotIn(ins_d, lead_available_ids)
        self.assertIn(ins_member_team_a, lead_available_ids)

        available_admin = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(available_admin.status_code, 200, available_admin.text)
        admin_available_ids = {int(item["id"]) for item in available_admin.json()}
        self.assertIn(ins_a, admin_available_ids)
        self.assertIn(ins_d, admin_available_ids)

        user_allowed = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_a,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-01"],
            },
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(user_allowed.status_code, 201, user_allowed.text)

        user_forbidden = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_d,
                "pozycja": 2,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-02"],
            },
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(user_forbidden.status_code, 403)

        lead_allowed = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_a,
                "pozycja": 3,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-03"],
            },
            headers=self._operator_headers(lead_team_a["login"]),
        )
        self.assertEqual(lead_allowed.status_code, 201, lead_allowed.text)

        lead_forbidden = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_d,
                "pozycja": 4,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-04"],
            },
            headers=self._operator_headers(lead_team_a["login"]),
        )
        self.assertEqual(lead_forbidden.status_code, 403)

        lead_allowed_by_member_team = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_member_team_a,
                "pozycja": 5,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-05"],
            },
            headers=self._operator_headers(lead_team_a["login"]),
        )
        self.assertEqual(lead_allowed_by_member_team.status_code, 201, lead_allowed_by_member_team.text)

        created_by_user_not_member = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RBAC-CREATED-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-10-20",
                "koniecInspekcji": "2026-10-25",
                "osobaKierujacaUserId": int(lead_team_d["id"]),
                "teamMemberUserIds": [int(lead_team_d["id"])],
            },
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(created_by_user_not_member.status_code, 201, created_by_user_not_member.text)
        ins_created_by_user = int(created_by_user_not_member.json()["id"])

        available_user_after_create = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(available_user_after_create.status_code, 200, available_user_after_create.text)
        user_available_ids_after_create = {int(item["id"]) for item in available_user_after_create.json()}
        self.assertIn(ins_created_by_user, user_available_ids_after_create)

        user_allowed_created_by = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_created_by_user,
                "pozycja": 6,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-06"],
            },
            headers=self._operator_headers(user_team_a["login"]),
        )
        self.assertEqual(user_allowed_created_by.status_code, 201, user_allowed_created_by.text)

    def test_closed_inspection_blocks_recommendations_and_sanctions(self) -> None:
        team_a = self._team_id("A")
        lead_a = self._create_user(role_id=2, team_id=team_a)

        inspection_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"BLOCKED-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-10-01",
                "koniecInspekcji": "2026-10-05",
                "status": "W toku",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_resp.status_code, 201, inspection_resp.text)
        blocked_inspection_id = int(inspection_resp.json()["id"])

        open_inspection_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OPEN-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-10-06",
                "koniecInspekcji": "2026-10-10",
                "status": "W toku",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(open_inspection_resp.status_code, 201, open_inspection_resp.text)
        open_inspection_id = int(open_inspection_resp.json()["id"])

        rec_before_close = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": blocked_inspection_id,
                "pozycja": 1,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-01"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_before_close.status_code, 201, rec_before_close.text)
        recommendation_id = int(rec_before_close.json()["id"])

        risk_before_close = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": blocked_inspection_id,
                "sankcjaList": ["Kara pieniezna"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(risk_before_close.status_code, 201, risk_before_close.text)
        sanction_id = int(risk_before_close.json()["id"])

        close_inspection = self._update_inspection_with_lock(
            blocked_inspection_id,
            "admin",
            {"status": "Zamkniete - wydano zalecenia"},
        )
        self.assertEqual(close_inspection.status_code, 200, close_inspection.text)

        rec_available = self.client.get(
            "/api/recommendations/available-inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_available.status_code, 200, rec_available.text)
        rec_available_ids = {int(item["id"]) for item in rec_available.json()}
        self.assertNotIn(blocked_inspection_id, rec_available_ids)
        self.assertIn(open_inspection_id, rec_available_ids)

        risk_available = self.client.get(
            "/api/sanction-requests/available-inspections",
            headers=self._admin_headers(),
        )
        self.assertEqual(risk_available.status_code, 200, risk_available.text)
        risk_available_ids = {int(item["id"]) for item in risk_available.json()}
        self.assertNotIn(blocked_inspection_id, risk_available_ids)
        self.assertIn(open_inspection_id, risk_available_ids)

        rec_create_blocked = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": blocked_inspection_id,
                "pozycja": 2,
                "status": "Nowe",
                "dataZalecenList": ["2026-11-02"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_create_blocked.status_code, 409, rec_create_blocked.text)
        rec_create_body = rec_create_blocked.json()
        self.assertEqual(rec_create_body.get("code"), "INSPECTION_STATUS_BLOCKS_OPERATION")

        sanction_create_blocked = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": blocked_inspection_id,
                "sankcjaList": ["Zakaz"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(sanction_create_blocked.status_code, 409, sanction_create_blocked.text)
        sanction_create_body = sanction_create_blocked.json()
        self.assertEqual(sanction_create_body.get("code"), "INSPECTION_STATUS_BLOCKS_OPERATION")

        rec_update_blocked = self._update_recommendation_with_lock(
            recommendation_id,
            "admin",
            {"komentarz": "blocked-after-close"},
        )
        self.assertEqual(rec_update_blocked.status_code, 409, rec_update_blocked.text)
        rec_update_body = rec_update_blocked.json()
        self.assertEqual(rec_update_body.get("code"), "INSPECTION_STATUS_BLOCKS_OPERATION")

        sanction_update_blocked = self._update_sanction_with_lock(
            sanction_id,
            "admin",
            {"komentarz": "blocked-after-close"},
        )
        self.assertEqual(sanction_update_blocked.status_code, 409, sanction_update_blocked.text)
        sanction_update_body = sanction_update_blocked.json()
        self.assertEqual(sanction_update_body.get("code"), "INSPECTION_STATUS_BLOCKS_OPERATION")

    def test_team_error_codes(self) -> None:
        unauthorized = self.client.post(
            "/api/admin/teams",
            json={"kod": "ERR1", "nazwa": "Err Team"},
            headers={"X-Operator-Login": "ghost"},
        )
        self.assertEqual(unauthorized.status_code, 401)

        forbidden = self.client.post(
            "/api/admin/teams",
            json={"kod": "ERR2", "nazwa": "Err Team 2"},
            headers={"X-Operator-Login": "admin"},
        )
        self.assertEqual(forbidden.status_code, 201, forbidden.text)
        team_id = int(forbidden.json()["id"])

        duplicate = self.client.post(
            "/api/admin/teams",
            json={"kod": "ERR2", "nazwa": "Different Name"},
            headers=self._admin_headers(),
        )
        self.assertEqual(duplicate.status_code, 409)

        schema_error = self.client.post(
            "/api/admin/teams",
            json={"kod": 123, "nazwa": "Bad"},
            headers=self._admin_headers(),
        )
        self.assertEqual(schema_error.status_code, 422)

        not_found = self.client.put(
            "/api/admin/teams/999999",
            json={"nazwa": "Missing"},
            headers=self._admin_headers(),
        )
        self.assertEqual(not_found.status_code, 404)

        self.client.delete(f"/api/admin/teams/{team_id}", headers=self._admin_headers())

    def test_user_rbac_scope_and_update(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        lead = self._create_user(role_id=2, team_id=team_a)
        same_team_user = self._create_user(role_id=1, team_id=team_a)
        other_team_user = self._create_user(role_id=1, team_id=team_d)

        as_lead = self.client.get(
            "/api/admin/users",
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(as_lead.status_code, 200, as_lead.text)
        lead_ids = {int(u["id"]) for u in as_lead.json()}
        self.assertIn(int(lead["id"]), lead_ids)
        self.assertIn(int(same_team_user["id"]), lead_ids)
        self.assertNotIn(int(other_team_user["id"]), lead_ids)

        as_inspector = self.client.get(
            "/api/admin/users",
            headers=self._operator_headers(same_team_user["login"]),
        )
        self.assertEqual(as_inspector.status_code, 403)

        as_admin = self.client.get("/api/admin/users", headers=self._admin_headers())
        self.assertEqual(as_admin.status_code, 200, as_admin.text)
        admin_ids = {int(u["id"]) for u in as_admin.json()}
        self.assertIn(int(other_team_user["id"]), admin_ids)

        update_same_team = self.client.put(
            f"/api/admin/users/{int(same_team_user['id'])}",
            json={"imie": "ChangedByLead"},
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(update_same_team.status_code, 200, update_same_team.text)
        self.assertEqual(update_same_team.json()["imie"], "ChangedByLead")

        update_other_team = self.client.put(
            f"/api/admin/users/{int(other_team_user['id'])}",
            json={"imie": "Blocked"},
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(update_other_team.status_code, 403)

    def test_team_lead_can_manage_users_created_by_self_outside_team(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead = self._create_user(role_id=2, team_id=team_a)

        created_by_lead = self.client.post(
            "/api/admin/users",
            json={
                "login": f"lead_created_{uuid.uuid4().hex[:8]}",
                "imie": "Lead",
                "nazwisko": "Created",
                "email": None,
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": True,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(created_by_lead.status_code, 200, created_by_lead.text)
        created_user_id = int(created_by_lead.json()["id"])

        move_to_other_team = self.client.put(
            f"/api/admin/users/{created_user_id}",
            json={"zespolId": team_b},
            headers=self._admin_headers(),
        )
        self.assertEqual(move_to_other_team.status_code, 200, move_to_other_team.text)

        as_lead = self.client.get(
            "/api/admin/users",
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(as_lead.status_code, 200, as_lead.text)
        visible_ids = {int(item["id"]) for item in as_lead.json()}
        self.assertIn(created_user_id, visible_ids)

        edit_created = self.client.put(
            f"/api/admin/users/{created_user_id}",
            json={"imie": "EditedByLead"},
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(edit_created.status_code, 200, edit_created.text)
        self.assertEqual(edit_created.json()["imie"], "EditedByLead")

    def test_team_lead_can_create_technical_user_without_team_with_department(self) -> None:
        team_a = self._team_id("A")
        lead = self._create_user(role_id=2, team_id=team_a)
        department_code = f"D{uuid.uuid4().hex[:6]}".upper()

        create_department = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "department_ogolne",
                "kodPozycji": department_code,
                "nazwaPozycji": f"Departament {department_code}",
                "skrotPozycji": department_code,
            },
            headers=self._admin_headers(),
        )
        self.assertIn(create_department.status_code, {200, 409}, create_department.text)

        create_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Tech",
                "nazwisko": "LeadCreated",
                "email": None,
                "rolaId": 2,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": department_code,
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(create_technical.status_code, 200, create_technical.text)
        payload = create_technical.json()
        self.assertEqual(payload["accountType"], "technical")
        self.assertFalse(bool(payload["aktywny"]))
        self.assertIsNone(payload["zespolId"])
        self.assertEqual(payload["departmentCode"], department_code)
        self.assertEqual(int(payload["rolaId"]), 1)

    def test_inspections_people_options_contract(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        inspector = self._create_user(role_id=1, team_id=team_a)
        lead = self._create_user(role_id=2, team_id=team_d)
        inactive = self._create_user(role_id=1, team_id=team_a)
        hidden = self._create_user(role_id=1, team_id=team_a)

        deactivate = self.client.put(
            f"/api/admin/users/{int(inactive['id'])}",
            json={"aktywny": False, "email": None, "login": ""},
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate.status_code, 200, deactivate.text)

        hide_user = self.client.put(
            f"/api/admin/users/{int(hidden['id'])}",
            json={"listVisibility": "hidden"},
            headers=self._admin_headers(),
        )
        self.assertEqual(hide_user.status_code, 200, hide_user.text)

        with get_connection() as conn:
            inactive_row = conn.execute("SELECT login FROM users WHERE id = ?", (int(inactive["id"]),)).fetchone()
        self.assertIsNotNone(inactive_row)
        assert inactive_row is not None
        inactive_internal_login = str(inactive_row["login"])

        missing_header = self.client.get("/api/inspections/people-options")
        self.assertEqual(missing_header.status_code, 422)
        self.assertEqual(missing_header.json()["detail"], "Brak lub nieprawidlowy X-Operator-Login")

        unknown_operator = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers("ghost"),
        )
        self.assertEqual(unknown_operator.status_code, 401)
        self.assertEqual(unknown_operator.json()["detail"], "Brak autoryzacji operatora")

        inactive_operator = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(inactive_internal_login),
        )
        self.assertEqual(inactive_operator.status_code, 403)
        self.assertEqual(inactive_operator.json()["detail"], "Operator nieaktywny lub brak dostepu")

        as_inspector = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(as_inspector.status_code, 200, as_inspector.text)
        options = as_inspector.json()
        logins = {item["login"] for item in options}
        self.assertIn(inspector["login"], logins)
        self.assertIn(lead["login"], logins)
        self.assertIn(inactive_internal_login, logins)
        self.assertIn(hidden["login"], logins)

        sample = options[0]
        self.assertIn("id", sample)
        self.assertIn("login", sample)
        self.assertIn("displayName", sample)
        self.assertIn("active", sample)
        self.assertIn("canBeLeader", sample)
        self.assertIn("listVisibility", sample)
        self.assertIn("visibleOnList", sample)
        self.assertIn("createdByOperator", sample)
        self.assertIn("createdByLogin", sample)

        display_names = [item["displayName"] for item in options]
        self.assertEqual(display_names, sorted(display_names, key=lambda value: value.casefold()))

        with_inactive = self.client.get(
            "/api/inspections/people-options?includeInactive=true",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(with_inactive.status_code, 200, with_inactive.text)
        options_with_inactive = with_inactive.json()
        inactive_entry = next((item for item in options_with_inactive if item["login"] == inactive_internal_login), None)
        self.assertIsNotNone(inactive_entry)
        self.assertFalse(bool(inactive_entry["active"]))
        self.assertEqual(inactive_entry["listVisibility"], "visible")
        self.assertTrue(bool(inactive_entry["visibleOnList"]))
        self.assertFalse(bool(inactive_entry["canBeLeader"]))

        hidden_entry = next((item for item in options_with_inactive if item["login"] == hidden["login"]), None)
        self.assertIsNotNone(hidden_entry)
        assert hidden_entry is not None
        self.assertEqual(hidden_entry["listVisibility"], "hidden")
        self.assertFalse(bool(hidden_entry["visibleOnList"]))
        self.assertFalse(bool(hidden_entry["canBeLeader"]))

    def test_team_lead_people_options_marks_created_by_operator_and_leader_eligibility(self) -> None:
        team_a = self._team_id("A")
        lead = self._create_user(role_id=2, team_id=team_a)

        create_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Lead",
                "nazwisko": "Technical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(create_technical.status_code, 200, create_technical.text)
        created_id = int(create_technical.json()["id"])

        options = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(options.status_code, 200, options.text)
        created_entry = next((item for item in options.json() if int(item["id"]) == created_id), None)
        self.assertIsNotNone(created_entry)
        assert created_entry is not None
        self.assertTrue(bool(created_entry["createdByOperator"]))
        self.assertEqual(created_entry["createdByLogin"], lead["login"])
        self.assertTrue(bool(created_entry["canBeLeader"]))
        self.assertIsNone(created_entry["teamId"])

        create_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-TECH-LEAD-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-01",
                "koniecInspekcji": "2026-06-02",
                "osobaKierujacaUserId": created_id,
                "teamMemberUserIds": [int(lead["id"])],
            },
            headers=self._operator_headers(lead["login"]),
        )
        self.assertEqual(create_inspection.status_code, 201, create_inspection.text)

    def test_people_options_with_inspection_id_puts_current_leader_first(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department_ogolne', 'Departament ogolne', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('zakresy_inspekcji', 'Zakresy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO teams (kod, nazwa)
                VALUES ('A', 'Zespol A')
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO teams (kod, nazwa)
                VALUES ('B', 'Zespol B')
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje
                (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department_ogolne', 'DIU', 'DIU', 'DIU', 1, 1)
                """
            )

        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        create_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"EDIT-LEADER-FIRST-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-12",
                "koniecInspekcji": "2026-06-13",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_a["id"]), int(lead_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_inspection.status_code, 201, create_inspection.text)
        inspection_id = int(create_inspection.json()["id"])

        options = self.client.get(
            f"/api/inspections/people-options?inspectionId={inspection_id}",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(options.status_code, 200, options.text)
        payload = options.json()
        self.assertGreater(len(payload), 0)
        self.assertEqual(int(payload[0]["id"]), int(lead_b["id"]))

        missing = self.client.get(
            "/api/inspections/people-options?inspectionId=99999999",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(missing.status_code, 404)
        self.assertEqual(missing.json()["detail"], "Inspection not found")

    def test_team_lead_people_options_scope_team_or_created_by_visible_only(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)

        same_team_user = self._create_user(role_id=1, team_id=team_a)
        foreign_user = self._create_user(role_id=1, team_id=team_b)

        self._update_user_role(user_id=int(lead_a["id"]), role_id=2, team_id=team_a)
        self._update_user_role(user_id=int(same_team_user["id"]), role_id=1, team_id=team_a)

        ensure_same_team_visible = self.client.put(
            f"/api/admin/users/{int(same_team_user['id'])}",
            json={"listVisibility": "visible"},
            headers=self._admin_headers(),
        )
        self.assertEqual(ensure_same_team_visible.status_code, 200, ensure_same_team_visible.text)

        ensure_foreign_visible = self.client.put(
            f"/api/admin/users/{int(foreign_user['id'])}",
            json={"listVisibility": "visible"},
            headers=self._admin_headers(),
        )
        self.assertEqual(ensure_foreign_visible.status_code, 200, ensure_foreign_visible.text)

        created_by_lead = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Lead",
                "nazwisko": "CreatedTechnical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(created_by_lead.status_code, 200, created_by_lead.text)
        created_user_id = int(created_by_lead.json()["id"])

        hide_created = self.client.put(
            f"/api/admin/users/{created_user_id}",
            json={"listVisibility": "hidden", "login": "", "email": None},
            headers=self._admin_headers(),
        )
        self.assertEqual(hide_created.status_code, 200, hide_created.text)

        options_hidden = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(options_hidden.status_code, 200, options_hidden.text)
        hidden_entry = next((item for item in options_hidden.json() if int(item["id"]) == created_user_id), None)
        self.assertIsNotNone(hidden_entry)
        assert hidden_entry is not None
        self.assertFalse(bool(hidden_entry["canBeLeader"]))

        show_created = self.client.put(
            f"/api/admin/users/{created_user_id}",
            json={"listVisibility": "visible", "login": "", "email": None},
            headers=self._admin_headers(),
        )
        self.assertEqual(show_created.status_code, 200, show_created.text)

        options = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(options.status_code, 200, options.text)

        same_team_entry = next((item for item in options.json() if int(item["id"]) == int(same_team_user["id"])), None)
        self.assertIsNotNone(same_team_entry)
        assert same_team_entry is not None
        self.assertTrue(bool(same_team_entry["canBeLeader"]))

        created_entry = next((item for item in options.json() if int(item["id"]) == created_user_id), None)
        self.assertIsNotNone(created_entry)
        assert created_entry is not None
        self.assertTrue(bool(created_entry["canBeLeader"]))

        foreign_entry = next((item for item in options.json() if int(item["id"]) == int(foreign_user["id"])), None)
        self.assertIsNotNone(foreign_entry)
        assert foreign_entry is not None
        self.assertFalse(bool(foreign_entry["canBeLeader"]))

    def test_director_can_use_technical_user_as_inspection_leader(self) -> None:
        director = self._create_user(role_id=3, team_id=None)

        create_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "Inspector",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(director["login"]),
        )
        self.assertEqual(create_technical.status_code, 200, create_technical.text)
        technical_user_id = int(create_technical.json()["id"])

        options = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(director["login"]),
        )
        self.assertEqual(options.status_code, 200, options.text)
        technical_entry = next((item for item in options.json() if int(item["id"]) == technical_user_id), None)
        self.assertIsNotNone(technical_entry)
        assert technical_entry is not None
        self.assertFalse(bool(technical_entry["active"]))
        self.assertTrue(bool(technical_entry["canBeLeader"]))

        create_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"DIR-TECH-LEAD-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-10",
                "koniecInspekcji": "2026-06-11",
                "osobaKierujacaUserId": technical_user_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(director["login"]),
        )
        self.assertEqual(create_inspection.status_code, 201, create_inspection.text)

    def test_create_inspection_technical_scope_with_empty_members(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        own_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "OwnTechnical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(own_technical.status_code, 200, own_technical.text)
        own_technical_id = int(own_technical.json()["id"])

        foreign_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "ForeignTechnical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_b["login"]),
        )
        self.assertEqual(foreign_technical.status_code, 200, foreign_technical.text)
        foreign_technical_id = int(foreign_technical.json()["id"])

        create_with_own_technical = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-OWN-TECH-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-20",
                "koniecInspekcji": "2026-06-21",
                "osobaKierujacaUserId": own_technical_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_with_own_technical.status_code, 201, create_with_own_technical.text)

        create_with_foreign_technical = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-FOREIGN-TECH-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-22",
                "koniecInspekcji": "2026-06-23",
                "osobaKierujacaUserId": foreign_technical_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_with_foreign_technical.status_code, 403, create_with_foreign_technical.text)
        self.assertEqual(
            (create_with_foreign_technical.json().get("detail") or {}).get("code"),
            "LEADER_OUT_OF_SCOPE",
        )

    def test_create_inspection_inactive_diu_scope_with_empty_members(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        own_inactive_diu = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "OwnDiu",
                "email": None,
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": False,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(own_inactive_diu.status_code, 200, own_inactive_diu.text)
        own_inactive_diu_id = int(own_inactive_diu.json()["id"])

        foreign_inactive_diu = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "ForeignDiu",
                "email": None,
                "rolaId": 1,
                "zespolId": team_b,
                "aktywny": False,
                "accountType": "diu",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_b["login"]),
        )
        self.assertEqual(foreign_inactive_diu.status_code, 200, foreign_inactive_diu.text)
        foreign_inactive_diu_id = int(foreign_inactive_diu.json()["id"])

        create_with_own_inactive_diu = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-OWN-DIU-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-24",
                "koniecInspekcji": "2026-06-25",
                "osobaKierujacaUserId": own_inactive_diu_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_with_own_inactive_diu.status_code, 201, create_with_own_inactive_diu.text)

        create_with_foreign_inactive_diu = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-FOREIGN-DIU-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-26",
                "koniecInspekcji": "2026-06-27",
                "osobaKierujacaUserId": foreign_inactive_diu_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_with_foreign_inactive_diu.status_code, 403, create_with_foreign_inactive_diu.text)
        self.assertEqual(
            (create_with_foreign_inactive_diu.json().get("detail") or {}).get("code"),
            "LEADER_OUT_OF_SCOPE",
        )

        create_with_director = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"DIR-DIU-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-06-28",
                "koniecInspekcji": "2026-06-29",
                "osobaKierujacaUserId": foreign_inactive_diu_id,
                "teamMemberUserIds": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_with_director.status_code, 201, create_with_director.text)

    def test_active_inspector_diu_can_set_leader_only_to_self_on_create_and_update(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        other_user = self._create_user(role_id=1, team_id=team_a)

        create_forbidden = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INSP-LEADER-FORB-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-07-01",
                "koniecInspekcji": "2026-07-02",
                "osobaKierujacaUserId": int(other_user["id"]),
                "teamMemberUserIds": [int(inspector["id"])],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_forbidden.status_code, 403, create_forbidden.text)
        denied_payload = create_forbidden.json().get("detail") or {}
        self.assertEqual(denied_payload.get("code"), "INSPECTOR_LEADER_MUST_BE_SELF")
        self.assertEqual(int(denied_payload.get("requiredLeaderUserId")), int(inspector["id"]))

        create_ok = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INSP-LEADER-OK-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-07-03",
                "koniecInspekcji": "2026-07-04",
                "osobaKierujacaUserId": int(inspector["id"]),
                "teamMemberUserIds": [int(inspector["id"])],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_ok.status_code, 201, create_ok.text)
        inspection_id = int(create_ok.json()["id"])

        update_forbidden = self._update_inspection_with_lock(
            inspection_id,
            inspector["login"],
            {"osobaKierujacaUserId": int(other_user["id"]), "teamMemberUserIds": [int(inspector["id"])]},
        )
        self.assertEqual(update_forbidden.status_code, 403, update_forbidden.text)
        update_denied_payload = update_forbidden.json().get("detail") or {}
        self.assertEqual(update_denied_payload.get("code"), "INSPECTOR_LEADER_MUST_BE_SELF")
        self.assertEqual(int(update_denied_payload.get("requiredLeaderUserId")), int(inspector["id"]))

        update_ok = self._update_inspection_with_lock(
            inspection_id,
            inspector["login"],
            {"komentarz": "inspector-update-ok"},
        )
        self.assertEqual(update_ok.status_code, 200, update_ok.text)

    def test_active_inspector_diu_team_member_can_save_when_leader_is_unchanged(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department_ogolne', 'Departament ogolne', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje
                (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department_ogolne', 'DIU', 'DIU', 'DIU', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO teams (kod, nazwa)
                VALUES ('A', 'Zespol A')
                """
            )
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        leader = self._create_user(role_id=1, team_id=team_a)

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INSP-MEMBER-SAVE-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-07-05",
                "koniecInspekcji": "2026-07-06",
                "osobaKierujacaUserId": int(leader["id"]),
                "teamMemberUserIds": [int(leader["id"]), int(inspector["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])

        updated = self._update_inspection_with_lock(
            inspection_id,
            inspector["login"],
            {
                "komentarz": "member-save-ok",
                "osobaKierujacaUserId": int(leader["id"]),
            },
        )
        self.assertEqual(updated.status_code, 200, updated.text)

    def test_people_options_inspector_self_only_and_account_type(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        other_user = self._create_user(role_id=1, team_id=team_a)

        options_response = self.client.get(
            "/api/inspections/people-options",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(options_response.status_code, 200, options_response.text)
        options = options_response.json()

        self_entry = next((item for item in options if int(item["id"]) == int(inspector["id"])), None)
        self.assertIsNotNone(self_entry)
        assert self_entry is not None
        self.assertTrue(bool(self_entry["canBeLeader"]))
        self.assertIn("accountType", self_entry)

        other_entry = next((item for item in options if int(item["id"]) == int(other_user["id"])), None)
        self.assertIsNotNone(other_entry)
        assert other_entry is not None
        self.assertFalse(bool(other_entry["canBeLeader"]))
        self.assertIn("accountType", other_entry)

    def test_team_lead_can_create_recommendation_and_sanction_for_own_created_users_scope(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)

        own_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Scope",
                "nazwisko": "OwnTechnical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(own_technical.status_code, 200, own_technical.text)
        own_technical_id = int(own_technical.json()["id"])

        foreign_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Scope",
                "nazwisko": "ForeignTechnical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_b["login"]),
        )
        self.assertEqual(foreign_technical.status_code, 200, foreign_technical.text)
        foreign_technical_id = int(foreign_technical.json()["id"])

        own_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-REC-RISK-OWN-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-02",
                "osobaKierujacaUserId": own_technical_id,
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(own_inspection.status_code, 201, own_inspection.text)
        own_inspection_id = int(own_inspection.json()["id"])

        foreign_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"TL-REC-RISK-FOREIGN-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-08-03",
                "koniecInspekcji": "2026-08-04",
                "osobaKierujacaUserId": foreign_technical_id,
                "teamMemberUserIds": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(foreign_inspection.status_code, 201, foreign_inspection.text)
        foreign_inspection_id = int(foreign_inspection.json()["id"])

        rec_allowed = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": own_inspection_id,
                "pozycja": 1,
                "status": "Nowe",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(rec_allowed.status_code, 201, rec_allowed.text)

        rec_forbidden = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": foreign_inspection_id,
                "pozycja": 1,
                "status": "Nowe",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(rec_forbidden.status_code, 403, rec_forbidden.text)

        risk_allowed = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": own_inspection_id,
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(risk_allowed.status_code, 201, risk_allowed.text)

        risk_forbidden = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": foreign_inspection_id,
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(risk_forbidden.status_code, 403, risk_forbidden.text)

    def test_hidden_user_can_be_leader_but_cannot_be_team_member(self) -> None:
        team_a = self._team_id("A")
        creator = self._create_user(role_id=2, team_id=team_a)
        hidden_leader = self._create_user(role_id=1, team_id=team_a)

        hide_user = self.client.put(
            f"/api/admin/users/{int(hidden_leader['id'])}",
            json={"listVisibility": "hidden"},
            headers=self._admin_headers(),
        )
        self.assertEqual(hide_user.status_code, 200, hide_user.text)

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"HIDDEN-LEAD-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-11",
                "osobaKierujacaUserId": int(hidden_leader["id"]),
                "teamMemberUserIds": [int(creator["id"])],
            },
            headers=self._operator_headers(str(creator["login"])),
        )
        self.assertEqual(created.status_code, 403, created.text)
        created_detail = created.json().get("detail") or {}
        self.assertEqual(created_detail.get("code"), "USER_HIDDEN_NOT_ALLOWED")

        rejected = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"HIDDEN-MEMBER-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-12",
                "koniecInspekcji": "2026-01-13",
                "osobaKierujacaUserId": int(creator["id"]),
                "teamMemberUserIds": [int(creator["id"]), int(hidden_leader["id"])],
            },
            headers=self._operator_headers(str(creator["login"])),
        )
        self.assertEqual(rejected.status_code, 422, rejected.text)
        self.assertIn("listVisibility=hidden", str(rejected.json().get("detail")))

    def test_inactive_visible_user_can_be_leader_and_team_member_in_inspection(self) -> None:
        team_a = self._team_id("A")
        creator = self._create_user(role_id=2, team_id=team_a)
        inactive_visible = self._create_user(role_id=1, team_id=team_a)

        deactivate = self.client.put(
            f"/api/admin/users/{int(inactive_visible['id'])}",
            json={"aktywny": False, "email": None, "login": "", "listVisibility": "visible"},
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate.status_code, 200, deactivate.text)

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"INACTIVE-VISIBLE-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-11",
                "osobaKierujacaUserId": int(inactive_visible["id"]),
                "teamMemberUserIds": [int(creator["id"]), int(inactive_visible["id"])],
            },
            headers=self._operator_headers(str(creator["login"])),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        self.assertEqual(int(created_body["osobaKierujacaUserId"]), int(inactive_visible["id"]))
        self.assertIn(int(inactive_visible["id"]), [int(x) for x in created_body["teamMemberUserIds"]])

    def test_member_out_of_scope_can_be_saved_when_visible(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        leader_in_scope = self._create_user(role_id=1, team_id=team_a)
        member_out_of_scope = self._create_user(role_id=1, team_id=team_b)

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"MEMBER-OOS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-15",
                "koniecInspekcji": "2026-01-16",
                "osobaKierujacaUserId": int(leader_in_scope["id"]),
                "teamMemberUserIds": [int(lead_a["id"]), int(member_out_of_scope["id"])],
            },
            headers=self._operator_headers(str(lead_a["login"])),
        )
        self.assertEqual(created.status_code, 201, created.text)

    def test_hidden_user_disappears_from_people_dictionaries_and_decision_people_options(self) -> None:
        team_a = self._team_id("A")
        visible_user = self._create_user(role_id=1, team_id=team_a)
        hidden_user = self._create_user(role_id=1, team_id=team_a)

        visible_person_id = self._ensure_person_slownik_id(visible_user)
        hidden_person_id = self._ensure_person_slownik_id(hidden_user)

        hide_user = self.client.put(
            f"/api/admin/users/{int(hidden_user['id'])}",
            json={"listVisibility": "hidden"},
            headers=self._admin_headers(),
        )
        self.assertEqual(hide_user.status_code, 200, hide_user.text)

        osoby = self.client.get(
            "/api/slowniki/pozycje",
            params={"kodTypu": "osoby"},
            headers=self._admin_headers(),
        )
        self.assertEqual(osoby.status_code, 200, osoby.text)
        osoby_ids = {int(item["id"]) for item in osoby.json()}
        self.assertIn(visible_person_id, osoby_ids)
        self.assertNotIn(hidden_person_id, osoby_ids)

        first_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(first_people.status_code, 200, first_people.text)
        first_user_ids = {int(item["userId"]) for item in first_people.json()["items"]}
        self.assertIn(int(visible_user["id"]), first_user_ids)
        self.assertNotIn(int(hidden_user["id"]), first_user_ids)

        second_people = self.client.get(
            "/api/obligating-decisions/available-second-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(second_people.status_code, 200, second_people.text)
        second_user_ids = {int(item["userId"]) for item in second_people.json()["items"]}
        self.assertIn(int(visible_user["id"]), second_user_ids)
        self.assertNotIn(int(hidden_user["id"]), second_user_ids)

    def test_inactive_visible_user_is_available_in_obligating_decision_people_options(self) -> None:
        team_a = self._team_id("A")
        inactive_visible = self._create_user(role_id=1, team_id=team_a)

        deactivate = self.client.put(
            f"/api/admin/users/{int(inactive_visible['id'])}",
            json={"aktywny": False, "email": None, "login": ""},
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate.status_code, 200, deactivate.text)

        self._ensure_person_slownik_id(inactive_visible)

        first_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(first_people.status_code, 200, first_people.text)
        first_user_ids = {int(item["userId"]) for item in first_people.json()["items"]}
        self.assertIn(int(inactive_visible["id"]), first_user_ids)

    def test_visible_user_without_person_dictionary_entry_is_listed_in_decision_people_options(self) -> None:
        team_a = self._team_id("A")
        visible_user = self._create_user(role_id=1, team_id=team_a)

        first_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(first_people.status_code, 200, first_people.text)
        items = first_people.json()["items"]
        target = next((item for item in items if int(item["userId"]) == int(visible_user["id"])), None)
        self.assertIsNotNone(target)
        assert target is not None
        self.assertIsInstance(target["id"], int)
        self.assertGreater(int(target["id"]), 0)
        self.assertEqual(target["listVisibility"], "visible")

    def test_director_people_options_include_visible_users_across_teams_technical_and_observer(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        visible_team_a = self._create_user(role_id=1, team_id=team_a)
        visible_team_b = self._create_user(role_id=1, team_id=team_b)

        set_observer = self.client.put(
            f"/api/admin/users/{int(visible_team_b['id'])}",
            json={"accountType": "observer"},
            headers=self._admin_headers(),
        )
        self.assertEqual(set_observer.status_code, 200, set_observer.text)

        create_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Visible",
                "nazwisko": "Technical",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_technical.status_code, 200, create_technical.text)
        visible_technical = create_technical.json()

        people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(people.status_code, 200, people.text)
        items = people.json()["items"]

        by_user_id = {int(item["userId"]): item for item in items}
        self.assertIn(int(visible_team_a["id"]), by_user_id)
        self.assertIn(int(visible_team_b["id"]), by_user_id)
        self.assertIn(int(visible_technical["id"]), by_user_id)

        observer_entry = by_user_id[int(visible_team_b["id"])]
        self.assertEqual(observer_entry["accountType"], "observer")
        self.assertEqual(observer_entry["listVisibility"], "visible")

        technical_entry = by_user_id[int(visible_technical["id"])]
        self.assertEqual(technical_entry["accountType"], "technical")
        self.assertEqual(technical_entry["listVisibility"], "visible")

    def test_obligating_decision_people_options_team_lead_scope_and_stable_contract(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        in_team_user = self._create_user(role_id=1, team_id=team_a)
        foreign_user = self._create_user(role_id=1, team_id=team_b)

        create_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Lead",
                "nazwisko": "CreatedOutsideTeam",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_technical.status_code, 200, create_technical.text)
        created_outside_user = create_technical.json()

        self._ensure_person_slownik_id(in_team_user)
        self._ensure_person_slownik_id(foreign_user)
        self._ensure_person_slownik_id(created_outside_user)

        first_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(first_people.status_code, 200, first_people.text)
        first_items = first_people.json()["items"]
        first_user_ids = {int(item["userId"]) for item in first_items}

        self.assertIn(int(in_team_user["id"]), first_user_ids)
        self.assertIn(int(created_outside_user["id"]), first_user_ids)
        self.assertIn(int(foreign_user["id"]), first_user_ids)

        sample = first_items[0]
        self.assertIn("id", sample)
        self.assertIn("displayName", sample)
        self.assertIn("label", sample)
        self.assertIn("accountType", sample)
        self.assertIn("listVisibility", sample)
        self.assertIn("createdByOperator", sample)
        self.assertIn("creatorLogin", sample)
        self.assertTrue(all(item.get("id") is not None for item in first_items))

        second_people = self.client.get(
            "/api/obligating-decisions/available-second-instance-people",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(second_people.status_code, 200, second_people.text)
        second_user_ids = {int(item["userId"]) for item in second_people.json()["items"]}
        self.assertEqual(second_user_ids, first_user_ids)

    def test_unlinked_recommendation_author_gets_full_first_instance_people_scope_on_create(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department_ogolne', 'Departament ogolne', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('osoby', 'Osoby', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje
                (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department_ogolne', 'DIU', 'DIU', 'DIU', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO teams (kod, nazwa)
                VALUES ('A', 'Zespol A')
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO teams (kod, nazwa)
                VALUES ('B', 'Zespol B')
                """
            )

        team_a = self._team_id("A")
        team_b = self._team_id("B")
        author = self._create_user(role_id=1, team_id=team_a)
        foreign_user = self._create_user(role_id=1, team_id=team_b)

        author_person_id = self._ensure_person_slownik_id(author)
        foreign_person_id = self._ensure_person_slownik_id(foreign_user)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-UNLINK-AUTHOR-{uuid.uuid4().hex[:6]}",
            },
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        default_scope = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(default_scope.status_code, 200, default_scope.text)
        default_ids = {int(item["id"]) for item in default_scope.json()["items"]}
        self.assertIn(author_person_id, default_ids)
        self.assertNotIn(foreign_person_id, default_ids)

        recommendation_scope = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            params={"recommendationKodZalecenia": recommendation_code},
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(recommendation_scope.status_code, 200, recommendation_scope.text)
        recommendation_ids = {int(item["id"]) for item in recommendation_scope.json()["items"]}
        self.assertIn(author_person_id, recommendation_ids)
        self.assertIn(foreign_person_id, recommendation_ids)

        created_decision = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [foreign_person_id],
            },
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(created_decision.status_code, 201, created_decision.text)

    def test_obligating_decision_save_hidden_rejected_and_inactive_visible_allowed(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])
        team_a = self._team_id("A")

        inactive_visible = self._create_user(role_id=1, team_id=team_a)
        hidden_user = self._create_user(role_id=1, team_id=team_a)

        inactive_visible_slownik_id = self._ensure_person_slownik_id(inactive_visible)
        hidden_user_slownik_id = self._ensure_person_slownik_id(hidden_user)

        deactivate = self.client.put(
            f"/api/admin/users/{int(inactive_visible['id'])}",
            json={"aktywny": False, "email": None, "login": ""},
            headers=self._admin_headers(),
        )
        self.assertEqual(deactivate.status_code, 200, deactivate.text)

        hide_user = self.client.put(
            f"/api/admin/users/{int(hidden_user['id'])}",
            json={"listVisibility": "hidden"},
            headers=self._admin_headers(),
        )
        self.assertEqual(hide_user.status_code, 200, hide_user.text)

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-HIDDEN-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-10",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-08-31",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        hidden_rejected = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": f"Podmiot H {uuid.uuid4().hex[:4]}",
                "osobyProwadzaceIInstancjeIds": [hidden_user_slownik_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(hidden_rejected.status_code, 422, hidden_rejected.text)
        hidden_detail = hidden_rejected.json().get("detail") or {}
        self.assertEqual(hidden_detail.get("code"), "USER_HIDDEN_NOT_ALLOWED")

        inactive_allowed = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": f"Podmiot I {uuid.uuid4().hex[:4]}",
                "osobyProwadzaceIInstancjeIds": [inactive_visible_slownik_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inactive_allowed.status_code, 201, inactive_allowed.text)

    def test_obligating_decision_save_out_of_scope_person_is_rejected(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        foreign_user = self._create_user(role_id=1, team_id=team_b)
        foreign_person_id = self._ensure_person_slownik_id(foreign_user)

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-OOS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-10",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-08-31",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": f"Podmiot OOS {uuid.uuid4().hex[:4]}",
                "osobyProwadzaceIInstancjeIds": [foreign_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(created.status_code, 201, created.text)
        decision_id = int(created.json()["id"])

        detail_before_update = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(detail_before_update.status_code, 200, detail_before_update.text)

        lock_acquire = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        local_user = self._create_user(role_id=1, team_id=team_a)
        local_person_id = self._ensure_person_slownik_id(local_user)

        rejected_update = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": detail_before_update.json()["zaktualizowanoO"],
                "osobyProwadzaceIInstancjeIds": [local_person_id, foreign_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(rejected_update.status_code, 403, rejected_update.text)
        rejected_detail = rejected_update.json().get("detail") or {}
        self.assertEqual(rejected_detail.get("code"), "LEADER_OUT_OF_SCOPE")

    def test_team_lead_can_create_with_foreign_second_instance_people_in_add_flow(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        foreign_user = self._create_user(role_id=1, team_id=team_b)
        foreign_person_id = self._ensure_person_slownik_id(foreign_user)

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-II-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-10",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-08-31",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": f"Podmiot II {uuid.uuid4().hex[:4]}",
                "osobyProwadzaceIInstancjeIds": [foreign_person_id],
                "dataWplywuWnioskuPonowneRozpatrzenie": "2026-09-01",
                "osobyProwadzaceIIInstancjeIds": [foreign_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(created.status_code, 201, created.text)

    def test_create_inspection_inspector_diu_self_only_leader_contract(self) -> None:
        team_a = self._team_id("A")
        creator = self._create_user(role_id=1, team_id=team_a)
        other_user = self._create_user(role_id=1, team_id=team_a)

        denied = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AUTH-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-11",
                "osobaKierujacaUserId": int(other_user["id"]),
                "teamMemberUserIds": [int(other_user["id"])],
            },
            headers=self._operator_headers(str(creator["login"])),
        )
        self.assertEqual(denied.status_code, 403, denied.text)
        denied_payload = denied.json().get("detail") or {}
        self.assertEqual(denied_payload.get("code"), "INSPECTOR_LEADER_MUST_BE_SELF")
        self.assertEqual(int(denied_payload.get("requiredLeaderUserId")), int(creator["id"]))

        allowed = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AUTH-OK-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-01-10",
                "koniecInspekcji": "2026-01-11",
                "osobaKierujacaUserId": int(creator["id"]),
                "teamMemberUserIds": [],
            },
            headers=self._operator_headers(str(creator["login"])),
        )
        self.assertEqual(allowed.status_code, 201, allowed.text)

    def test_slowniki_update_pozycja(self) -> None:
        create_resp = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "nazwaPozycji": "Przed update auto",
                "skrotPozycji": "PRZ",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_resp.status_code, 200, create_resp.text)
        created = create_resp.json()
        code = created["kodPozycji"]
        self.assertTrue(bool(code))

        create_second = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "nazwaPozycji": "Przed update auto",
                "skrotPozycji": "PR2",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_second.status_code, 200, create_second.text)
        second_body = create_second.json()
        self.assertNotEqual(second_body["kodPozycji"], code)

        conflict = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "kodPozycji": code,
                "nazwaPozycji": "Jawny konflikt",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(conflict.status_code, 409)

        update_resp = self.client.put(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "kodPozycji": code,
                "nazwaPozycji": "Po update",
                "skrotPozycji": "UPD",
                "aktywny": False,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(update_resp.status_code, 200, update_resp.text)
        body = update_resp.json()
        self.assertEqual(body["kodPozycji"], code)
        self.assertEqual(body["nazwaPozycji"], "Po update")
        self.assertEqual(body["skrotPozycji"], "UPD")
        self.assertFalse(bool(body["aktywny"]))

        update_by_id_resp = self.client.put(
            f"/api/slowniki/pozycje/{int(created['id'])}",
            json={
                "nazwaPozycji": "Po update id",
                "skrotPozycji": "UID",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(update_by_id_resp.status_code, 200, update_by_id_resp.text)
        by_id_body = update_by_id_resp.json()
        self.assertEqual(by_id_body["id"], created["id"])
        self.assertEqual(by_id_body["kodPozycji"], code)
        self.assertEqual(by_id_body["nazwaPozycji"], "Po update id")
        self.assertTrue(bool(by_id_body["aktywny"]))

        not_found = self.client.put(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "kodPozycji": f"MISS_{uuid.uuid4().hex[:4]}".upper(),
                "nazwaPozycji": "Brak",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(not_found.status_code, 404)

        by_id_not_found = self.client.put(
            "/api/slowniki/pozycje/999999",
            json={
                "nazwaPozycji": "Brak",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(by_id_not_found.status_code, 404)

        unauthorized = self.client.put(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "kodPozycji": code,
                "nazwaPozycji": "NoAuth",
                "aktywny": True,
            },
            headers={"X-Operator-Login": "ghost"},
        )
        self.assertEqual(unauthorized.status_code, 401)

    def test_slowniki_sanction_decision_alias_endpoints(self) -> None:
        first = self.client.get(
            "/api/slowniki/wnioski-sankcyjne/rozstrzygniecie-i",
        )
        self.assertEqual(first.status_code, 200, first.text)
        first_items = first.json()
        self.assertTrue(any(item["kodTypu"] == "rozstrzygniecie_wniosku_sankcyjnego_I" for item in first_items))

        removed_alias = self.client.get(
            "/api/slowniki/wnioski-sankcyjne/rozstrzygniecie-ii",
        )
        self.assertEqual(removed_alias.status_code, 404, removed_alias.text)

        second = self.client.get("/api/slowniki/typy")
        self.assertEqual(second.status_code, 200, second.text)
        type_codes = {item["kodTypu"] for item in second.json()}
        self.assertNotIn("rozstrzygniecie_wniosku_sankcyjnego_II", type_codes)

    def test_slowniki_inspector_read_and_write_denied_with_effective_permissions(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)

        read_response = self.client.get(
            "/api/slowniki/typy",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(read_response.status_code, 200, read_response.text)
        self.assertTrue(isinstance(read_response.json(), list))

        write_response = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "department_ogolne",
                "nazwaPozycji": f"TEST-INSPECTOR-{uuid.uuid4().hex[:6]}",
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(write_response.status_code, 403, write_response.text)

        login_response = self.client.post(
            "/api/auth/login",
            json={"login": inspector["login"]},
        )
        self.assertEqual(login_response.status_code, 200, login_response.text)
        effective_permissions = login_response.json()["user"]["effectivePermissions"]
        self.assertIn("management.dictionaries.read", effective_permissions)
        self.assertNotIn("management.dictionaries.write", effective_permissions)

    def test_slowniki_zakresy_inspekcji_nazwa_uzytkowa_contract(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('zakresy_inspekcji', 'Zakresy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )

        created = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "zakresy_inspekcji",
                "nazwaPozycji": "Zakres testowy kontrakt",
                "nazwaUzytkowa": "Zakres testowy UI",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 200, created.text)
        created_body = created.json()
        self.assertEqual(created_body["nazwaUzytkowa"], "Zakres testowy UI")

        updated = self.client.put(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "zakresy_inspekcji",
                "kodPozycji": created_body["kodPozycji"],
                "nazwaPozycji": "Zakres testowy kontrakt 2",
                "nazwaUzytkowa": "Zakres testowy UI 2",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertEqual(updated_body["nazwaUzytkowa"], "Zakres testowy UI 2")

        updated_by_id = self.client.put(
            f"/api/slowniki/pozycje/{int(created_body['id'])}",
            json={
                "nazwaPozycji": "Zakres testowy kontrakt 3",
                "nazwaUzytkowa": "Zakres testowy UI 3",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(updated_by_id.status_code, 200, updated_by_id.text)
        updated_by_id_body = updated_by_id.json()
        self.assertEqual(updated_by_id_body["nazwaUzytkowa"], "Zakres testowy UI 3")

        listed = self.client.get(
            "/api/slowniki/pozycje",
            params={"kodTypu": "zakresy_inspekcji"},
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_items = listed.json()
        selected = next((item for item in listed_items if int(item["id"]) == int(created_body["id"])), None)
        self.assertIsNotNone(selected)
        assert selected is not None
        self.assertEqual(selected["nazwaUzytkowa"], "Zakres testowy UI 3")

        non_scope = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "typy_inspekcji",
                "nazwaPozycji": "Kontrola",
                "nazwaUzytkowa": "To ma byc ignorowane",
                "aktywny": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(non_scope.status_code, 200, non_scope.text)
        non_scope_body = non_scope.json()
        self.assertIsNone(non_scope_body["nazwaUzytkowa"])

    def test_recommendations_crud_and_filters(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"REC-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-05",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Zaklad testowy",
                "terminWykonaniaZalecen": "2026-11-30",
                "status": "W toku",
                "komentarz": "Opis",
                "dataZalecenList": ["2026-11-10", "2026-11-12"],
                "dataAkceptacjiNotyWeryfikacjiList": ["2026-11-20"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        recommendation_id = int(created_body["id"])
        self.assertEqual(created_body["inspectionId"], inspection_id)
        self.assertRegex(str(created_body["kodZalecenia"]), r"^Z/2026/\d+$")
        self.assertEqual(created_body["pozycja"], 1)
        self.assertEqual(created_body["dataZalecenList"], ["2026-11-10", "2026-11-12"])
        self.assertEqual(created_body["dataAkceptacjiNotyWeryfikacjiList"], ["2026-11-20"])

        duplicate = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Drugi",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(duplicate.status_code, 201, duplicate.text)
        duplicate_body = duplicate.json()
        self.assertEqual(duplicate_body["inspectionId"], inspection_id)
        self.assertEqual(duplicate_body["pozycja"], 1)
        self.assertNotEqual(duplicate_body["id"], recommendation_id)
        self.assertNotEqual(duplicate_body["kodZalecenia"], created_body["kodZalecenia"])

        listed = self.client.get(
            "/api/recommendations",
            params={
                "inspectionId": inspection_id,
                "status": "w toku",
                "sortBy": "pozycja",
                "sortOrder": "asc",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_body = listed.json()
        self.assertGreaterEqual(int(listed_body["total"]), 1)

        detail = self.client.get(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertEqual(detail.json()["kodZalecenia"], created_body["kodZalecenia"])

        updated = self._update_recommendation_with_lock(
            recommendation_id,
            "admin",
            {
                "status": "Zamkniete",
                "pozycja": 2,
                "dataZalecenList": ["2026-11-15"],
                "dataAkceptacjiNotyWeryfikacjiList": ["2026-11-25", "2026-11-26"],
            },
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertEqual(updated_body["pozycja"], 2)
        self.assertEqual(updated_body["status"], "Zamkniete")
        self.assertEqual(updated_body["dataZalecenList"], ["2026-11-15"])
        self.assertEqual(updated_body["dataAkceptacjiNotyWeryfikacjiList"], ["2026-11-25", "2026-11-26"])

        deleted = self.client.delete(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)
        self.assertTrue(bool(deleted.json()["ok"]))

        missing = self.client.get(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(missing.status_code, 404)

    def test_recommendations_without_inspection_id(self) -> None:
        create_without_inspection = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot bez LP",
                "status": "Nowe",
                "dataZalecenList": ["2026-12-01"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(create_without_inspection.status_code, 201, create_without_inspection.text)
        created = create_without_inspection.json()
        self.assertIsNone(created["inspectionId"])
        self.assertEqual(created["nazwaPodmiotu"], "Podmiot bez LP")

        detail = self.client.get(
            f"/api/recommendations/{int(created['id'])}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertIsNone(detail.json()["inspectionId"])

        update = self._update_recommendation_with_lock(
            int(created["id"]),
            "admin",
            {"inspectionId": None, "nazwaPodmiotu": "Podmiot bez LP 2"},
        )
        self.assertEqual(update.status_code, 200, update.text)
        self.assertIsNone(update.json()["inspectionId"])
        self.assertEqual(update.json()["nazwaPodmiotu"], "Podmiot bez LP 2")

        missing_name = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 2,
                "status": "Nowe",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(missing_name.status_code, 400)

    def test_recommendations_without_inspection_id_rbac_author_manager_director(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        author = self._create_user(role_id=1, team_id=team_a)
        manager_same_team = self._create_user(role_id=2, team_id=team_a)
        manager_other_team = self._create_user(role_id=2, team_id=team_b)
        other_user = self._create_user(role_id=1, team_id=team_b)

        created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"Bez INS {uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(created.status_code, 201, created.text)
        recommendation_id = int(created.json()["id"])

        detail_author = self.client.get(
            f"/api/recommendations/{recommendation_id}",
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(detail_author.status_code, 200, detail_author.text)
        self.assertTrue(bool(detail_author.json()["canEdit"]))

        updated_by_author = self._update_recommendation_with_lock(
            recommendation_id,
            str(author["login"]),
            {"komentarz": "author-update"},
        )
        self.assertEqual(updated_by_author.status_code, 200, updated_by_author.text)

        updated_by_manager_same_team = self._update_recommendation_with_lock(
            recommendation_id,
            str(manager_same_team["login"]),
            {"komentarz": "manager-update"},
        )
        self.assertEqual(updated_by_manager_same_team.status_code, 200, updated_by_manager_same_team.text)

        forbidden_manager_other_team = self.client.put(
            f"/api/recommendations/{recommendation_id}",
            json={"komentarz": "forbidden-manager"},
            headers=self._operator_headers(manager_other_team["login"]),
        )
        self.assertEqual(forbidden_manager_other_team.status_code, 403)

        forbidden_other_user = self.client.put(
            f"/api/recommendations/{recommendation_id}",
            json={"komentarz": "forbidden-user"},
            headers=self._operator_headers(other_user["login"]),
        )
        self.assertEqual(forbidden_other_user.status_code, 403)

        updated_by_director = self._update_recommendation_with_lock(
            recommendation_id,
            "admin",
            {"komentarz": "director-update"},
        )
        self.assertEqual(updated_by_director.status_code, 200, updated_by_director.text)

    def test_recommendations_allows_duplicate_position_per_inspection(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"REC-DUP-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-01",
                "koniecInspekcji": "2026-12-10",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        first = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "Nowe",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(first.status_code, 201, first.text)
        first_body = first.json()

        second = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "status": "W toku",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(second.status_code, 201, second.text)
        second_body = second.json()

        self.assertEqual(first_body["inspectionId"], inspection_id)
        self.assertEqual(second_body["inspectionId"], inspection_id)
        self.assertEqual(first_body["pozycja"], 1)
        self.assertEqual(second_body["pozycja"], 1)
        self.assertNotEqual(int(first_body["id"]), int(second_body["id"]))
        self.assertNotEqual(str(first_body["kodZalecenia"]), str(second_body["kodZalecenia"]))

    def test_recommendations_return_short_and_full_names(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('statusy_zalecen', 'Statusy zalecen', 1, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow', 'PODMIOT_SKROT_TEST', 'General Inspection Sp. z o.o.', 'General Inspection', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('statusy_zalecen', 'STATUS_SKROT_TEST', 'W trakcie realizacji', 'W trakcie', 1, 1)
                """
            )
            conn.commit()

        created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": "General Inspection Sp. z o.o.",
                "status": "W trakcie realizacji",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        recommendation_id = int(created_body["id"])

        self.assertEqual(created_body["nazwaPodmiotuSkrocona"], "General Inspection")
        self.assertEqual(created_body["nazwaPodmiotuSkrot"], "General Inspection")
        self.assertEqual(created_body["statusSkrocona"], "W trakcie")
        self.assertEqual(created_body["statusSkrot"], "W trakcie")

        listed = self.client.get(
            "/api/recommendations",
            headers=self._admin_headers(),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_item = next(item for item in listed.json()["items"] if int(item["id"]) == recommendation_id)

        self.assertIn("nazwaPodmiotuSkrocona", listed_item)
        self.assertIn("nazwaPodmiotuSkrot", listed_item)
        self.assertIn("statusSkrocona", listed_item)
        self.assertIn("statusSkrot", listed_item)
        self.assertEqual(listed_item["nazwaPodmiotuSkrocona"], "General Inspection")
        self.assertEqual(listed_item["statusSkrocona"], "W trakcie")

        detail = self.client.get(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        detail_body = detail.json()
        self.assertEqual(detail_body["nazwaPodmiotuSkrocona"], "General Inspection")
        self.assertEqual(detail_body["statusSkrocona"], "W trakcie")

        updated = self._update_recommendation_with_lock(
            recommendation_id,
            "admin",
            {"komentarz": "aktualizacja"},
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertIn("nazwaPodmiotuSkrocona", updated_body)
        self.assertIn("statusSkrocona", updated_body)

    def test_risk_exposure_crud_and_rbac(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        inspector = self._create_user(role_id=1, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_d = self._create_user(role_id=2, team_id=team_d)

        ins_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX-A-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-01",
                "koniecInspekcji": "2026-12-05",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(inspector["id"]), int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_a_resp.status_code, 201, ins_a_resp.text)
        inspection_a_id = int(ins_a_resp.json()["id"])

        ins_d_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX-D-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-10",
                "koniecInspekcji": "2026-12-15",
                "osobaKierujacaUserId": int(lead_d["id"]),
                "teamMemberUserIds": [int(lead_d["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_d_resp.status_code, 201, ins_d_resp.text)
        inspection_d_id = int(ins_d_resp.json()["id"])

        available_user = self.client.get(
            "/api/sanction-requests/available-inspections",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(available_user.status_code, 200, available_user.text)
        user_ids = {int(item["id"]) for item in available_user.json()}
        self.assertIn(inspection_a_id, user_ids)
        self.assertNotIn(inspection_d_id, user_ids)

        create_allowed = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": inspection_a_id,
                "nazwaPodmiotuObjetegoSankcjaList": ["Podmiot Sankcja A", "Podmiot Sankcja A"],
                "dataWniosku": "2026-12-20",
                "sankcjaList": ["Kara pieniezna"],
                "podstawaPrawnaSankcjiList": ["Art. 12"],
                "naruszeniaSkutkujaceSankcjaList": ["Brak raportu"],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_allowed.status_code, 201, create_allowed.text)
        created = create_allowed.json()
        risk_exposure_id = int(created["id"])
        self.assertEqual(created["inspectionId"], inspection_a_id)
        self.assertEqual(created["nazwaPodmiotuObjetegoSankcjaList"], ["Podmiot Sankcja A"])
        self.assertEqual(len(created["nazwaPodmiotuObjetegoSankcjaIds"]), 1)
        self.assertEqual(len(created["sankcjaIds"]), 1)
        self.assertEqual(len(created["podstawaPrawnaSankcjiIds"]), 1)
        self.assertEqual(len(created["naruszeniaSkutkujaceSankcjaIds"]), 1)

        create_forbidden = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": inspection_d_id,
                "sankcjaList": ["Zakaz"],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_forbidden.status_code, 403)

        updated = self.client.put(
            f"/api/sanction-requests/{risk_exposure_id}",
            json={
                "sankcjaList": ["Zakaz", "Kara pieniezna"],
                "rozstrzygniecie": "W toku",
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        self.assertEqual(updated.json()["sankcjaList"], ["Kara pieniezna", "Zakaz"])
        self.assertEqual(len(updated.json()["sankcjaIds"]), 2)

        listed = self.client.get(
            "/api/sanction-requests",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_item = next(item for item in listed.json()["items"] if int(item["id"]) == risk_exposure_id)
        self.assertTrue(bool(listed_item["canEdit"]))

        deleted = self.client.delete(
            f"/api/sanction-requests/{risk_exposure_id}",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(deleted.status_code, 403, deleted.text)

        deleted_by_director = self.client.delete(
            f"/api/sanction-requests/{risk_exposure_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted_by_director.status_code, 200, deleted_by_director.text)
        self.assertTrue(bool(deleted_by_director.json()["ok"]))

    def test_sanction_requests_sort_by_lp_is_numeric_and_stable(self) -> None:
        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)

        ins_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX-SORT-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "zakresInspekcji": "RTU",
                "poczatekInspekcji": "2026-12-01",
                "koniecInspekcji": "2026-12-05",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(inspector["id"]), int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_a_resp.status_code, 201, ins_a_resp.text)
        inspection_a_id = int(ins_a_resp.json()["id"])

        create_first = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": inspection_a_id,
                "sankcjaList": ["Kara pieniezna"],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_first.status_code, 201, create_first.text)
        first_lp = int(create_first.json()["lp"])

        create_second = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": inspection_a_id,
                "sankcjaList": ["Kara pieniezna"],
            },
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(create_second.status_code, 201, create_second.text)
        second_lp = int(create_second.json()["lp"])
        self.assertGreater(second_lp, first_lp)

        listed = self.client.get(
            "/api/sanction-requests",
            params={"sortBy": "lp", "sortOrder": "asc"},
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(listed.status_code, 200, listed.text)

        lps = [int(item["lp"]) for item in listed.json()["items"]]
        self.assertEqual(lps, sorted(lps))
        self.assertLess(lps[0], lps[1])

    def test_risk_exposure_available_inspections_and_create_rbac_matrix(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        inspector_a = self._create_user(role_id=1, team_id=team_a)
        member_a = self._create_user(role_id=1, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_d = self._create_user(role_id=2, team_id=team_d)

        ins_lead_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX2-A-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-01",
                "koniecInspekcji": "2026-12-05",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(inspector_a["id"]), int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_lead_a_resp.status_code, 201, ins_lead_a_resp.text)
        ins_lead_a = int(ins_lead_a_resp.json()["id"])

        ins_lead_d_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX2-D-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-10",
                "koniecInspekcji": "2026-12-15",
                "osobaKierujacaUserId": int(lead_d["id"]),
                "teamMemberUserIds": [int(lead_d["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_lead_d_resp.status_code, 201, ins_lead_d_resp.text)
        ins_lead_d = int(ins_lead_d_resp.json()["id"])

        ins_member_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX2-M-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-16",
                "koniecInspekcji": "2026-12-20",
                "osobaKierujacaUserId": int(lead_d["id"]),
                "teamMemberUserIds": [int(member_a["id"]), int(lead_d["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_member_a_resp.status_code, 201, ins_member_a_resp.text)
        ins_member_a = int(ins_member_a_resp.json()["id"])

        ins_created_by_inspector_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"RX2-C-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-12-21",
                "koniecInspekcji": "2026-12-24",
                "osobaKierujacaUserId": int(lead_d["id"]),
                "teamMemberUserIds": [int(lead_d["id"])],
            },
            headers=self._operator_headers(inspector_a["login"]),
        )
        self.assertEqual(ins_created_by_inspector_resp.status_code, 201, ins_created_by_inspector_resp.text)
        ins_created_by_inspector = int(ins_created_by_inspector_resp.json()["id"])

        available_inspector = self.client.get(
            "/api/sanction-requests/available-inspections",
            headers=self._operator_headers(inspector_a["login"]),
        )
        self.assertEqual(available_inspector.status_code, 200, available_inspector.text)
        inspector_ids = {int(item["id"]) for item in available_inspector.json()}
        self.assertIn(ins_lead_a, inspector_ids)
        self.assertIn(ins_created_by_inspector, inspector_ids)
        self.assertNotIn(ins_lead_d, inspector_ids)
        self.assertNotIn(ins_member_a, inspector_ids)

        available_lead_a = self.client.get(
            "/api/sanction-requests/available-inspections",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(available_lead_a.status_code, 200, available_lead_a.text)
        lead_a_ids = {int(item["id"]) for item in available_lead_a.json()}
        self.assertIn(ins_lead_a, lead_a_ids)
        self.assertIn(ins_member_a, lead_a_ids)
        self.assertNotIn(ins_lead_d, lead_a_ids)

        create_allowed_member = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": ins_lead_a,
                "sankcjaList": ["Kara pieniezna"],
            },
            headers=self._operator_headers(inspector_a["login"]),
        )
        self.assertEqual(create_allowed_member.status_code, 201, create_allowed_member.text)

        create_allowed_created_by = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": ins_created_by_inspector,
                "sankcjaList": ["Zakaz"],
            },
            headers=self._operator_headers(inspector_a["login"]),
        )
        self.assertEqual(create_allowed_created_by.status_code, 201, create_allowed_created_by.text)

        create_forbidden_inspector = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": ins_lead_d,
                "sankcjaList": ["Zakaz"],
            },
            headers=self._operator_headers(inspector_a["login"]),
        )
        self.assertEqual(create_forbidden_inspector.status_code, 403)

        create_allowed_manager_by_member = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": ins_member_a,
                "sankcjaList": ["Kara pieniezna"],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_allowed_manager_by_member.status_code, 201, create_allowed_manager_by_member.text)

        create_forbidden_manager = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": ins_lead_d,
                "sankcjaList": ["Zakaz"],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_forbidden_manager.status_code, 403)

    def test_sanction_requests_return_short_and_full_names(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', 'Nazwy podmiotow sankcje', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department', 'Departament', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('sankcja', 'Sankcja', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('podstawa_prawna_sankcji', 'Podstawa prawna sankcji', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('naruszenia_skutkujace_sankcja', 'Naruszenia skutkujace sankcja', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('informacja_o_wszczeciu_postepowania_sankcyjnego', 'Informacja o wszczeciu', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('rozstrzygniecie_wniosku_sankcyjnego_I', 'Rozstrzygniecie wniosku sankcyjnego I', 2, NULL, 1)
                """
            )

            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow', 'RX_PODMIOT', 'Podmiot Objety Inspekcja SA', 'POI SA', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', 'RX_SANK_PODMIOT', 'Podmiot Sankcja SA', 'PS SA', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department', 'RX_DEP', 'Departament Kontroli', 'DK', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('sankcja', 'RX_SAN', 'Kara pieniezna', 'KP', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('podstawa_prawna_sankcji', 'RX_PODST', 'Art. 12', 'A12', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('naruszenia_skutkujace_sankcja', 'RX_NAR', 'Brak raportu', 'BR', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('informacja_o_wszczeciu_postepowania_sankcyjnego', 'RX_WSZ', 'Tak', 'T', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('rozstrzygniecie_wniosku_sankcyjnego_I', 'RX_ROZ', 'W toku', 'WT', 1, 1)
                """
            )
            conn.commit()

        created = self.client.post(
            "/api/sanction-requests",
            json={
                "nazwaPodmiotuObjetegoInspekcja": "Podmiot Objety Inspekcja SA",
                "nazwaPodmiotuObjetegoSankcjaList": ["Podmiot Sankcja SA"],
                "wniosekDo": "Departament Kontroli",
                "sankcjaList": ["Kara pieniezna"],
                "podstawaPrawnaSankcjiList": ["Art. 12"],
                "naruszeniaSkutkujaceSankcjaList": ["Brak raportu"],
                "czyMamyInformacjeOWszczeciuPostepowania": "Tak",
                "rozstrzygniecie": "W toku",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        body = created.json()
        risk_id = int(body["id"])

        self.assertEqual(body["nazwaPodmiotuObjetegoInspekcjaSkrocona"], "POI SA")
        self.assertEqual(body["nazwaPodmiotuObjetegoInspekcjaSkrot"], "POI SA")
        self.assertEqual(body["nazwaPodmiotuObjetegoSankcjaListSkrocona"], ["PS SA"])
        self.assertEqual(body["wniosekDoSkrocona"], "DK")
        self.assertEqual(body["sankcjaListSkrocona"], ["KP"])
        self.assertEqual(body["podstawaPrawnaSankcjiListSkrocona"], ["A12"])
        self.assertEqual(body["naruszeniaSkutkujaceSankcjaListSkrocona"], ["BR"])
        self.assertEqual(body["czyMamyInformacjeOWszczeciuPostepowaniaSkrocona"], "T")
        self.assertEqual(body["rozstrzygniecieSkrocona"], "WT")

        listed = self.client.get("/api/sanction-requests", headers=self._admin_headers())
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_item = next(item for item in listed.json()["items"] if int(item["id"]) == risk_id)
        self.assertIn("nazwaPodmiotuObjetegoInspekcjaSkrocona", listed_item)
        self.assertIn("nazwaPodmiotuObjetegoSankcjaListSkrocona", listed_item)
        self.assertIn("wniosekDoSkrocona", listed_item)
        self.assertIn("sankcjaListSkrocona", listed_item)
        self.assertIn("podstawaPrawnaSankcjiListSkrocona", listed_item)
        self.assertIn("naruszeniaSkutkujaceSankcjaListSkrocona", listed_item)
        self.assertIn("czyMamyInformacjeOWszczeciuPostepowaniaSkrocona", listed_item)
        self.assertIn("rozstrzygniecieSkrocona", listed_item)

        detail = self.client.get(f"/api/sanction-requests/{risk_id}", headers=self._admin_headers())
        self.assertEqual(detail.status_code, 200, detail.text)
        detail_body = detail.json()
        self.assertEqual(detail_body["nazwaPodmiotuObjetegoInspekcjaSkrocona"], "POI SA")
        self.assertEqual(detail_body["rozstrzygniecieSkrocona"], "WT")

        updated = self._update_sanction_with_lock(
            risk_id,
            "admin",
            {"komentarz": "aktualizacja"},
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertIn("nazwaPodmiotuObjetegoInspekcjaSkrocona", updated_body)
        self.assertIn("rozstrzygniecieSkrocona", updated_body)

    def test_sanction_request_entity_options_merge_dedupe_sort_and_pagination(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        subject_name = "Vienna Life Towarzystwo Ubezpieczen na Zycie Spolka Akcyjna Vienna Insurance Group"
        suffix = uuid.uuid4().hex[:8].upper()
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', 'Nazwy podmiotow sankcje', 2, NULL, 1)
                """
            )

            conn.execute(
                """
                INSERT INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow', ?, ?, NULL, 1, 1)
                """,
                (f"INS_{suffix}", subject_name),
            )
            inspection_subject_id = int(conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"])

            dictionary_only_subject_name = "Podmiot tylko ze slownika inspekcji"
            conn.execute(
                """
                INSERT INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow', ?, ?, ?, 2, 1)
                """,
                (f"INS_DICT_ONLY_{suffix}", dictionary_only_subject_name, "PDSI"),
            )

            conn.execute(
                """
                INSERT INTO inspections (
                    lp,
                    created_by_user_id,
                    nazwa_podmiotu_id,
                    poczatek_inspekcji,
                    koniec_inspekcji
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (1, admin_id, inspection_subject_id, "2026-12-01", "2026-12-05"),
            )

            conn.execute(
                """
                INSERT INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', ?, ?, ?, 1, 1)
                """,
                (f"SAN_{suffix}", f"  {subject_name}  ", "Vienna Life TU na Zycie SA VIG"),
            )
            conn.execute(
                """
                INSERT INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', ?, 'PZU SA', 'PZU', 2, 1)
                """,
                (f"PZU_{suffix}",),
            )
            conn.execute(
                """
                INSERT INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow_sankcje', ?, 'Historyczny Podmiot SA', 'HPS', 3, 1)
                """,
                (f"HIST_{suffix}",),
            )
            historical_id = int(conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"])
            conn.commit()

        historical_usage = self.client.post(
            "/api/sanction-requests",
            json={"nazwaPodmiotuObjetegoSankcjaList": ["Historyczny Podmiot SA"]},
            headers=self._admin_headers(),
        )
        self.assertEqual(historical_usage.status_code, 201, historical_usage.text)

        with get_connection() as conn:
            conn.execute(
                "UPDATE slownik_pozycje SET aktywny = 0 WHERE id = ?",
                (historical_id,),
            )
            conn.commit()

        options = self.client.get(
            "/api/sanction-requests/entity-options",
            headers=self._admin_headers(),
        )
        self.assertEqual(options.status_code, 200, options.text)
        items = options.json()
        self.assertGreaterEqual(len(items), 2)

        vienna = next(item for item in items if item["value"] == subject_name)
        self.assertEqual(vienna["source"], "inspections")
        self.assertEqual(vienna["label"], "Vienna Life TU na Zycie SA VIG")
        self.assertTrue(bool(vienna["active"]))

        dictionary_only = next(item for item in items if item["value"] == "Podmiot tylko ze slownika inspekcji")
        self.assertEqual(dictionary_only["source"], "inspections")
        self.assertEqual(dictionary_only["label"], "PDSI")
        self.assertTrue(bool(dictionary_only["active"]))

        historical = next(item for item in items if item["value"] == "Historyczny Podmiot SA")
        self.assertEqual(historical["source"], "historical")
        self.assertFalse(bool(historical["active"]))

        labels = [str(item["label"]) for item in items]
        self.assertEqual(labels, sorted(labels, key=lambda value: (value.casefold(), value)))

        without_history = self.client.get(
            "/api/sanction-requests/entity-options",
            params={"includeHistorical": False},
            headers=self._admin_headers(),
        )
        self.assertEqual(without_history.status_code, 200, without_history.text)
        without_history_values = {item["value"] for item in without_history.json()}
        self.assertNotIn("Historyczny Podmiot SA", without_history_values)

        paged = self.client.get(
            "/api/sanction-requests/entity-options",
            params={"offset": 1, "limit": 2},
            headers=self._admin_headers(),
        )
        self.assertEqual(paged.status_code, 200, paged.text)
        self.assertEqual(paged.json(), items[1:3])

    def test_sanction_request_entity_options_requires_operator(self) -> None:
        unauthorized = self.client.get("/api/sanction-requests/entity-options")
        self.assertEqual(unauthorized.status_code, 401)

    def test_obligating_decisions_crud_with_multi_persons(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])
        team_a = self._team_id("A")

        user_i = self._create_user(role_id=1, team_id=team_a)
        user_ii = self._create_user(role_id=1, team_id=team_a)

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-08-01",
                "koniecInspekcji": "2026-08-10",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-08-31",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        osoba_i_id = self._ensure_person_slownik_id(user_i)
        osoba_ii_id = self._ensure_person_slownik_id(user_ii)

        dec_i = self.client.post(
            "/api/slowniki/pozycje",
            json={"kodTypu": "rozstrzygniecie_decyzji_i", "nazwaPozycji": f"Roz I {uuid.uuid4().hex[:4]}"},
            headers=self._admin_headers(),
        )
        self.assertEqual(dec_i.status_code, 200, dec_i.text)
        dec_i_name = str(dec_i.json()["nazwaPozycji"])

        dec_ii = self.client.post(
            "/api/slowniki/pozycje",
            json={"kodTypu": "rozstrzygniecie_decyzji_ii", "nazwaPozycji": f"Roz II {uuid.uuid4().hex[:4]}"},
            headers=self._admin_headers(),
        )
        self.assertEqual(dec_ii.status_code, 200, dec_ii.text)
        dec_ii_name = str(dec_ii.json()["nazwaPozycji"])

        created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": f"Podmiot D {uuid.uuid4().hex[:4]}",
                "liczbaZalecen": 2,
                "dataWszczeciaPostepowaniaIInstancji": "2026-08-15",
                "osobyProwadzaceIInstancjeIds": [osoba_i_id],
                "dataDecyzjiIInstancji": "2026-08-20",
                "rozstrzygniecieI": dec_i_name,
                "dataWnioskuPonowneRozpatrzenie": "2026-08-25",
                "dataWplywuWnioskuPonowneRozpatrzenie": "2026-08-26",
                "osobyProwadzaceIIInstancjeIds": [osoba_ii_id],
                "dataDecyzjiIIInstancji": "2026-09-01",
                "rozstrzygniecieII": dec_ii_name,
                "komentarz": "Test create",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        decision_id = int(created_body["id"])
        self.assertRegex(str(created_body["kodDecyzji"]), r"^DZ/2026/\d+$")
        self.assertEqual(created_body["recommendationKodZalecenia"], recommendation_code)
        self.assertEqual(created_body["osobyProwadzaceIInstancjeIds"], [osoba_i_id])
        self.assertEqual(created_body["osobyProwadzaceIIInstancjeIds"], [osoba_ii_id])

        detail = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        self.assertEqual(int(detail.json()["id"]), decision_id)

        lock_acquire = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._admin_headers(),
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        updated = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": detail.json()["zaktualizowanoO"],
                "liczbaZalecen": 3,
                "komentarz": "Test update",
                "osobyProwadzaceIInstancjeIds": [osoba_i_id, osoba_ii_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(updated.status_code, 200, updated.text)

        lock_release = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_token},
            headers=self._admin_headers(),
        )
        self.assertEqual(lock_release.status_code, 200, lock_release.text)
        updated_body = updated.json()
        self.assertEqual(updated_body["liczbaZalecen"], 3)
        self.assertEqual(updated_body["komentarz"], "Test update")
        self.assertEqual(updated_body["osobyProwadzaceIInstancjeIds"], sorted([osoba_i_id, osoba_ii_id]))

        listed = self.client.get("/api/obligating-decisions", headers=self._admin_headers())
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_items = listed.json()["items"]
        self.assertTrue(any(int(item["id"]) == decision_id for item in listed_items))

        available_recommendations = self.client.get(
            "/api/obligating-decisions/available-recommendations",
            headers=self._admin_headers(),
        )
        self.assertEqual(available_recommendations.status_code, 200, available_recommendations.text)
        recommendation_codes = {item["kodZalecenia"] for item in available_recommendations.json()}
        self.assertIn(recommendation_code, recommendation_codes)

    def test_obligating_decisions_return_short_and_full_names(self) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('statusy_zalecen', 'Statusy zalecen', 1, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('rozstrzygniecie_decyzji_i', 'Rozstrzygniecie decyzji I', 2, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('rozstrzygniecie_decyzji_ii', 'Rozstrzygniecie decyzji II', 2, NULL, 1)
                """
            )

            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('nazwy_podmiotow', 'DEC_PODMIOT_SHORT', 'Podmiot Decyzji Test Sp. z o.o.', 'PDT', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('statusy_zalecen', 'DEC_STATUS_SHORT', 'W trakcie realizacji', 'W trakcie', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('rozstrzygniecie_decyzji_i', 'DEC_RI_SHORT', 'Rozstrzygniecie I test', 'RI test', 1, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('rozstrzygniecie_decyzji_ii', 'DEC_RII_SHORT', 'Rozstrzygniecie II test', 'RII test', 1, 1)
                """
            )
            conn.commit()

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot Decyzji Test Sp. z o.o.",
                "status": "W trakcie realizacji",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "nazwaPodmiotu": "Podmiot Decyzji Test Sp. z o.o.",
                "rozstrzygniecieI": "Rozstrzygniecie I test",
                "dataWplywuWnioskuPonowneRozpatrzenie": "2026-09-10",
                "rozstrzygniecieII": "Rozstrzygniecie II test",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        decision_id = int(created_body["id"])

        self.assertEqual(created_body["nazwaPodmiotuSkrocona"], "PDT")
        self.assertEqual(created_body["nazwaPodmiotuSkrot"], "PDT")
        self.assertEqual(created_body["rozstrzygniecieISkrocona"], "RI test")
        self.assertEqual(created_body["rozstrzygniecieISkrot"], "RI test")
        self.assertEqual(created_body["rozstrzygniecieIISkrocona"], "RII test")
        self.assertEqual(created_body["rozstrzygniecieIISkrot"], "RII test")

        listed = self.client.get(
            "/api/obligating-decisions",
            headers=self._admin_headers(),
        )
        self.assertEqual(listed.status_code, 200, listed.text)
        listed_item = next(item for item in listed.json()["items"] if int(item["id"]) == decision_id)
        self.assertIn("nazwaPodmiotuSkrocona", listed_item)
        self.assertIn("nazwaPodmiotuSkrot", listed_item)
        self.assertIn("rozstrzygniecieISkrocona", listed_item)
        self.assertIn("rozstrzygniecieISkrot", listed_item)
        self.assertIn("rozstrzygniecieIISkrocona", listed_item)
        self.assertIn("rozstrzygniecieIISkrot", listed_item)

        detail = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(detail.status_code, 200, detail.text)
        detail_body = detail.json()
        self.assertEqual(detail_body["nazwaPodmiotuSkrocona"], "PDT")
        self.assertEqual(detail_body["rozstrzygniecieISkrocona"], "RI test")
        self.assertEqual(detail_body["rozstrzygniecieIISkrocona"], "RII test")

        updated = self._update_decision_with_lock(
            decision_id,
            "admin",
            {"komentarz": "aktualizacja"},
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertIn("nazwaPodmiotuSkrocona", updated_body)
        self.assertIn("rozstrzygniecieISkrocona", updated_body)
        self.assertIn("rozstrzygniecieIISkrocona", updated_body)

    def test_obligating_decision_rbac_for_unlinked_recommendation_author_manager_director(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        author = self._create_user(role_id=1, team_id=team_a)
        manager_same_team = self._create_user(role_id=2, team_id=team_a)
        manager_other_team = self._create_user(role_id=2, team_id=team_b)
        other_user = self._create_user(role_id=1, team_id=team_b)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-RBAC-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": recommendation_code},
            headers=self._operator_headers(author["login"]),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        detail_manager = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager_same_team["login"]),
        )
        self.assertEqual(detail_manager.status_code, 200, detail_manager.text)
        self.assertTrue(bool(detail_manager.json()["canEdit"]))

        updated_by_manager = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "manager-update"},
            headers=self._operator_headers(manager_same_team["login"]),
        )
        self.assertEqual(updated_by_manager.status_code, 200, updated_by_manager.text)

        forbidden_manager_other_team = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "forbidden-manager"},
            headers=self._operator_headers(manager_other_team["login"]),
        )
        self.assertEqual(forbidden_manager_other_team.status_code, 403)

        forbidden_other_user = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "forbidden-user"},
            headers=self._operator_headers(other_user["login"]),
        )
        self.assertEqual(forbidden_other_user.status_code, 403)

        updated_by_director = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "director-update"},
            headers=self._admin_headers(),
        )
        self.assertEqual(updated_by_director.status_code, 200, updated_by_director.text)

    def test_obligating_decision_inherits_permissions_from_linked_recommendation(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        recommendation_author = self._create_user(role_id=1, team_id=team_a)
        manager_same_team = self._create_user(role_id=2, team_id=team_a)
        manager_other_team = self._create_user(role_id=2, team_id=team_b)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-INHERIT-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(recommendation_author["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        # Decyzja jest tworzona przez dyrektora, ale uprawnienia do edycji maja dziedziczyc
        # z powiazanego zalecenia, a nie z autora decyzji.
        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": recommendation_code},
            headers=self._admin_headers(),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        detail_manager = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager_same_team["login"]),
        )
        self.assertEqual(detail_manager.status_code, 200, detail_manager.text)
        self.assertTrue(bool(detail_manager.json()["canEdit"]))

        update_manager = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "manager-inherited"},
            headers=self._operator_headers(manager_same_team["login"]),
        )
        self.assertEqual(update_manager.status_code, 200, update_manager.text)

        update_forbidden = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "forbidden"},
            headers=self._operator_headers(manager_other_team["login"]),
        )
        self.assertEqual(update_forbidden.status_code, 403)

    def test_role_change_revokes_write_access_across_all_main_modules(self) -> None:
        team_a = self._team_id("A")
        worker = self._create_user(role_id=1, team_id=team_a)
        worker_login = str(worker["login"])
        worker_id = int(worker["id"])

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ROLE-CHAIN-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-06-01",
                "koniecInspekcji": "2026-06-03",
                "osobaKierujacaUserId": worker_id,
                "teamMemberUserIds": [worker_id],
            },
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": f"ROLE-REC-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_id = int(recommendation_created.json()["id"])

        sanction_created = self.client.post(
            "/api/sanction-requests",
            json={
                "inspectionId": inspection_id,
                "komentarz": "before-role-change",
            },
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(sanction_created.status_code, 201, sanction_created.text)
        sanction_id = int(sanction_created.json()["id"])

        unlinked_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"ROLE-UNLINK-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(unlinked_recommendation.status_code, 201, unlinked_recommendation.text)
        recommendation_code = str(unlinked_recommendation.json()["kodZalecenia"])

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": recommendation_code},
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        # Change role to external_user and verify write is rejected on all main modules.
        self._update_user_role(user_id=worker_id, role_id=4, team_id=None)

        inspection_update = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json={"komentarz": "blocked-after-role-change"},
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(inspection_update.status_code, 403, inspection_update.text)

        recommendation_update = self.client.put(
            f"/api/recommendations/{recommendation_id}",
            json={"komentarz": "blocked-after-role-change"},
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(recommendation_update.status_code, 403, recommendation_update.text)

        sanction_update = self.client.put(
            f"/api/sanction-requests/{sanction_id}",
            json={"komentarz": "blocked-after-role-change"},
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(sanction_update.status_code, 403, sanction_update.text)

        decision_update = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={"komentarz": "blocked-after-role-change"},
            headers=self._operator_headers(worker_login),
        )
        self.assertEqual(decision_update.status_code, 403, decision_update.text)

    def test_role_transition_user_teamlead_director_across_main_modules(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        user_a = self._create_user(role_id=1, team_id=team_a)
        user_a_login = str(user_a["login"])
        user_a_id = int(user_a["id"])

        user_b = self._create_user(role_id=1, team_id=team_b)
        user_b_login = str(user_b["login"])
        user_b_id = int(user_b["id"])

        # User A creates full chain in team A.
        ins_a = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ROLE-A-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-07-01",
                "koniecInspekcji": "2026-07-03",
                "osobaKierujacaUserId": user_a_id,
                "teamMemberUserIds": [user_a_id],
            },
            headers=self._operator_headers(user_a_login),
        )
        self.assertEqual(ins_a.status_code, 201, ins_a.text)
        ins_a_id = int(ins_a.json()["id"])

        rec_a = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_a_id,
                "pozycja": 1,
                "nazwaPodmiotu": f"REC-A-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(user_a_login),
        )
        self.assertEqual(rec_a.status_code, 201, rec_a.text)
        rec_a_id = int(rec_a.json()["id"])

        sanction_a = self.client.post(
            "/api/sanction-requests",
            json={"inspectionId": ins_a_id, "komentarz": "role-a"},
            headers=self._operator_headers(user_a_login),
        )
        self.assertEqual(sanction_a.status_code, 201, sanction_a.text)
        sanction_a_id = int(sanction_a.json()["id"])

        rec_unlinked_a = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"REC-U-A-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(user_a_login),
        )
        self.assertEqual(rec_unlinked_a.status_code, 201, rec_unlinked_a.text)
        rec_unlinked_a_code = str(rec_unlinked_a.json()["kodZalecenia"])

        decision_a = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": rec_unlinked_a_code},
            headers=self._operator_headers(user_a_login),
        )
        self.assertEqual(decision_a.status_code, 201, decision_a.text)
        decision_a_id = int(decision_a.json()["id"])

        # As user (inspector) A can still edit own records.
        self.assertEqual(
            self._update_inspection_with_lock(ins_a_id, user_a_login, {"komentarz": "as-user"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_recommendation_with_lock(rec_a_id, user_a_login, {"komentarz": "as-user"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_sanction_with_lock(sanction_a_id, user_a_login, {"komentarz": "as-user"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_decision_with_lock(decision_a_id, user_a_login, {"komentarz": "as-user"}).status_code,
            403,
        )

        # Promote A to team lead in team A.
        self._update_user_role(user_id=user_a_id, role_id=2, team_id=team_a)

        # Team B chain should remain forbidden for team lead from another team.
        ins_b = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ROLE-B-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-07-05",
                "koniecInspekcji": "2026-07-07",
                "osobaKierujacaUserId": user_b_id,
                "teamMemberUserIds": [user_b_id],
            },
            headers=self._operator_headers(user_b_login),
        )
        self.assertEqual(ins_b.status_code, 201, ins_b.text)
        ins_b_id = int(ins_b.json()["id"])

        rec_b = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": ins_b_id,
                "pozycja": 1,
                "nazwaPodmiotu": f"REC-B-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(user_b_login),
        )
        self.assertEqual(rec_b.status_code, 201, rec_b.text)
        rec_b_id = int(rec_b.json()["id"])

        sanction_b = self.client.post(
            "/api/sanction-requests",
            json={"inspectionId": ins_b_id, "komentarz": "role-b"},
            headers=self._operator_headers(user_b_login),
        )
        self.assertEqual(sanction_b.status_code, 201, sanction_b.text)
        sanction_b_id = int(sanction_b.json()["id"])

        rec_unlinked_b = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"REC-U-B-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(user_b_login),
        )
        self.assertEqual(rec_unlinked_b.status_code, 201, rec_unlinked_b.text)
        rec_unlinked_b_code = str(rec_unlinked_b.json()["kodZalecenia"])

        decision_b = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": rec_unlinked_b_code},
            headers=self._operator_headers(user_b_login),
        )
        self.assertEqual(decision_b.status_code, 201, decision_b.text)
        decision_b_id = int(decision_b.json()["id"])

        self.assertEqual(
            self._update_inspection_with_lock(ins_b_id, user_a_login, {"komentarz": "blocked-as-team-lead"}).status_code,
            403,
        )
        self.assertEqual(
            self._update_recommendation_with_lock(rec_b_id, user_a_login, {"komentarz": "blocked-as-team-lead"}).status_code,
            403,
        )
        self.assertEqual(
            self._update_sanction_with_lock(sanction_b_id, user_a_login, {"komentarz": "blocked-as-team-lead"}).status_code,
            403,
        )
        self.assertEqual(
            self._update_decision_with_lock(decision_b_id, user_a_login, {"komentarz": "blocked-as-team-lead"}).status_code,
            403,
        )

        # Promote A to director and verify cross-team edit is allowed.
        self._update_user_role(user_id=user_a_id, role_id=3, team_id=None)

        self.assertEqual(
            self._update_inspection_with_lock(ins_b_id, user_a_login, {"komentarz": "ok-as-director"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_recommendation_with_lock(rec_b_id, user_a_login, {"komentarz": "ok-as-director"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_sanction_with_lock(sanction_b_id, user_a_login, {"komentarz": "ok-as-director"}).status_code,
            200,
        )
        self.assertEqual(
            self._update_decision_with_lock(decision_b_id, user_a_login, {"komentarz": "ok-as-director"}).status_code,
            200,
        )

    def test_obligating_decision_first_instance_people_lookup_and_scope_validation(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        worker_a = self._create_user(role_id=1, team_id=team_a)
        worker_b = self._create_user(role_id=1, team_id=team_b)
        lead_a = self._create_user(role_id=2, team_id=team_a)

        worker_a_person_id = self._ensure_person_slownik_id(worker_a)
        worker_b_person_id = self._ensure_person_slownik_id(worker_b)

        manager_lookup = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(manager_lookup.status_code, 200, manager_lookup.text)
        manager_ids = {int(item["id"]) for item in manager_lookup.json()["items"]}
        self.assertIn(worker_a_person_id, manager_ids)
        self.assertIn(worker_b_person_id, manager_ids)

        manager_lookup_ii = self.client.get(
            "/api/obligating-decisions/available-second-instance-people",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(manager_lookup_ii.status_code, 200, manager_lookup_ii.text)
        manager_ids_ii = {int(item["id"]) for item in manager_lookup_ii.json()["items"]}
        self.assertEqual(manager_ids_ii, manager_ids)

        director_lookup = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(director_lookup.status_code, 200, director_lookup.text)
        director_ids = {int(item["id"]) for item in director_lookup.json()["items"]}
        self.assertIn(worker_a_person_id, director_ids)
        self.assertIn(worker_b_person_id, director_ids)

        director_lookup_ii = self.client.get(
            "/api/obligating-decisions/available-second-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(director_lookup_ii.status_code, 200, director_lookup_ii.text)
        director_ids_ii = {int(item["id"]) for item in director_lookup_ii.json()["items"]}
        self.assertEqual(director_ids_ii, director_ids)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-I-SCOPE-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker_a["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        create_allowed_foreign = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [worker_b_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_allowed_foreign.status_code, 201, create_allowed_foreign.text)

        create_allowed = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [worker_a_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_allowed.status_code, 201, create_allowed.text)
        decision_id = int(create_allowed.json()["id"])

        update_forbidden = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": "",
                "osobyProwadzaceIInstancjeIds": [worker_b_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(update_forbidden.status_code, 423, update_forbidden.text)

        detail_before_update = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(detail_before_update.status_code, 200, detail_before_update.text)

        lock_acquire = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        update_allowed = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": detail_before_update.json()["zaktualizowanoO"],
                "osobyProwadzaceIInstancjeIds": [worker_a_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(update_allowed.status_code, 200, update_allowed.text)

        lock_release = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_token},
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(lock_release.status_code, 200, lock_release.text)

    def test_obligating_decision_people_include_technical_for_director_and_creator_team_lead(self) -> None:
        team_a = self._team_id("A")
        lead_a = self._create_user(role_id=2, team_id=team_a)
        worker_a = self._create_user(role_id=1, team_id=team_a)

        lead_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "LeadOwned",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(lead_technical.status_code, 200, lead_technical.text)
        lead_technical_user = lead_technical.json()
        lead_technical_person_id = self._ensure_person_slownik_id(lead_technical_user)

        director_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Former",
                "nazwisko": "DirectorOwned",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(director_technical.status_code, 200, director_technical.text)
        director_technical_user = director_technical.json()
        director_technical_person_id = self._ensure_person_slownik_id(director_technical_user)

        lead_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(lead_people.status_code, 200, lead_people.text)
        lead_person_ids = {int(item["id"]) for item in lead_people.json()["items"]}
        self.assertIn(lead_technical_person_id, lead_person_ids)
        self.assertNotIn(director_technical_person_id, lead_person_ids)

        director_people = self.client.get(
            "/api/obligating-decisions/available-first-instance-people",
            headers=self._admin_headers(),
        )
        self.assertEqual(director_people.status_code, 200, director_people.text)
        director_person_ids = {int(item["id"]) for item in director_people.json()["items"]}
        self.assertIn(lead_technical_person_id, director_person_ids)
        self.assertIn(director_technical_person_id, director_person_ids)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-TECH-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker_a["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        create_decision_with_technical = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [lead_technical_person_id],
            },
            headers=self._operator_headers(lead_a["login"]),
        )
        self.assertEqual(create_decision_with_technical.status_code, 201, create_decision_with_technical.text)

    def test_obligating_decision_ii_permissions_for_manager_of_i_instance_after_appeal_inflow_date(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        worker = self._create_user(role_id=1, team_id=team_a)
        manager = self._create_user(role_id=2, team_id=team_a)
        other_manager = self._create_user(role_id=2, team_id=team_b)
        worker_b = self._create_user(role_id=1, team_id=team_b)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-II-PERM-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        person_code = f"OSOBA_{int(worker['id'])}"
        ensure_person = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "osoby",
                "kodPozycji": person_code,
                "nazwaPozycji": f"{worker['imie']} {worker['nazwisko']}",
                "skrotPozycji": worker["login"],
            },
            headers=self._admin_headers(),
        )
        self.assertIn(ensure_person.status_code, {200, 409}, ensure_person.text)
        if ensure_person.status_code == 200:
            worker_person_id = int(ensure_person.json()["id"])
        else:
            with get_connection() as conn:
                person_row = conn.execute(
                    """
                    SELECT id
                    FROM slownik_pozycje
                    WHERE lower(kod_typu) = 'osoby'
                      AND lower(kod_pozycji) = lower(?)
                    LIMIT 1
                    """,
                    (person_code,),
                ).fetchone()
            self.assertIsNotNone(person_row)
            assert person_row is not None
            worker_person_id = int(person_row["id"])

        person_b_code = f"OSOBA_{int(worker_b['id'])}"
        ensure_person_b = self.client.post(
            "/api/slowniki/pozycje",
            json={
                "kodTypu": "osoby",
                "kodPozycji": person_b_code,
                "nazwaPozycji": f"{worker_b['imie']} {worker_b['nazwisko']}",
                "skrotPozycji": worker_b["login"],
            },
            headers=self._admin_headers(),
        )
        self.assertIn(ensure_person_b.status_code, {200, 409}, ensure_person_b.text)
        if ensure_person_b.status_code == 200:
            worker_b_person_id = int(ensure_person_b.json()["id"])
        else:
            with get_connection() as conn:
                person_b_row = conn.execute(
                    """
                    SELECT id
                    FROM slownik_pozycje
                    WHERE lower(kod_typu) = 'osoby'
                      AND lower(kod_pozycji) = lower(?)
                    LIMIT 1
                    """,
                    (person_b_code,),
                ).fetchone()
            self.assertIsNotNone(person_b_row)
            assert person_b_row is not None
            worker_b_person_id = int(person_b_row["id"])

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [worker_person_id],
            },
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        before_update = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(before_update.status_code, 200, before_update.text)
        self.assertFalse(bool(before_update.json()["canEditIIInstance"]))
        self.assertFalse(bool(before_update.json()["canAssignIIInstancePeople"]))

        detail_for_update = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(detail_for_update.status_code, 200, detail_for_update.text)

        lock_acquire = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
        lock_token = str(lock_acquire.json()["lockToken"])

        set_appeal_inflow = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": detail_for_update.json()["zaktualizowanoO"],
                "dataWplywuWnioskuPonowneRozpatrzenie": "2026-12-01",
            },
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(set_appeal_inflow.status_code, 200, set_appeal_inflow.text)

        release_worker_lock = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_token},
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(release_worker_lock.status_code, 200, release_worker_lock.text)

        after_update = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(after_update.status_code, 200, after_update.text)
        self.assertTrue(bool(after_update.json()["canEditIIInstance"]))
        self.assertTrue(bool(after_update.json()["canAssignIIInstancePeople"]))

        lock_for_manager = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(lock_for_manager.status_code, 200, lock_for_manager.text)
        manager_lock_token = str(lock_for_manager.json()["lockToken"])

        set_ii_people = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": manager_lock_token,
                "expectedUpdatedAt": after_update.json()["zaktualizowanoO"],
                "osobyProwadzaceIIInstancjeIds": [worker_b_person_id],
            },
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(set_ii_people.status_code, 200, set_ii_people.text)

        after_switch_manager_a = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(after_switch_manager_a.status_code, 200, after_switch_manager_a.text)
        self.assertFalse(bool(after_switch_manager_a.json()["canEditIIInstance"]))
        self.assertTrue(bool(after_switch_manager_a.json()["canAssignIIInstancePeople"]))

        after_switch_manager_b = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(other_manager["login"]),
        )
        self.assertEqual(after_switch_manager_b.status_code, 200, after_switch_manager_b.text)
        self.assertTrue(bool(after_switch_manager_b.json()["canEditIIInstance"]))
        self.assertTrue(bool(after_switch_manager_b.json()["canAssignIIInstancePeople"]))

        after_switch_worker_b = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(worker_b["login"]),
        )
        self.assertEqual(after_switch_worker_b.status_code, 200, after_switch_worker_b.text)
        self.assertTrue(bool(after_switch_worker_b.json()["canEditIIInstance"]))

        list_for_manager = self.client.get(
            "/api/obligating-decisions",
            headers=self._operator_headers(manager["login"]),
        )
        self.assertEqual(list_for_manager.status_code, 200, list_for_manager.text)
        manager_item = next(item for item in list_for_manager.json()["items"] if int(item["id"]) == decision_id)
        self.assertFalse(bool(manager_item["canEditIIInstance"]))
        self.assertTrue(bool(manager_item["canAssignIIInstancePeople"]))
        self.assertIn("canEdit", manager_item)
        self.assertIn("canEditIInstance", manager_item)
        self.assertIn("canAssignIInstancePeople", manager_item)
        self.assertIn("canEditIIInstance", manager_item)
        self.assertIn("canAssignIIInstancePeople", manager_item)
        self.assertIn("canEditComment", manager_item)

        list_for_manager_b = self.client.get(
            "/api/obligating-decisions",
            headers=self._operator_headers(other_manager["login"]),
        )
        self.assertEqual(list_for_manager_b.status_code, 200, list_for_manager_b.text)
        manager_b_item = next(item for item in list_for_manager_b.json()["items"] if int(item["id"]) == decision_id)
        self.assertTrue(bool(manager_b_item["canEditIIInstance"]))
        self.assertTrue(bool(manager_b_item["canAssignIIInstancePeople"]))

        forbidden_other_manager = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(other_manager["login"]),
        )
        self.assertEqual(forbidden_other_manager.status_code, 200, forbidden_other_manager.text)
        self.assertTrue(bool(forbidden_other_manager.json()["canEditIIInstance"]))
        self.assertTrue(bool(forbidden_other_manager.json()["canAssignIIInstancePeople"]))

    def test_obligating_decision_worker_can_edit_substantive_but_not_people_fields(self) -> None:
        team_a = self._team_id("A")
        worker_i = self._create_user(role_id=1, team_id=team_a)
        manager_a = self._create_user(role_id=2, team_id=team_a)
        worker_ii = self._create_user(role_id=1, team_id=team_a)

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-WORKER-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        def ensure_person_id(user: dict) -> int:
            person_code = f"OSOBA_{int(user['id'])}"
            ensure_person = self.client.post(
                "/api/slowniki/pozycje",
                json={
                    "kodTypu": "osoby",
                    "kodPozycji": person_code,
                    "nazwaPozycji": f"{user['imie']} {user['nazwisko']}",
                    "skrotPozycji": user["login"],
                },
                headers=self._admin_headers(),
            )
            self.assertIn(ensure_person.status_code, {200, 409}, ensure_person.text)
            if ensure_person.status_code == 200:
                return int(ensure_person.json()["id"])
            with get_connection() as conn:
                row = conn.execute(
                    """
                    SELECT id
                    FROM slownik_pozycje
                    WHERE lower(kod_typu) = 'osoby'
                      AND lower(kod_pozycji) = lower(?)
                    LIMIT 1
                    """,
                    (person_code,),
                ).fetchone()
            self.assertIsNotNone(row)
            assert row is not None
            return int(row["id"])

        worker_i_person_id = ensure_person_id(worker_i)
        manager_person_id = ensure_person_id(manager_a)
        worker_ii_person_id = ensure_person_id(worker_ii)

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [worker_i_person_id],
            },
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        detail_worker_before = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(detail_worker_before.status_code, 200, detail_worker_before.text)
        self.assertTrue(bool(detail_worker_before.json()["canEditIInstance"]))
        self.assertFalse(bool(detail_worker_before.json()["canAssignIInstancePeople"]))
        self.assertFalse(bool(detail_worker_before.json()["canEditIIInstance"]))
        self.assertFalse(bool(detail_worker_before.json()["canAssignIIInstancePeople"]))

        lock_worker_i = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(lock_worker_i.status_code, 200, lock_worker_i.text)
        lock_worker_i_token = str(lock_worker_i.json()["lockToken"])

        worker_updates_substantive = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_worker_i_token,
                "expectedUpdatedAt": detail_worker_before.json()["zaktualizowanoO"],
                "liczbaZalecen": 5,
                "dataWplywuWnioskuPonowneRozpatrzenie": "2026-12-10",
            },
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(worker_updates_substantive.status_code, 200, worker_updates_substantive.text)

        worker_updates_people_i = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_worker_i_token,
                "expectedUpdatedAt": worker_updates_substantive.json()["zaktualizowanoO"],
                "osobyProwadzaceIInstancjeIds": [worker_i_person_id, manager_person_id],
            },
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(worker_updates_people_i.status_code, 403, worker_updates_people_i.text)

        release_worker_lock = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_worker_i_token},
            headers=self._operator_headers(worker_i["login"]),
        )
        self.assertEqual(release_worker_lock.status_code, 200, release_worker_lock.text)

        detail_manager = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(detail_manager.status_code, 200, detail_manager.text)
        self.assertTrue(bool(detail_manager.json()["canEditIInstance"]))
        self.assertTrue(bool(detail_manager.json()["canAssignIInstancePeople"]))
        self.assertTrue(bool(detail_manager.json()["canEditIIInstance"]))
        self.assertTrue(bool(detail_manager.json()["canAssignIIInstancePeople"]))

        lock_manager = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(lock_manager.status_code, 200, lock_manager.text)
        lock_manager_token = str(lock_manager.json()["lockToken"])

        manager_sets_people_ii = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_manager_token,
                "expectedUpdatedAt": detail_manager.json()["zaktualizowanoO"],
                "osobyProwadzaceIIInstancjeIds": [worker_ii_person_id],
            },
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(manager_sets_people_ii.status_code, 200, manager_sets_people_ii.text)

        release_manager_lock = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/release",
            json={"lockToken": lock_manager_token},
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(release_manager_lock.status_code, 200, release_manager_lock.text)

        detail_worker_ii = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(worker_ii["login"]),
        )
        self.assertEqual(detail_worker_ii.status_code, 200, detail_worker_ii.text)
        self.assertTrue(bool(detail_worker_ii.json()["canEditIIInstance"]))
        self.assertFalse(bool(detail_worker_ii.json()["canAssignIIInstancePeople"]))

        lock_worker_ii = self.client.post(
            f"/api/locks/obligating-decisions/{decision_id}/acquire",
            headers=self._operator_headers(worker_ii["login"]),
        )
        self.assertEqual(lock_worker_ii.status_code, 200, lock_worker_ii.text)
        lock_worker_ii_token = str(lock_worker_ii.json()["lockToken"])

        worker_ii_updates_substantive = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_worker_ii_token,
                "expectedUpdatedAt": detail_worker_ii.json()["zaktualizowanoO"],
                "dataDecyzjiIIInstancji": "2026-12-20",
            },
            headers=self._operator_headers(worker_ii["login"]),
        )
        self.assertEqual(worker_ii_updates_substantive.status_code, 200, worker_ii_updates_substantive.text)

        worker_ii_updates_people = self.client.put(
            f"/api/obligating-decisions/{decision_id}",
            json={
                "lockToken": lock_worker_ii_token,
                "expectedUpdatedAt": worker_ii_updates_substantive.json()["zaktualizowanoO"],
                "osobyProwadzaceIIInstancjeIds": [worker_ii_person_id, manager_person_id],
            },
            headers=self._operator_headers(worker_ii["login"]),
        )
        self.assertEqual(worker_ii_updates_people.status_code, 403, worker_ii_updates_people.text)

    def test_obligating_decision_team_lead_scope_includes_users_created_by_lead(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager_a = self._create_user(role_id=2, team_id=team_a)

        created_by_manager = self.client.post(
            "/api/admin/users",
            json={
                "login": f"lead_scope_{uuid.uuid4().hex[:8]}",
                "imie": "Lead",
                "nazwisko": "Scope",
                "email": f"lead_scope_{uuid.uuid4().hex[:8]}@example.local",
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": True,
            },
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(created_by_manager.status_code, 200, created_by_manager.text)
        worker = created_by_manager.json()

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-CREATED-BY-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(worker["login"]),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        worker_person_id = self._ensure_person_slownik_id(worker)

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [worker_person_id],
            },
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        moved_to_team_b = self.client.put(
            f"/api/admin/users/{int(worker['id'])}",
            json={"zespolId": team_b},
            headers=self._admin_headers(),
        )
        self.assertEqual(moved_to_team_b.status_code, 200, moved_to_team_b.text)

        manager_detail = self.client.get(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(manager_detail.status_code, 200, manager_detail.text)
        self.assertTrue(bool(manager_detail.json()["canEditIInstance"]))

    def test_available_recommendations_rbac_filtered_for_manager(self) -> None:
        team_a = self._team_id("A")
        team_b = self._team_id("B")

        manager_a = self._create_user(role_id=2, team_id=team_a)
        member_a = self._create_user(role_id=1, team_id=team_a)
        lead_a = self._create_user(role_id=2, team_id=team_a)
        lead_b = self._create_user(role_id=2, team_id=team_b)
        author_b = self._create_user(role_id=1, team_id=team_b)

        ins_lead_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-AV-LA-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-09-01",
                "koniecInspekcji": "2026-09-05",
                "osobaKierujacaUserId": int(lead_a["id"]),
                "teamMemberUserIds": [int(lead_a["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_lead_a_resp.status_code, 201, ins_lead_a_resp.text)
        ins_lead_a = int(ins_lead_a_resp.json()["id"])

        ins_member_a_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-AV-MA-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-09-06",
                "koniecInspekcji": "2026-09-10",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(member_a["id"]), int(lead_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_member_a_resp.status_code, 201, ins_member_a_resp.text)
        ins_member_a = int(ins_member_a_resp.json()["id"])

        ins_hidden_resp = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-AV-H-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-09-11",
                "koniecInspekcji": "2026-09-15",
                "osobaKierujacaUserId": int(lead_b["id"]),
                "teamMemberUserIds": [int(lead_b["id"])],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(ins_hidden_resp.status_code, 201, ins_hidden_resp.text)
        ins_hidden = int(ins_hidden_resp.json()["id"])

        rec_lead_a = self.client.post(
            "/api/recommendations",
            json={"inspectionId": ins_lead_a, "pozycja": 1, "status": "Nowe"},
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_lead_a.status_code, 201, rec_lead_a.text)
        rec_lead_a_code = str(rec_lead_a.json()["kodZalecenia"])

        rec_member_a = self.client.post(
            "/api/recommendations",
            json={"inspectionId": ins_member_a, "pozycja": 1, "status": "Nowe"},
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_member_a.status_code, 201, rec_member_a.text)
        rec_member_a_code = str(rec_member_a.json()["kodZalecenia"])

        rec_hidden = self.client.post(
            "/api/recommendations",
            json={"inspectionId": ins_hidden, "pozycja": 1, "status": "Nowe"},
            headers=self._admin_headers(),
        )
        self.assertEqual(rec_hidden.status_code, 201, rec_hidden.text)
        rec_hidden_code = str(rec_hidden.json()["kodZalecenia"])

        rec_unlinked_visible = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-AV-UV-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(member_a["login"]),
        )
        self.assertEqual(rec_unlinked_visible.status_code, 201, rec_unlinked_visible.text)
        rec_unlinked_visible_code = str(rec_unlinked_visible.json()["kodZalecenia"])

        rec_unlinked_hidden = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"OD-AV-UH-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._operator_headers(author_b["login"]),
        )
        self.assertEqual(rec_unlinked_hidden.status_code, 201, rec_unlinked_hidden.text)
        rec_unlinked_hidden_code = str(rec_unlinked_hidden.json()["kodZalecenia"])

        available = self.client.get(
            "/api/obligating-decisions/available-recommendations",
            headers=self._operator_headers(manager_a["login"]),
        )
        self.assertEqual(available.status_code, 200, available.text)
        codes = {item["kodZalecenia"] for item in available.json()}

        self.assertIn(rec_lead_a_code, codes)
        self.assertIn(rec_member_a_code, codes)
        self.assertIn(rec_unlinked_visible_code, codes)
        self.assertNotIn(rec_hidden_code, codes)
        self.assertNotIn(rec_unlinked_hidden_code, codes)

    def test_delete_obligating_decision_removes_only_decision(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-DEL-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-10-01",
                "koniecInspekcji": "2026-10-05",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-10-31",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_id = int(recommendation_created.json()["id"])
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        osoba_i = self.client.post(
            "/api/slowniki/pozycje",
            json={"kodTypu": "osoby", "nazwaPozycji": f"Osoba DEL I {uuid.uuid4().hex[:4]}"},
            headers=self._admin_headers(),
        )
        self.assertEqual(osoba_i.status_code, 200, osoba_i.text)
        osoba_i_id = int(osoba_i.json()["id"])

        created = self.client.post(
            "/api/obligating-decisions",
            json={
                "recommendationKodZalecenia": recommendation_code,
                "osobyProwadzaceIInstancjeIds": [osoba_i_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        decision_id = int(created.json()["id"])

        team_a = self._team_id("A")
        inspector = self._create_user(role_id=1, team_id=team_a)
        forbidden_delete = self.client.delete(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._operator_headers(inspector["login"]),
        )
        self.assertEqual(forbidden_delete.status_code, 403)

        deleted = self.client.delete(
            f"/api/obligating-decisions/{decision_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted.status_code, 200, deleted.text)
        self.assertTrue(bool(deleted.json().get("ok")))

        with get_connection() as conn:
            decision_left = conn.execute(
                "SELECT COUNT(*) AS total FROM obligating_decisions WHERE id = ?",
                (decision_id,),
            ).fetchone()
            decision_persons_left = conn.execute(
                "SELECT COUNT(*) AS total FROM obligating_decisions_persons_i WHERE obligating_decision_id = ?",
                (decision_id,),
            ).fetchone()
            recommendation_left = conn.execute(
                "SELECT COUNT(*) AS total FROM recommendations WHERE id = ?",
                (recommendation_id,),
            ).fetchone()

        self.assertEqual(int(decision_left["total"]), 0)
        self.assertEqual(int(decision_persons_left["total"]), 0)
        self.assertEqual(int(recommendation_left["total"]), 1)

    def test_delete_recommendation_cascades_obligating_decisions(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        inspection_created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"OD-CASC-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-05",
                "osobaKierujacaUserId": admin_id,
                "teamMemberUserIds": [admin_id],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_created.status_code, 201, inspection_created.text)
        inspection_id = int(inspection_created.json()["id"])

        recommendation_created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "nazwaPodmiotu": "Podmiot decyzji",
                "terminWykonaniaZalecen": "2026-11-30",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(recommendation_created.status_code, 201, recommendation_created.text)
        recommendation_id = int(recommendation_created.json()["id"])
        recommendation_code = str(recommendation_created.json()["kodZalecenia"])

        decision_created = self.client.post(
            "/api/obligating-decisions",
            json={"recommendationKodZalecenia": recommendation_code},
            headers=self._admin_headers(),
        )
        self.assertEqual(decision_created.status_code, 201, decision_created.text)
        decision_id = int(decision_created.json()["id"])

        deleted_recommendation = self.client.delete(
            f"/api/recommendations/{recommendation_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(deleted_recommendation.status_code, 200, deleted_recommendation.text)
        self.assertTrue(bool(deleted_recommendation.json().get("ok")))

        with get_connection() as conn:
            recommendation_left = conn.execute(
                "SELECT COUNT(*) AS total FROM recommendations WHERE id = ?",
                (recommendation_id,),
            ).fetchone()
            decision_left = conn.execute(
                "SELECT COUNT(*) AS total FROM obligating_decisions WHERE id = ?",
                (decision_id,),
            ).fetchone()

        self.assertEqual(int(recommendation_left["total"]), 0)
        self.assertEqual(int(decision_left["total"]), 0)

    def test_available_recommendations_returns_subject_for_unlinked_recommendation(self) -> None:
        created = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": None,
                "pozycja": 1,
                "nazwaPodmiotu": f"PODMIOT-BEZ-INS-{uuid.uuid4().hex[:6]}",
                "status": "Nowe",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        recommendation_code = str(created_body["kodZalecenia"])
        expected_subject = str(created_body["nazwaPodmiotu"])

        available_recommendations = self.client.get(
            "/api/obligating-decisions/available-recommendations",
            headers=self._admin_headers(),
        )
        self.assertEqual(available_recommendations.status_code, 200, available_recommendations.text)

        match = next(
            (item for item in available_recommendations.json() if item["kodZalecenia"] == recommendation_code),
            None,
        )
        self.assertIsNotNone(match)
        assert match is not None
        self.assertIsNone(match["inspectionId"])
        self.assertEqual(match["nazwaPodmiotu"], expected_subject)
        self.assertIsInstance(match["nazwaPodmiotu"], str)
        self.assertNotEqual(match["nazwaPodmiotu"].strip(), "")


if __name__ == "__main__":
    unittest.main(verbosity=2)

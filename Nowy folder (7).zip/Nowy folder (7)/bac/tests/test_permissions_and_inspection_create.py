from __future__ import annotations

import tempfile
import unittest
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from app.db import get_connection
from app.database import connection as db_connection


class PermissionsAndInspectionCreateTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp_dir_path = Path(tempfile.mkdtemp(prefix="rejestr-tests-"))
        cls._original_db_path = db_connection.DB_PATH
        db_connection.DB_PATH = cls._tmp_dir_path / "bootstrap_rejestr_permissions_test.db"

        from app.main import app

        cls.client = TestClient(app)

    def setUp(self) -> None:
        # Fresh DB per test keeps tests deterministic and independent.
        db_connection.DB_PATH = self._tmp_dir_path / f"rejestr_permissions_test_{uuid.uuid4().hex}.db"

        from app.db import init_db

        init_db()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.client.close()
        db_connection.DB_PATH = cls._original_db_path

    def _admin_headers(self) -> dict[str, str]:
        return {"X-Operator-Login": "admin"}

    def _team_id(self, code: str) -> int:
        teams = self.client.get("/api/admin/teams").json()
        for team in teams:
            if team["kod"] == code:
                return int(team["id"])
        raise AssertionError(f"Team code {code} not found")

    def _create_user(self, role_id: int, team_id: int | None, prefix: str) -> dict:
        suffix = uuid.uuid4().hex[:6]
        payload = {
            "login": f"{prefix}_{suffix}",
            "imie": prefix.capitalize(),
            "nazwisko": f"User{suffix}",
            "email": f"{prefix}_{suffix}@example.local",
            "rolaId": role_id,
            "zespolId": team_id,
            "aktywny": True,
        }
        response = self.client.post(
            "/api/admin/users",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def _insert_audit_log_row(
        self,
        *,
        session_id: str,
        uzytkownik: str,
        akcja: str,
        data_godz: str,
        rejestr: str,
        rekord_kod: str,
        pole: str | None,
        przed: str | None,
        po: str | None,
    ) -> None:
        with get_connection() as conn:
            conn.execute(
                """
                INSERT INTO audit_log (session_id, uzytkownik, akcja, data_godz, rejestr, rekord_kod, pole, przed, po)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (session_id, uzytkownik, akcja, data_godz, rejestr, rekord_kod, pole, przed, po),
            )

    def _seed_audit_log_fixture(self) -> None:
        self._insert_audit_log_row(
            session_id="s1",
            uzytkownik="admin",
            akcja="UPDATE",
            data_godz="2026-10-10T10:00:00.000Z",
            rejestr="inspekcje",
            rekord_kod="INS-100",
            pole="Status",
            przed="Nowa",
            po="W toku",
        )
        self._insert_audit_log_row(
            session_id="s2",
            uzytkownik="admin",
            akcja="UPDATE",
            data_godz="2026-10-11T10:00:00.000Z",
            rejestr="inspekcje",
            rekord_kod="INS-100",
            pole="Data doręczenia protokołu",
            przed=None,
            po="2026-10-11",
        )
        self._insert_audit_log_row(
            session_id="s3",
            uzytkownik="admin",
            akcja="CREATE",
            data_godz="2026-10-11T11:00:00.000Z",
            rejestr="inspekcje",
            rekord_kod="INS-100",
            pole=None,
            przed=None,
            po=None,
        )
        self._insert_audit_log_row(
            session_id="s4",
            uzytkownik="admin",
            akcja="UPDATE",
            data_godz="2026-10-12T10:00:00.000Z",
            rejestr="zalecenia",
            rekord_kod="ZAL-77",
            pole="Data doręczenia protokołu",
            przed=None,
            po="2026-10-12",
        )
        self._insert_audit_log_row(
            session_id="s5",
            uzytkownik="anna",
            akcja="UPDATE",
            data_godz="2026-10-13T10:00:00.000Z",
            rejestr="inspekcje",
            rekord_kod="INS-999",
            pole="Data doręczenia protokołu",
            przed=None,
            po="2026-10-13",
        )

    def test_can_edit_permissions_matrix(self) -> None:
        team_a = self._team_id("A")
        team_d = self._team_id("D")

        creator = self._create_user(1, team_a, "creator")
        member = self._create_user(1, team_a, "member")
        lead_same_team = self._create_user(2, team_a, "lead")
        outsider = self._create_user(1, team_d, "outsider")

        payload = {
            "nazwaPodmiotu": f"PERM-{uuid.uuid4().hex[:6]}",
            "poczatekInspekcji": "2026-08-01",
            "koniecInspekcji": "2026-08-10",
            "osobaKierujacaUserId": int(creator["id"]),
            "teamMemberUserIds": [int(creator["id"]), int(member["id"])],
        }
        created = self.client.post(
            "/api/structure/inspections",
            json=payload,
            headers={"X-Operator-Login": creator["login"]},
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])

        def get_can_edit(login: str) -> bool:
            rows = self.client.get(
                "/api/structure/inspections",
                headers={"X-Operator-Login": login},
            )
            self.assertEqual(rows.status_code, 200, rows.text)
            item = next(i for i in rows.json()["items"] if int(i["id"]) == inspection_id)
            return bool(item["canEdit"])

        self.assertTrue(get_can_edit(creator["login"]))
        self.assertTrue(get_can_edit(member["login"]))
        self.assertTrue(get_can_edit(lead_same_team["login"]))
        self.assertTrue(get_can_edit("admin"))
        self.assertFalse(get_can_edit(outsider["login"]))

        denied = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json={"komentarz": "blocked"},
            headers={"X-Operator-Login": outsider["login"]},
        )
        self.assertEqual(denied.status_code, 403)

    def test_team_lead_can_edit_when_member_created_by_lead(self) -> None:
        suffix = uuid.uuid4().hex[:6]
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department_ogolne', 'Departament ogolne', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje
                (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department_ogolne', 'DIU', 'DIU', 'DIU', 1, 1)
                """
            )
            team_a_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TA{suffix}", f"Team A {suffix}"),
            )
            team_d_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TD{suffix}", f"Team D {suffix}"),
            )
            team_a = int(team_a_cursor.lastrowid)
            team_d = int(team_d_cursor.lastrowid)
            conn.commit()

        lead_a = self._create_user(2, team_a, "lead")
        outsider = self._create_user(1, team_d, "outsider")

        created_technical = self.client.post(
            "/api/admin/users",
            json={
                "login": "",
                "imie": "Tech",
                "nazwisko": "CreatedByLead",
                "email": None,
                "rolaId": 1,
                "zespolId": None,
                "aktywny": False,
                "accountType": "technical",
                "departmentCode": "DIU",
            },
            headers={"X-Operator-Login": lead_a["login"]},
        )
        self.assertEqual(created_technical.status_code, 200, created_technical.text)
        created_technical_id = int(created_technical.json()["id"])

        payload = {
            "nazwaPodmiotu": f"PERM-TECH-{uuid.uuid4().hex[:6]}",
            "typInspekcji": "Kontrola",
            "poczatekInspekcji": "2026-08-11",
            "koniecInspekcji": "2026-08-12",
            "osobaKierujacaUserId": int(outsider["id"]),
            "teamMemberUserIds": [created_technical_id],
        }
        created = self.client.post(
            "/api/structure/inspections",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])

        rows = self.client.get(
            "/api/structure/inspections",
            headers={"X-Operator-Login": lead_a["login"]},
        )
        self.assertEqual(rows.status_code, 200, rows.text)
        item = next(i for i in rows.json()["items"] if int(i["id"]) == inspection_id)
        self.assertTrue(bool(item["canEdit"]))

    def test_team_lead_can_edit_when_observer_member_created_by_lead(self) -> None:
        suffix = uuid.uuid4().hex[:6]
        with get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('department_ogolne', 'Departament ogolne', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('nazwy_podmiotow', 'Nazwy podmiotow', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_typy (kod_typu, nazwa_typu, kategoria, opis, aktywny)
                VALUES ('typy_inspekcji', 'Typy inspekcji', 0, NULL, 1)
                """
            )
            conn.execute(
                """
                INSERT OR IGNORE INTO slownik_pozycje
                (kod_typu, kod_pozycji, nazwa_pozycji, skrot_pozycji, kolejnosc, aktywny)
                VALUES ('department_ogolne', 'DIU', 'DIU', 'DIU', 1, 1)
                """
            )
            team_a_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TA{suffix}", f"Team A {suffix}"),
            )
            team_d_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TD{suffix}", f"Team D {suffix}"),
            )
            team_a = int(team_a_cursor.lastrowid)
            team_d = int(team_d_cursor.lastrowid)
            conn.commit()

        lead_a = self._create_user(2, team_a, "lead")
        outsider = self._create_user(1, team_d, "outsider")

        observer_login = f"observer_{suffix}"
        created_member = self.client.post(
            "/api/admin/users",
            json={
                "login": observer_login,
                "imie": "Observer",
                "nazwisko": "CreatedByLead",
                "email": f"{observer_login}@example.local",
                "rolaId": 1,
                "zespolId": team_a,
                "aktywny": True,
                "accountType": "observer",
            },
            headers={"X-Operator-Login": lead_a["login"]},
        )
        self.assertEqual(created_member.status_code, 200, created_member.text)
        created_member_id = int(created_member.json()["id"])

        move_to_other_team = self.client.put(
            f"/api/admin/users/{created_member_id}",
            json={"zespolId": team_d},
            headers=self._admin_headers(),
        )
        self.assertEqual(move_to_other_team.status_code, 200, move_to_other_team.text)

        payload = {
            "nazwaPodmiotu": f"PERM-OBS-{uuid.uuid4().hex[:6]}",
            "typInspekcji": "Kontrola",
            "poczatekInspekcji": "2026-08-13",
            "koniecInspekcji": "2026-08-14",
            "osobaKierujacaUserId": int(outsider["id"]),
            "teamMemberUserIds": [created_member_id],
        }
        created = self.client.post(
            "/api/structure/inspections",
            json=payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        inspection_id = int(created.json()["id"])

        rows = self.client.get(
            "/api/structure/inspections",
            headers={"X-Operator-Login": lead_a["login"]},
        )
        self.assertEqual(rows.status_code, 200, rows.text)
        item = next(i for i in rows.json()["items"] if int(i["id"]) == inspection_id)
        self.assertTrue(bool(item["canEdit"]))

    def test_team_lead_can_keep_existing_out_of_scope_leader_on_update(self) -> None:
        suffix = uuid.uuid4().hex[:6]
        with get_connection() as conn:
            team_a_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TA{suffix}", f"Team A {suffix}"),
            )
            team_a = int(team_a_cursor.lastrowid)

            team_b_cursor = conn.execute(
                "INSERT INTO teams (kod, nazwa) VALUES (?, ?)",
                (f"TB{suffix}", f"Team B {suffix}"),
            )
            team_b = int(team_b_cursor.lastrowid)

            leader_login = f"leadera_{suffix}"
            lead_b_login = f"leadb_{suffix}"
            leader_cursor = conn.execute(
                """
                INSERT INTO users (
                    login, imie, nazwisko, email, rola_id, zespol_id, aktywny, account_type, list_visibility
                ) VALUES (?, ?, ?, ?, ?, ?, 1, 'diu', 'visible')
                """,
                (leader_login, "Leader", "A", f"{leader_login}@example.local", 1, team_a),
            )
            leader_a_id = int(leader_cursor.lastrowid)

            lead_b_cursor = conn.execute(
                """
                INSERT INTO users (
                    login, imie, nazwisko, email, rola_id, zespol_id, aktywny, account_type, list_visibility
                ) VALUES (?, ?, ?, ?, ?, ?, 1, 'diu', 'visible')
                """,
                (lead_b_login, "Lead", "B", f"{lead_b_login}@example.local", 2, team_b),
            )
            lead_b_id = int(lead_b_cursor.lastrowid)
            conn.commit()

        with get_connection() as conn:
            admin_row = conn.execute("SELECT id FROM users WHERE lower(login) = 'admin' LIMIT 1").fetchone()
            self.assertIsNotNone(admin_row)
            assert admin_row is not None
            admin_id = int(admin_row["id"])

            max_lp_row = conn.execute("SELECT COALESCE(MAX(lp), 0) AS max_lp FROM inspections").fetchone()
            next_lp = int(max_lp_row["max_lp"]) + 1

            inspection_cursor = conn.execute(
                """
                INSERT INTO inspections (
                    lp,
                    kod_inspekcji,
                    created_by_user_id,
                    poczatek_inspekcji,
                    koniec_inspekcji,
                    osoba_kierujaca_user_id
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (next_lp, f"TEST/{suffix}/{next_lp}", admin_id, "2026-12-01", "2026-12-05", leader_a_id),
            )
            inspection_id = int(inspection_cursor.lastrowid)

            conn.execute(
                "INSERT INTO inspection_members (inspection_id, user_id) VALUES (?, ?)",
                (inspection_id, leader_a_id),
            )
            conn.execute(
                "INSERT INTO inspection_members (inspection_id, user_id) VALUES (?, ?)",
                (inspection_id, lead_b_id),
            )

            current_row = conn.execute(
                "SELECT zaktualizowano_o FROM inspections WHERE id = ?",
                (inspection_id,),
            ).fetchone()
            self.assertIsNotNone(current_row)
            assert current_row is not None
            expected_updated_at = str(current_row["zaktualizowano_o"])
            conn.commit()

        lock = self.client.post(
            f"/api/locks/inspections/{inspection_id}/acquire",
            headers={"X-Operator-Login": lead_b_login},
        )
        self.assertEqual(lock.status_code, 200, lock.text)
        lock_token = str(lock.json()["lockToken"])

        updated = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": expected_updated_at,
                # Frontend often sends current leader value unchanged.
                "osobaKierujacaUserId": leader_a_id,
                "komentarz": "Team B lead updated without changing leader",
            },
            headers={"X-Operator-Login": lead_b_login},
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()
        self.assertEqual(int(updated_body["osobaKierujacaUserId"]), leader_a_id)
        self.assertEqual(updated_body["komentarz"], "Team B lead updated without changing leader")

    def test_inspection_create_form_and_validations(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        minimal_payload = {
            "nazwaPodmiotu": f"FORM-{uuid.uuid4().hex[:6]}",
            "poczatekInspekcji": "2026-09-01",
            "koniecInspekcji": "2026-09-05",
            "osobaKierujacaUserId": admin_id,
        }
        created = self.client.post(
            "/api/structure/inspections",
            json=minimal_payload,
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        body = created.json()
        self.assertEqual(body["osobaKierujacaUserId"], admin_id)
        self.assertEqual(body["teamMemberUserIds"], [admin_id])
        self.assertEqual(body["dataZalecenList"], [])
        self.assertEqual(body["dataAkceptacjiNotyList"], [])
        self.assertFalse(body["brakDatAkceptacjiNoty"])
        self.assertIn("canEdit", body)

        missing_leader = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": "MISS-LEAD",
                "poczatekInspekcji": "2026-09-01",
                "koniecInspekcji": "2026-09-02",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(missing_leader.status_code, 400)

        missing_user = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": "NO-USER",
                "poczatekInspekcji": "2026-09-01",
                "koniecInspekcji": "2026-09-02",
                "osobaKierujacaUserId": 999999,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(missing_user.status_code, 404)

        invalid_business_dates = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": "BAD-DATE-RANGE",
                "poczatekInspekcji": "2026-09-10",
                "koniecInspekcji": "2026-09-02",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(invalid_business_dates.status_code, 400)

        invalid_schema = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": "BAD-SCHEMA",
                "poczatekInspekcji": "2026-09-01",
                "koniecInspekcji": "2026-09-02",
                "osobaKierujacaUserId": admin_id,
                "dataZalecenList": [123],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(invalid_schema.status_code, 422)

    def test_inspection_update_single_field_writes_single_audit_row(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"AUDIT-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-10-01",
                "koniecInspekcji": "2026-10-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 201, created.text)
        created_body = created.json()
        inspection_id = int(created_body["id"])
        inspection_code = str(created_body["kodInspekcji"])

        lock = self.client.post(
            f"/api/locks/inspections/{inspection_id}/acquire",
            headers=self._admin_headers(),
        )
        self.assertEqual(lock.status_code, 200, lock.text)
        lock_token = str(lock.json()["lockToken"])

        updated = self.client.put(
            f"/api/structure/inspections/{inspection_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": created_body["zaktualizowanoO"],
                "dataDoreczeniaProtokolu": "2026-10-11",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(updated.status_code, 200, updated.text)

        logs = self.client.get(
            "/api/audit-log",
            params={
                "rejestr": "inspekcje",
                "akcja": "UPDATE",
                "id_rejestru": inspection_code,
                "limit": 50,
                "offset": 0,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(logs.status_code, 200, logs.text)
        body = logs.json()

        self.assertEqual(int(body["total"]), 1)
        self.assertEqual(len(body["items"]), 1)
        self.assertEqual(body["items"][0]["pole"], "Data doręczenia protokołu")
        self.assertEqual(body["items"][0]["przed"], None)
        self.assertEqual(body["items"][0]["po"], "2026-10-11")

    def test_inspection_letter_date_absence_flags_semantics(self) -> None:
        admin_login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(admin_login.status_code, 200, admin_login.text)
        admin_id = int(admin_login.json()["user"]["id"])

        created = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ABS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-03",
                "osobaKierujacaUserId": admin_id,
                "dataDoreczeniaPisma": None,
                "brakDataDoreczeniaPisma": True,
                "dataWyslaniaPismaZZastrzezeniami": "2026-11-02",
                "brakDataWyslaniaPismaZZastrzezeniami": True,
                "dataPismaZastrzezenia": None,
                "brakDataPismaZastrzezenia": True,
                "dataWplywuPisma": None,
                "brakDataWplywuPisma": False,
                "dataPismaZOdpowiedzia": "2026-11-04",
                "brakDataPismaZOdpowiedzia": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created.status_code, 422, created.text)

        created_ok = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ABS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-03",
                "osobaKierujacaUserId": admin_id,
                "dataDoreczeniaPisma": None,
                "brakDataDoreczeniaPisma": True,
                "dataPismaZastrzezenia": "2026-11-02",
                "brakDataPismaZastrzezenia": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_ok.status_code, 422, created_ok.text)

        created_ok = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ABS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-03",
                "osobaKierujacaUserId": admin_id,
                "dataDoreczeniaPisma": None,
                "brakDataDoreczeniaPisma": True,
                "dataPismaZastrzezenia": None,
                "brakDataPismaZastrzezenia": False,
                "dataWplywuPisma": "2026-11-02",
                "brakDataWplywuPisma": True,
                "dataPismaZOdpowiedzia": None,
                "brakDataPismaZOdpowiedzia": True,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_ok.status_code, 422, created_ok.text)

        created_ok = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"ABS-{uuid.uuid4().hex[:6]}",
                "typInspekcji": "Kontrola",
                "poczatekInspekcji": "2026-11-01",
                "koniecInspekcji": "2026-11-03",
                "osobaKierujacaUserId": admin_id,
                "dataDoreczeniaPisma": None,
                "brakDataDoreczeniaPisma": True,
                "dataWyslaniaPismaZZastrzezeniami": None,
                "brakDataWyslaniaPismaZZastrzezeniami": False,
                "dataPismaZastrzezenia": None,
                "brakDataPismaZastrzezenia": False,
                "dataWplywuPisma": None,
                "brakDataWplywuPisma": False,
                "dataPismaZOdpowiedzia": "2026-11-04",
                "brakDataPismaZOdpowiedzia": False,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_ok.status_code, 201, created_ok.text)
        body = created_ok.json()
        inspection_id = int(body["id"])
        self.assertTrue(body["brakDataDoreczeniaPisma"])
        self.assertIsNone(body["dataDoreczeniaPisma"])
        self.assertFalse(body["brakDataWyslaniaPismaZZastrzezeniami"])
        self.assertIsNone(body["dataWyslaniaPismaZZastrzezeniami"])
        self.assertFalse(body["brakDataPismaZOdpowiedzia"])
        self.assertEqual(body["dataPismaZOdpowiedzia"], "2026-11-04")

        def _put_with_lock(update_payload: dict[str, object]):
            detail = self.client.get(
                f"/api/structure/inspections/{inspection_id}",
                headers=self._admin_headers(),
            )
            self.assertEqual(detail.status_code, 200, detail.text)

            lock_acquire = self.client.post(
                f"/api/locks/inspections/{inspection_id}/acquire",
                headers=self._admin_headers(),
            )
            self.assertEqual(lock_acquire.status_code, 200, lock_acquire.text)
            lock_token = str(lock_acquire.json()["lockToken"])

            payload = dict(update_payload)
            payload["lockToken"] = lock_token
            payload["expectedUpdatedAt"] = detail.json()["zaktualizowanoO"]
            response = self.client.put(
                f"/api/structure/inspections/{inspection_id}",
                json=payload,
                headers=self._admin_headers(),
            )

            release = self.client.post(
                f"/api/locks/inspections/{inspection_id}/release",
                json={"lockToken": lock_token},
                headers=self._admin_headers(),
            )
            self.assertEqual(release.status_code, 200, release.text)
            return response

        invalid_token = _put_with_lock({"dataPismaZastrzezenia": "brak pisma"})
        self.assertEqual(invalid_token.status_code, 422, invalid_token.text)

        force_absence = _put_with_lock(
            {
                "dataPismaZOdpowiedzia": None,
                "brakDataPismaZOdpowiedzia": True,
                "dataWyslaniaPismaZZastrzezeniami": None,
                "brakDataWyslaniaPismaZZastrzezeniami": True,
            }
        )
        self.assertEqual(force_absence.status_code, 200, force_absence.text)
        body_after = force_absence.json()
        self.assertTrue(body_after["brakDataPismaZOdpowiedzia"])
        self.assertIsNone(body_after["dataPismaZOdpowiedzia"])
        self.assertTrue(body_after["brakDataWyslaniaPismaZZastrzezeniami"])
        self.assertIsNone(body_after["dataWyslaniaPismaZZastrzezeniami"])

        invalid_noty_token = _put_with_lock({"dataAkceptacjiNotyList": ["0000-00-00"]})
        self.assertEqual(invalid_noty_token.status_code, 422, invalid_noty_token.text)

        invalid_noty_conflict = _put_with_lock(
            {
                "dataAkceptacjiNotyList": ["2026-11-08"],
                "brakDatAkceptacjiNoty": True,
            }
        )
        self.assertEqual(invalid_noty_conflict.status_code, 422, invalid_noty_conflict.text)

        noty_brak = _put_with_lock({"brakDatAkceptacjiNoty": True})
        self.assertEqual(noty_brak.status_code, 200, noty_brak.text)
        body_noty_brak = noty_brak.json()
        self.assertTrue(body_noty_brak["brakDatAkceptacjiNoty"])
        self.assertEqual(body_noty_brak["dataAkceptacjiNotyList"], [])

        noty_dates = _put_with_lock(
            {
                "dataAkceptacjiNotyList": ["2026-11-09", "2026-11-10"],
                "brakDatAkceptacjiNoty": False,
            }
        )
        self.assertEqual(noty_dates.status_code, 200, noty_dates.text)
        body_noty_dates = noty_dates.json()
        self.assertFalse(body_noty_dates["brakDatAkceptacjiNoty"])
        self.assertEqual(body_noty_dates["dataAkceptacjiNotyList"], ["2026-11-09", "2026-11-10"])

    def test_audit_log_pole_contains_and_and_semantics_with_total(self) -> None:
        self._seed_audit_log_fixture()

        response = self.client.get(
            "/api/audit-log",
            params={
                "pole": "doręczenia",
                "pole_mode": "contains",
                "uzytkownik": " ADMIN ",
                "akcja": "update",
                "rejestr": "INSPEKCJE",
                "id_rejestru": "ins-100",
                "data_od": "2026-10-01",
                "data_do": "2026-10-31",
                "limit": 50,
                "offset": 0,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(response.status_code, 200, response.text)
        body = response.json()

        self.assertEqual(int(body["total"]), 1)
        self.assertEqual(len(body["items"]), 1)
        self.assertEqual(body["items"][0]["pole"], "Data doręczenia protokołu")

    def test_audit_log_pole_exact_and_no_pole_backward_compat_total(self) -> None:
        self._seed_audit_log_fixture()

        exact = self.client.get(
            "/api/audit-log",
            params={
                "pole": "status",
                "pole_mode": "exact",
                "uzytkownik": "admin",
                "akcja": "UPDATE",
                "rejestr": "inspekcje",
                "id_rejestru": "INS-100",
                "limit": 50,
                "offset": 0,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(exact.status_code, 200, exact.text)
        exact_body = exact.json()
        self.assertEqual(int(exact_body["total"]), 1)
        self.assertEqual(len(exact_body["items"]), 1)
        self.assertEqual(exact_body["items"][0]["pole"], "Status")

        without_pole = self.client.get(
            "/api/audit-log",
            params={
                "uzytkownik": "admin",
                "akcja": "UPDATE",
                "rejestr": "inspekcje",
                "id_rejestru": "INS-100",
                "limit": 1,
                "offset": 0,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(without_pole.status_code, 200, without_pole.text)
        without_pole_body = without_pole.json()
        self.assertEqual(int(without_pole_body["total"]), 2)
        self.assertEqual(len(without_pole_body["items"]), 1)

    def test_audit_log_filter_options_context_and_limit(self) -> None:
        self._seed_audit_log_fixture()
        for idx in range(30):
            self._insert_audit_log_row(
                session_id=f"extra-{idx}",
                uzytkownik="admin",
                akcja="UPDATE",
                data_godz=f"2026-11-01T10:{idx:02d}:00.000Z",
                rejestr="inspekcje",
                rekord_kod=f"INS-EXTRA-{idx:02d}",
                pole=f"Pole dodatkowe {idx:02d}",
                przed=None,
                po=None,
            )

        contextual = self.client.get(
            "/api/audit-log/filter-options",
            params={
                "rejestr": "inspekcje",
                "akcja": "UPDATE",
                "uzytkownik": "admin",
                "id_rejestru": "INS-100",
                "limit": 50,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(contextual.status_code, 200, contextual.text)
        contextual_body = contextual.json()
        options = contextual_body["options"]

        self.assertEqual(options["uzytkownik"], ["admin"])
        self.assertEqual(options["akcja"], ["UPDATE"])
        self.assertEqual(options["rejestr"], ["inspekcje"])
        self.assertEqual(options["id_rejestru"], ["INS-100"])
        self.assertEqual(options["pole"], ["Data doręczenia protokołu", "Status"])

        limited = self.client.get(
            "/api/audit-log/filter-options",
            params={
                "rejestr": "inspekcje",
                "akcja": "UPDATE",
                "uzytkownik": "admin",
                "fraza": "pole dodatkowe",
                "limit": 10,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(limited.status_code, 200, limited.text)
        limited_body = limited.json()

        self.assertEqual(int(limited_body["limit"]), 10)
        self.assertLessEqual(len(limited_body["options"]["pole"]), 10)
        self.assertEqual(len(limited_body["options"]["pole"]), 10)


if __name__ == "__main__":
    unittest.main(verbosity=2)

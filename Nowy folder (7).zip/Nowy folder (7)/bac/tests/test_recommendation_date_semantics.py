from __future__ import annotations

import tempfile
import unittest
import uuid
from pathlib import Path

from fastapi.testclient import TestClient

from app.database import connection as db_connection


class RecommendationDateSemanticsTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp_dir_path = Path(tempfile.mkdtemp(prefix="rejestr-tests-"))
        cls._original_db_path = db_connection.DB_PATH
        db_connection.DB_PATH = cls._tmp_dir_path / "bootstrap_rejestr_recommendation_dates.db"

        from app.main import app

        cls.client = TestClient(app)

    def setUp(self) -> None:
        db_connection.DB_PATH = self._tmp_dir_path / f"rejestr_recommendation_dates_{uuid.uuid4().hex}.db"

        from app.db import init_db

        init_db()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.client.close()
        db_connection.DB_PATH = cls._original_db_path

    def _admin_headers(self) -> dict[str, str]:
        return {"X-Operator-Login": "admin"}

    def _admin_id(self) -> int:
        login = self.client.post("/api/auth/login", json={"login": "admin"})
        self.assertEqual(login.status_code, 200, login.text)
        return int(login.json()["user"]["id"])

    def test_create_recommendation_uses_canonical_date_semantics(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-04-01",
                "koniecInspekcji": "2026-04-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "dataZalecen": "2026-04-17",
                "terminyWykonaniaZalecenList": ["2026-04-26", "2026-04-30"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)

        body = created_recommendation.json()
        self.assertEqual(body["dataZalecen"], "2026-04-17")
        self.assertEqual(body["terminyWykonaniaZalecenList"], ["2026-04-26", "2026-04-30"])

        # Legacy aliases should still expose the same semantic data during transition.
        self.assertEqual(body["terminWykonaniaZalecen"], "2026-04-26")
        self.assertEqual(body["dataZalecenList"], ["2026-04-26", "2026-04-30"])

    def test_update_recommendation_single_and_list_are_independent(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-04-01",
                "koniecInspekcji": "2026-04-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "dataZalecen": "2026-04-17",
                "terminyWykonaniaZalecenList": ["2026-04-26"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)
        rec = created_recommendation.json()
        rec_id = int(rec["id"])

        lock = self.client.post(
            f"/api/locks/recommendations/{rec_id}/acquire",
            headers=self._admin_headers(),
        )
        self.assertEqual(lock.status_code, 200, lock.text)
        lock_token = str(lock.json()["lockToken"])

        updated = self.client.put(
            f"/api/recommendations/{rec_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": rec["zaktualizowanoO"],
                "dataZalecen": "2026-04-19",
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(updated.status_code, 200, updated.text)
        updated_body = updated.json()

        self.assertEqual(updated_body["dataZalecen"], "2026-04-19")
        self.assertEqual(updated_body["terminyWykonaniaZalecenList"], ["2026-04-26"])
        self.assertEqual(updated_body["terminWykonaniaZalecen"], "2026-04-26")

    def test_inspection_data_zalecen_comes_from_recommendation_single_date(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-04-01",
                "koniecInspekcji": "2026-04-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "dataZalecen": "2026-04-17",
                "terminyWykonaniaZalecenList": ["2026-04-26", "2026-04-30"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)

        inspection_after = self.client.get(
            f"/api/structure/inspections/{inspection_id}",
            headers=self._admin_headers(),
        )
        self.assertEqual(inspection_after.status_code, 200, inspection_after.text)
        body = inspection_after.json()

        self.assertEqual(body["dataZalecen"], "2026-04-17")
        self.assertEqual(body["dataZalecenList"], ["2026-04-17"])

    def test_canonical_data_zalecen_wins_when_legacy_field_also_sent(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-04-01",
                "koniecInspekcji": "2026-04-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "dataZalecen": "2026-04-17",
                "terminWykonaniaZalecen": "2026-05-12",
                "terminyWykonaniaZalecenList": ["2026-06-20"],
                "dataZalecenList": ["2026-06-25"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)

        body = created_recommendation.json()
        self.assertEqual(body["dataZalecen"], "2026-04-17")
        self.assertEqual(body["terminyWykonaniaZalecenList"], ["2026-06-20"])
        self.assertEqual(body["terminWykonaniaZalecen"], "2026-06-20")

    def test_create_recommendation_absence_flags_and_validation(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-05-01",
                "koniecInspekcji": "2026-05-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_brak = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "brakTerminowWykonaniaZalecen": True,
                "brakDatAkceptacjiNotyWeryfikacji": True,
                "terminyWykonaniaZalecenList": [],
                "dataAkceptacjiNotyWeryfikacjiList": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_brak.status_code, 201, created_brak.text)
        body_brak = created_brak.json()
        self.assertTrue(body_brak["brakTerminowWykonaniaZalecen"])
        self.assertTrue(body_brak["brakDatAkceptacjiNotyWeryfikacji"])
        self.assertEqual(body_brak["terminyWykonaniaZalecenList"], [])
        self.assertEqual(body_brak["dataAkceptacjiNotyWeryfikacjiList"], [])

        invalid_brak_with_dates = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 2,
                "brakTerminowWykonaniaZalecen": True,
                "terminyWykonaniaZalecenList": ["2026-05-20"],
                "brakDatAkceptacjiNotyWeryfikacji": False,
                "dataAkceptacjiNotyWeryfikacjiList": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(invalid_brak_with_dates.status_code, 422, invalid_brak_with_dates.text)

        created_dash = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 3,
                "brakTerminowWykonaniaZalecen": False,
                "terminyWykonaniaZalecenList": [],
                "brakDatAkceptacjiNotyWeryfikacji": False,
                "dataAkceptacjiNotyWeryfikacjiList": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_dash.status_code, 201, created_dash.text)
        body_dash = created_dash.json()
        self.assertFalse(body_dash["brakTerminowWykonaniaZalecen"])
        self.assertFalse(body_dash["brakDatAkceptacjiNotyWeryfikacji"])

    def test_update_recommendation_switches_between_dates_dash_and_brak(self) -> None:
        admin_id = self._admin_id()

        created_inspection = self.client.post(
            "/api/structure/inspections",
            json={
                "nazwaPodmiotu": f"P-{uuid.uuid4().hex[:6]}",
                "poczatekInspekcji": "2026-06-01",
                "koniecInspekcji": "2026-06-05",
                "osobaKierujacaUserId": admin_id,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_inspection.status_code, 201, created_inspection.text)
        inspection_id = int(created_inspection.json()["id"])

        created_recommendation = self.client.post(
            "/api/recommendations",
            json={
                "inspectionId": inspection_id,
                "pozycja": 1,
                "terminyWykonaniaZalecenList": ["2026-06-10", "2026-06-10", "2026-06-08"],
                "dataAkceptacjiNotyWeryfikacjiList": ["2026-06-20"],
                "brakTerminowWykonaniaZalecen": False,
                "brakDatAkceptacjiNotyWeryfikacji": False,
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(created_recommendation.status_code, 201, created_recommendation.text)
        rec = created_recommendation.json()
        rec_id = int(rec["id"])
        self.assertEqual(rec["terminyWykonaniaZalecenList"], ["2026-06-08", "2026-06-10"])
        self.assertFalse(rec["brakTerminowWykonaniaZalecen"])

        lock = self.client.post(
            f"/api/locks/recommendations/{rec_id}/acquire",
            headers=self._admin_headers(),
        )
        self.assertEqual(lock.status_code, 200, lock.text)
        lock_token = str(lock.json()["lockToken"])

        to_brak = self.client.put(
            f"/api/recommendations/{rec_id}",
            json={
                "lockToken": lock_token,
                "expectedUpdatedAt": rec["zaktualizowanoO"],
                "brakTerminowWykonaniaZalecen": True,
                "terminyWykonaniaZalecenList": [],
                "brakDatAkceptacjiNotyWeryfikacji": False,
                "dataAkceptacjiNotyWeryfikacjiList": ["2026-06-21"],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(to_brak.status_code, 200, to_brak.text)
        body_brak = to_brak.json()
        self.assertTrue(body_brak["brakTerminowWykonaniaZalecen"])
        self.assertEqual(body_brak["terminyWykonaniaZalecenList"], [])
        self.assertEqual(body_brak["dataAkceptacjiNotyWeryfikacjiList"], ["2026-06-21"])

        lock2 = self.client.post(
            f"/api/locks/recommendations/{rec_id}/acquire",
            headers=self._admin_headers(),
        )
        self.assertEqual(lock2.status_code, 200, lock2.text)
        lock_token2 = str(lock2.json()["lockToken"])

        to_dash = self.client.put(
            f"/api/recommendations/{rec_id}",
            json={
                "lockToken": lock_token2,
                "expectedUpdatedAt": body_brak["zaktualizowanoO"],
                "brakTerminowWykonaniaZalecen": False,
                "terminyWykonaniaZalecenList": [],
                "brakDatAkceptacjiNotyWeryfikacji": False,
                "dataAkceptacjiNotyWeryfikacjiList": [],
            },
            headers=self._admin_headers(),
        )
        self.assertEqual(to_dash.status_code, 200, to_dash.text)
        body_dash = to_dash.json()
        self.assertFalse(body_dash["brakTerminowWykonaniaZalecen"])
        self.assertEqual(body_dash["terminyWykonaniaZalecenList"], [])
        self.assertFalse(body_dash["brakDatAkceptacjiNotyWeryfikacji"])
        self.assertEqual(body_dash["dataAkceptacjiNotyWeryfikacjiList"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)

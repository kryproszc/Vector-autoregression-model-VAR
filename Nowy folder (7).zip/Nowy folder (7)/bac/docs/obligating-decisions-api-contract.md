# Obligating Decisions API Contract (People Options + Save Validation)

## Scope

This document covers endpoint contracts for:

- `GET /api/obligating-decisions/available-first-instance-people`
- `GET /api/obligating-decisions/available-second-instance-people`
- `POST /api/obligating-decisions`
- `PUT /api/obligating-decisions/{decision_id}`

## People Options Contract

Both endpoints return an object with `items` array (not a top-level array):

```json
{
  "items": [
    {
      "id": 1399,
      "displayName": "Jan Kowalski",
      "login": "a-user1",
      "listVisibility": "visible",
      "accountType": "diu"
    }
  ]
}
```

### Preferred label field

- `displayName` is the preferred primary UI label.
- `label` is a backward-compatible alias/fallback.

### Stable fields returned for each person option

- `id` (dictionary item id, `slownik_pozycje.id`)
- `userId` (linked user id)
- `displayName` (preferred)
- `listVisibility`
- optional `login`
- `accountType`
- `label` (fallback alias)
- `createdByOperator`
- `creatorLogin`
- `kodPozycji`
- `nazwaPozycji`
- `skrotPozycji`

### Filtering rules

- User activity (`aktywny`) is **not** used as a filter.
- Only hidden users are excluded (`listVisibility == hidden`).
- Both active and inactive users are returned if not hidden.

### RBAC scope

- `director`: full scope.
- `team_lead`: user is visible if:
  - in the same team, or
  - created by this operator (`created_by_user_id == operator.id`).
- Other roles: unchanged policy (self-scope only, no extra exceptions introduced).

## Domain Error Code Map (create/update validation)

The endpoints return domain-style errors in `detail` with at least:

- `detail.code`
- `detail.message`

Example shape:

```json
{
  "detail": {
    "code": "LEADER_OUT_OF_SCOPE",
    "message": "Brak uprawnien do przypisania wybranych osob",
    "invalidIds": [123, 124]
  }
}
```

### `LEADER_OUT_OF_SCOPE`

- HTTP: `403`
- Meaning: selected person ids are outside operator RBAC scope.
- Where: create/update person assignments.

### `USER_HIDDEN_NOT_ALLOWED`

- HTTP: `422`
- Meaning: hidden user cannot be assigned to decision person fields.
- Where: id validation for `kodTypu=osoby`.
- Extra fields: `field`, `userId`.

### `PERMISSION_DENIED_I_INSTANCE`

- HTTP: `403`
- Meaning: no permission for I-instance edit/assignment/comment operations.
- Where: update permission checks for I-instance fields.

### `PERMISSION_DENIED_II_INSTANCE`

- HTTP: `403`
- Meaning: no permission for II-instance edit/assignment or II usage before inflow date.
- Where: create/update permission checks for II-instance fields.

### `PERMISSION_DENIED_CREATE_FOR_RECOMMENDATION`

- HTTP: `403`
- Meaning: no permission to create/update decision for linked recommendation scope.
- Where: create and update when recommendation is set/changed.

### `VALIDATION_RECOMMENDATION_REQUIRED`

- HTTP: `400`
- Meaning: `recommendationKodZalecenia` is required on create.
- Where: create.

## Non-domain errors still possible

These endpoints may also return plain validation/technical errors (without `detail.code`) from shared validation and framework-level checks (for example malformed IDs, invalid dates, lock checks, missing operator header).

Additionally, people-options endpoints can return a technical domain error:

- `PEOPLE_OPTIONS_CONTRACT_VIOLATION` (HTTP `500`) when a required contract field is missing/invalid in a generated item.

## Observability (release diagnostics)

For both people-options endpoints, technical logs include:

- `operatorLogin`, `role`
- candidates count before any filter
- count after hidden filter
- count after RBAC filter

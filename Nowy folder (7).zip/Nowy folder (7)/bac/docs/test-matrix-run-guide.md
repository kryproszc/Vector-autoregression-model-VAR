# Run Guide - Macierz C1-C8

## Co jest gotowe

- Runner: scripts/run_full_matrix_and_export_excel.py
- Helper API: scripts/run_concurrency_checks.py
- Skrypt pelny: scripts/run_matrix_full.ps1
- Skrypt szybki smoke: scripts/run_matrix_smoke.ps1
- Skrypt wielogodzinny: scripts/run_matrix_long.ps1
- Skrypt cross-module soak (Inspekcje/Zalecenia/Wnioski/Decyzje): scripts/run_cross_module_soak.py
- Wrapper z parametrem minut: scripts/run_cross_module_soak.ps1

## Czas wykonania

- Smoke: okolo 2-3 min
- Pelny C1-C7: okolo 16-22 min
- C8 (restart pod obciazeniem): dodatkowe 5-10 min, krok kontrolowany
- Profil wielogodzinny: od 2h do 8h (zalezy od parametru Hours)

## Uruchomienie

W katalogu repo uruchom:

```powershell
./scripts/run_matrix_full.ps1
```

Skalowalny test cross-module (obejmuje Inspekcje, Zalecenia, Wnioski sankcyjne, Decyzje zobowiazujace):

````powershell
./scripts/run_cross_module_soak.ps1 -Minutes 10
./scripts/run_cross_module_soak.ps1 -Minutes 300

Bootstrap danych testowych (na starcie runu):
- Dyrektor tworzy zespoly (domyslnie A,B,C,D) jako Zespol-A, Zespol-B itd.
- Dyrektor tworzy i przypisuje kierownikow: a-kier1, b-kier1 itd.
- Kierownicy tworza pracownikow we wlasnych zespolach: a-user1, a-user2, b-user1 itd.

Mozesz to parametryzowac:

```powershell
./scripts/run_cross_module_soak.ps1 -Minutes 10 -TeamCodes "A,B" -WorkersPerTeam 3
````

````

Gdzie:
- 10 minut = szybka walidacja stabilnosci
- 300 minut = 5 godzin

Albo profil wielogodzinny (domyslnie 4h):

```powershell
./scripts/run_matrix_long.ps1
````

Przyklady:

```powershell
./scripts/run_matrix_long.ps1 -Hours 2
./scripts/run_matrix_long.ps1 -Hours 4
./scripts/run_matrix_long.ps1 -Hours 8
```

Wynik XLSX zapisze sie jako:

- docs/test-matrix-results.xlsx
- docs/test-matrix-results-soak-<X>h.xlsx (dla run_matrix_long.ps1)

Wynik JSON cross-module zapisze sie jako:

- docs/cross-module-soak-<X>min.json

## Zawartosc Excela

- Zakladka Podsumowanie
- Zakladki C1, C2, C3, C4, C5, C6, C7, C8
- W kazdej zakladce: cel, co test zrobil, metryki liczbowe, wnioski

## Uwaga o C8

Aktualnie C8 jest oznaczane jako PENDING, bo wymaga kontrolowanego restartu procesu podczas ruchu.
C8 mozna domknac osobnym krokiem po uruchomieniu pelnego raportu.

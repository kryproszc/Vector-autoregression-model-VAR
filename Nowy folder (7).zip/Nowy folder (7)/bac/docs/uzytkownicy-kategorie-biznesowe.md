# Kategorie uzytkownikow - perspektywa biznesowa

## Cel
Zdefiniowac jasne, wspolne kategorie uzytkownikow jako podstawe do decyzji o tworzeniu i edycji inspekcji.

## Tabela kategorii

| Obszar | Kategoria uzytkownika | Znaczenie biznesowe |
|---|---|---|
| Rola organizacyjna | Dyrektor | Nadzor calosciowy i decyzje przekrojowe |
| Rola organizacyjna | Kierownik zespolu | Odpowiedzialnosc za prace zespolu i prowadzenie spraw w swoim obszarze |
| Rola organizacyjna | Inspektor | Realizacja operacyjna zadan i obsluga spraw |
| Dostep operacyjny | Uzytkownik zewnetrzny | Dostep ograniczony, bez dzialan modyfikujacych |
| Typ konta | DIU | Konto standardowe do pracy operacyjnej |
| Typ konta | Techniczne | Konto pomocnicze/systemowe dla ciaglosci procesu |
| Typ konta | Obserwator | Wglad informacyjny bez ingerencji w dane |
| Status konta | Aktywny | Uzytkownik dostepny do biezacej pracy |
| Status konta | Nieaktywny | Uzytkownik wylaczony z biezacej obslugi |
| Widocznosc na listach | Widoczny | Uzytkownik dostepny do wyboru w procesach |
| Widocznosc na listach | Ukryty | Uzytkownik niewidoczny w standardowej pracy operacyjnej |
| Przynaleznosc organizacyjna | Zespol / brak zespolu | Okresla obszar odpowiedzialnosci i sciezke pracy |

## Wniosek dla zarzadzania
Ujednolicenie tych kategorii upraszcza decyzje, skraca czas obslugi spraw i ogranicza ryzyko bledow organizacyjnych.

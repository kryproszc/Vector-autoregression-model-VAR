from __future__ import annotations

import sqlite3
from pathlib import Path


CREATE_SLOWNIK_TYPY_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS slownik_typy (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kod_typu TEXT NOT NULL UNIQUE,
    nazwa_typu TEXT NOT NULL,
    opis TEXT,
    aktywny INTEGER NOT NULL DEFAULT 1,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
)
"""

CREATE_SLOWNIK_POZYCJE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS slownik_pozycje (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kod_typu TEXT NOT NULL,
    kod_pozycji TEXT NOT NULL,
    nazwa_pozycji TEXT NOT NULL,
    skrot_pozycji TEXT,
    kolejnosc INTEGER,
    aktywny INTEGER NOT NULL DEFAULT 1,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (kod_typu) REFERENCES slownik_typy(kod_typu),
    UNIQUE (kod_typu, kod_pozycji),
    CHECK (kod_pozycji = UPPER(kod_pozycji) AND INSTR(kod_pozycji, ' ') = 0)
)
"""

CREATE_INDEX_SLOWNIK_POZYCJE_KOD_TYPU_SQL = """
CREATE INDEX IF NOT EXISTS idx_slownik_pozycje_kod_typu
ON slownik_pozycje(kod_typu)
"""

CREATE_TEAMS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kod TEXT NOT NULL UNIQUE,
    nazwa TEXT NOT NULL,
    slownik_pozycja_id INTEGER,
    kierownik_user_id INTEGER,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (slownik_pozycja_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (kierownik_user_id) REFERENCES users(id)
)
"""

CREATE_USERS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    login TEXT NOT NULL UNIQUE,
    imie TEXT NOT NULL,
    nazwisko TEXT NOT NULL,
    email TEXT,
    rola_id INTEGER NOT NULL,
    zespol_id INTEGER,
    aktywny INTEGER NOT NULL DEFAULT 1,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (zespol_id) REFERENCES teams(id)
)
"""

CREATE_INSPECTIONS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS inspections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_by_user_id INTEGER NOT NULL,
    nazwa_podmiotu_id INTEGER,
    typ_inspekcji_id INTEGER,
    zakres_inspekcji_id INTEGER,
    poczatek_inspekcji TEXT NOT NULL,
    koniec_inspekcji TEXT NOT NULL,
    osoba_kierujaca_user_id INTEGER,
    osoba_kierujaca_tekst TEXT,
    rynek_id INTEGER,
    rodzaj_podmiotu_id INTEGER,
    sklad_zespolu_tekst TEXT,
    komentarz TEXT,
    status_inspekcji_id INTEGER,
    data_protokolu_sprawozdania TEXT,
    data_doreczenia_protokolu TEXT,
    data_akceptacji_sprawozdania TEXT,
    data_doreczenia_pisma TEXT,
    data_pisma_zastrzezenia TEXT,
    data_wplywu_pisma TEXT,
    data_pisma_z_odpowiedzia TEXT,
    data_akceptacji_noty TEXT,
    data_zalecen TEXT,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by_user_id) REFERENCES users(id),
    FOREIGN KEY (nazwa_podmiotu_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (typ_inspekcji_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (zakres_inspekcji_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (osoba_kierujaca_user_id) REFERENCES users(id),
    FOREIGN KEY (rynek_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (rodzaj_podmiotu_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (status_inspekcji_id) REFERENCES slownik_pozycje(id)
)
"""

CREATE_INSPECTION_MEMBERS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS inspection_members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inspection_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE (inspection_id, user_id)
)
"""

CREATE_INDEX_INSPECTION_MEMBERS_INSPECTION_SQL = """
CREATE INDEX IF NOT EXISTS idx_inspection_members_inspection_id
ON inspection_members(inspection_id)
"""

CREATE_INDEX_INSPECTION_MEMBERS_USER_SQL = """
CREATE INDEX IF NOT EXISTS idx_inspection_members_user_id
ON inspection_members(user_id)
"""

CREATE_INSPECTION_MULTI_DATES_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS inspection_multi_dates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inspection_id INTEGER NOT NULL,
    date_type TEXT NOT NULL CHECK (date_type IN ('ZALECENIE', 'AKCEPTACJA_NOTY')),
    date_value TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by_user_id INTEGER NOT NULL,
    updated_by_user_id INTEGER NOT NULL,
    FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by_user_id) REFERENCES users(id),
    FOREIGN KEY (updated_by_user_id) REFERENCES users(id),
    UNIQUE (inspection_id, date_type, date_value)
)
"""

CREATE_INDEX_MULTI_DATES_INSPECTION_SQL = """
CREATE INDEX IF NOT EXISTS idx_inspection_multi_dates_inspection
ON inspection_multi_dates(inspection_id)
"""

CREATE_INDEX_MULTI_DATES_TYPE_VALUE_SQL = """
CREATE INDEX IF NOT EXISTS idx_inspection_multi_dates_type_value
ON inspection_multi_dates(date_type, date_value)
"""

CREATE_RECOMMENDATIONS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS recommendations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    inspection_id INTEGER,
    pozycja INTEGER NOT NULL,
    data_zalecen TEXT,
    nazwa_podmiotu_id INTEGER,
    status_zalecenia_id INTEGER,
    komentarz TEXT,
    created_by_user_id INTEGER NOT NULL,
    updated_by_user_id INTEGER NOT NULL,
    utworzono_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    zaktualizowano_o TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inspection_id) REFERENCES inspections(id) ON DELETE CASCADE,
    FOREIGN KEY (nazwa_podmiotu_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (status_zalecenia_id) REFERENCES slownik_pozycje(id),
    FOREIGN KEY (created_by_user_id) REFERENCES users(id),
    FOREIGN KEY (updated_by_user_id) REFERENCES users(id),
    UNIQUE (inspection_id, pozycja)
)
"""

CREATE_INDEX_RECOMMENDATIONS_INSPECTION_SQL = """
CREATE INDEX IF NOT EXISTS idx_recommendations_inspection
ON recommendations(inspection_id)
"""

CREATE_INDEX_RECOMMENDATIONS_STATUS_SQL = """
CREATE INDEX IF NOT EXISTS idx_recommendations_status
ON recommendations(status_zalecenia_id)
"""

CREATE_RECOMMENDATION_MULTI_DATES_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS recommendation_multi_dates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    recommendation_id INTEGER NOT NULL,
    date_type TEXT NOT NULL CHECK (date_type IN ('TERMIN_WYKONANIA_ZALECEN', 'AKCEPTACJA_NOTY_WERYFIKACJI')),
    date_value TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by_user_id INTEGER NOT NULL,
    updated_by_user_id INTEGER NOT NULL,
    FOREIGN KEY (recommendation_id) REFERENCES recommendations(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by_user_id) REFERENCES users(id),
    FOREIGN KEY (updated_by_user_id) REFERENCES users(id),
    UNIQUE (recommendation_id, date_type, date_value)
)
"""

CREATE_INDEX_RECOMMENDATION_MULTI_DATES_REC_SQL = """
CREATE INDEX IF NOT EXISTS idx_recommendation_multi_dates_rec
ON recommendation_multi_dates(recommendation_id)
"""

CREATE_INDEX_RECOMMENDATION_MULTI_DATES_TYPE_VALUE_SQL = """
CREATE INDEX IF NOT EXISTS idx_recommendation_multi_dates_type_value
ON recommendation_multi_dates(date_type, date_value)
"""


def _create_schema(conn: sqlite3.Connection) -> None:
    conn.execute(CREATE_SLOWNIK_TYPY_TABLE_SQL)
    conn.execute(CREATE_SLOWNIK_POZYCJE_TABLE_SQL)
    conn.execute(CREATE_INDEX_SLOWNIK_POZYCJE_KOD_TYPU_SQL)

    conn.execute(CREATE_TEAMS_TABLE_SQL)
    conn.execute(CREATE_USERS_TABLE_SQL)

    conn.execute(CREATE_INSPECTIONS_TABLE_SQL)
    conn.execute(CREATE_INSPECTION_MEMBERS_TABLE_SQL)
    conn.execute(CREATE_INDEX_INSPECTION_MEMBERS_INSPECTION_SQL)
    conn.execute(CREATE_INDEX_INSPECTION_MEMBERS_USER_SQL)

    conn.execute(CREATE_INSPECTION_MULTI_DATES_TABLE_SQL)
    conn.execute(CREATE_INDEX_MULTI_DATES_INSPECTION_SQL)
    conn.execute(CREATE_INDEX_MULTI_DATES_TYPE_VALUE_SQL)

    conn.execute(CREATE_RECOMMENDATIONS_TABLE_SQL)
    conn.execute(CREATE_INDEX_RECOMMENDATIONS_INSPECTION_SQL)
    conn.execute(CREATE_INDEX_RECOMMENDATIONS_STATUS_SQL)
    conn.execute(CREATE_RECOMMENDATION_MULTI_DATES_TABLE_SQL)
    conn.execute(CREATE_INDEX_RECOMMENDATION_MULTI_DATES_REC_SQL)
    conn.execute(CREATE_INDEX_RECOMMENDATION_MULTI_DATES_TYPE_VALUE_SQL)


def _truncate_all_tables(conn: sqlite3.Connection) -> None:
    # Child tables first, then parent tables.
    ordered_tables = [
        "inspection_members",
        "inspection_multi_dates",
        "recommendation_multi_dates",
        "recommendations",
        "inspections",
        "users",
        "teams",
        "slownik_pozycje",
        "slownik_typy",
    ]
    for table_name in ordered_tables:
        conn.execute(f"DELETE FROM {table_name}")

    conn.execute("DELETE FROM sqlite_sequence")


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    db_dir = base_dir / "Baza"
    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / "rejestr.db"

    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(db_path, timeout=max(1.0, busy_timeout_ms / 1000.0))
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute(f"PRAGMA journal_mode = {journal_mode}")
        conn.execute(f"PRAGMA busy_timeout = {busy_timeout_ms}")
        if journal_mode == "WAL":
            conn.execute("PRAGMA synchronous = NORMAL")
        _create_schema(conn)
        _truncate_all_tables(conn)
        conn.commit()
    finally:
        conn.close()

    print(f"OK: utworzono pusta baze i tabele: {db_path}")


if __name__ == "__main__":
    main()

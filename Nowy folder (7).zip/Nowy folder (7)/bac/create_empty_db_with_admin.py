from __future__ import annotations

import os
import sqlite3
from pathlib import Path

from create_empty_db import _create_schema, _truncate_all_tables


def _seed_admin(conn: sqlite3.Connection) -> None:
    conn.execute(
        """
        INSERT INTO users (login, imie, nazwisko, email, rola_id, zespol_id, aktywny)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        ("admin", "Admin", "Systemu", "admin@rejestr.local", 3, None, 1),
    )


def main() -> None:
    base_dir = Path(__file__).resolve().parent
    db_dir = base_dir / "Baza"
    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / "rejestr.db"

    busy_timeout_ms = int((os.getenv("SQLITE_BUSY_TIMEOUT_MS") or "5000").strip())
    journal_mode = (os.getenv("SQLITE_JOURNAL_MODE") or "WAL").strip().upper()

    conn = sqlite3.connect(db_path, timeout=max(1.0, busy_timeout_ms / 1000.0))
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute(f"PRAGMA journal_mode = {journal_mode}")
        conn.execute(f"PRAGMA busy_timeout = {busy_timeout_ms}")
        if journal_mode == "WAL":
            conn.execute("PRAGMA synchronous = NORMAL")
        _create_schema(conn)
        _truncate_all_tables(conn)
        _seed_admin(conn)
        conn.commit()
    finally:
        conn.close()

    print(f"OK: utworzono baze i tabele. Pozostawiono tylko admin: {db_path}")


if __name__ == "__main__":
    main()

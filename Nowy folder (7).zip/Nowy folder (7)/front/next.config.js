/**
 * Run `build` or `dev` with `SKIP_ENV_VALIDATION` to skip env validation. This is especially useful
 * for Docker builds.
 */
import "./src/env.js";

/** @type {import("next").NextConfig} */
const config = {
	allowedDevOrigins: ["192.168.1.139"],

	async rewrites() {
		const backendUrl = process.env.BACKEND_API_URL ?? "http://127.0.0.1:8002";

		return [
			{
				source: "/api/auth/:path*",
				destination: `${backendUrl}/api/auth/:path*`,
			},
			{
				source: "/api/admin/:path*",
				destination: `${backendUrl}/api/admin/:path*`,
			},
			{
				source: "/api/slowniki/:path*",
				destination: `${backendUrl}/api/slowniki/:path*`,
			},
			{
				source: "/api/risk-exposure/:path*",
				destination: `${backendUrl}/api/risk-exposure/:path*`,
			},
			{
				source: "/api/sanction-requests/:path*",
				destination: `${backendUrl}/api/sanction-requests/:path*`,
			},
			{
				source: "/api/structure/:path*",
				destination: `${backendUrl}/api/structure/:path*`,
			},
			{
				source: "/api/inspections/:path*",
				destination: `${backendUrl}/api/inspections/:path*`,
			},
			{
				source: "/api/recommendations/:path*",
				destination: `${backendUrl}/api/recommendations/:path*`,
			},
			{
				source: "/api/obligating-decisions/:path*",
				destination: `${backendUrl}/api/obligating-decisions/:path*`,
			},
			{
				source: "/api/reports/:path*",
				destination: `${backendUrl}/api/reports/:path*`,
			},
			{
				source: "/api/locks/:path*",
				destination: `${backendUrl}/api/locks/:path*`,
			},
			{
				source: "/api/audit-log",
				destination: `${backendUrl}/api/audit-log`,
			},
			{
				source: "/api/audit-log/:path*",
				destination: `${backendUrl}/api/audit-log/:path*`,
			},
		];
	},
};

export default config;

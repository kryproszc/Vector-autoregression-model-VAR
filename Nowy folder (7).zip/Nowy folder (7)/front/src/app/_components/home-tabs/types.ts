export type PanelMode = "registry" | "management";

export type AuthRole =
	| "director"
	| "team_lead"
	| "inspector"
	| "external_user";

export type MenuItem = {
	id: string;
	label: string;
};

export type MenuSection = {
	id: string;
	label: string;
	icon: "registers" | "tools";
	items: MenuItem[];
};

export type AuthUser = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	rolaId: number;
	rola: string;
	zespolId: number | null;
	zespolSkroconaNazwa: string | null;
	zespolPelnaNazwa: string | null;
	accountType?: string;
	effectivePermissions: string[];
	role: AuthRole;
	canViewTimeReports: boolean;
	canViewOwnTimeReport: boolean;
};

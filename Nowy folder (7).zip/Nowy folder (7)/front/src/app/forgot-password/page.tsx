"use client";

import Link from "next/link";
import { useState } from "react";

type ForgotPasswordResponse = {
	ok?: boolean;
	delivery?: "accepted" | "log" | "smtp";
	resetLink?: string;
};

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown };
		return typeof payload.detail === "string" ? payload.detail : "";
	} catch {
		return "";
	}
}

export default function ForgotPasswordPage() {
	const [loginOrEmail, setLoginOrEmail] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [success, setSuccess] = useState<string | null>(null);
	const [resetLink, setResetLink] = useState<string | null>(null);

	const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		if (!loginOrEmail.trim()) {
			setError("Podaj login lub e-mail.");
			return;
		}

		setError(null);
		setSuccess(null);
		setResetLink(null);
		setIsSubmitting(true);

		try {
			const response = await fetch("/api/auth/forgot-password", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					loginOrEmail: loginOrEmail.trim(),
				}),
			});

			if (response.status === 400) {
				setError("Podaj login lub e-mail.");
				return;
			}

			if (response.status === 429) {
				const detail = await readApiDetail(response);
				setError(detail || "Spróbuj ponownie za chwilę.");
				return;
			}

			if (!response.ok) {
				setError("Nie udało się wysłać linku resetu hasła.");
				return;
			}

			const payload = (await response.json()) as ForgotPasswordResponse;
			setSuccess("Jeśli konto istnieje, link resetu został przygotowany lub wysłany.");
			setResetLink(typeof payload.resetLink === "string" ? payload.resetLink : null);
		} catch {
			setError("Nie udało się wysłać linku resetu hasła.");
		} finally {
			setIsSubmitting(false);
		}
	};

	const handleCopyResetLink = async () => {
		if (!resetLink) {
			return;
		}

		try {
			await navigator.clipboard.writeText(resetLink);
		} catch {
			// Ignore clipboard failures.
		}
	};

	return (
		<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
			<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />

			<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
				<h1 className="font-bold text-3xl text-sky-300">Reset hasła</h1>
				<p className="mt-2 text-slate-200/80 text-sm">
					Podaj login lub e-mail. Jeśli konto istnieje, przygotujemy link resetu hasła.
				</p>

				<form className="mt-4 space-y-3" onSubmit={handleSubmit}>
					<label className="block text-slate-200 text-sm">
						<span className="mb-1.5 block font-medium">Login lub e-mail</span>
						<input
							type="text"
							value={loginOrEmail}
							onChange={(event) => setLoginOrEmail(event.target.value)}
							className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
						/>
					</label>

					{error ? (
						<p className="rounded-lg border border-rose-300/45 bg-rose-950/35 px-3 py-2 text-rose-200 text-sm">
							{error}
						</p>
					) : null}

					{success ? (
						<p className="rounded-lg border border-emerald-300/45 bg-emerald-950/30 px-3 py-2 text-emerald-200 text-sm">
							{success}
						</p>
					) : null}

					{resetLink ? (
						<div className="rounded-lg border border-emerald-300/45 bg-emerald-950/25 px-3 py-2 text-emerald-100 text-sm">
							<p>Tryb log: dostępny link resetu.</p>
							<div className="mt-2 flex flex-wrap gap-2">
								<button
									type="button"
									onClick={() => void handleCopyResetLink()}
									className="rounded-md border border-emerald-300 bg-white px-2.5 py-1.5 font-semibold text-emerald-800 text-xs transition-colors hover:bg-emerald-100"
								>
									Kopiuj link
								</button>
								<a
									href={resetLink}
									target="_blank"
									rel="noreferrer"
									className="rounded-md border border-emerald-300 bg-white px-2.5 py-1.5 font-semibold text-emerald-800 text-xs transition-colors hover:bg-emerald-100"
								>
									Otwórz link
								</a>
							</div>
						</div>
					) : null}

					<button
						type="submit"
						disabled={isSubmitting}
						className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-[#6ea3f0] bg-linear-to-r from-[#2f4f83] to-[#365e9a] font-semibold text-base text-white transition-colors hover:from-[#3a619e] hover:to-[#4673b4] disabled:cursor-not-allowed disabled:opacity-70"
					>
						{isSubmitting ? "Wysyłanie..." : "Wyślij link resetu"}
					</button>
				</form>

				<div className="mt-4 text-center text-sm">
					<Link href="/login" className="text-sky-300 hover:text-sky-200">
						Powrót do logowania
					</Link>
				</div>
			</div>
		</div>
	);
}

"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useMemo, useState } from "react";

type ValidateResult = {
	ok?: boolean;
	login?: string;
	expiresAt?: string;
};

function SetPasswordContent() {
	const router = useRouter();
	const searchParams = useSearchParams();
	const token = searchParams.get("token")?.trim() ?? "";

	const [isValidating, setIsValidating] = useState(true);
	const [isValid, setIsValid] = useState(false);
	const [login, setLogin] = useState("");
	const [expiresAt, setExpiresAt] = useState("");
	const [password, setPassword] = useState("");
	const [confirmPassword, setConfirmPassword] = useState("");
	const [error, setError] = useState<string | null>(null);
	const [success, setSuccess] = useState<string | null>(null);
	const [isSubmitting, setIsSubmitting] = useState(false);

	useEffect(() => {
		if (!token) {
			setError("Link niepoprawny lub wygasł.");
			setIsValid(false);
			setIsValidating(false);
			return;
		}

		const validateToken = async () => {
			setIsValidating(true);
			setError(null);
			setSuccess(null);

			try {
				const response = await fetch(
					`/api/auth/invitations/validate?token=${encodeURIComponent(token)}`,
					{
						method: "GET",
						headers: {
							"Content-Type": "application/json",
						},
						cache: "no-store",
					},
				);

				if (!response.ok) {
					if (response.status === 400) {
						setError("Link niepoprawny lub wygasł.");
					} else {
						setError("Nie udało się zweryfikować linku zaproszenia.");
					}
					setIsValid(false);
					return;
				}

				const payload = (await response.json()) as ValidateResult;
				setLogin(typeof payload.login === "string" ? payload.login : "");
				setExpiresAt(typeof payload.expiresAt === "string" ? payload.expiresAt : "");
				setIsValid(true);
			} catch {
				setError("Nie udało się zweryfikować linku zaproszenia.");
				setIsValid(false);
			} finally {
				setIsValidating(false);
			}
		};

		void validateToken();
	}, [token]);

	const expiresAtLabel = useMemo(() => {
		if (!expiresAt) {
			return "";
		}

		const parsed = new Date(expiresAt);
		if (Number.isNaN(parsed.getTime())) {
			return expiresAt;
		}

		return parsed.toLocaleString("pl-PL", {
			year: "numeric",
			month: "2-digit",
			day: "2-digit",
			hour: "2-digit",
			minute: "2-digit",
		});
	}, [expiresAt]);

	const submit = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		if (isSubmitting || success) {
			return;
		}

		if (password.length < 8) {
			setError("Hasło musi mieć co najmniej 8 znaków.");
			return;
		}

		if (password !== confirmPassword) {
			setError("Hasła nie są takie same.");
			return;
		}

		setIsSubmitting(true);
		setError(null);
		setSuccess(null);

		try {
			const response = await fetch("/api/auth/invitations/set-password", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ token, password }),
			});

			if (!response.ok) {
				if (response.status === 400) {
					setError("Link niepoprawny lub wygasł.");
				} else {
					setError("Nie udało się ustawić hasła.");
				}
				return;
			}

			setSuccess("Hasło zostało ustawione. Za chwilę nastąpi przekierowanie do logowania.");
			setTimeout(() => {
				router.replace("/login");
			}, 1200);
		} catch {
			setError("Nie udało się ustawić hasła.");
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
			<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />

			<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
				<h1 className="font-bold text-3xl text-sky-300">Ustaw hasło</h1>

				{isValidating ? (
					<p className="mt-3 text-slate-200/90 text-sm">Weryfikacja linku...</p>
				) : null}

				{error ? (
					<p className="mt-3 rounded-lg border border-rose-300/45 bg-rose-950/35 px-3 py-2 text-rose-200 text-sm">
						{error}
					</p>
				) : null}

				{success ? (
					<p className="mt-3 rounded-lg border border-emerald-300/45 bg-emerald-950/30 px-3 py-2 text-emerald-200 text-sm">
						{success}
					</p>
				) : null}

				{isValid && !isValidating ? (
					<>
						<p className="mt-3 text-slate-200/85 text-sm">
							Login: <span className="font-semibold text-slate-100">{login || "-"}</span>
						</p>
						{expiresAtLabel ? (
							<p className="mt-1 text-slate-300/75 text-xs">Ważność linku: {expiresAtLabel}</p>
						) : null}

						<form className="mt-4 space-y-3" onSubmit={submit}>
							<label className="block text-slate-200 text-sm">
								<span className="mb-1.5 block font-medium">Nowe hasło</span>
								<input
									type="password"
									value={password}
									onChange={(event) => setPassword(event.target.value)}
									minLength={8}
									className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
								/>
							</label>
							<label className="block text-slate-200 text-sm">
								<span className="mb-1.5 block font-medium">Powtórz hasło</span>
								<input
									type="password"
									value={confirmPassword}
									onChange={(event) => setConfirmPassword(event.target.value)}
									minLength={8}
									className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
								/>
							</label>

							<button
								type="submit"
								disabled={isSubmitting || Boolean(success)}
								className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-[#6ea3f0] bg-linear-to-r from-[#2f4f83] to-[#365e9a] font-semibold text-base text-white transition-colors hover:from-[#3a619e] hover:to-[#4673b4] disabled:cursor-not-allowed disabled:opacity-70"
							>
								{isSubmitting ? "Zapisywanie..." : "Ustaw hasło"}
							</button>
						</form>
					</>
				) : null}
			</div>
		</div>
	);
}

function SetPasswordFallback() {
	return (
		<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
			<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />
			<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
				<h1 className="font-bold text-3xl text-sky-300">Ustaw hasło</h1>
				<p className="mt-3 text-slate-200/90 text-sm">Weryfikacja linku...</p>
			</div>
		</div>
	);
}

export default function SetPasswordPage() {
	return (
		<Suspense fallback={<SetPasswordFallback />}>
			<SetPasswordContent />
		</Suspense>
	);
}

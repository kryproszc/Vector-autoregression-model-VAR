import { HomeTabs } from "../_components/HomeTabs";

export default function LoginPage() {
	return <HomeTabs />;
}

"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { clearStoredAuthSession, getStoredAuthToken } from "@/features/auth/session";
import { DeleteSuccessModal } from "@/shared/components/DeleteSuccessModal";

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown };
		return typeof payload.detail === "string" ? payload.detail : "";
	} catch {
		return "";
	}
}

export default function ChangePasswordPage() {
	const router = useRouter();
	const [oldPassword, setOldPassword] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
	const redirectTimeoutRef = useRef<number | null>(null);

	useEffect(() => {
		return () => {
			if (redirectTimeoutRef.current !== null) {
				window.clearTimeout(redirectTimeoutRef.current);
			}
		};
	}, []);

	const redirectToLogin = () => {
		if (redirectTimeoutRef.current !== null) {
			window.clearTimeout(redirectTimeoutRef.current);
		}

		router.replace("/login");
	};

	const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		if (!oldPassword || !newPassword) {
			setError("Uzupełnij stare i nowe hasło.");
			return;
		}

		if (newPassword.length < 8) {
			setError("Nowe hasło musi mieć co najmniej 8 znaków.");
			return;
		}

		setError(null);
		setIsSuccessModalOpen(false);
		setIsSubmitting(true);

		try {
			const token = getStoredAuthToken();
			if (!token) {
				clearStoredAuthSession();
				router.replace("/login");
				return;
			}

			const response = await fetch("/api/auth/change-password", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: `Bearer ${token}`,
				},
				body: JSON.stringify({
					oldPassword,
					newPassword,
				}),
			});

			if (response.status === 400) {
				const detail = await readApiDetail(response);
				setError(detail || "Nieprawidłowe dane zmiany hasła.");
				return;
			}

			if (response.status === 401) {
				clearStoredAuthSession();
				router.replace("/login");
				return;
			}

			if (response.status === 403) {
				setError("Brak uprawnień do zmiany hasła dla tego konta.");
				return;
			}

			if (!response.ok) {
				setError("Nie udało się zmienić hasła.");
				return;
			}

			setIsSuccessModalOpen(true);
			clearStoredAuthSession();
			redirectTimeoutRef.current = window.setTimeout(() => {
				redirectToLogin();
			}, 1600);
		} catch {
			setError("Nie udało się zmienić hasła.");
		} finally {
			setIsSubmitting(false);
		}
	};

	return (
		<>
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />

				<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
				<h1 className="font-bold text-3xl text-sky-300">Zmień hasło</h1>
				<p className="mt-2 text-slate-200/80 text-sm">
					Po zmianie hasła nastąpi automatyczne wylogowanie.
				</p>

				<form className="mt-4 space-y-3" onSubmit={handleSubmit}>
					<label className="block text-slate-200 text-sm">
						<span className="mb-1.5 block font-medium">Stare hasło</span>
						<input
							type="password"
							value={oldPassword}
							onChange={(event) => setOldPassword(event.target.value)}
							className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
						/>
					</label>
					<label className="block text-slate-200 text-sm">
						<span className="mb-1.5 block font-medium">Nowe hasło</span>
						<input
							type="password"
							value={newPassword}
							onChange={(event) => setNewPassword(event.target.value)}
							minLength={8}
							className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
						/>
					</label>

					{error ? (
						<p className="rounded-lg border border-rose-300/45 bg-rose-950/35 px-3 py-2 text-rose-200 text-sm">
							{error}
						</p>
					) : null}

					<button
						type="submit"
						disabled={isSubmitting}
						className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-[#6ea3f0] bg-linear-to-r from-[#2f4f83] to-[#365e9a] font-semibold text-base text-white transition-colors hover:from-[#3a619e] hover:to-[#4673b4] disabled:cursor-not-allowed disabled:opacity-70"
					>
						{isSubmitting ? "Zapisywanie..." : "Zmień hasło"}
					</button>
				</form>

				<div className="mt-4 text-center text-sm">
					<Link href="/" className="text-sky-300 hover:text-sky-200">
						Powrót do aplikacji
					</Link>
				</div>
				</div>
			</div>

			<DeleteSuccessModal
				isOpen={isSuccessModalOpen}
				heading="Hasło zostało zmienione"
				detailsMessage="Za chwilę nastąpi przekierowanie do ekranu logowania."
				onClose={redirectToLogin}
			/>
		</>
	);
}

import { useCallback, useEffect, useRef, useState } from "react";

type UseInactivityTimeoutParams = {
	enabled: boolean;
	inactivityMs: number;
	warningMs: number;
	onTimeout: () => void;
};

export function useInactivityTimeout({
	enabled,
	inactivityMs,
	warningMs,
	onTimeout,
}: UseInactivityTimeoutParams) {
	const [isWarning, setIsWarning] = useState(false);
	const [secondsRemaining, setSecondsRemaining] = useState(0);

	const isWarningRef = useRef(false);
	const inactivityTimerRef = useRef<number | null>(null);
	const countdownIntervalRef = useRef<number | null>(null);
	const onTimeoutRef = useRef(onTimeout);
	const enabledRef = useRef(enabled);

	useEffect(() => {
		onTimeoutRef.current = onTimeout;
	}, [onTimeout]);

	useEffect(() => {
		enabledRef.current = enabled;
	}, [enabled]);

	const clearTimers = useCallback(() => {
		if (inactivityTimerRef.current !== null) {
			window.clearTimeout(inactivityTimerRef.current);
			inactivityTimerRef.current = null;
		}
		if (countdownIntervalRef.current !== null) {
			window.clearInterval(countdownIntervalRef.current);
			countdownIntervalRef.current = null;
		}
	}, []);

	const startCountdown = useCallback(() => {
		isWarningRef.current = true;
		setIsWarning(true);
		setSecondsRemaining(Math.floor(warningMs / 1000));

		countdownIntervalRef.current = window.setInterval(() => {
			setSecondsRemaining((prev) => {
				if (prev <= 1) {
					if (countdownIntervalRef.current !== null) {
						window.clearInterval(countdownIntervalRef.current);
						countdownIntervalRef.current = null;
					}
					isWarningRef.current = false;
					setIsWarning(false);
					onTimeoutRef.current();
					return 0;
				}
				return prev - 1;
			});
		}, 1000);
	}, [warningMs]);

	const resetTimer = useCallback(() => {
		clearTimers();
		isWarningRef.current = false;
		setIsWarning(false);
		setSecondsRemaining(0);

		if (!enabledRef.current) return;

		inactivityTimerRef.current = window.setTimeout(() => {
			inactivityTimerRef.current = null;
			startCountdown();
		}, inactivityMs);
	}, [clearTimers, inactivityMs, startCountdown]);

	useEffect(() => {
		if (!enabled) {
			clearTimers();
			isWarningRef.current = false;
			setIsWarning(false);
			setSecondsRemaining(0);
			return;
		}

		const handleActivity = () => {
			resetTimer();
		};

		document.addEventListener("keydown", handleActivity);
		document.addEventListener("mousedown", handleActivity);
		document.addEventListener("scroll", handleActivity, true);

		resetTimer();

		return () => {
			document.removeEventListener("keydown", handleActivity);
			document.removeEventListener("mousedown", handleActivity);
			document.removeEventListener("scroll", handleActivity, true);
			clearTimers();
		};
	}, [enabled, resetTimer, clearTimers]);

	return {
		isWarning,
		secondsRemaining,
		resetTimer,
	};
}

$ErrorActionPreference='Stop'
$base='http://127.0.0.1:3002'

function Call-Api {
  param(
    [string]$Method,
    [string]$Url,
    [hashtable]$Headers,
    $BodyObj
  )
  try {
    if ($null -ne $BodyObj) {
      $json = $BodyObj | ConvertTo-Json -Depth 20
      $resp = Invoke-WebRequest -Uri $Url -Method $Method -Headers $Headers -ContentType 'application/json' -Body $json -UseBasicParsing -ErrorAction Stop
    } else {
      $resp = Invoke-WebRequest -Uri $Url -Method $Method -Headers $Headers -UseBasicParsing -ErrorAction Stop
    }
    $raw = $resp.Content
    $parsed = $null
    try { if ($raw) { $parsed = $raw | ConvertFrom-Json } } catch {}
    return [pscustomobject]@{ status = [int]$resp.StatusCode; body = $parsed; raw = $raw }
  } catch {
    $ex = $_.Exception
    if ($ex.Response) {
      $status = [int]$ex.Response.StatusCode.value__
      $reader = New-Object System.IO.StreamReader($ex.Response.GetResponseStream())
      $raw = $reader.ReadToEnd()
      $reader.Close()
      $parsed = $null
      try { if ($raw) { $parsed = $raw | ConvertFrom-Json } } catch {}
      return [pscustomobject]@{ status = $status; body = $parsed; raw = $raw }
    }
    throw
  }
}

$results = New-Object System.Collections.Generic.List[object]
function Add-Result([string]$name,[string]$expected,[int]$actual,[bool]$pass,[string]$detail){
  $results.Add([pscustomobject]@{ test=$name; expected=$expected; actual=$actual; pass=$pass; detail=$detail })
}

$bootstrapOperator = if ($env:OPERATOR_LOGIN) { $env:OPERATOR_LOGIN } else { 'admin' }
$hBootstrap = @{ 'X-Operator-Login' = $bootstrapOperator }

$users = Call-Api -Method 'GET' -Url "$base/api/admin/users" -Headers $hBootstrap -BodyObj $null
if ($users.status -ne 200) { throw "Cannot fetch users. Status: $($users.status)" }
$activeUsers = @($users.body | Where-Object { $_.aktywny -eq $true })
$admin = $activeUsers | Where-Object { $_.login -eq 'admin' } | Select-Object -First 1
if (-not $admin) { $admin = $activeUsers | Select-Object -First 1 }
$restrictedUser = $activeUsers | Where-Object { $_.login -ne $admin.login } | Select-Object -First 1
$leaderCandidate = $activeUsers | Where-Object { $_.login -ne $admin.login -and $_.rola -ne 'team_lead' } | Select-Object -First 1
if (-not $leaderCandidate) { $leaderCandidate = $activeUsers | Where-Object { $_.login -ne $admin.login } | Select-Object -First 1 }
$memberCandidate = $activeUsers | Where-Object { $_.id -ne $leaderCandidate.id -and $_.id -ne $admin.id } | Select-Object -First 1

$hAdmin = @{ 'X-Operator-Login' = $admin.login }
$hRestricted = if ($restrictedUser) { @{ 'X-Operator-Login' = $restrictedUser.login } } else { $null }

$stamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$codeA = "QAT$stamp".ToUpper()
$nameA = "QA TEAM A $stamp"
$codeB = "QBU$stamp".ToUpper()
$nameB = "QA TEAM B $stamp"

$teamA = Call-Api -Method 'POST' -Url "$base/api/admin/teams" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId=$null }
Add-Result 'Teams create bez kierownika' '200/201' $teamA.status (($teamA.status -eq 200) -or ($teamA.status -eq 201)) "kod=$codeA"

$teamsList = Call-Api -Method 'GET' -Url "$base/api/admin/teams" -Headers $hAdmin -BodyObj $null
$teamAObj = @($teamsList.body | Where-Object { $_.kod -eq $codeA } | Select-Object -First 1)
$teamAId = if ($teamAObj) { [int]$teamAObj.id } else { -1 }

$setLeader = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/$teamAId" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId=[int]$leaderCandidate.id }
Add-Result 'Teams ustawienie kierownika pozniej' '200' $setLeader.status ($setLeader.status -eq 200) "teamId=$teamAId userId=$($leaderCandidate.id)"

$unsetLeader = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/$teamAId" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId=$null }
Add-Result 'Teams zdjecie kierownika null' '200' $unsetLeader.status ($unsetLeader.status -eq 200) "teamId=$teamAId"

$anyActiveLeader = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/$teamAId" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId=[int]$leaderCandidate.id }
Add-Result 'Teams dowolny aktywny user jako kierownik' '200' $anyActiveLeader.status ($anyActiveLeader.status -eq 200) "login=$($leaderCandidate.login) rola=$($leaderCandidate.rola)"

$teamB = Call-Api -Method 'POST' -Url "$base/api/admin/teams" -Headers $hAdmin -BodyObj @{ kod=$codeB; nazwa=$nameB; kierownikUserId=$null }
$teamsList2 = Call-Api -Method 'GET' -Url "$base/api/admin/teams" -Headers $hAdmin -BodyObj $null
$teamBObj = @($teamsList2.body | Where-Object { $_.kod -eq $codeB } | Select-Object -First 1)
$teamBId = if ($teamBObj) { [int]$teamBObj.id } else { -1 }
$leaderConflict = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/$teamBId" -Headers $hAdmin -BodyObj @{ kod=$codeB; nazwa=$nameB; kierownikUserId=[int]$leaderCandidate.id }
Add-Result 'Teams 409 lider w innym zespole' '409' $leaderConflict.status ($leaderConflict.status -eq 409) "teamBId=$teamBId"

$dupTeam = Call-Api -Method 'POST' -Url "$base/api/admin/teams" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId=$null }
Add-Result 'Teams 409 duplikat kod/nazwa' '409' $dupTeam.status ($dupTeam.status -eq 409) "kod=$codeA"

$today = (Get-Date).ToString('yyyy-MM-dd')
$tomorrow = (Get-Date).AddDays(1).ToString('yyyy-MM-dd')
$plus2 = (Get-Date).AddDays(2).ToString('yyyy-MM-dd')
$plus3 = (Get-Date).AddDays(3).ToString('yyyy-MM-dd')
$plus4 = (Get-Date).AddDays(4).ToString('yyyy-MM-dd')

$insBody = @{
  nazwaPodmiotu = "QA INSPECTION $stamp"
  typInspekcji = "PLANOWA"
  zakresInspekcji = "PELNY"
  poczatekInspekcji = $today
  koniecInspekcji = $plus4
  rynek = "BANK"
  rodzajPodmiotu = "SPOLKA"
  dataProtokolu = $null
  dataDoreczeniaProtokolu = $null
  dataAkceptacjiSprawozdania = $null
  dataDoreczeniaPisma = $null
  dataPismaZastrzezenia = $null
  dataWplywuPisma = $null
  dataPismaZOdpowiedzia = $null
  dataAkceptacjiNotyList = @($tomorrow,$plus2)
  dataZalecenList = @($plus3,$plus4)
  status = "W_TOKU"
  komentarz = "QA-$stamp"
  osobaKierujacaUserId = [int]$leaderCandidate.id
  teamMemberUserIds = @([int]$leaderCandidate.id,[int]$memberCandidate.id)
}
$createIns = Call-Api -Method 'POST' -Url "$base/api/structure/inspections" -Headers $hAdmin -BodyObj $insBody
Add-Result 'Inspections create relacyjne IDs + listy dat' '200/201' $createIns.status (($createIns.status -eq 200) -or ($createIns.status -eq 201)) "leader=$($leaderCandidate.id), members=$($leaderCandidate.id),$($memberCandidate.id)"

$listAfterCreate = Call-Api -Method 'GET' -Url "$base/api/structure/inspections" -Headers $hAdmin -BodyObj $null
$createdRow = @($listAfterCreate.body.items | Where-Object { $_.komentarz -eq "QA-$stamp" } | Select-Object -First 1)
$createdId = if ($createdRow) { [int]$createdRow.id } else { -1 }

$renderOk = ($createdRow -and $createdRow.osobaKierujacaUserId -eq [int]$leaderCandidate.id -and @($createdRow.teamMemberUserIds).Count -ge 2 -and ($createdRow.canEdit -is [bool]))
Add-Result 'Inspections render osobaKierujaca/sklad/canEdit' 'idy relacyjne + canEdit bool' 200 $renderOk "id=$createdId canEdit=$($createdRow.canEdit)"

$detail = Call-Api -Method 'GET' -Url "$base/api/structure/inspections/$createdId" -Headers $hAdmin -BodyObj $null
Add-Result 'Inspections detail z canEdit' '200 i canEdit' $detail.status (($detail.status -eq 200) -and ($detail.body.canEdit -is [bool])) "canEdit=$($detail.body.canEdit)"

$upd1 = $insBody.Clone()
$upd1.dataAkceptacjiNotyList = @($tomorrow,$plus3)
$upd1.dataZalecenList = @($plus3,$plus4)
$upd1.komentarz = "QA-$stamp-upd1"
$put1 = Call-Api -Method 'PUT' -Url "$base/api/structure/inspections/$createdId" -Headers $hAdmin -BodyObj $upd1
Add-Result 'Inspections edycja jednej daty bez utraty reszty' '200' $put1.status ($put1.status -eq 200) "id=$createdId"

$upd2 = $upd1.Clone(); $upd2.dataAkceptacjiNotyList = @($plus3); $upd2.komentarz = "QA-$stamp-upd2"
$put2 = Call-Api -Method 'PUT' -Url "$base/api/structure/inspections/$createdId" -Headers $hAdmin -BodyObj $upd2
Add-Result 'Inspections usuniecie jednej daty' '200' $put2.status ($put2.status -eq 200) "id=$createdId"

$upd3 = $upd2.Clone(); $upd3.dataZalecenList = @(); $upd3.komentarz = "QA-$stamp-upd3"
$put3 = Call-Api -Method 'PUT' -Url "$base/api/structure/inspections/$createdId" -Headers $hAdmin -BodyObj $upd3
Add-Result 'Inspections pusta lista jako []' '200' $put3.status ($put3.status -eq 200) "id=$createdId"

$verify = Call-Api -Method 'GET' -Url "$base/api/structure/inspections/$createdId" -Headers $hAdmin -BodyObj $null
$verifyListEmpty = (@($verify.body.dataZalecenList).Count -eq 0)
Add-Result 'Inspections update list dat zachowuje spojnosc' 'GET po PUT i poprawne listy' 200 $verifyListEmpty "dataZalecenListCount=$(@($verify.body.dataZalecenList).Count)"

if ($hRestricted) {
  $listNoEdit = Call-Api -Method 'GET' -Url "$base/api/structure/inspections" -Headers $hRestricted -BodyObj $null
  $falseRow = @($listNoEdit.body.items | Where-Object { $_.canEdit -eq $false } | Select-Object -First 1)
  if ($falseRow) {
    Add-Result 'Uprawnienia canEdit=false dla pozostalych' 'co najmniej 1 rekord false' 200 $true "rowId=$($falseRow.id)"
    $forbiddenPut = Call-Api -Method 'PUT' -Url "$base/api/structure/inspections/$($falseRow.id)" -Headers $hRestricted -BodyObj $upd3
    Add-Result 'Uprawnienia serwerowy 403 przy braku uprawnien' '403' $forbiddenPut.status ($forbiddenPut.status -eq 403) "login=$($restrictedUser.login)"
  } else {
    Add-Result 'Uprawnienia canEdit=false dla pozostalych' 'co najmniej 1 rekord false' 200 $false "Brak rekordu false dla usera $($restrictedUser.login)"
  }
} else {
  Add-Result 'Uprawnienia canEdit=false dla pozostalych' 'co najmniej 1 rekord false' 200 $false 'Brak innego aktywnego usera poza adminem'
}

$badOperator = Call-Api -Method 'GET' -Url "$base/api/structure/inspections" -Headers @{ 'X-Operator-Login'='__no_such_user__' } -BodyObj $null
Add-Result 'Blad 401 operator' '401' $badOperator.status ($badOperator.status -eq 401) 'invalid login header'

$notFound = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/99999999" -Headers $hAdmin -BodyObj @{ kod='NOPE'; nazwa='NOPE'; kierownikUserId=$null }
Add-Result 'Blad 404 brak zasobu' '404' $notFound.status ($notFound.status -eq 404) 'update non-existing team'

$schema422 = Call-Api -Method 'PUT' -Url "$base/api/admin/teams/$teamAId" -Headers $hAdmin -BodyObj @{ kod=$codeA; nazwa=$nameA; kierownikUserId='abc' }
Add-Result 'Blad 422 schema validation' '422' $schema422.status ($schema422.status -eq 422) 'kierownikUserId string'

$bizInvalidBody = $insBody.Clone()
$bizInvalidBody.poczatekInspekcji = $plus4
$bizInvalidBody.koniecInspekcji = $today
$bizInvalidBody.komentarz = "QA-$stamp-biz400"
$biz400 = Call-Api -Method 'POST' -Url "$base/api/structure/inspections" -Headers $hAdmin -BodyObj $bizInvalidBody
Add-Result 'Blad 400 walidacja biznesowa' '400' $biz400.status ($biz400.status -eq 400) 'intentionally invalid business payload'

$report = [pscustomobject]@{
  generatedAt = (Get-Date).ToString('s')
  operator = $admin.login
  leaderCandidate = [pscustomobject]@{ id = $leaderCandidate.id; login = $leaderCandidate.login; role = $leaderCandidate.rola }
  totals = [pscustomobject]@{
    all = $results.Count
    passed = @($results | Where-Object { $_.pass }).Count
    failed = @($results | Where-Object { -not $_.pass }).Count
  }
  results = $results
}

$report | ConvertTo-Json -Depth 10 | Out-File -FilePath 'tmp/frontend-scenario-report.json' -Encoding utf8
Write-Output 'REPORT_READY: tmp/frontend-scenario-report.json'
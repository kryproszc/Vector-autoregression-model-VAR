$t = [char]9  # single tab

# ===== OBLIGATING DECISIONS PANEL =====
$filePath1 = "d:\rejestr\triangle-t3\triangle-t3\src\features\obligating-decisions\components\ObligatingDecisionsPanel.tsx"
$c1 = [System.IO.File]::ReadAllText($filePath1, [System.Text.Encoding]::UTF8)

# --- 1a. Insert inactivity banner before "acquiring" block ---
$acquiringMarker1 = "{isEditMode && editRecordLock.status === " + [char]34 + "acquiring" + [char]34

$t8 = "$t$t$t$t$t$t$t$t"
$t9 = "$t$t$t$t$t$t$t$t$t"
$t10 = "$t$t$t$t$t$t$t$t$t$t"
$t11 = "$t$t$t$t$t$t$t$t$t$t$t"
$t12 = "$t$t$t$t$t$t$t$t$t$t$t$t"

$inactivityBanner = "${t8}{inactivityTimeout.isWarning ? (`r`n${t9}<div className=" + [char]34 + "mt-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-amber-900 text-sm" + [char]34 + ">`r`n${t10}<p className=" + [char]34 + "font-semibold" + [char]34 + ">`r`n${t11}Nie wykryto aktywnosci. Formularz zostanie zamkniety za{" + [char]34 + " " + [char]34 + "}`r`n${t11}<span className=" + [char]34 + "tabular-nums" + [char]34 + ">{inactivityTimeout.secondsRemaining}</span> s.`r`n${t10}</p>`r`n${t10}<button`r`n${t11}type=" + [char]34 + "button" + [char]34 + "`r`n${t11}onClick={inactivityTimeout.resetTimer}`r`n${t11}className=" + [char]34 + "mt-2 inline-flex h-7 items-center rounded border border-amber-400 bg-amber-100 px-2 font-semibold text-amber-900 text-xs transition-colors hover:bg-amber-200" + [char]34 + "`r`n${t10}>`r`n${t11}Kontynuuj edycje`r`n${t10}</button>`r`n${t9}</div>`r`n${t8}) : null}`r`n`r`n"

if ($c1.Contains($acquiringMarker1)) {
    $c1 = $c1.Replace($acquiringMarker1, $inactivityBanner + $acquiringMarker1)
    Write-Host "1a: inactivity banner inserted before acquiring"
} else {
    Write-Host "1a: WARNING - acquiring marker not found"
}

# --- 1b. Replace error block with connection lost / expired / acquireFailed ---
$oldErrorMarker = "{isEditMode && editRecordLock.status === " + [char]34 + "error" + [char]34

$startIdx = $c1.IndexOf($oldErrorMarker)
if ($startIdx -ge 0) {
    $endIdx = $c1.IndexOf("null}", $startIdx) + 5
    $oldErrorBlock = $c1.Substring($startIdx, $endIdx - $startIdx)
    
    $newBanners = "${t8}{isEditMode && editRecordLock.isConnectionLost ? (`r`n${t9}<p className=" + [char]34 + "mt-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 font-medium text-amber-800 text-sm" + [char]34 + ">`r`n${t10}{editRecordLock.error ?? " + [char]34 + "Utracono polaczenie z serwerem — trwa proba odnowienia blokady..." + [char]34 + "}`r`n${t9}</p>`r`n${t8}) : null}`r`n`r`n${t8}{isEditMode && editRecordLock.isExpired ? (`r`n${t9}<p className=" + [char]34 + "mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 font-medium text-rose-800 text-sm" + [char]34 + ">`r`n${t10}{editRecordLock.error ?? " + [char]34 + "Czas edycji wygasl — polaczenie zostalo przerwane zbyt dlugo. Zamknij formularz i otworz ponownie." + [char]34 + "}`r`n${t9}</p>`r`n${t8}) : null}`r`n`r`n${t8}{isEditMode && editRecordLock.isAcquireFailed ? (`r`n${t9}<div className=" + [char]34 + "mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-rose-800 text-sm" + [char]34 + ">`r`n${t10}<p className=" + [char]34 + "font-medium" + [char]34 + ">`r`n${t11}{editRecordLock.error ?? " + [char]34 + "Nie udalo sie zalozyc blokady rekordu." + [char]34 + "}`r`n${t10}</p>`r`n${t10}<button`r`n${t11}type=" + [char]34 + "button" + [char]34 + "`r`n${t11}onClick={() => editRecordLock.retryAcquire()}`r`n${t11}className=" + [char]34 + "mt-2 inline-flex h-7 items-center rounded border border-rose-300 bg-rose-100 px-2 font-semibold text-rose-800 text-xs transition-colors hover:bg-rose-200" + [char]34 + "`r`n${t10}>`r`n${t11}Sprobuj ponownie`r`n${t10}</button>`r`n${t9}</div>`r`n${t8}) : null}"
    
    $c1 = $c1.Replace($oldErrorBlock, $newBanners)
    Write-Host "1b: error block replaced with 3 new banners"
} else {
    Write-Host "1b: WARNING - error marker not found"
}

# --- 1c. Update submit button ---
$oldSubmitSearch = "disabled={isSubmitting || isReadOnlyDueToLock}"
$newSubmitSearch = "disabled={isSubmitting || isReadOnlyDueToLock || isSaveDisabledDueToLock}"

if ($c1.Contains($oldSubmitSearch)) {
    $c1 = $c1.Replace($oldSubmitSearch, $newSubmitSearch)
    Write-Host "1c: submit disabled updated"
} else {
    Write-Host "1c: WARNING - submit disabled not found"
}

# --- 1d. Update submit label ---
$oldLabelSearch = ": isReadOnlyDueToLock`r`n${t10}? " + [char]34 + "Tylko podglad" + [char]34 + "`r`n${t10}: editingItem`r`n${t10}? " + [char]34 + "Zapisz zmiany" + [char]34 + "`r`n${t10}: " + [char]34 + "Dodaj" + [char]34

# Let me search for the label area differently
$labelIdx = $c1.IndexOf("Tylko podglad")
if ($labelIdx -lt 0) { $labelIdx = $c1.IndexOf("Tylko podgl" + [char]0x105 + "d") }
Write-Host "label idx=$labelIdx"

# Find the isReadOnlyDueToLock ternary
$ternarySearch = "isReadOnlyDueToLock"
$ternaryIdx = $c1.IndexOf($ternarySearch, $c1.IndexOf("isReadOnlyDueToLock || isSaveDisabledDueToLock") + 50)
Write-Host "ternary label idx=$ternaryIdx"
Write-Host $c1.Substring($ternaryIdx, 300)

[System.IO.File]::WriteAllText($filePath1, $c1, [System.Text.Encoding]::UTF8)
Write-Host "File 1 written."
Write-Host "=== Done ==="

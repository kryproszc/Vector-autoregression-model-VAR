const fs = require('fs');
const file = 'src/features/logs/components/LogsPanel.tsx';
let c = fs.readFileSync(file, 'utf8');

// Count tabs in front of known unique string to calibrate
const marker = '<td className="px-3 py-2.5">';
const markerIdx = c.indexOf(marker);
if (markerIdx === -1) {
  console.log('ERROR: marker not found - file may already be patched');
  process.exit(0);
}

// Get the line start to count tabs
const lineStart = c.lastIndexOf('\n', markerIdx) + 1;
let tabCount = 0;
let i = lineStart;
while (c[i] === '\t') { tabCount++; i++; }
console.log('td tab count:', tabCount); // should be 14

const t = (n) => '\t'.repeat(n);
const NL = c.includes('\r\n') ? '\r\n' : '\n';

// Build old thead <tr> block
const oldTr = 
  t(12) + '<tr>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Data i godzina' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Użytkownik' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Akcja' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Rejestr' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Id rekordu' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Zmiany' + NL +
  t(13) + '</th>' + NL +
  t(12) + '</tr>';

const newTr =
  t(12) + '<tr>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Lp.' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Data i godzina' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Użytkownik' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Akcja' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Rejestr' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Id rekordu' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Pozycja' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Wartość przed zmianą' + NL +
  t(13) + '</th>' + NL +
  t(13) + '<th className="whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800">' + NL +
  t(14) + 'Wartość po zmianie' + NL +
  t(13) + '</th>' + NL +
  t(12) + '</tr>';

console.log('oldTr found:', c.includes(oldTr));
if (c.includes(oldTr)) {
  c = c.replace(oldTr, newTr);
  console.log('thead replaced OK');
}

// Build old tbody
const oldTbody =
  t(11) + '<tbody>' + NL +
  t(12) + '{auditItems.map((item) => (' + NL +
  t(13) + '<tr' + NL +
  t(14) + 'key={item.session_id}' + NL +
  t(14) + 'className="border-slate-200 border-b last:border-b-0 hover:bg-slate-50"' + NL +
  t(13) + '>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-600 text-xs">' + NL +
  t(15) + '{formatAuditDate(item.data_godz)}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 font-medium">' + NL +
  t(15) + '{item.uzytkownik}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5">' + NL +
  t(15) + '<AuditActionBadge akcja={item.akcja} />' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5">' + NL +
  t(15) + '<RejestrBadge rejestr={item.rejestr} />' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 font-mono text-xs">' + NL +
  t(15) + '{item.rekord_kod || "\u2014"}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="px-3 py-2.5">' + NL +
  t(15) + '<ZmianyCell item={item} />' + NL +
  t(14) + '</td>' + NL +
  t(13) + '</tr>' + NL +
  t(12) + '))}' + NL +
  t(11) + '</tbody>';

const newTbody =
  t(11) + '<tbody>' + NL +
  t(12) + '{auditItems.map((item, index) => (' + NL +
  t(13) + '<tr' + NL +
  t(14) + 'key={item.id || `${item.session_id}-${index}`}' + NL +
  t(14) + 'className="border-slate-200 border-b last:border-b-0 hover:bg-slate-50"' + NL +
  t(13) + '>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-500 text-xs">' + NL +
  t(15) + '{auditOffset + index + 1}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-600 text-xs">' + NL +
  t(15) + '{formatAuditDate(item.data_godz)}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 font-medium">' + NL +
  t(15) + '{item.uzytkownik}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5">' + NL +
  t(15) + '<AuditActionBadge akcja={item.akcja} />' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5">' + NL +
  t(15) + '<RejestrBadge rejestr={item.rejestr} />' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 font-mono text-xs">' + NL +
  t(15) + '{item.rekord_kod || "\u2014"}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-700 text-xs">' + NL +
  t(15) + '{item.pole ?? "\u2014"}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-500 text-xs">' + NL +
  t(15) + '{item.przed ?? "\u2014"}' + NL +
  t(14) + '</td>' + NL +
  t(14) + '<td className="whitespace-nowrap px-3 py-2.5 text-slate-800 text-xs">' + NL +
  t(15) + '{item.po ?? "\u2014"}' + NL +
  t(14) + '</td>' + NL +
  t(13) + '</tr>' + NL +
  t(12) + '))}' + NL +
  t(11) + '</tbody>';

console.log('oldTbody found:', c.includes(oldTbody));
if (c.includes(oldTbody)) {
  c = c.replace(oldTbody, newTbody);
  console.log('tbody replaced OK');
}

fs.writeFileSync(file, c, 'utf8');
console.log('DONE - file written');

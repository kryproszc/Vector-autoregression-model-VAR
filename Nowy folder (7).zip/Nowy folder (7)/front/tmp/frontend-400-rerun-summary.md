# Frontend Rerun 400 Cases (deterministyczne)

Data: 2026-03-25
Warstwa testu: HTTP przez frontend proxy (`/api` na 3002) + weryfikacja bezpośrednia backend (`8002`).

## Wynik

- Przypadki 400 wymagane przez backend: 5
- Potwierdzone statusem 400: 5/5
- Potwierdzenie szczegółowego `detail`: nie (response body jest puste w odczycie HTTP)

## Statusy

1. POST /api/structure/inspections (brak `osobaKierujacaUserId`) -> 400
2. PUT /api/structure/inspections/{id} (pusty payload) -> 400
3. PUT /api/structure/inspections/{id} (`dataZalecenList` z duplikatami) -> 400
4. POST /api/admin/teams (kod ze spacją) -> 400
5. PUT /api/admin/teams/{id} (pusty payload) -> 400

## Uwaga techniczna

Dla wszystkich powyższych przypadków status jest poprawny i stabilny (400), natomiast body odpowiedzi z serwera jest puste w trakcie testu integracyjnego HTTP, więc nie było możliwe automatyczne porównanie `detail` tekstowego.

const fs = require("fs");

const t = "\t";
const t8 = t.repeat(8);
const t9 = t.repeat(9);
const t10 = t.repeat(10);
const t11 = t.repeat(11);
const CRLF = "\r\n";

function fixPanel(filePath) {
  let c = fs.readFileSync(filePath, "utf8");
  const basename = filePath.split("\\").pop();
  let changed = false;

  // 1. Insert inactivity banner BEFORE the acquiring block
  const acquiringMarker = `{isEditMode && editRecordLock.status === "acquiring"`;
  const inactivityBanner =
    `${t8}{inactivityTimeout.isWarning ? (${CRLF}` +
    `${t9}<div className="mt-2 rounded-md border border-amber-300 bg-amber-50 px-3 py-2 text-amber-900 text-sm">${CRLF}` +
    `${t10}<p className="font-semibold">${CRLF}` +
    `${t11}Nie wykryto aktywno\u015bci. Formularz zostanie zamkni\u0119ty za{" "}${CRLF}` +
    `${t11}<span className="tabular-nums">{inactivityTimeout.secondsRemaining}</span> s.${CRLF}` +
    `${t10}</p>${CRLF}` +
    `${t10}<button${CRLF}` +
    `${t11}type="button"${CRLF}` +
    `${t11}onClick={inactivityTimeout.resetTimer}${CRLF}` +
    `${t11}className="mt-2 inline-flex h-7 items-center rounded border border-amber-400 bg-amber-100 px-2 font-semibold text-amber-900 text-xs transition-colors hover:bg-amber-200"${CRLF}` +
    `${t10}>${CRLF}` +
    `${t11}Kontynuuj edycj\u0119${CRLF}` +
    `${t10}</button>${CRLF}` +
    `${t9}</div>${CRLF}` +
    `${t8}) : null}${CRLF}${CRLF}` +
    acquiringMarker;

  if (!c.includes("inactivityTimeout.isWarning") && c.includes(acquiringMarker)) {
    c = c.replace(acquiringMarker, inactivityBanner);
    console.log(`[${basename}] 1. Inactivity banner inserted`);
    changed = true;
  } else if (c.includes("inactivityTimeout.isWarning")) {
    console.log(`[${basename}] 1. Inactivity banner already present`);
  } else {
    console.log(`[${basename}] 1. WARNING: acquiring marker not found`);
  }

  // 2. Replace error block with 3 new banners
  const errorMarker = `{isEditMode && editRecordLock.status === "error"`;
  if (c.includes(errorMarker)) {
    const startIdx = c.indexOf(errorMarker);
    const endIdx = c.indexOf("null}", startIdx) + 5;
    const oldErrorBlock = c.substring(startIdx, endIdx);
    console.log(`[${basename}] 2. Found error block (${oldErrorBlock.length} chars)`);

    const newBanners =
      `${t8}{isEditMode && editRecordLock.isConnectionLost ? (${CRLF}` +
      `${t9}<p className="mt-2 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 font-medium text-amber-800 text-sm">${CRLF}` +
      `${t10}{editRecordLock.error ?? "Utracono po\u0142\u0105czenie z serwerem \u2014 trwa pr\u00f3ba odnowienia blokady..."}${CRLF}` +
      `${t9}</p>${CRLF}` +
      `${t8}) : null}${CRLF}${CRLF}` +
      `${t8}{isEditMode && editRecordLock.isExpired ? (${CRLF}` +
      `${t9}<p className="mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 font-medium text-rose-800 text-sm">${CRLF}` +
      `${t10}{editRecordLock.error ?? "Czas edycji wygas\u0142 \u2014 po\u0142\u0105czenie zosta\u0142o przerwane zbyt d\u0142ugo. Zamknij formularz i otw\u00f3rz ponownie."}${CRLF}` +
      `${t9}</p>${CRLF}` +
      `${t8}) : null}${CRLF}${CRLF}` +
      `${t8}{isEditMode && editRecordLock.isAcquireFailed ? (${CRLF}` +
      `${t9}<div className="mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-rose-800 text-sm">${CRLF}` +
      `${t10}<p className="font-medium">${CRLF}` +
      `${t11}{editRecordLock.error ?? "Nie uda\u0142o si\u0119 za\u0142o\u017cy\u0107 blokady rekordu."}${CRLF}` +
      `${t10}</p>${CRLF}` +
      `${t10}<button${CRLF}` +
      `${t11}type="button"${CRLF}` +
      `${t11}onClick={() => editRecordLock.retryAcquire()}${CRLF}` +
      `${t11}className="mt-2 inline-flex h-7 items-center rounded border border-rose-300 bg-rose-100 px-2 font-semibold text-rose-800 text-xs transition-colors hover:bg-rose-200"${CRLF}` +
      `${t10}>${CRLF}` +
      `${t11}Spr\u00f3buj ponownie${CRLF}` +
      `${t10}</button>${CRLF}` +
      `${t9}</div>${CRLF}` +
      `${t8}) : null}`;

    c = c.replace(oldErrorBlock, newBanners);
    console.log(`[${basename}] 2. Error block replaced with 3 new banners`);
    changed = true;
  } else if (c.includes("isAcquireFailed")) {
    console.log(`[${basename}] 2. New banners already present`);
  } else {
    console.log(`[${basename}] 2. WARNING: error marker not found`);
  }

  // 3. Update submit button disabled
  const oldDisabled = `disabled={isSubmitting || isReadOnlyDueToLock}`;
  const newDisabled = `disabled={isSubmitting || isReadOnlyDueToLock || isSaveDisabledDueToLock}`;
  if (c.includes(oldDisabled)) {
    c = c.replace(oldDisabled, newDisabled);
    console.log(`[${basename}] 3. Submit disabled updated`);
    changed = true;
  } else if (c.includes("isSaveDisabledDueToLock}")) {
    console.log(`[${basename}] 3. Submit disabled already updated`);
  } else {
    console.log(`[${basename}] 3. WARNING: submit disabled not found`);
  }

  // 4. Update submit label - find "Tylko podgląd" and add isSaveDisabledDueToLock branch
  const oldLabel = `? "Tylko pogl\u0105d"`;
  const newLabel =
    `? "Tylko pogl\u0105d"` +
    `${CRLF}${t10}: isSaveDisabledDueToLock` +
    `${CRLF}${t11}? "Brak blokady"`;
  if (c.includes("Brak blokady")) {
    console.log(`[${basename}] 4. Submit label already updated`);
  } else if (c.includes(oldLabel)) {
    c = c.replace(oldLabel, newLabel);
    console.log(`[${basename}] 4. Submit label updated`);
    changed = true;
  } else {
    console.log(`[${basename}] 4. WARNING: submit label not found`);
  }

  if (changed) {
    fs.writeFileSync(filePath, c, "utf8");
    console.log(`[${basename}] File saved.`);
  } else {
    console.log(`[${basename}] No changes needed.`);
  }
}

fixPanel("d:\\rejestr\\triangle-t3\\triangle-t3\\src\\features\\obligating-decisions\\components\\ObligatingDecisionsPanel.tsx");
fixPanel("d:\\rejestr\\triangle-t3\\triangle-t3\\src\\features\\sanction-requests\\components\\SanctionRequestsPanel.tsx");
console.log("=== All done ===");

const fs = require("fs");
const CRLF = "\r\n";
const t = "\t";
const t8 = t.repeat(8);
const t9 = t.repeat(9);
const t10 = t.repeat(10);
const t11 = t.repeat(11);

const files = [
  "d:\\rejestr\\triangle-t3\\triangle-t3\\src\\features\\obligating-decisions\\components\\ObligatingDecisionsPanel.tsx",
  "d:\\rejestr\\triangle-t3\\triangle-t3\\src\\features\\sanction-requests\\components\\SanctionRequestsPanel.tsx",
];

for (const filePath of files) {
  const basename = filePath.split("\\").pop();
  let c = fs.readFileSync(filePath, "utf8");

  if (c.includes("Brak blokady")) {
    console.log(`[${basename}] submit label already done`);
    continue;
  }

  // Find "Tylko podgląd" in the file
  const search = 'Tylko podgl\u0105d';
  const idx = c.indexOf(search);
  console.log(`[${basename}] 'Tylko podgląd' at idx=${idx}`);
  if (idx < 0) {
    // Try with raw chars
    const rawSearch = "Tylko podgl";
    const idx2 = c.indexOf(rawSearch);
    console.log(`[${basename}] 'Tylko podgl' at idx=${idx2}, snip=${JSON.stringify(c.substring(idx2, idx2 + 20))}`);
    continue;
  }

  // Find the `: isReadOnlyDueToLock` ternary that precedes "Tylko podgląd"
  // The structure is:
  //   <tabs>: isReadOnlyDueToLock\r\n<tabs>? "Tylko podgląd"\r\n<tabs>: editingItem
  // We want to insert after the `? "Tylko podgląd"` line:
  //   \r\n<tabs>: isSaveDisabledDueToLock\r\n<tabs+1>? "Brak blokady"

  const oldPattern = '? "Tylko podgl\u0105d"';
  const newPattern = '? "Tylko podgl\u0105d"' + CRLF + `${t10}: isSaveDisabledDueToLock` + CRLF + `${t11}? "Brak blokady"`;

  c = c.replace(oldPattern, newPattern);
  fs.writeFileSync(filePath, c, "utf8");
  console.log(`[${basename}] submit label updated`);
}
console.log("Done");

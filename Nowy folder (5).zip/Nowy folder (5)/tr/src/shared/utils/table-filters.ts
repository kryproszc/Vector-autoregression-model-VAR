export function hasActiveTableFilters<TColumnKey extends string>(
	columnFilters: Partial<Record<TColumnKey, string>>,
	advancedFilters: Partial<Record<TColumnKey, string[]>>,
) {
	return (
		Object.values(columnFilters).some(
			(value) => typeof value === "string" && value.trim().length > 0,
		) ||
		Object.values(advancedFilters).some(
			(values) => Array.isArray(values) && values.length > 0,
		)
	);
}

export function splitAdvancedFilterCellValue(rawValue: string) {
	const normalizedValue = rawValue.trim();
	if (!normalizedValue) {
		return ["(puste)"];
	}

	const tokens = normalizedValue
		.split(";")
		.map((item) => item.trim())
		.filter(Boolean);

	if (tokens.length === 0) {
		return ["(puste)"];
	}

	return Array.from(new Set(tokens));
}

export function matchesAdvancedFilterCellValue(
	rawValue: string,
	selectedValues: string[],
) {
	if (selectedValues.length === 0) {
		return true;
	}

	const cellTokens = splitAdvancedFilterCellValue(rawValue);
	return cellTokens.some((token) => selectedValues.includes(token));
}

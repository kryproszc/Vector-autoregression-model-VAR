const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function normalizeDateList(values: string[]) {
	const normalized = values
		.map((item) => item.trim())
		.filter((item) => ISO_DATE_PATTERN.test(item));

	return Array.from(new Set(normalized)).sort((left, right) =>
		left.localeCompare(right),
	);
}

export function toDateInputValue(value: unknown) {
	const normalized =
		value === null || value === undefined ? "" : String(value).trim();

	if (!normalized) {
		return "";
	}

	if (ISO_DATE_PATTERN.test(normalized)) {
		return normalized;
	}

	const extractedDate = normalized.slice(0, 10);
	return ISO_DATE_PATTERN.test(extractedDate) ? extractedDate : "";
}

export function toDateList(value: unknown) {
	if (!Array.isArray(value)) {
		return [];
	}

	return normalizeDateList(
		value.map((item) => toDateInputValue(item)).filter(Boolean),
	);
}

export function parseIsoDateListFromText(value: string) {
	return normalizeDateList(value.split(/[\n,;]/));
}

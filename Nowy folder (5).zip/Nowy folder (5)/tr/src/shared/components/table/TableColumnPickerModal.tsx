import { X } from "lucide-react";

type TableLayoutOption<TLayoutId extends string> = {
	id: TLayoutId;
	label: string;
	description?: string;
};

type TableColumnDefinition<TColumnKey extends string> = {
	key: TColumnKey;
	label: string;
};

type TableColumnPickerModalProps<
	TColumnKey extends string,
	TLayoutId extends string,
> = {
	isOpen: boolean;
	columns: TableColumnDefinition<TColumnKey>[];
	hiddenColumns: TColumnKey[];
	visibleColumnsCount: number;
	onClose: () => void;
	onChangeColumnVisibility: (columnKey: TColumnKey, isVisible: boolean) => void;
	onShowAllColumns: () => void;
	onApply: () => void;
	layoutOptions?: TableLayoutOption<TLayoutId>[];
	selectedLayoutId?: TLayoutId;
	onSelectLayout?: (layoutId: TLayoutId) => void;
	title?: string;
	description?: string;
};

export function TableColumnPickerModal<
	TColumnKey extends string,
	TLayoutId extends string,
>({
	isOpen,
	columns,
	hiddenColumns,
	visibleColumnsCount,
	onClose,
	onChangeColumnVisibility,
	onShowAllColumns,
	onApply,
	layoutOptions,
	selectedLayoutId,
	onSelectLayout,
	title = "Widok tabeli",
	description = "Wybierz układ kolumn i zaznacz kolumny widoczne w tabeli.",
}: TableColumnPickerModalProps<TColumnKey, TLayoutId>) {
	if (!isOpen) {
		return null;
	}

	const hasLayouts = Boolean(
		layoutOptions &&
			layoutOptions.length > 0 &&
			selectedLayoutId &&
			onSelectLayout,
	);

	return (
		<div className="fixed inset-0 z-40 flex items-center justify-center p-4">
			<button
				type="button"
				aria-label="Zamknij okno wyboru kolumn"
				className="absolute inset-0 bg-slate-950/65"
				onClick={onClose}
			/>

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Wybór kolumn tabeli"
				className="relative z-10 max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">{title}</h3>
						<p className="mt-1 text-slate-600 text-sm">{description}</p>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				{hasLayouts ? (
					<div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
						<p className="mb-2 font-semibold text-slate-700 text-sm">Układ</p>
						<div className="grid gap-2 sm:grid-cols-3">
							{layoutOptions?.map((view) => {
								const isActive = selectedLayoutId === view.id;

								return (
									<button
										key={view.id}
										type="button"
										onClick={() => onSelectLayout?.(view.id)}
										className={`rounded-lg border px-3 py-2 text-left transition-colors ${
											isActive
												? "border-blue-300 bg-blue-50 text-slate-900"
												: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
										}`}
									>
										<p className="font-semibold text-sm">{view.label}</p>
										{view.description ? (
											<p className="mt-1 text-slate-500 text-xs">{view.description}</p>
										) : null}
									</button>
								);
							})}
						</div>
					</div>
				) : null}

				<p className="mb-2 font-semibold text-slate-700 text-sm">Kolumny</p>
				<div className="grid gap-2 sm:grid-cols-2">
					{columns.map((column) => {
						const isVisible = !hiddenColumns.includes(column.key);
						const isOnlyVisibleColumn =
							isVisible && visibleColumnsCount <= 1;

						return (
							<label
								key={column.key}
								className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-800 text-sm transition-colors hover:bg-slate-50"
							>
								<input
									type="checkbox"
									checked={isVisible}
									disabled={isOnlyVisibleColumn}
									onChange={(event) =>
										onChangeColumnVisibility(column.key, event.target.checked)
									}
									className="h-4 w-4 rounded border-slate-300 text-blue-600"
								/>
								<span>{column.label}</span>
							</label>
						);
					})}
				</div>

				<div className="mt-4 flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
					<button
						type="button"
						onClick={onShowAllColumns}
						className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-white px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Pokaż wszystkie
					</button>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Anuluj
					</button>

					<button
						type="button"
						onClick={onApply}
						className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99]"
					>
						Pokaż
					</button>
				</div>
			</div>
		</div>
	);
}

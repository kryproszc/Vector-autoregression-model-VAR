import { X } from "lucide-react";
import { useMemo } from "react";
import { useExportConfigTabs } from "@/shared/hooks/useExportConfigTabs";

type ExportColumnOption = {
	key: string;
	label: string;
};

type ExportRelationOption = {
	id: string;
	label: string;
	enabled: boolean;
	selectedCount: number;
	onToggle: () => void;
};

type ExportTabOption = {
	id: string;
	label: string;
	columns: ExportColumnOption[];
	selectedKeys: string[];
	onToggleKey: (key: string, isSelected: boolean) => void;
	onSelectAll: () => void;
};

type ExportConfigModalProps = {
	isOpen: boolean;
	title?: string;
	description: string;
	relationsLabel: string;
	relations: ExportRelationOption[];
	tabs: ExportTabOption[];
	activeTabId: string;
	onActiveTabChange: (tabId: string) => void;
	onClose: () => void;
	onConfirm: () => void;
	isConfirmDisabled: boolean;
	isExporting: boolean;
};

export function ExportConfigModal({
	isOpen,
	title = "Eksport danych",
	description,
	relationsLabel,
	relations,
	tabs,
	activeTabId,
	onActiveTabChange,
	onClose,
	onConfirm,
	isConfirmDisabled,
	isExporting,
}: ExportConfigModalProps) {
	const { enabledTabIds, resolvedTabId } = useExportConfigTabs(
		relations.map((relation) => ({
			id: relation.id,
			enabled: relation.enabled,
		})),
		activeTabId,
	);

	const resolvedTab = useMemo(
		() => tabs.find((tab) => tab.id === resolvedTabId) ?? null,
		[resolvedTabId, tabs],
	);

	if (!isOpen) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-40 flex items-center justify-center p-4">
			<button
				type="button"
				aria-label="Zamknij okno konfiguracji eksportu"
				className="absolute inset-0 bg-slate-950/65"
				onClick={onClose}
			/>

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Konfiguracja eksportu"
				className="relative z-10 max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">{title}</h3>
						<p className="mt-1 text-slate-600 text-sm">{description}</p>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				<div className="mb-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
					<p className="mb-2 font-semibold text-slate-700 text-sm">{relationsLabel}</p>
					<div className="grid gap-2 sm:grid-cols-3">
						{relations.map((relation) => (
							<button
								key={relation.id}
								type="button"
								onClick={relation.onToggle}
								className={`rounded-lg border px-3 py-2 text-left transition-colors ${
									relation.enabled
										? "border-blue-300 bg-blue-50"
										: "border-slate-300 bg-white hover:bg-slate-100"
								}`}
							>
								<p className="font-semibold text-slate-800 text-sm">{relation.label}</p>
								<p className="text-slate-600 text-xs">
									{relation.enabled
										? `${relation.selectedCount} kolumn(y) wybrano`
										: "Wyłączone"}
								</p>
							</button>
						))}
					</div>
				</div>

				{resolvedTab === null ? (
					<p className="mb-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-slate-600 text-sm">
						Włącz co najmniej jedną zakładkę powiązaną, aby wybrać kolumny eksportu.
					</p>
				) : (
					<>
						<p className="mb-2 font-semibold text-slate-700 text-sm">Kolumny</p>

						{enabledTabIds.length > 1 ? (
							<div className="mb-3 grid gap-2 sm:grid-cols-3">
								{tabs
									.filter((tab) => enabledTabIds.includes(tab.id))
									.map((tab) => (
										<button
											key={tab.id}
											type="button"
											onClick={() => onActiveTabChange(tab.id)}
											className={`rounded-lg border px-3 py-2 text-left transition-colors ${
												resolvedTabId === tab.id
													? "border-blue-300 bg-blue-50"
													: "border-slate-300 bg-white hover:bg-slate-100"
											}`}
										>
											<p className="font-semibold text-slate-800 text-sm">{tab.label}</p>
										</button>
									))}
							</div>
						) : null}

						<div className="grid gap-2 sm:grid-cols-2">
							{resolvedTab.columns.map((column) => {
								const isSelected = resolvedTab.selectedKeys.includes(column.key);
								const isOnlySelected =
									isSelected && resolvedTab.selectedKeys.length <= 1;

								return (
									<label
										key={column.key}
										className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-800 text-sm transition-colors hover:bg-slate-50"
									>
										<input
											type="checkbox"
											checked={isSelected}
											disabled={isOnlySelected}
											onChange={(event) =>
												resolvedTab.onToggleKey(column.key, event.target.checked)
											}
											className="h-4 w-4 rounded border-slate-300 text-blue-600"
										/>
										<span>{column.label}</span>
									</label>
								);
							})}
						</div>
					</>
				)}

				<div className="mt-4 flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
					<button
						type="button"
						onClick={() => resolvedTab?.onSelectAll()}
						disabled={resolvedTab === null}
						className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Pokaż wszystkie
					</button>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
					>
						Anuluj
					</button>

					<button
						type="button"
						onClick={onConfirm}
						disabled={isConfirmDisabled}
						className="inline-flex h-9 items-center rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
					>
						{isExporting ? "Eksportowanie..." : "Eksportuj"}
					</button>
				</div>
			</div>
		</div>
	);
}
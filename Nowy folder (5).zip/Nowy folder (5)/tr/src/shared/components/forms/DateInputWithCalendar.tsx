import { CalendarDays } from "lucide-react";
import { DateCalendar } from "@mui/x-date-pickers/DateCalendar";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { pl } from "date-fns/locale";

type DateInputWithCalendarProps = {
	label: string;
	value: string;
	onChange: (next: string) => void;
	disabled?: boolean;
};

function parseIsoDate(value: string): Date | undefined {
	if (!value) {
		return undefined;
	}

	const [yearText, monthText, dayText] = value.split("-");
	const year = Number(yearText);
	const month = Number(monthText);
	const day = Number(dayText);
	if (
		!Number.isInteger(year) ||
		!Number.isInteger(month) ||
		!Number.isInteger(day) ||
		month < 1 ||
		month > 12 ||
		day < 1 ||
		day > 31
	) {
		return undefined;
	}

	const date = new Date(year, month - 1, day);
	if (
		date.getFullYear() !== year ||
		date.getMonth() !== month - 1 ||
		date.getDate() !== day
	) {
		return undefined;
	}

	return date;
}

function toIsoDateValue(date: Date) {
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, "0");
	const day = String(date.getDate()).padStart(2, "0");
	return `${year}-${month}-${day}`;
}

const MIN_CALENDAR_DATE = new Date(2016, 0, 1);
const MAX_CALENDAR_DATE = new Date(2030, 11, 31);

function clampDateToCalendarRange(date: Date) {
	if (date < MIN_CALENDAR_DATE) {
		return MIN_CALENDAR_DATE;
	}

	if (date > MAX_CALENDAR_DATE) {
		return MAX_CALENDAR_DATE;
	}

	return date;
}

function formatDisplayDate(value: string) {
	const parsed = parseIsoDate(value);
	if (!parsed) {
		return "";
	}

	const day = String(parsed.getDate()).padStart(2, "0");
	const month = String(parsed.getMonth() + 1).padStart(2, "0");
	const year = parsed.getFullYear();
	return `${day}.${month}.${year}`;
}

export function DateInputWithCalendar({
	label,
	value,
	onChange,
	disabled = false,
}: DateInputWithCalendarProps) {
	const [isCalendarOpen, setIsCalendarOpen] = useState(false);
	const [calendarView, setCalendarView] = useState<"year" | "month" | "day">(
		"day",
	);
	const containerRef = useRef<HTMLDivElement | null>(null);
	const popupRef = useRef<HTMLDivElement | null>(null);
	const [popupPosition, setPopupPosition] = useState<{
		top: number;
		left: number;
	} | null>(null);
	const [tempDate, setTempDate] = useState<Date | null>(() =>
		parseIsoDate(value) ?? null,
	);
	const popupWidth = calendarView === "day" ? 288 : 336;
	const popupHeight = calendarView === "day" ? 420 : 372;

	const updatePopupPosition = () => {
		const anchor = containerRef.current;
		if (!anchor) {
			return;
		}

		const anchorRect = anchor.getBoundingClientRect();
		const viewportPadding = 8;
		const offset = 8;
		const dialog = anchor.closest('[role="dialog"]') as HTMLElement | null;
		const dialogRect = dialog?.getBoundingClientRect() ?? null;
		const availableTop = Math.max(
			viewportPadding,
			dialogRect ? dialogRect.top + 8 : viewportPadding,
		);
		const availableBottom = Math.min(
			window.innerHeight,
			dialogRect ? dialogRect.bottom - 8 : window.innerHeight,
		);
		const spaceBelow = availableBottom - anchorRect.bottom;
		const shouldPreferUp = spaceBelow < popupHeight + offset;
		const requestedTop = shouldPreferUp
			? anchorRect.top - popupHeight - offset
			: anchorRect.bottom + offset;
		const maxTop = Math.max(availableTop, availableBottom - popupHeight);
		const top = Math.min(Math.max(requestedTop, availableTop), maxTop);
		const left = Math.min(
			Math.max(viewportPadding, anchorRect.right - popupWidth),
			window.innerWidth - popupWidth - viewportPadding,
		);

		setPopupPosition({ top, left });
	};

	useEffect(() => {
		setTempDate(parseIsoDate(value) ?? null);
	}, [value]);

	useEffect(() => {
		if (!isCalendarOpen) {
			setPopupPosition(null);
			return;
		}

		updatePopupPosition();
		const handleAnyScroll = (event: Event) => {
			const target = event.target as Node | null;
			if (target && popupRef.current?.contains(target)) {
				return;
			}
			setIsCalendarOpen(false);
		};

		window.addEventListener("resize", updatePopupPosition);
		window.addEventListener("scroll", handleAnyScroll, true);
		return () => {
			window.removeEventListener("resize", updatePopupPosition);
			window.removeEventListener("scroll", handleAnyScroll, true);
		};
	}, [isCalendarOpen, calendarView]);

	useEffect(() => {
		if (!isCalendarOpen) {
			return;
		}

		const handlePointerDown = (event: MouseEvent) => {
			const target = event.target as Node | null;
			if (!target) {
				return;
			}

			const isInsideAnchor =
				containerRef.current && containerRef.current.contains(target);
			const isInsidePopup = popupRef.current && popupRef.current.contains(target);

			if (!isInsideAnchor && !isInsidePopup) {
				setIsCalendarOpen(false);
			}
		};

		const handleEscape = (event: KeyboardEvent) => {
			if (event.key === "Escape") {
				setIsCalendarOpen(false);
			}
		};

		document.addEventListener("mousedown", handlePointerDown);
		document.addEventListener("keydown", handleEscape);

		return () => {
			document.removeEventListener("mousedown", handlePointerDown);
			document.removeEventListener("keydown", handleEscape);
		};
	}, [isCalendarOpen]);

	const handleClear = () => {
		onChange("");
		setTempDate(null);
		setCalendarView("day");
		setIsCalendarOpen(false);
	};

	const handleToday = () => {
		const today = clampDateToCalendarRange(new Date());
		setTempDate(today);
		onChange(toIsoDateValue(today));
		setCalendarView("day");
		setIsCalendarOpen(false);
	};

	return (
		<label className="text-slate-700 text-sm">
			<span className="mb-1 block">{label}</span>
			<div ref={containerRef} className="relative">
				<input
					type="text"
					value={formatDisplayDate(value)}
					placeholder="dd.mm.rrrr"
					readOnly
					disabled={disabled}
					onKeyDown={(event) => {
						if (disabled || !value) {
							return;
						}

						if (event.key === "Backspace" || event.key === "Delete") {
							event.preventDefault();
							handleClear();
						}
					}}
					onClick={() => {
						if (!disabled) {
							setIsCalendarOpen((prev) => {
								const next = !prev;
								if (next) {
									setTempDate(parseIsoDate(value) ?? null);
									setCalendarView("day");
								}
								return next;
							});
						}
					}}
					className="w-full cursor-pointer rounded-lg border border-slate-300 px-3 py-2 pr-10 text-sm outline-none transition-colors focus:border-blue-400 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-700"
				/>
				<button
					type="button"
					disabled={disabled}
					aria-label={`Otwórz kalendarz dla pola: ${label}`}
					onMouseDown={(event) => {
						event.preventDefault();
						event.stopPropagation();
					}}
					onClick={() => {
						if (disabled) {
							return;
						}

						setIsCalendarOpen((prev) => {
							const next = !prev;
							if (next) {
								setTempDate(parseIsoDate(value) ?? null);
								setCalendarView("day");
							}
							return next;
						});
					}}
					className="absolute top-1/2 right-2 inline-flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full border border-slate-200 bg-slate-50 text-slate-600 transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:text-slate-300"
				>
					<CalendarDays size={13} />
				</button>

				{isCalendarOpen && !disabled && popupPosition
					? createPortal(
							<div
								ref={popupRef}
								className={`fixed z-[80] rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_16px_40px_rgba(15,23,42,0.14)] ${
									calendarView === "day" ? "w-[18rem]" : "w-[21rem]"
								}`}
								style={{
									top: popupPosition.top,
									left: popupPosition.left,
								}}
							>
								<LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={pl}>
									<DateCalendar
										value={tempDate}
										onChange={(nextValue) => {
											setTempDate(nextValue);
											if (calendarView === "day" && nextValue) {
												onChange(toIsoDateValue(nextValue));
												setCalendarView("day");
												setIsCalendarOpen(false);
											}
										}}
										view={calendarView}
										onViewChange={(nextView) => setCalendarView(nextView)}
										views={["year", "month", "day"]}
										openTo="day"
										minDate={MIN_CALENDAR_DATE}
										maxDate={MAX_CALENDAR_DATE}
										referenceDate={tempDate ?? new Date()}
										sx={{
											width: "100%",
											maxHeight: calendarView === "day" ? 336 : 356,
											"& .MuiPickersCalendarHeader-root": {
												paddingLeft: 0,
												paddingRight: 0,
												marginBottom: "0.35rem",
											},
											"& .MuiPickersCalendarHeader-label": {
												fontSize: "1.05rem",
												fontWeight: 700,
												color: "#0f172a",
											},
											"& .MuiPickersArrowSwitcher-button": {
												color: "#64748b",
											},
											"& .MuiDayCalendar-weekDayLabel": {
												fontSize: "0.76rem",
												fontWeight: 600,
												color: "#64748b",
											},
											"& .MuiPickersDay-root": {
												fontSize: "0.95rem",
												fontWeight: 500,
												color: "#0f172a",
											},
											"& .MuiPickersDay-root.Mui-selected": {
												backgroundColor: "#1976d2",
												color: "#fff",
											},
											"& .MuiPickersDay-root.MuiPickersDay-today": {
												borderColor: "#94a3b8",
											},
											"& .MuiYearCalendar-button": {
												fontSize: "0.98rem",
												fontWeight: 500,
												color: "#0f172a",
											},
											"& .MuiYearCalendar-button.Mui-selected": {
												backgroundColor: "#1976d2",
												color: "#fff",
											},
											"& .MuiMonthCalendar-button": {
												fontSize: "0.98rem",
												fontWeight: 600,
												color: "#0f172a",
											},
											"& .MuiMonthCalendar-button.Mui-selected": {
												backgroundColor: "#1976d2",
												color: "#fff",
											},
											"& .MuiYearCalendar-root": {
												height: 252,
											},
											"& .MuiMonthCalendar-root": {
												height: 252,
											},
										}}
									/>
								</LocalizationProvider>

								<div className="mt-3 flex items-center justify-between border-slate-100 border-t pt-3">
									<button
										type="button"
										onClick={handleToday}
										className="font-bold text-[11px] text-slate-400 uppercase tracking-wide transition-colors hover:text-slate-500"
									>
										Dzisiaj
									</button>
									<button
										type="button"
										onClick={handleClear}
										className="rounded-lg bg-blue-50 px-4 py-2 font-bold text-[11px] text-blue-600 uppercase tracking-wide transition-colors hover:bg-blue-100"
									>
										Wyczyść
									</button>
								</div>
							</div>,
							document.body,
						)
					: null}
			</div>
		</label>
	);
}

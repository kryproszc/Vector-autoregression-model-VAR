import { useEffect, useMemo, useState } from "react";

import {
	hasActiveTableFilters,
	matchesAdvancedFilterCellValue,
	splitAdvancedFilterCellValue,
} from "@/shared/utils/table-filters";
import type {
	TableAdvancedFilters,
	TableColumnFilters,
	TableSortDirection,
} from "@/shared/types/table";

type UseTableStateOptions<TRow, TColumnKey extends string> = {
	rows: TRow[];
	allColumnKeys: TColumnKey[];
	initialAdvancedFilterColumnKey: TColumnKey;
	getCellValue: (row: TRow, columnKey: TColumnKey) => string;
	pageSize?: number;
	sortComparators?: Partial<
		Record<TColumnKey, (leftRow: TRow, rightRow: TRow) => number>
	>;
};

const DEFAULT_TABLE_PAGE_SIZE = 25;

type PaginationItem = number | "ellipsis";

function createRange(start: number, end: number) {
	const length = end - start + 1;
	return Array.from({ length }, (_, index) => index + start);
}

function buildPaginationItems(
	currentPage: number,
	totalPages: number,
	siblingCount = 1,
): PaginationItem[] {
	const totalPageNumbers = siblingCount + 5;

	if (totalPageNumbers >= totalPages) {
		return createRange(1, totalPages);
	}

	const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
	const rightSiblingIndex = Math.min(currentPage + siblingCount, totalPages);

	const shouldShowLeftDots = leftSiblingIndex > 2;
	const shouldShowRightDots = rightSiblingIndex < totalPages - 2;

	if (!shouldShowLeftDots && shouldShowRightDots) {
		const leftItemCount = 3 + 2 * siblingCount;
		const leftRange = createRange(1, leftItemCount);
		return [...leftRange, "ellipsis", totalPages];
	}

	if (shouldShowLeftDots && !shouldShowRightDots) {
		const rightItemCount = 3 + 2 * siblingCount;
		const rightRange = createRange(totalPages - rightItemCount + 1, totalPages);
		return [1, "ellipsis", ...rightRange];
	}

	if (shouldShowLeftDots && shouldShowRightDots) {
		const middleRange = createRange(leftSiblingIndex, rightSiblingIndex);
		return [1, "ellipsis", ...middleRange, "ellipsis", totalPages];
	}

	return createRange(1, totalPages);
}

export function useTableState<TRow, TColumnKey extends string>({
	rows,
	allColumnKeys,
	initialAdvancedFilterColumnKey,
	getCellValue,
	pageSize = DEFAULT_TABLE_PAGE_SIZE,
	sortComparators,
}: UseTableStateOptions<TRow, TColumnKey>) {
	const [sortColumnKey, setSortColumnKey] = useState<TColumnKey | null>(null);
	const [sortDirection, setSortDirection] = useState<TableSortDirection | null>(
		null,
	);
	const [columnFilters, setColumnFilters] =
		useState<TableColumnFilters<TColumnKey>>({});
	const [advancedFilters, setAdvancedFilters] =
		useState<TableAdvancedFilters<TColumnKey>>({});
	const [isAdvancedFilterModalOpen, setIsAdvancedFilterModalOpen] =
		useState(false);
	const [advancedFilterColumnKey, setAdvancedFilterColumnKey] =
		useState<TColumnKey>(initialAdvancedFilterColumnKey);
	const [advancedFilterSearch, setAdvancedFilterSearch] = useState("");
	const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
	const [hiddenColumns, setHiddenColumns] = useState<TColumnKey[]>([]);
	const [draftHiddenColumns, setDraftHiddenColumns] = useState<TColumnKey[]>([]);
	const [currentPage, setCurrentPage] = useState(1);

	const hasActiveFilters = useMemo(
		() => hasActiveTableFilters(columnFilters, advancedFilters),
		[advancedFilters, columnFilters],
	);

	const canClearFilters = hasActiveFilters;

	const visibleColumns = useMemo(
		() => allColumnKeys.filter((columnKey) => !hiddenColumns.includes(columnKey)),
		[allColumnKeys, hiddenColumns],
	);

	const draftVisibleColumns = useMemo(
		() =>
			allColumnKeys.filter((columnKey) => !draftHiddenColumns.includes(columnKey)),
		[allColumnKeys, draftHiddenColumns],
	);

	const advancedFilterValuesByColumn = useMemo(() => {
		const map: TableAdvancedFilters<TColumnKey> = {};

		allColumnKeys.forEach((columnKey) => {
			const uniqueValues = Array.from(
				new Set(
					rows.flatMap((row) =>
						splitAdvancedFilterCellValue(getCellValue(row, columnKey)),
					),
				),
			).sort((left, right) =>
				left.localeCompare(right, "pl", {
					sensitivity: "base",
					numeric: true,
				}),
			);

			map[columnKey] = uniqueValues;
		});

		return map;
	}, [allColumnKeys, getCellValue, rows]);

	const selectedAdvancedFilterValues = useMemo(
		() => advancedFilters[advancedFilterColumnKey] ?? [],
		[advancedFilterColumnKey, advancedFilters],
	);

	const visibleAdvancedFilterValues = useMemo(() => {
		const sourceValues = advancedFilterValuesByColumn[advancedFilterColumnKey] ?? [];
		const normalizedSearch = advancedFilterSearch.trim().toLowerCase();

		if (!normalizedSearch) {
			return sourceValues;
		}

		return sourceValues.filter((value) =>
			value.toLowerCase().includes(normalizedSearch),
		);
	}, [advancedFilterColumnKey, advancedFilterSearch, advancedFilterValuesByColumn]);

	const filteredAndSortedRows = useMemo(() => {
		const filteredRows = rows.filter((row) => {
			const advancedFiltersMatch = (Object.keys(advancedFilters) as TColumnKey[]).every(
				(columnKey) => {
					const selectedValues = advancedFilters[columnKey] ?? [];
					return matchesAdvancedFilterCellValue(
						getCellValue(row, columnKey),
						selectedValues,
					);
				},
			);

			if (!advancedFiltersMatch) {
				return false;
			}

			return (Object.keys(columnFilters) as TColumnKey[]).every((columnKey) => {
				const filterValue = (columnFilters[columnKey] ?? "").trim();
				if (!filterValue) {
					return true;
				}

				const cellValue = getCellValue(row, columnKey).toLowerCase();
				return cellValue.includes(filterValue.toLowerCase());
			});
		});

		if (!sortColumnKey || !sortDirection) {
			return filteredRows;
		}

		const directionMultiplier = sortDirection === "asc" ? 1 : -1;
		const customComparator = sortComparators?.[sortColumnKey];

		return [...filteredRows].sort((leftRow, rightRow) => {
			if (customComparator) {
				return customComparator(leftRow, rightRow) * directionMultiplier;
			}

			const leftValue = getCellValue(leftRow, sortColumnKey);
			const rightValue = getCellValue(rightRow, sortColumnKey);
			return (
				leftValue.localeCompare(rightValue, "pl", {
					numeric: true,
					sensitivity: "base",
				}) * directionMultiplier
			);
		});
	}, [
		advancedFilters,
		columnFilters,
		getCellValue,
		rows,
		sortColumnKey,
		sortComparators,
		sortDirection,
	]);

	const totalPages = useMemo(
		() => Math.max(1, Math.ceil(filteredAndSortedRows.length / pageSize)),
		[filteredAndSortedRows.length, pageSize],
	);

	useEffect(() => {
		setCurrentPage(totalPages);
	}, [
		advancedFilters,
		columnFilters,
		hiddenColumns,
		totalPages,
		sortColumnKey,
		sortDirection,
	]);

	useEffect(() => {
		setCurrentPage((previous) => Math.min(Math.max(previous, 1), totalPages));
	}, [totalPages]);

	const paginatedRows = useMemo(() => {
		const startIndex = (currentPage - 1) * pageSize;
		const endIndex = startIndex + pageSize;
		return filteredAndSortedRows.slice(startIndex, endIndex);
	}, [currentPage, filteredAndSortedRows, pageSize]);

	const paginationItems = useMemo(
		() => buildPaginationItems(currentPage, totalPages),
		[currentPage, totalPages],
	);

	const handlePageChange = (nextPage: number) => {
		if (!Number.isFinite(nextPage)) {
			return;
		}

		const normalized = Math.trunc(nextPage);
		setCurrentPage(Math.min(Math.max(normalized, 1), totalPages));
	};

	const handleSortByColumn = (columnKey: TColumnKey) => {
		if (sortColumnKey !== columnKey) {
			setSortColumnKey(columnKey);
			setSortDirection("asc");
			return;
		}

		if (sortDirection === "asc") {
			setSortDirection("desc");
			return;
		}

		if (sortDirection === "desc") {
			setSortColumnKey(null);
			setSortDirection(null);
			return;
		}

		setSortDirection("asc");
	};

	const handleFilterChange = (columnKey: TColumnKey, value: string) => {
		setColumnFilters((prev) => ({ ...prev, [columnKey]: value }));
	};

	const clearFilters = () => {
		setColumnFilters({});
		setAdvancedFilters({});
	};

	const toggleAdvancedFilterValue = (value: string) => {
		setAdvancedFilters((prev) => {
			const currentValues = prev[advancedFilterColumnKey] ?? [];
			const nextValues = currentValues.includes(value)
				? currentValues.filter((item) => item !== value)
				: [...currentValues, value];

			return {
				...prev,
				[advancedFilterColumnKey]: nextValues,
			};
		});
	};

	const selectAllVisibleAdvancedFilterValues = () => {
		setAdvancedFilters((prev) => {
			const currentValues = new Set(prev[advancedFilterColumnKey] ?? []);
			visibleAdvancedFilterValues.forEach((value) => currentValues.add(value));

			return {
				...prev,
				[advancedFilterColumnKey]: Array.from(currentValues),
			};
		});
	};

	const clearAdvancedFilterForSelectedColumn = () => {
		setAdvancedFilters((prev) => ({
			...prev,
			[advancedFilterColumnKey]: [],
		}));
	};

	const handleDraftColumnVisibilityChange = (
		columnKey: TColumnKey,
		isVisible: boolean,
	) => {
		if (!isVisible && draftVisibleColumns.length <= 1) {
			return;
		}

		if (isVisible) {
			setDraftHiddenColumns((prev) => prev.filter((key) => key !== columnKey));
			return;
		}

		setDraftHiddenColumns((prev) => {
			if (prev.includes(columnKey)) {
				return prev;
			}

			return [...prev, columnKey];
		});
	};

	const handleOpenViewModal = () => {
		setDraftHiddenColumns(hiddenColumns);
		setIsColumnPickerOpen(true);
	};

	const handleApplyViewChanges = () => {
		setHiddenColumns(
			draftHiddenColumns.filter((columnKey) => allColumnKeys.includes(columnKey)),
		);
		setIsColumnPickerOpen(false);
	};

	return {
		advancedFilterColumnKey,
		advancedFilterSearch,
		advancedFilters,
		canClearFilters,
		clearAdvancedFilterForSelectedColumn,
		clearFilters,
		columnFilters,
		draftHiddenColumns,
		draftVisibleColumns,
		filteredAndSortedRows,
		paginatedRows,
		currentPage,
		totalPages,
		pageSize,
		paginationItems,
		handlePageChange,
		handleApplyViewChanges,
		handleDraftColumnVisibilityChange,
		handleFilterChange,
		handleOpenViewModal,
		handleSortByColumn,
		hiddenColumns,
		isAdvancedFilterModalOpen,
		isColumnPickerOpen,
		selectedAdvancedFilterValues,
		selectAllVisibleAdvancedFilterValues,
		setAdvancedFilterColumnKey,
		setAdvancedFilterSearch,
		setDraftHiddenColumns,
		setIsAdvancedFilterModalOpen,
		setIsColumnPickerOpen,
		sortColumnKey,
		sortDirection,
		toggleAdvancedFilterValue,
		visibleAdvancedFilterValues,
		visibleColumns,
	};
}

"use client";

import { FolderOpen, LogOut, Menu, ShieldCheck, Wrench } from "lucide-react";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import {
	PANEL_MODE_CONFIG,
	getDefaultMenuItemId,
} from "@/app/_components/home-tabs/config";
import { renderTabContent } from "@/app/_components/home-tabs/content-registry";
import type {
	AuthRole,
	AuthUser,
	MenuSection,
	PanelMode,
} from "@/app/_components/home-tabs/types";
import {
	clearStoredAuthSession,
	getStoredAuthSession,
	getStoredAuthToken,
	setStoredAuthSession,
} from "@/features/auth/session";
import type { LoginUser } from "@/features/auth/types";
import { normalizeAuthRole } from "@/features/auth/types";
import { useInactivityTimeout } from "@/shared/hooks/useInactivityTimeout";

const GLOBAL_INACTIVITY_TIMEOUT_MS = 5 * 60_000;
const GLOBAL_INACTIVITY_WARNING_MS = 30_000;

type PasswordLoginResponse = {
	ok?: boolean;
	token?: string;
	expiresAt?: string;
	user?: LoginUser;
};

type MeTokenResponse = {
	ok?: boolean;
	user?: LoginUser;
};

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as { detail?: unknown };
		return typeof payload.detail === "string" ? payload.detail : "";
	} catch {
		return "";
	}
}

function mapLoginUserToAuthUser(user: LoginUser): AuthUser {
	const effectivePermissions = Array.isArray(user.effectivePermissions)
		? user.effectivePermissions
				.filter((permission): permission is string => typeof permission === "string")
				.map((permission) => permission.trim())
				.filter(Boolean)
		: [];
	const isObserver =
		typeof user.accountType === "string" &&
		user.accountType.trim().toLowerCase() === "observer";

	return {
		...user,
		effectivePermissions,
		role: isObserver ? "external_user" : normalizeAuthRole(user.rola),
	};
}

function hasPermission(permissions: Set<string>, permission: string) {
	return permissions.has(permission);
}

function getVisibleMenuSections(
	panelMode: PanelMode,
	role: AuthRole,
	canViewTimeReports: boolean,
	canViewOwnTimeReport: boolean,
	effectivePermissions: Set<string>,
): MenuSection[] {
	const baseSections = PANEL_MODE_CONFIG[panelMode].sections;
	if (panelMode === "registry") {
		const usePermissionBasedRegistryVisibility =
			effectivePermissions.size > 0;

		if (usePermissionBasedRegistryVisibility) {
			return baseSections
				.map((section) => ({
					...section,
					items: section.items.filter((item) => {
						if (item.id === "inspections") {
							return hasPermission(
								effectivePermissions,
								"registry.inspections.read",
							);
						}

						if (item.id === "recommendations") {
							return hasPermission(
								effectivePermissions,
								"registry.recommendations.read",
							);
						}

						if (item.id === "binding_decisions") {
							return hasPermission(
								effectivePermissions,
								"registry.obligating_decisions.read",
							);
						}

						if (item.id === "sanction_requests") {
							return hasPermission(
								effectivePermissions,
								"registry.risk_exposure.read",
							);
						}

						if (item.id === "reports") {
							return hasPermission(
								effectivePermissions,
								"reports.executed_inspections.read",
							);
						}

						if (item.id === "report_protocol_time") {
							return hasPermission(
								effectivePermissions,
								"reports.protocol_time.read",
							);
						}

						if (item.id === "report_statement_time") {
							return hasPermission(
								effectivePermissions,
								"reports.report_time.read",
							);
						}

						if (item.id === "start") {
							return true;
						}

						if (item.id === "report_own_time") {
							return false;
						}

						return true;
					}),
				}))
				.filter((section) => section.items.length > 0);
		}

		return baseSections
			.map((section) => ({
				...section,
				items: section.items.filter((item) => {
					if (
						item.id === "report_protocol_time" ||
						item.id === "report_statement_time"
					) {
						return canViewTimeReports;
					}

					if (item.id === "report_own_time") {
						return role === "inspector" && canViewOwnTimeReport;
					}

					return true;
				}),
			}))
			.filter((section) => section.items.length > 0);
	}

	if (panelMode !== "management") {
		return baseSections;
	}

	if (role !== "team_lead") {
		return baseSections;
	}

	return baseSections
		.map((section) => ({
			...section,
			items: section.items.filter(
				(item) =>
					item.id !== "teams" &&
					item.id !== "logs" &&
					item.id !== "schedules" &&
					item.id !== "external_users",
			),
		}))
		.filter((section) => section.items.length > 0);
}

function getSectionIcon(icon: MenuSection["icon"]) {
	if (icon === "tools") {
		return Wrench;
	}

	return FolderOpen;
}

export function HomeTabs() {
	const router = useRouter();
	const pathname = usePathname();
	const companyShortName = "UPZ";
	const companyFullName = "Rejestr spraw Uniwersytetu Jazdy Rowerem";
	const [initialSession] = useState(() => getStoredAuthSession());

	const [isCheckingSession, setIsCheckingSession] = useState(
		() => initialSession !== null,
	);
	const [isSidebarOpen, setIsSidebarOpen] = useState(false);
	const [panelMode, setPanelMode] = useState<PanelMode>("registry");
	const [selectedItemId, setSelectedItemId] = useState<string>(
		getDefaultMenuItemId("registry"),
	);
	const [authUser, setAuthUser] = useState<AuthUser | null>(() =>
		initialSession ? mapLoginUserToAuthUser(initialSession.user) : null,
	);
	const [loginInput, setLoginInput] = useState("");
	const [passwordInput, setPasswordInput] = useState("");
	const [isLoginSubmitting, setIsLoginSubmitting] = useState(false);
	const [loginError, setLoginError] = useState<string | null>(null);

	useEffect(() => {
		const session = initialSession;
		if (!session) {
			setIsCheckingSession(false);
			return;
		}

		const bootstrapSession = async () => {
			try {
				const response = await fetch("/api/auth/me-token", {
					method: "GET",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${session.token}`,
					},
					cache: "no-store",
				});

				if (!response.ok) {
					clearStoredAuthSession();
					setAuthUser(null);
					return;
				}

				const payload = (await response.json()) as MeTokenResponse;
				if (!payload.user) {
					clearStoredAuthSession();
					setAuthUser(null);
					return;
				}

				setStoredAuthSession({
					token: session.token,
					expiresAt: session.expiresAt,
					user: payload.user,
				});
				setAuthUser(mapLoginUserToAuthUser(payload.user));
			} catch {
				clearStoredAuthSession();
				setAuthUser(null);
			} finally {
				setIsCheckingSession(false);
			}
		};

		void bootstrapSession();
	}, [initialSession]);

	useEffect(() => {
		if (isCheckingSession) {
			return;
		}

		if (!authUser && pathname !== "/login") {
			router.replace("/login");
			return;
		}

		if (authUser && pathname === "/login") {
			router.replace("/");
		}
	}, [authUser, isCheckingSession, pathname, router]);

	const authRole = authUser?.role ?? "inspector";
	const isObserver = authUser?.accountType === "observer";
	const canViewTimeReports = authUser?.canViewTimeReports ?? false;
	const canViewOwnTimeReport = authUser?.canViewOwnTimeReport ?? false;
	const isDirector = authRole === "director";
	const isTeamLead = authRole === "team_lead";
	const isRegistryOnlyUser = !isDirector && !isTeamLead;

	const menuSections = useMemo(
		() =>
			getVisibleMenuSections(
				panelMode,
				authRole,
				canViewTimeReports,
				canViewOwnTimeReport,
				new Set(authUser?.effectivePermissions ?? []),
			),
		[
			authRole,
			authUser?.effectivePermissions,
			canViewOwnTimeReport,
			canViewTimeReports,
			panelMode,
		],
	);

	const firstVisibleItemId = menuSections[0]?.items[0]?.id ?? "";

	useEffect(() => {
		if (!authUser) {
			return;
		}

		if (isRegistryOnlyUser && panelMode !== "registry") {
			setPanelMode("registry");
			return;
		}

		const itemExists = menuSections.some((section) =>
			section.items.some((item) => item.id === selectedItemId),
		);
		if (!itemExists && firstVisibleItemId) {
			setSelectedItemId(firstVisibleItemId);
		}
	}, [
		authUser,
		firstVisibleItemId,
		isRegistryOnlyUser,
		menuSections,
		panelMode,
		selectedItemId,
	]);

	const switchPanelMode = (mode: PanelMode) => {
		if (isRegistryOnlyUser && mode === "management") {
			return;
		}

		setPanelMode(mode);
		const visibleSections = getVisibleMenuSections(
			mode,
			authRole,
			canViewTimeReports,
			canViewOwnTimeReport,
			new Set(authUser?.effectivePermissions ?? []),
		);
		const nextDefaultItemId =
			visibleSections[0]?.items[0]?.id ?? getDefaultMenuItemId(mode);
		setSelectedItemId(nextDefaultItemId);
	};

	const handleMenuItemSelect = (itemId: string) => {
		setSelectedItemId(itemId);
		setIsSidebarOpen(false);
	};

	const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
		event.preventDefault();

		const trimmedLogin = loginInput.trim();
		if (!trimmedLogin || !passwordInput) {
			setLoginError("Login i hasło są wymagane.");
			return;
		}

		setIsLoginSubmitting(true);
		setLoginError(null);

		try {
			const response = await fetch("/api/auth/password-login", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					login: trimmedLogin,
					password: passwordInput,
				}),
			});

			if (response.status === 400) {
				setLoginError("Login i hasło są wymagane.");
				return;
			}

			if (response.status === 401) {
				setLoginError("Nieprawidłowy login lub hasło.");
				return;
			}

			if (response.status === 403) {
				setLoginError("Użytkownik jest nieaktywny.");
				return;
			}

			if (response.status === 429) {
				const detail = await readApiDetail(response);
				setLoginError(
					detail ||
						"Zbyt wiele nieudanych prób logowania. Spróbuj ponownie później.",
				);
				return;
			}

			if (!response.ok) {
				setLoginError("Nie udało się zalogować. Spróbuj ponownie za chwilę.");
				return;
			}

			const payload = (await response.json()) as PasswordLoginResponse;
			if (!payload.token || !payload.expiresAt || !payload.user) {
				setLoginError("Nieprawidłowa odpowiedź serwera logowania.");
				return;
			}

			setStoredAuthSession({
				token: payload.token,
				expiresAt: payload.expiresAt,
				user: payload.user,
			});
			setLoginError(null);
			router.replace("/");
		} catch {
			setLoginError("Brak połączenia z backendem logowania.");
		} finally {
			setIsLoginSubmitting(false);
		}
	};

	const handleLogout = async () => {
		const token = getStoredAuthToken();
		if (token) {
			try {
				await fetch("/api/auth/logout-token", {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Authorization: `Bearer ${token}`,
					},
				});
			} catch {
				// Local logout still needs to happen even if backend is unreachable.
			}
		}

		clearStoredAuthSession();
		setAuthUser(null);
		setLoginError(null);
		setLoginInput("");
		setPasswordInput("");
		router.replace("/login");
	};

	const inactivityTimeout = useInactivityTimeout({
		enabled: Boolean(authUser) && !isCheckingSession,
		inactivityMs: GLOBAL_INACTIVITY_TIMEOUT_MS,
		warningMs: GLOBAL_INACTIVITY_WARNING_MS,
		onTimeout: () => {
			void handleLogout();
		},
	});

	if (isCheckingSession && !authUser) {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<p className="text-slate-200/80">Sprawdzanie sesji...</p>
			</div>
		);
	}

	if (!authUser && pathname !== "/login") {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<p className="text-slate-200/80">Przekierowywanie do logowania...</p>
			</div>
		);
	}

	if (!authUser) {
		return (
			<div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#09152b] px-4 text-slate-100">
				<div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_18%_20%,rgba(103,163,255,0.22),transparent_34%),radial-gradient(circle_at_82%_82%,rgba(56,189,248,0.16),transparent_34%),linear-gradient(180deg,#09152b_0%,#071028_100%)]" />

				<div className="relative z-10 w-full max-w-md rounded-2xl border border-[#37547e] bg-linear-to-b from-[#1d3154]/96 via-[#182a4a]/96 to-[#132341]/96 p-6 shadow-[0_24px_64px_rgba(2,8,23,0.52)]">
					<div className="mb-6">
						<div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-xl border border-[#4c78b1] bg-[#284878] text-sky-100">
							<ShieldCheck size={20} />
						</div>

						<p className="font-semibold text-[11px] text-slate-300/85 uppercase tracking-[0.16em]">
							System
						</p>
						<h1 className="mt-1 font-bold text-4xl text-sky-300 leading-none">
							Rejestr spraw
						</h1>
						<p className="mt-2 text-slate-200/80 text-sm">
							Uniwersytet Jazdy Rowerem
						</p>
						<p className="mt-1 text-slate-200/80 text-sm">
							Zaloguj się, aby kontynuować pracę w aplikacji.
						</p>
					</div>

					<form className="space-y-3" onSubmit={handleLogin}>
						<label className="block text-slate-200 text-sm">
							<span className="mb-1.5 block font-medium">Login</span>
							<input
								type="text"
								value={loginInput}
								onChange={(event) => setLoginInput(event.target.value)}
								placeholder="np. user123"
								className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
							/>
						</label>

						<label className="block text-slate-200 text-sm">
							<span className="mb-1.5 block font-medium">Hasło</span>
							<input
								type="password"
								value={passwordInput}
								onChange={(event) => setPasswordInput(event.target.value)}
								placeholder="Wpisz hasło"
								className="w-full rounded-xl border border-[#4a6a98] bg-[#12213d] px-3 py-2.5 text-slate-100 outline-none transition-colors placeholder:text-slate-400 focus:border-sky-300"
							/>
						</label>

						{loginError ? (
							<p className="font-medium text-rose-300 text-sm">{loginError}</p>
						) : null}

						<button
							type="submit"
							disabled={isLoginSubmitting}
							className="inline-flex h-11 w-full items-center justify-center rounded-xl border border-[#6ea3f0] bg-linear-to-r from-[#2f4f83] to-[#365e9a] font-semibold text-base text-white transition-colors hover:from-[#3a619e] hover:to-[#4673b4] disabled:cursor-not-allowed disabled:opacity-70"
						>
							{isLoginSubmitting ? "Logowanie..." : "Zaloguj"}
						</button>

						<button
							type="button"
							onClick={() => router.push("/forgot-password")}
							className="inline-flex h-9 w-full items-center justify-center rounded-lg border border-[#5b7fae] bg-[#203a62] px-3 font-semibold text-sm text-slate-100 transition-colors hover:bg-[#2a4a79]"
						>
							Nie pamiętam hasła
						</button>
					</form>

					<p className="mt-5 border-[#33517d] border-t pt-3 text-center text-slate-300/85 text-xs">
						Rejestr spraw | Wersja robocza
					</p>
				</div>
			</div>
		);
	}

	return (
		<div className="relative flex h-screen w-full overflow-hidden bg-[#09152b] text-slate-100">
			{inactivityTimeout.isWarning ? (
				<div className="fixed top-4 right-4 z-50 max-w-sm rounded-xl border border-amber-300/60 bg-amber-100 px-4 py-3 text-amber-900 shadow-xl">
					<p className="font-semibold text-sm">Automatyczne wylogowanie</p>
					<p className="mt-1 text-sm">
						Brak aktywności. Wylogowanie za <span className="tabular-nums">{inactivityTimeout.secondsRemaining}</span> s.
					</p>
					<button
						type="button"
						onClick={inactivityTimeout.resetTimer}
						className="mt-3 inline-flex h-8 items-center justify-center rounded-md border border-amber-500/70 bg-amber-200 px-3 font-semibold text-[13px] hover:bg-amber-300"
					>
						Kontynuuj pracę
					</button>
				</div>
			) : null}

			{isSidebarOpen ? (
				<button
					type="button"
					aria-label="Zamknij menu"
					className="fixed inset-0 z-20 bg-slate-950/50 lg:hidden"
					onClick={() => setIsSidebarOpen(false)}
				/>
			) : null}

			<aside
				className={`fixed inset-y-0 left-0 z-30 flex h-screen w-80 flex-col border-[#2f4368] border-r bg-linear-to-b from-[#1d3053] via-[#192b49] to-[#14233e] p-5 shadow-[12px_0_28px_rgba(2,8,23,0.38)] transition-transform duration-300 lg:sticky lg:top-0 lg:translate-x-0 ${
					isSidebarOpen ? "translate-x-0" : "-translate-x-full"
				}`}
			>
				<div className="mb-4 rounded-2xl border border-[#3f5f8f] bg-[#22385c]/85 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.06)]">
					<p className="text-[11px] text-slate-300/80 uppercase tracking-[0.14em]">
						Rejestr spraw
					</p>
					<h1 className="mt-1 font-bold text-[1.75rem] text-sky-300 leading-none">
						{companyShortName}
					</h1>
					<p className="mt-1 text-slate-200/80 text-sm">{companyFullName}</p>
				</div>

				{!isRegistryOnlyUser ? (
					<div className="mb-5 grid grid-cols-2 gap-2 rounded-xl border border-[#37537d] bg-[#1c3153]/80 p-1.5">
						<button
							type="button"
							onClick={() => switchPanelMode("registry")}
							className={`rounded-lg px-3 py-2 font-semibold text-sm transition-colors ${
								panelMode === "registry"
									? "bg-[#345689] text-white"
									: "text-slate-200 hover:bg-[#274470]"
							}`}
						>
							Rejestr
						</button>

						<button
							type="button"
							onClick={() => switchPanelMode("management")}
							className={`rounded-lg px-3 py-2 font-semibold text-sm transition-colors ${
								panelMode === "management"
									? "bg-[#345689] text-white"
									: "text-slate-200 hover:bg-[#274470]"
							}`}
						>
							Zarządzanie
						</button>
					</div>
				) : null}

				<nav className="min-h-0 flex-1 space-y-4 overflow-y-auto pr-1">
					{menuSections.map((section) => {
						const SectionIcon = getSectionIcon(section.icon);

						return (
							<section
								key={section.id}
								className="rounded-2xl border border-[#35517b]/75 bg-[#1a2d4c]/72 p-3.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.03)]"
							>
								<div className="mb-2 flex w-full items-center rounded-md px-1 py-1 text-left font-semibold text-[1rem] text-slate-100">
									<span className="flex items-center gap-2">
										<SectionIcon size={16} className="text-slate-300" />
										{section.label}
									</span>
								</div>

								<div className="space-y-1.5">
									{section.items.map((item) => {
										const isActive = item.id === selectedItemId;

										return (
											<button
												key={item.id}
												type="button"
												onClick={() => handleMenuItemSelect(item.id)}
												className={`group relative flex w-full items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-[1rem] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-sky-300/60 ${
													isActive
														? "border-[#84b0f2] bg-[#345689] text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.08)]"
														: "border-transparent text-slate-100/90 hover:border-[#43628f] hover:bg-[#22375b]"
												}`}
											>
												{isActive ? (
													<span className="absolute inset-y-1.5 left-0 w-1 rounded-r bg-sky-300" />
												) : null}
												<span
													className={`h-1.5 w-1.5 rounded-full ${isActive ? "bg-sky-300" : "bg-slate-500"}`}
												/>
												{item.label}
											</button>
										);
									})}
								</div>
							</section>
						);
					})}
				</nav>

				<div className="mt-4 rounded-xl border border-[#466792] bg-[#1f3558]/90 p-3">
					<p className="text-[11px] text-slate-300/80 uppercase tracking-[0.12em]">
						Konto
					</p>
					<p className="mt-1 truncate font-semibold text-slate-100 text-sm">
						{authUser.login}
					</p>

					<div className="mt-3 flex items-center gap-2">
						<button
							type="button"
							onClick={() => router.push("/change-password")}
							className="inline-flex h-8 items-center justify-center rounded-md border border-[#5b7fae] bg-[#2a4774] px-2.5 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#35598e]"
						>
							Zmień hasło
						</button>

						<button
							type="button"
							onClick={() => void handleLogout()}
							className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[#5b7fae] bg-[#2a4774] px-2.5 font-semibold text-slate-100 text-xs transition-colors hover:bg-[#35598e]"
						>
							<LogOut size={14} />
							Wyloguj
						</button>
					</div>
				</div>
			</aside>

			<main className="min-h-0 min-w-0 flex-1 overflow-hidden p-4 sm:p-6 lg:p-8">
				<div className="mb-4 flex items-center lg:hidden">
					<button
						type="button"
						onClick={() => setIsSidebarOpen(true)}
						className="inline-flex items-center gap-2 rounded-md border border-slate-700 bg-[#1b2c4a] px-3 py-2 text-sm"
					>
						<Menu size={16} />
						Nawigacja
					</button>
				</div>

				{renderTabContent({
					panelMode,
					selectedItemId,
					operatorLogin: authUser.login,
				isObserver,
					authRole: authUser.role,
				})}
			</main>
		</div>
	);
}

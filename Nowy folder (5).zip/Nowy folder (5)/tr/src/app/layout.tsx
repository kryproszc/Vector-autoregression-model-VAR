import "@/styles/globals.css";

import { AuthFetchProvider } from "@/features/auth/components/AuthFetchProvider";
import type { Metadata } from "next";
import { Geist } from "next/font/google";

export const metadata: Metadata = {
	title: "Rejestr spraw",
	description: "Rejestr spraw Uniwersytetu Jazdy Rowerem",
	icons: [{ rel: "icon", url: "/favicon.ico" }],
};

const geist = Geist({
	subsets: ["latin"],
	variable: "--font-geist-sans",
});

export default function RootLayout({
	children,
}: Readonly<{ children: React.ReactNode }>) {
	return (
		<html lang="en" className={geist.variable} suppressHydrationWarning>
			<body className="dark" suppressHydrationWarning>
				<AuthFetchProvider>{children}</AuthFetchProvider>
			</body>
		</html>
	);
}

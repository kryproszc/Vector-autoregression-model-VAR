import type {
	AddDictionaryEntryForm,
	DictionaryEntry,
	DictionaryType,
	TeamLeaderOption,
} from "@/features/dictionaries/types";

type Result<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
	  };

export async function fetchDictionaryTypes(): Promise<
	Result<DictionaryType[]>
> {
	const response = await fetch("/api/slowniki/typy", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać typów słowników (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const data = Array.isArray(payload) ? (payload as DictionaryType[]) : [];
	return { ok: true, data };
}

export async function fetchDictionaryEntries(
	kodTypu: string,
	operatorLogin?: string,
): Promise<Result<DictionaryEntry[]>> {
	const normalizedKodTypu = kodTypu.trim().toLowerCase();
	const customEndpointByKodTypu: Record<string, string> = {
		rozstrzygniecie_wniosku_sankcyjnego_i:
			"/api/slowniki/wnioski-sankcyjne/rozstrzygniecie-i",
	};

	const endpoint =
		customEndpointByKodTypu[normalizedKodTypu] ??
		`/api/slowniki/pozycje?${new URLSearchParams({ kodTypu }).toString()}`;

	const response = await fetch(endpoint, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			...(operatorLogin?.trim()
				? { "X-Operator-Login": operatorLogin.trim() }
				: {}),
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać pozycji słownika (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const data = Array.isArray(payload)
		? (payload as DictionaryEntry[])
		: (Array.isArray((payload as { items?: unknown[] })?.items)
			? ((payload as { items: DictionaryEntry[] }).items ?? [])
			: []);
	return { ok: true, data };
}

type TeamRead = {
	id: number;
	kod: string;
	nazwa: string;
	kierownikUserId: number | null;
	kierownikDisplayName?: string | null;
};

type AdminUserRead = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	rolaId: number;
	aktywny: boolean;
	zespolId?: number | null;
};

type FetchTeamsAsDictionaryEntriesParams = {
	operatorLogin: string;
};

export async function fetchTeamsAsDictionaryEntries({
	operatorLogin,
}: FetchTeamsAsDictionaryEntriesParams): Promise<Result<DictionaryEntry[]>> {
	const response = await fetch("/api/admin/teams", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać listy zespołów (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const teams = Array.isArray(payload) ? (payload as TeamRead[]) : [];

	let userDisplayNameById: Record<number, string> = {};
	try {
		const usersResponse = await fetch("/api/admin/users", {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (usersResponse.ok) {
			const usersPayload = (await usersResponse.json()) as unknown;
			const users = Array.isArray(usersPayload)
				? (usersPayload as AdminUserRead[])
				: [];
			userDisplayNameById = users.reduce<Record<number, string>>(
				(acc, user) => {
					const fullName = `${user.imie ?? ""} ${user.nazwisko ?? ""}`.trim();
					acc[user.id] = fullName || user.login;
					return acc;
				},
				{},
			);

			const fallbackLeaderByTeamId = users.reduce<
				Record<number, { id: number; displayName: string }>
			>((acc, user) => {
				if (
					!user.aktywny ||
					user.rolaId !== 2 ||
					typeof user.zespolId !== "number" ||
					!Number.isFinite(user.zespolId)
				) {
					return acc;
				}

				if (acc[user.zespolId]) {
					return acc;
				}

				acc[user.zespolId] = {
					id: user.id,
					displayName: userDisplayNameById[user.id] ?? user.login,
				};
				return acc;
			}, {});

			const mapped: DictionaryEntry[] = teams.map((team) => {
				const fallbackLeader = fallbackLeaderByTeamId[team.id];
				const resolvedLeaderId =
					typeof team.kierownikUserId === "number"
						? team.kierownikUserId
						: (fallbackLeader?.id ?? null);

				const displayNameFromTeam =
					typeof team.kierownikDisplayName === "string" &&
					team.kierownikDisplayName.trim()
						? team.kierownikDisplayName
						: null;
				const displayNameFromUserId =
					typeof resolvedLeaderId === "number"
						? (userDisplayNameById[resolvedLeaderId] ?? null)
						: null;

				const resolvedLeaderDisplayName =
					displayNameFromTeam ??
					displayNameFromUserId ??
					fallbackLeader?.displayName ??
					null;

				return {
					teamId: team.id,
					kodTypu: "zespoly",
					kodPozycji: team.kod,
					nazwaPozycji: team.nazwa,
					skrotPozycji: team.kod,
					kolejnosc: null,
					aktywny: true,
					kierownikUserId: resolvedLeaderId,
					kierownikDisplayName: resolvedLeaderDisplayName,
				};
			});

			return { ok: true, data: mapped };
		}
	} catch {
		userDisplayNameById = {};
	}

	const mapped: DictionaryEntry[] = teams.map((team) => ({
		teamId: team.id,
		kodTypu: "zespoly",
		kodPozycji: team.kod,
		nazwaPozycji: team.nazwa,
		skrotPozycji: team.kod,
		kolejnosc: null,
		aktywny: true,
		kierownikUserId: team.kierownikUserId,
		kierownikDisplayName:
			team.kierownikDisplayName ??
			(typeof team.kierownikUserId === "number"
				? (userDisplayNameById[team.kierownikUserId] ?? null)
				: null),
	}));

	return { ok: true, data: mapped };
}

type FetchTeamLeadersParams = {
	operatorLogin: string;
};

export async function fetchTeamLeaders({
	operatorLogin,
}: FetchTeamLeadersParams): Promise<Result<TeamLeaderOption[]>> {
	const response = await fetch("/api/admin/users", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return {
			ok: false,
			error: `Nie udało się pobrać listy kierowników (${response.status}).`,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const users = Array.isArray(payload) ? (payload as AdminUserRead[]) : [];

	const leaders = users
		.filter((user) => user.aktywny)
		.map((user) => {
			const fullName = `${user.imie ?? ""} ${user.nazwisko ?? ""}`.trim();
			return {
				id: user.id,
				displayName: fullName || user.login,
			};
		})
		.sort((left, right) =>
			left.displayName.localeCompare(right.displayName, "pl", {
				sensitivity: "base",
			}),
		);

	return { ok: true, data: leaders };
}

type CreateDictionaryEntryParams = {
	operatorLogin: string;
	kodTypu: string;
	form: AddDictionaryEntryForm;
};

export async function createDictionaryEntry({
	operatorLogin,
	kodTypu,
	form,
}: CreateDictionaryEntryParams) {
	const normalizedKodPozycji = form.kodPozycji.trim().toUpperCase();
	const response = await fetch("/api/slowniki/pozycje", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kodTypu,
			...(normalizedKodPozycji ? { kodPozycji: normalizedKodPozycji } : {}),
			nazwaPozycji: form.nazwaPozycji.trim(),
			skrotPozycji: form.skrotPozycji.trim() || null,
			kolejnosc: null,
			aktywny: form.aktywny,
		}),
	});

	if (response.status === 400) {
		return {
			ok: false as const,
			error: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return { ok: false as const, error: "Brak uprawnień.", status: 403 };
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: "Kod pozycji już istnieje w tym słowniku.",
			status: 409,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się dodać pozycji (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

type UpdateDictionaryEntryParams = {
	operatorLogin: string;
	kodTypu: string;
	entryId?: number;
	form: AddDictionaryEntryForm;
};

export async function updateDictionaryEntry({
	operatorLogin,
	kodTypu,
	entryId,
	form,
}: UpdateDictionaryEntryParams) {
	const isIdBasedUpdate =
		typeof entryId === "number" && Number.isFinite(entryId);
	const requestUrl = isIdBasedUpdate
		? `/api/slowniki/pozycje/${entryId}`
		: "/api/slowniki/pozycje";

	const response = await fetch(requestUrl, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify(
			isIdBasedUpdate
				? {
						nazwaPozycji: form.nazwaPozycji.trim(),
						skrotPozycji: form.skrotPozycji.trim() || null,
						aktywny: form.aktywny,
					}
				: {
						kodTypu,
						kodPozycji: form.kodPozycji.trim().toUpperCase(),
						nazwaPozycji: form.nazwaPozycji.trim(),
						skrotPozycji: form.skrotPozycji.trim() || null,
						aktywny: form.aktywny,
					},
		),
	});

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;
			if (typeof detail === "string") {
				apiDetail = detail;
			}
		} catch {
			apiDetail = "";
		}
	}

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return { ok: false as const, error: "Operator nie istnieje.", status: 401 };
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail ? `Brak uprawnień: ${apiDetail}` : "Brak uprawnień.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono pozycji: ${apiDetail}`
				: "Nie znaleziono pozycji słownika.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Konflikt danych: ${apiDetail}`
				: "Kod pozycji już istnieje w tym słowniku.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się zaktualizować pozycji (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

type CreateTeamParams = {
	operatorLogin: string;
	form: AddDictionaryEntryForm;
};

export async function createTeamEntry({
	operatorLogin,
	form,
}: CreateTeamParams) {
	const readApiDetail = async () => {
		const contentType = response.headers.get("content-type") ?? "";
		if (!contentType.includes("application/json")) {
			return "";
		}

		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;

			if (typeof detail === "string") {
				return detail;
			}

			if (Array.isArray(detail)) {
				const joined = detail
					.map((item) => {
						if (typeof item === "string") {
							return item;
						}

						if (item && typeof item === "object") {
							const maybeMsg = (item as { msg?: unknown }).msg;
							return typeof maybeMsg === "string"
								? maybeMsg
								: JSON.stringify(item);
						}

						return "";
					})
					.filter(Boolean)
					.join("; ");

				return joined;
			}

			return "";
		} catch {
			return "";
		}
	};

	const response = await fetch("/api/admin/teams", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kod: form.kodPozycji.trim().toUpperCase(),
			nazwa: form.nazwaPozycji.trim(),
			kierownikUserId: form.kierownikUserId,
		}),
	});

	const apiDetail = await readApiDetail();

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return {
			ok: false as const,
			error: "Brak autoryzacji operatora.",
			status: 401,
		};
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail
				? `Brak uprawnień do zarządzania zespołami: ${apiDetail}`
				: "Brak uprawnień do zarządzania zespołami.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono wskazanego kierownika zespołu: ${apiDetail}`
				: "Nie znaleziono wskazanego kierownika zespołu.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Kod lub nazwa zespołu już istnieje: ${apiDetail}`
				: "Kod lub nazwa zespołu już istnieje.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych wejściowych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się dodać zespołu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

type UpdateTeamParams = {
	operatorLogin: string;
	teamId: number;
	kod: string;
	nazwa: string;
	kierownikUserId: number | null;
};

export async function updateTeamEntry({
	operatorLogin,
	teamId,
	kod,
	nazwa,
	kierownikUserId,
}: UpdateTeamParams) {
	const response = await fetch(`/api/admin/teams/${teamId}`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			kod: kod.trim().toUpperCase(),
			nazwa: nazwa.trim(),
			kierownikUserId,
		}),
	});

	const contentType = response.headers.get("content-type") ?? "";
	let apiDetail = "";

	if (contentType.includes("application/json")) {
		try {
			const payload = (await response.json()) as {
				detail?: unknown;
				message?: unknown;
			};
			const detail = payload.detail ?? payload.message;

			if (typeof detail === "string") {
				apiDetail = detail;
			} else if (Array.isArray(detail)) {
				apiDetail = detail
					.map((item) => {
						if (typeof item === "string") {
							return item;
						}

						if (item && typeof item === "object") {
							const maybeMsg = (item as { msg?: unknown }).msg;
							return typeof maybeMsg === "string"
								? maybeMsg
								: JSON.stringify(item);
						}

						return "";
					})
					.filter(Boolean)
					.join("; ");
			}
		} catch {
			apiDetail = "";
		}
	}

	if (response.status === 400) {
		return {
			ok: false as const,
			error: apiDetail
				? `Błędne dane formularza: ${apiDetail}`
				: "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 401) {
		return {
			ok: false as const,
			error: "Brak autoryzacji operatora.",
			status: 401,
		};
	}

	if (response.status === 403) {
		return {
			ok: false as const,
			error: apiDetail
				? `Brak uprawnień do zarządzania zespołami: ${apiDetail}`
				: "Brak uprawnień do zarządzania zespołami.",
			status: 403,
		};
	}

	if (response.status === 404) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nie znaleziono zespołu lub użytkownika: ${apiDetail}`
				: "Nie znaleziono zespołu lub użytkownika.",
			status: 404,
		};
	}

	if (response.status === 409) {
		return {
			ok: false as const,
			error: apiDetail
				? `Konflikt danych: ${apiDetail}`
				: "Konflikt danych zespołu.",
			status: 409,
		};
	}

	if (response.status === 422) {
		return {
			ok: false as const,
			error: apiDetail
				? `Nieprawidłowy format danych wejściowych: ${apiDetail}`
				: "Nieprawidłowy format danych wejściowych.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: `Nie udało się zaktualizować zespołu (${response.status}).`,
			status: response.status,
		};
	}

	return { ok: true as const };
}

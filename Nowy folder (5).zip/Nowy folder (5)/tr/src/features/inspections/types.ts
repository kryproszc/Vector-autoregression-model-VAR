export type InspectionRow = {
	id: string;
	lp: number;
	kodInspekcji: string;
	nazwaPodmiotu: string;
	typInspekcji: string;
	zakresInspekcji: string;
	aspektKonsumencki: string;
	poczatekInspekcji: string;
	koniecInspekcji: string;
	osobaKierujaca: string;
	skladZespolu: string;
	rynek: string;
	rodzajPodmiotu: string;
	dataProtokolu: string;
	dataDoreczeniaProtokolu: string;
	dataAkceptacjiSprawozdania: string;
	dataDoreczeniaPisma: string;
	dataPismaZastrzezenia: string;
	dataWyslaniaPismaZZastrzezeniami: string;
	dataWplywuPisma: string;
	dataPismaZOdpowiedzia: string;
	dataWyslaniaPismaZOdpowiedzia: string;
	dataAkceptacjiNoty: string;
	dataZalecen: string;
	status: string;
	komentarz: string;
};

export type InspectionColumnKey = Exclude<keyof InspectionRow, "id">;

export type InspectionColumn = {
	key: InspectionColumnKey;
	label: string;
};

export type InspectionViewId = "calosc" | "podstawowe" | "terminy";

export type InspectionViewOption = {
	id: InspectionViewId;
	label: string;
	description: string;
};

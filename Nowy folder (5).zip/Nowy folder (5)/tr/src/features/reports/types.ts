export type ReportInspectionMatrixRawRow = {
	kod_inspekcji?: unknown;
	nazwa_podmiotu?: unknown;
	wartosci?: unknown;
};

export type ReportInspectionMatrixRow = {
	kodInspekcji: string;
	nazwaPodmiotu: string;
	wartosci: Record<string, string>;
};

export type ReportsInspectionsMatrixResponse = {
	lata: string[];
	rows: ReportInspectionMatrixRow[];
};

export type ReportInspectionDetailedRawRow = {
	kod_inspekcji?: unknown;
	nazwa_podmiotu?: unknown;
	inspekcja?: unknown;
	typ_zakres_inspekcji?: unknown;
	rok_poczatku?: unknown;
	poczatek_inspekcji?: unknown;
	koniec_inspekcji?: unknown;
	osoba_kierujaca?: unknown;
	zespol_osoby_kierujacej_kod?: unknown;
	data_protokolu_sprawozdania?: unknown;
	roznica_dni_miedzy_data_protokolu_a_koncem?: unknown;
};

export type ReportInspectionDetailedRow = {
	kodInspekcji: string;
	nazwaPodmiotu: string;
	inspekcja: "K" | "W" | "-";
	kontrola: string;
	rokPoczatku: string;
	poczatekInspekcji: string;
	koniecInspekcji: string;
	osobaKierujaca: string;
	zespol: string;
	data: string;
	czas: string;
};

export type ReportsInspectionsDetailedResponse = {
	rows: ReportInspectionDetailedRow[];
};

export type TimeReportTrendMode = "average" | "median";

export type TimeReportSummaryPivotRow = {
	zespol: string;
	values: Record<string, string | number | null>;
};

export type TimeReportYearCountRow = {
	label: string;
	values: Record<string, string | number | null>;
};

export type TimeReportYearCountByTeamRow = {
	label: string;
	zespol: string;
	inspekcja: "K" | "W";
	values: Record<string, string | number | null>;
};

export type TimeReportOverallRow = {
	[key: string]: string | number | null;
};

export type TimeReportOverallColumn = {
	key: string;
	label: string;
};

export type TimeReportTrendRow = {
	year: number;
	trend: number;
	average: number;
	median: number;
	min: number;
	max: number;
	count: number;
};

export type TimeReportScatterRow = {
	year: number;
	time: number;
	nazwaPodmiotu: string;
	kontrola: string;
	osobaKierujaca: string;
	zespol: string;
};

export type ReportsInspectionsTimeAnalyticsResponse = {
	inspectionType: "K" | "W";
	trendMode: TimeReportTrendMode;
	selectedMetricLabel: string;
	baseCount: number;
	filteredCount: number;
	teamOptions: string[];
	yearOptions: string[];
	detailRows: ReportInspectionDetailedRow[];
	scatterRows: TimeReportScatterRow[];
	trendRows: TimeReportTrendRow[];
	summaryPivotYears: string[];
	summaryPivotRows: TimeReportSummaryPivotRow[];
	yearCountColumns: string[];
	yearCountRows: TimeReportYearCountRow[];
	yearCountByTeamColumns: string[];
	yearCountByTeamRows: TimeReportYearCountByTeamRow[];
	overallColumns: TimeReportOverallColumn[];
	overallRows: TimeReportOverallRow[];
};

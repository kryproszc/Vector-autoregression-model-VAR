import { X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

import { ROLE_OPTIONS } from "@/features/admin-users/constants";
import type { AddUserForm, AdminTeam } from "@/features/admin-users/types";
import type {
	CreateExternalUserForm,
	ExternalPermissionCatalogItem,
} from "@/features/external-users/types";
import { SingleSelectPortalField } from "@/shared/components/forms/SingleSelectPortalField";

function normalizeEmailPart(value: string) {
	return value
		.trim()
		.toLowerCase()
		.normalize("NFD")
		.replace(/[\u0300-\u036f]/g, "")
		.replace(/[^a-z0-9]+/g, ".")
		.replace(/^\.+|\.+$/g, "");
}

function buildSuggestedEmail(imie: string, nazwisko: string) {
	const first = normalizeEmailPart(imie);
	const last = normalizeEmailPart(nazwisko);

	if (!first || !last) {
		return "";
	}

	return `${first}.${last}@gmail.com`;
}

type AddAdminUserModalProps = {
	isOpen: boolean;
	isAddingUser: boolean;
	isTeamRequired: boolean;
	isRoleLocked: boolean;
	isTeamLocked: boolean;
	isTeamsLoading: boolean;
	addUserError: string | null;
	addUserForm: AddUserForm;
	availableTeams: AdminTeam[];
	lockedTeamLabel: string | null;
	isCreatingObserver: boolean;
	observerError: string | null;
	observerForm: CreateExternalUserForm;
	observerPermissionsCatalog: ExternalPermissionCatalogItem[];
	departmentOptions: Array<{ value: string; label: string }>;
	isDepartmentsLoading: boolean;
	onClose: () => void;
	onSubmit: (event: React.FormEvent<HTMLFormElement>) => void;
	onSubmitObserver: (event: React.FormEvent<HTMLFormElement>) => void;
	onFormChange: (updater: (previous: AddUserForm) => AddUserForm) => void;
	onObserverFormChange: (
		updater: (previous: CreateExternalUserForm) => CreateExternalUserForm,
	) => void;
	onToggleObserverPermission: (permissionKey: string) => void;
};

type UserKindTab = "diu" | "observers" | "technical";

type TechnicalUserForm = {
	imie: string;
	nazwisko: string;
	departament: string;
	aktywny: boolean;
};

export function AddAdminUserModal({
	isOpen,
	isAddingUser,
	isTeamRequired,
	isRoleLocked,
	isTeamLocked,
	isTeamsLoading,
	addUserError,
	addUserForm,
	availableTeams,
	lockedTeamLabel,
	isCreatingObserver,
	observerError,
	observerForm,
	observerPermissionsCatalog,
	departmentOptions,
	isDepartmentsLoading,
	onClose,
	onSubmit,
	onSubmitObserver,
	onFormChange,
	onObserverFormChange,
	onToggleObserverPermission,
}: AddAdminUserModalProps) {
	const [activeTab, setActiveTab] = useState<UserKindTab>("diu");
	const [selectedActivity, setSelectedActivity] = useState(true);
	const [diuDepartment, setDiuDepartment] = useState("");
	const [observerDepartment, setObserverDepartment] = useState("");
	const [diuListVisibility, setDiuListVisibility] = useState("visible");
	const [observerListVisibility, setObserverListVisibility] =
		useState("visible");
	const [technicalForm, setTechnicalForm] = useState<TechnicalUserForm>({
		imie: "",
		nazwisko: "",
		departament: "",
		aktywny: true,
	});
	const [technicalListVisibility, setTechnicalListVisibility] =
		useState("visible");

	useEffect(() => {
		if (!isOpen) {
			return;
		}

		setActiveTab("diu");
		setSelectedActivity(true);
		setDiuDepartment("");
		setObserverDepartment("");
		setDiuListVisibility("visible");
		setObserverListVisibility("visible");
		setTechnicalForm({
			imie: "",
			nazwisko: "",
			departament: "",
			aktywny: true,
		});
		setTechnicalListVisibility("visible");
	}, [isOpen]);

	const sortedObserverPermissions = useMemo(
		() =>
			[...observerPermissionsCatalog].sort((left, right) =>
				left.label.localeCompare(right.label, "pl", { sensitivity: "base" }),
			),
		[observerPermissionsCatalog],
	);

	const observerPermissionSections = useMemo(() => {
		const reports = sortedObserverPermissions.filter((permission) =>
			permission.key.startsWith("reports."),
		);
		const registries = sortedObserverPermissions.filter((permission) =>
			permission.key.startsWith("registry."),
		);
		const other = sortedObserverPermissions.filter(
			(permission) =>
				!permission.key.startsWith("reports.") &&
				!permission.key.startsWith("registry."),
		);

		const sections: Array<{
			id: string;
			title: string;
			permissions: ExternalPermissionCatalogItem[];
		}> = [];

		if (reports.length > 0) {
			sections.push({ id: "reports", title: "Raporty", permissions: reports });
		}

		if (registries.length > 0) {
			sections.push({ id: "registry", title: "Rejestry", permissions: registries });
		}

		if (other.length > 0) {
			sections.push({ id: "other", title: "Pozostałe", permissions: other });
		}

		return sections;
	}, [sortedObserverPermissions]);

	const normalizedDepartmentOptions = useMemo(
		() =>
			departmentOptions.map((item) => ({
				value: item.value,
				label: item.label,
			})),
		[departmentOptions],
	);

	const listVisibilityOptions = useMemo(
		() => [
			{ value: "visible", label: "Widoczny" },
			{ value: "hidden", label: "Ukryty" },
		],
		[],
	);

	const diuDepartmentOption = useMemo(() => {
		return (
			normalizedDepartmentOptions.find((item) => {
				const label = item.label
					.trim()
					.toLowerCase()
					.normalize("NFD")
					.replace(/[\u0300-\u036f]/g, "");
				const value = item.value
					.trim()
					.toLowerCase()
					.normalize("NFD")
					.replace(/[\u0300-\u036f]/g, "");
				return label.includes("diu") || value.includes("diu");
			}) ?? null
		);
	}, [normalizedDepartmentOptions]);

	const isDiuDepartmentLocked = activeTab === "diu";
	const isDiuInactiveMode = activeTab === "diu" && !selectedActivity;

	useEffect(() => {
		if (!isDiuDepartmentLocked) {
			return;
		}

		if (diuDepartmentOption && diuDepartment !== diuDepartmentOption.value) {
			setDiuDepartment(diuDepartmentOption.value);
		}
	}, [diuDepartment, diuDepartmentOption, isDiuDepartmentLocked]);

	useEffect(() => {
		if (!isDiuInactiveMode) {
			return;
		}

		onFormChange((previous) => ({
			...previous,
			rolaId: 1,
			email: "",
			login: "",
		}));
	}, [isDiuInactiveMode, onFormChange]);

	useEffect(() => {
		if (activeTab !== "technical") {
			return;
		}

		setSelectedActivity(false);
		onFormChange((previous) => ({
			...previous,
			aktywny: false,
			email: "",
			login: "",
		}));
		onObserverFormChange((previous) => ({
			...previous,
			aktywny: false,
		}));
		setTechnicalForm((previous) => ({
			...previous,
			aktywny: false,
		}));
	}, [activeTab, onFormChange, onObserverFormChange]);

	useEffect(() => {
		onFormChange((previous) => {
			const nextAccountType =
				activeTab === "observers"
					? "observer"
					: activeTab === "technical"
						? "technical"
						: "diu";
			const nextDepartmentCode =
				nextAccountType === "diu"
					? diuDepartment || "DIU"
					: nextAccountType === "technical"
						? technicalForm.departament || null
					: previous.departmentCode;
			const nextListVisibility =
				nextAccountType === "diu"
					? (diuListVisibility as "visible" | "hidden")
					: nextAccountType === "technical"
						? (technicalListVisibility as "visible" | "hidden")
					: previous.listVisibility;

			if (
				previous.accountType === nextAccountType &&
				previous.departmentCode === nextDepartmentCode &&
				previous.listVisibility === nextListVisibility
			) {
				return previous;
			}

			return {
				...previous,
				accountType: nextAccountType,
				departmentCode: nextDepartmentCode,
				listVisibility: nextListVisibility,
			};
		});
	}, [
		activeTab,
		diuDepartment,
		diuListVisibility,
		onFormChange,
		technicalForm.departament,
		technicalListVisibility,
	]);

	const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
		if (activeTab === "diu") {
			onSubmit(event);
			return;
		}

		if (activeTab === "observers") {
			onSubmitObserver(event);
			return;
		}

		onSubmit(event);
	};

	const isCurrentTabActive = selectedActivity;
	const isObserversTabDisabled = !isCurrentTabActive;
	const isTechnicalTabDisabled = isCurrentTabActive;
	const isDiuSelected = activeTab === "diu";
	const isObserversSelected = activeTab === "observers";
	const isTechnicalSelected = activeTab === "technical";

	const setCurrentTabActive = (nextValue: boolean) => {
		setSelectedActivity(nextValue);
		if (!nextValue && activeTab === "observers") {
			setActiveTab("diu");
		}
		onFormChange((previous) => ({
			...previous,
			aktywny: nextValue,
			login: !nextValue && activeTab === "diu" ? "" : previous.login,
			email: !nextValue && activeTab === "diu" ? "" : previous.email,
		}));
		onObserverFormChange((previous) => ({
			...previous,
			aktywny: nextValue,
		}));
		setTechnicalForm((previous) => ({
			...previous,
			aktywny: nextValue,
		}));
	};

	const sharedLogin =
		activeTab === "observers" ? observerForm.login : addUserForm.login;
	const sharedImie =
		activeTab === "technical"
			? technicalForm.imie
			: activeTab === "observers"
				? observerForm.imie
				: addUserForm.imie;
	const sharedNazwisko =
		activeTab === "technical"
			? technicalForm.nazwisko
			: activeTab === "observers"
				? observerForm.nazwisko
				: addUserForm.nazwisko;
	const sharedEmail =
		activeTab === "observers" ? observerForm.email : addUserForm.email;

	const isSharedLoginRequired =
		isObserversSelected || (isDiuSelected && isCurrentTabActive);
	const isSharedEmailRequired = isObserversSelected;
	const isSharedLoginDisabled =
		isTechnicalSelected || (isDiuSelected && !isCurrentTabActive);
	const isSharedEmailDisabled =
		isTechnicalSelected || (isDiuSelected && !isCurrentTabActive);

	const handleSharedImieChange = (nextImie: string) => {
		onFormChange((previous) => {
			if (isDiuInactiveMode || isTechnicalSelected) {
				return {
					...previous,
					imie: nextImie,
					email: "",
				};
			}

			const previousSuggestedEmail = buildSuggestedEmail(
				previous.imie,
				previous.nazwisko,
			);
			const nextSuggestedEmail = buildSuggestedEmail(nextImie, previous.nazwisko);

			return {
				...previous,
				imie: nextImie,
				email:
					!previous.email || previous.email === previousSuggestedEmail
						? nextSuggestedEmail
						: previous.email,
			};
		});

		onObserverFormChange((previous) => {
			const previousSuggestedEmail = buildSuggestedEmail(
				previous.imie,
				previous.nazwisko,
			);
			const nextSuggestedEmail = buildSuggestedEmail(nextImie, previous.nazwisko);

			return {
				...previous,
				imie: nextImie,
				email:
					!previous.email || previous.email === previousSuggestedEmail
						? nextSuggestedEmail
						: previous.email,
			};
		});

		setTechnicalForm((previous) => ({
			...previous,
			imie: nextImie,
		}));
	};

	const handleSharedNazwiskoChange = (nextNazwisko: string) => {
		onFormChange((previous) => {
			if (isDiuInactiveMode || isTechnicalSelected) {
				return {
					...previous,
					nazwisko: nextNazwisko,
					email: "",
				};
			}

			const previousSuggestedEmail = buildSuggestedEmail(
				previous.imie,
				previous.nazwisko,
			);
			const nextSuggestedEmail = buildSuggestedEmail(previous.imie, nextNazwisko);

			return {
				...previous,
				nazwisko: nextNazwisko,
				email:
					!previous.email || previous.email === previousSuggestedEmail
						? nextSuggestedEmail
						: previous.email,
			};
		});

		onObserverFormChange((previous) => {
			const previousSuggestedEmail = buildSuggestedEmail(
				previous.imie,
				previous.nazwisko,
			);
			const nextSuggestedEmail = buildSuggestedEmail(previous.imie, nextNazwisko);

			return {
				...previous,
				nazwisko: nextNazwisko,
				email:
					!previous.email || previous.email === previousSuggestedEmail
						? nextSuggestedEmail
						: previous.email,
			};
		});

		setTechnicalForm((previous) => ({
			...previous,
			nazwisko: nextNazwisko,
		}));
	};

	if (!isOpen) {
		return null;
	}

	return (
		<div className="fixed inset-0 z-50 flex items-center justify-center p-4">
			<div aria-hidden="true" className="absolute inset-0 bg-slate-950/65" />

			<div
				role="dialog"
				aria-modal="true"
				aria-label="Dodaj użytkownika"
				className="relative z-10 w-full max-w-6xl rounded-2xl border border-slate-300 bg-white p-4 text-slate-900 shadow-[0_24px_56px_rgba(2,8,23,0.35)] sm:p-5"
			>
				<div className="mb-4 flex items-center justify-between gap-3 border-slate-200 border-b pb-3">
					<div>
						<h3 className="font-semibold text-base text-slate-900">
							Nowy użytkownik
						</h3>
					</div>

					<button
						type="button"
						onClick={onClose}
						className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-slate-300 text-slate-600 transition-colors hover:bg-slate-100"
					>
						<X size={14} />
					</button>
				</div>

				<form className="flex max-h-[82vh] flex-col" onSubmit={handleSubmit}>
					<div className="space-y-4 overflow-y-auto pr-1">
					<div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
						<div className="grid gap-3 lg:grid-cols-12">
						<div className="lg:col-span-4">
							<div className="rounded-lg border border-slate-200 bg-white px-2.5 py-2">
							<p className="mb-2 font-semibold text-slate-800 text-sm">Dostęp do konta</p>
							<div className="inline-flex rounded-lg border border-slate-300 bg-white p-1">
							<button
								type="button"
								onClick={() => setCurrentTabActive(true)}
								disabled={isTechnicalSelected}
								className={`rounded-md px-3 py-1.5 font-semibold text-sm transition-colors ${
									isTechnicalSelected
										? "cursor-not-allowed text-slate-400"
										: isCurrentTabActive
										? "bg-[#345689] text-white"
										: "text-slate-700 hover:bg-slate-100"
								}`}
							>
								Aktywny
							</button>
							<button
								type="button"
								onClick={() => setCurrentTabActive(false)}
								className={`rounded-md px-3 py-1.5 font-semibold text-sm transition-colors ${
									!isCurrentTabActive
										? "bg-[#345689] text-white"
										: "text-slate-700 hover:bg-slate-100"
								}`}
							>
								Nieaktywny
							</button>
							</div>
						</div>
						</div>

						<div className="lg:col-span-8">
							<div className="rounded-lg border border-slate-200 bg-white px-2.5 py-2">
							<p className="mb-2 font-semibold text-slate-800 text-sm">Typ użytkownika</p>
							<div className="grid gap-2 sm:grid-cols-3">
							<button
								type="button"
								onClick={() => setActiveTab("diu")}
								className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
									activeTab === "diu"
										? "border-[#84b0f2] bg-[#345689] text-white"
										: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
								}`}
							>
								<span className="block text-center leading-[1.05]">
									Pracownicy
									<br />
									DIU
								</span>
							</button>
							<button
								type="button"
								onClick={() => setActiveTab("observers")}
								disabled={isObserversTabDisabled}
								className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
									isObserversTabDisabled
										? "cursor-not-allowed border-slate-300 bg-slate-100 text-slate-400"
										: activeTab === "observers"
										? "border-[#84b0f2] bg-[#345689] text-white"
										: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
								}`}
							>
								<span className="block text-center leading-[1.05]">
									Użytkownicy
									<br />
									obserwatorzy
								</span>
							</button>
							<button
								type="button"
								onClick={() => setActiveTab("technical")}
								disabled={isTechnicalTabDisabled}
								className={`inline-flex min-h-11 w-full items-center justify-center rounded-lg border px-3 py-1.5 font-semibold text-center text-sm leading-tight transition-colors ${
									isTechnicalTabDisabled
										? "cursor-not-allowed border-slate-300 bg-slate-100 text-slate-400"
										: activeTab === "technical"
										? "border-[#84b0f2] bg-[#345689] text-white"
										: "border-slate-300 bg-white text-slate-700 hover:bg-slate-100"
								}`}
							>
								<span className="block text-center leading-[1.05]">
									Użytkownicy
									<br />
									techniczni
								</span>
							</button>
						</div>
						</div>
						</div>
						</div>
					</div>

					<div className="rounded-lg border border-slate-200 p-3">
						<p className="mb-2 font-semibold text-slate-800 text-sm">Dane podstawowe</p>
						<div className="grid gap-3 sm:grid-cols-2">
							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Login {isSharedLoginRequired ? "*" : ""}</span>
								<input
									required={isSharedLoginRequired}
									value={sharedLogin}
									onChange={(event) => {
										const nextValue = event.target.value;
										onFormChange((previous) => ({ ...previous, login: nextValue }));
										onObserverFormChange((previous) => ({
											...previous,
											login: nextValue,
										}));
									}}
									disabled={isSharedLoginDisabled}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500"
								/>
							</label>

							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Imię *</span>
								<input
									required={isDiuSelected || isObserversSelected || isTechnicalSelected}
									value={sharedImie}
									onChange={(event) => handleSharedImieChange(event.target.value)}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>

							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">Nazwisko *</span>
								<input
									required={isDiuSelected || isObserversSelected || isTechnicalSelected}
									value={sharedNazwisko}
									onChange={(event) => handleSharedNazwiskoChange(event.target.value)}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400"
								/>
							</label>

							<label className="text-slate-700 text-sm">
								<span className="mb-1 block">E-mail {isSharedEmailRequired ? "*" : ""}</span>
								<input
									type="email"
									required={isSharedEmailRequired}
									value={sharedEmail}
									onChange={(event) => {
										const nextValue = event.target.value;
										onFormChange((previous) => ({ ...previous, email: nextValue }));
										onObserverFormChange((previous) => ({
											...previous,
											email: nextValue,
										}));
									}}
									disabled={isSharedEmailDisabled}
									className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none transition-colors focus:border-blue-400 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-500"
								/>
							</label>
						</div>
					</div>

					<div className="grid gap-4 xl:grid-cols-2">
						<div className="space-y-4">
							<fieldset
								disabled={!isDiuSelected}
								className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
									isDiuSelected ? "" : "opacity-60"
								}`}
							>
								<p className="font-semibold text-slate-800 text-sm">Pracownicy DIU</p>
								<div className="grid gap-3 sm:grid-cols-2">
									<div className="text-slate-700 text-sm">
										<SingleSelectPortalField
											label="Rola *"
											value={isDiuSelected ? String(addUserForm.rolaId) : ""}
											options={ROLE_OPTIONS.map((role) => ({
												value: String(role.id),
												label: role.label,
											}))}
											placeholder="Wybierz rolę"
											onChange={(next) => {
												if (!next) {
													return;
												}
												const nextRoleId = Number(next);
												onFormChange((previous) => ({
													...previous,
													rolaId: nextRoleId,
													zespolId: nextRoleId === 3 ? null : previous.zespolId,
												}));
											}}
											disabled={!isDiuSelected || isRoleLocked || isDiuInactiveMode}
										/>
										{isRoleLocked && !isDiuInactiveMode ? (
											<p className="mt-1 text-slate-500 text-xs">
												Rola ustawiona przez uprawnienia kierownika zespołu.
											</p>
										) : null}
									</div>

									<div className="text-slate-700 text-sm">
										<SingleSelectPortalField
											label={`Zespół ${isTeamRequired ? "*" : ""}`}
											value={
												isDiuSelected && addUserForm.zespolId
													? String(addUserForm.zespolId)
													: ""
											}
											options={availableTeams.map((team) => ({
												value: String(team.id),
												label: `${team.skroconaNazwa} - ${team.pelnaNazwa}`,
											}))}
											placeholder={
												isTeamRequired ? "Wybierz zespół" : "Nie dotyczy dla dyrektora"
											}
											onChange={(next) =>
												onFormChange((previous) => ({
													...previous,
													zespolId: next ? Number(next) : null,
												}))
											}
											disabled={!isDiuSelected || !isTeamRequired || isTeamsLoading || isTeamLocked}
										/>
										{isTeamLocked && lockedTeamLabel ? (
											<p className="mt-1 text-slate-500 text-xs">
												Przypisanie tylko do zespołu: {lockedTeamLabel}
											</p>
										) : null}
									</div>
								</div>
								<div className="grid gap-3 sm:grid-cols-2">
									<SingleSelectPortalField
										label="Departament *"
										value={isDiuSelected ? diuDepartment : ""}
										options={normalizedDepartmentOptions}
										placeholder={
											isDepartmentsLoading
												? "Ładowanie departamentów..."
												: "Wybierz departament"
										}
										onChange={(next) => setDiuDepartment(next)}
										disabled={
											!isDiuSelected ||
											isDiuDepartmentLocked ||
											isDepartmentsLoading ||
											normalizedDepartmentOptions.length === 0
										}
									/>
									<SingleSelectPortalField
										label="Widoczność na liście *"
										value={isDiuSelected ? diuListVisibility : ""}
										options={listVisibilityOptions}
										placeholder="Wybierz"
										onChange={(next) => setDiuListVisibility(next || "visible")}
									/>
								</div>
							</fieldset>

							<fieldset
								disabled={!isTechnicalSelected}
								className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
									isTechnicalSelected ? "" : "opacity-60"
								}`}
							>
								<p className="font-semibold text-slate-800 text-sm">Użytkownicy techniczni</p>
								<div className="grid gap-3 sm:grid-cols-2">
									<div>
										<SingleSelectPortalField
											label="Departament *"
											value={technicalForm.departament}
											options={normalizedDepartmentOptions}
											placeholder={
												isDepartmentsLoading
													? "Ładowanie departamentów..."
													: "Wybierz departament"
											}
											onChange={(next) =>
												setTechnicalForm((previous) => ({
													...previous,
													departament: next,
												}))
											}
											disabled={
												!isTechnicalSelected ||
												isDepartmentsLoading ||
												normalizedDepartmentOptions.length === 0
											}
										/>
									</div>
									<div>
										<SingleSelectPortalField
											label="Widoczność na liście *"
											value={technicalListVisibility}
											options={listVisibilityOptions}
											placeholder="Wybierz"
											onChange={(next) => setTechnicalListVisibility(next || "visible")}
											disabled={!isTechnicalSelected}
										/>
									</div>
								</div>
							</fieldset>
						</div>

						<div>
							<fieldset
								disabled={!isObserversSelected || !isCurrentTabActive}
								className={`space-y-3 rounded-lg border border-slate-200 p-3 ${
									isObserversSelected && isCurrentTabActive ? "" : "opacity-60"
								}`}
							>
								<p className="font-semibold text-slate-800 text-sm">Użytkownicy obserwatorzy</p>

								<div className="grid gap-3 sm:grid-cols-2">
									<SingleSelectPortalField
										label="Departament *"
										value={observerDepartment}
										options={normalizedDepartmentOptions}
										placeholder={
											isDepartmentsLoading
												? "Ładowanie departamentów..."
												: "Wybierz departament"
										}
										onChange={(next) => setObserverDepartment(next)}
										disabled={
											!isObserversSelected ||
											!isCurrentTabActive ||
											isDepartmentsLoading ||
											normalizedDepartmentOptions.length === 0
										}
									/>
									<SingleSelectPortalField
										label="Widoczność na liście *"
										value={observerListVisibility}
										options={listVisibilityOptions}
										placeholder="Wybierz"
										onChange={(next) => setObserverListVisibility(next || "visible")}
									/>
								</div>

								<div className="rounded-lg border border-slate-200 p-3 max-h-[360px] overflow-y-auto">
									<p className="mb-2 font-semibold text-slate-800 text-sm">Widoczność modułów *</p>
									{sortedObserverPermissions.length === 0 ? (
										<p className="mb-2 rounded-md border border-amber-300 bg-amber-50 px-2.5 py-2 text-amber-800 text-xs">
											Nie udało się odczytać katalogu uprawnień z backendu.
										</p>
									) : null}
									<div className="space-y-3">
										{observerPermissionSections.map((section) => (
											<div key={section.id} className="space-y-2">
												<p className="font-semibold text-slate-700 text-xs uppercase tracking-[0.06em]">
													{section.title}
												</p>
												<div className="grid gap-x-4 gap-y-1 sm:grid-cols-2">
													{section.permissions.map((permission) => {
														const checked = observerForm.permissions.includes(permission.key);
														return (
															<label
																key={permission.key}
																className={`flex items-start gap-2 py-1 text-sm leading-5 transition-colors ${
																	checked
																		? "text-[#1f4d8f]"
																		: "text-slate-700 hover:text-slate-900"
																}`}
															>
																<input
																	type="checkbox"
																	checked={checked}
																	disabled={!isObserversSelected || !isCurrentTabActive}
																	onChange={() => onToggleObserverPermission(permission.key)}
																	className="mt-0.5 h-3.5 w-3.5 accent-[#345689]"
																/>
																<span className="min-w-0 pr-1">
																	<span className="block font-medium text-sm">
																		{permission.label}
																	</span>
																</span>
															</label>
														);
													})}
												</div>
											</div>
										))}
									</div>
								</div>

							</fieldset>
						</div>
					</div>

					{(isDiuSelected || isTechnicalSelected) && addUserError ? (
						<p className="font-medium text-rose-600 text-sm">{addUserError}</p>
					) : null}

					{isObserversSelected && observerError ? (
						<p className="font-medium text-rose-600 text-sm">{observerError}</p>
					) : null}
					</div>

					<div className="mt-4 flex flex-wrap justify-end gap-2 border-slate-200 border-t pt-3">
						<button
							type="button"
							onClick={onClose}
							className="inline-flex h-9 items-center rounded-lg border border-slate-300 bg-transparent px-3 font-semibold text-slate-700 text-sm transition-colors hover:bg-slate-100"
						>
							Anuluj
						</button>

						<button
							type="submit"
							disabled={isAddingUser || isCreatingObserver}
							className="inline-flex h-9 items-center gap-2 rounded-lg border border-[#6ea3f0] bg-[#2d4d7f] px-3 font-semibold text-slate-100 text-sm transition-colors hover:bg-[#375f99] disabled:cursor-not-allowed disabled:opacity-70"
						>
							{isAddingUser || isCreatingObserver ? "Dodawanie..." : "Dodaj"}
						</button>
					</div>
				</form>
			</div>
		</div>
	);
}

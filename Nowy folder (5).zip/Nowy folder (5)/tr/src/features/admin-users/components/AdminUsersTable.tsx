import { History, Pencil } from "lucide-react";

import type { AdminUser } from "@/features/admin-users/types";
import { getRoleLabelById } from "@/features/admin-users/utils";

type AdminUsersTableProps = {
	users: AdminUser[];
	usersError: string | null;
	isUsersLoading: boolean;
	canEditUser: (user: AdminUser) => boolean;
	onEditUser: (user: AdminUser) => void;
	onViewHistory: (user: AdminUser) => void;
	className?: string;
};

export function AdminUsersTable({
	users,
	usersError,
	isUsersLoading,
	canEditUser,
	onEditUser,
	onViewHistory,
	className,
}: AdminUsersTableProps) {
	const getAccountTypeLabel = (accountType: AdminUser["accountType"]) => {
		switch ((accountType ?? "").toLowerCase()) {
			case "diu":
				return "Pracownicy DIU";
			case "observer":
			case "observers":
				return "Użytkownicy obserwatorzy";
			case "technical":
				return "Użytkownicy techniczni";
			default:
				return "-";
		}
	};

	const getListVisibilityLabel = (listVisibility: AdminUser["listVisibility"]) => {
		switch ((listVisibility ?? "").toLowerCase()) {
			case "visible":
			case "widoczny":
				return "Widoczny";
			case "hidden":
			case "ukryty":
				return "Ukryty";
			default:
				return "-";
		}
	};

	const formatDateTime = (value: string | null | undefined) => {
		if (!value) {
			return "-";
		}

		const parsed = new Date(value);
		if (Number.isNaN(parsed.getTime())) {
			return value;
		}

		return parsed.toLocaleString("pl-PL", {
			year: "numeric",
			month: "2-digit",
			day: "2-digit",
			hour: "2-digit",
			minute: "2-digit",
		});
	};

	const headerCellClass =
		"sticky top-0 z-10 border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold";

	return (
		<div
			className={`subtle-horizontal-scroll subtle-vertical-scroll min-h-96 overflow-x-auto overflow-y-auto rounded-xl border border-slate-300 bg-white shadow-[0_10px_28px_rgba(2,8,23,0.18)] ${className ?? "h-full"}`}
		>
			{usersError ? (
				<p className="border-rose-200 border-b bg-rose-50 px-3 py-2 font-medium text-rose-700 text-sm">
					{usersError}
				</p>
			) : null}

			{isUsersLoading ? (
				<p className="border-slate-200 border-b bg-slate-50 px-3 py-2 font-medium text-slate-600 text-sm">
					Ładowanie użytkowników...
				</p>
			) : null}

			<table className="min-w-full border-collapse text-slate-900 text-sm">
				<thead>
					<tr className="bg-slate-100 text-slate-800">
						<th className={headerCellClass}>
							Login
						</th>
						<th className={headerCellClass}>
							Imię i nazwisko
						</th>
						<th className={headerCellClass}>
							Typ konta
						</th>
						<th className={headerCellClass}>
							Rola
						</th>
						<th className={headerCellClass}>
							Zespół
						</th>
						<th className={headerCellClass}>
							Departament
						</th>
						<th className={headerCellClass}>
							E-mail
						</th>
						<th className={headerCellClass}>
							Status
						</th>
						<th className={headerCellClass}>
							Widoczność
						</th>
						<th className={headerCellClass}>
							Ostatnia zmiana
						</th>
						<th className={headerCellClass} />
					</tr>
				</thead>

				<tbody>
					{users.map((user) => (
						<tr
							key={user.id}
							className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
						>
							<td className="whitespace-nowrap px-3 py-2.5 font-medium">
								{user.login || "brak"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.imie} {user.nazwisko}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getAccountTypeLabel(user.accountType)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getRoleLabelById(user.rolaId, user.rola)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.zespolSkroconaNazwa && user.zespolPelnaNazwa
									? `${user.zespolSkroconaNazwa} - ${user.zespolPelnaNazwa}`
									: "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.departmentLabel ?? user.departmentCode ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.email ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								<span
									className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${
										user.aktywny
											? "bg-emerald-100 text-emerald-800"
											: "bg-slate-200 text-slate-700"
									}`}
								>
									{user.aktywny ? "Aktywny" : "Nieaktywny"}
								</span>
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getListVisibilityLabel(user.listVisibility)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{formatDateTime(user.profileChangedAt)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								<button
									type="button"
									onClick={() => onViewHistory(user)}
									className="mr-2 inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
								>
									<History size={12} />
									Historia
								</button>
								<button
									type="button"
									onClick={() => onEditUser(user)}
									disabled={!canEditUser(user)}
									className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
								>
									<Pencil size={12} />
									Edytuj
								</button>
							</td>
						</tr>
					))}

					{!isUsersLoading && users.length === 0 ? (
						<tr>
							<td colSpan={11} className="px-3 py-8 text-center text-slate-500">
								Brak użytkowników do wyświetlenia.
							</td>
						</tr>
					) : null}
				</tbody>
			</table>
		</div>
	);
}

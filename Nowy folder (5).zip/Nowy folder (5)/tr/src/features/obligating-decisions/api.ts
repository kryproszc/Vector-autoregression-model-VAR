import type {
	AvailableRecommendation,
	ObligatingDecisionListResponse,
	ObligatingDecisionRead,
	ObligatingDecisionWrite,
} from "@/features/obligating-decisions/types";

export type ObligatingDecisionLockConflict = {
	module: string;
	recordId: string;
	ownerUserId: string;
	ownerLogin: string;
	ownerDisplayName: string;
	acquiredAt: string;
	expiresAt: string;
};

type ApiResult<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
			errorCode?: string;
			lockConflict?: ObligatingDecisionLockConflict;
			lockErrorCode?: string;
			lockReason?: string;
			currentUpdatedAt?: string;
	  };

export type ObligatingDecisionPersonOption = {
	id: number;
	label: string;
};

function getErrorMessageByStatus(status: number) {
	if (status === 400) return "Błędne dane wejściowe.";
	if (status === 401) return "Brak autoryzacji operatora.";
	if (status === 403) return "Brak uprawnień do operacji.";
	if (status === 404) return "Nie znaleziono zasobu.";
	if (status === 409)
		return "Dane zostały zmienione przez innego użytkownika. Odśwież widok i spróbuj ponownie.";
	if (status === 423) return "Błąd blokady rekordu.";
	return `Błąd API (${status}).`;
}

function toStringValue(value: unknown) {
	return typeof value === "string" ? value.trim() : "";
}

function getDomainPayloadSource(payload: unknown): Record<string, unknown> | null {
	if (!payload || typeof payload !== "object") {
		return null;
	}

	const source = payload as Record<string, unknown>;
	const detail = source.detail;
	if (detail && typeof detail === "object" && !Array.isArray(detail)) {
		return detail as Record<string, unknown>;
	}

	return source;
}

function parseErrorCode(payload: unknown) {
	const source = getDomainPayloadSource(payload);
	if (!source) {
		return undefined;
	}

	const code = toStringValue(source.code);
	return code || undefined;
}

function parseLockConflict(payload: unknown): ObligatingDecisionLockConflict | undefined {
	const source = getDomainPayloadSource(payload);
	if (!source) {
		return undefined;
	}

	if (toStringValue(source.code) !== "RECORD_LOCKED") {
		return undefined;
	}

	return {
		module: toStringValue(source.module),
		recordId: toStringValue(source.recordId),
		ownerUserId: toStringValue(source.ownerUserId),
		ownerLogin: toStringValue(source.ownerLogin),
		ownerDisplayName: toStringValue(source.ownerDisplayName),
		acquiredAt: toStringValue(source.acquiredAt),
		expiresAt: toStringValue(source.expiresAt),
	};
}

function parseCurrentUpdatedAt(payload: unknown) {
	const source = getDomainPayloadSource(payload);
	if (!source) {
		return undefined;
	}
	const value = source.currentUpdatedAt ?? source.updatedAt;
	const parsed = toStringValue(value);
	return parsed || undefined;
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
		};
		const detail = payload.detail ?? payload.message;

		if (typeof detail === "string") {
			return detail;
		}

		if (Array.isArray(detail)) {
			return detail
				.map((item) => {
					if (typeof item === "string") return item;
					if (item && typeof item === "object") {
						const maybeMsg = (item as { msg?: unknown }).msg;
						return typeof maybeMsg === "string"
							? maybeMsg
							: JSON.stringify(item);
					}
					return "";
				})
				.filter(Boolean)
				.join("; ");
		}

		if (detail && typeof detail === "object" && !Array.isArray(detail)) {
			const detailObject = detail as Record<string, unknown>;
			const maybeMessage =
				toStringValue(detailObject.message) ||
				toStringValue(detailObject.reason) ||
				toStringValue(detailObject.code);
			return maybeMessage;
		}

		return "";
	} catch {
		return "";
	}
}

function parseAvailablePeoplePayload(
	payload: unknown,
): ObligatingDecisionPersonOption[] {
	const toRecord = (value: unknown): Record<string, unknown> | null =>
		value && typeof value === "object" ? (value as Record<string, unknown>) : null;
	const readString = (value: unknown): string =>
		typeof value === "string" ? value.trim() : "";
	const readNumber = (value: unknown): number => {
		if (typeof value === "number") {
			return value;
		}

		if (typeof value === "string") {
			return Number(value.trim());
		}

		return NaN;
	};

	const root = toRecord(payload);
	const dataNode = root ? toRecord(root.data) : null;
	const candidates: unknown[] = [
		payload,
		root?.items,
		root?.data,
		root?.results,
		root?.users,
		root?.people,
		dataNode?.items,
		dataNode?.results,
		dataNode?.users,
		dataNode?.people,
	].filter((entry) => entry !== undefined);

	const rawItems = candidates.find((entry) => Array.isArray(entry));
	if (!Array.isArray(rawItems)) {
		return [];
	}

	const deduped = new Map<string, ObligatingDecisionPersonOption>();

	for (const item of rawItems) {
		const raw = toRecord(item);
		if (!raw) {
			continue;
		}

		const nestedUser = toRecord(raw.user) ?? toRecord(raw.person) ?? toRecord(raw.operator);
		const visibility = (
			readString(raw.listVisibility) ||
			readString(raw.widocznoscNaLiscie) ||
			readString(nestedUser?.listVisibility) ||
			readString(nestedUser?.widocznoscNaLiscie)
		).toLowerCase();
		if (visibility === "hidden" || visibility === "ukryty") {
			continue;
		}

		const id = readNumber(
			raw.id ??
				raw.userId ??
				raw.personId ??
				raw.osobaId ??
				raw.operatorId ??
				nestedUser?.id ??
				nestedUser?.userId,
		);
		if (!Number.isFinite(id) || id <= 0) {
			continue;
		}

		const firstName =
			readString(raw.firstName) ||
			readString(raw.imie) ||
			readString(nestedUser?.firstName) ||
			readString(nestedUser?.imie);
		const lastName =
			readString(raw.lastName) ||
			readString(raw.nazwisko) ||
			readString(nestedUser?.lastName) ||
			readString(nestedUser?.nazwisko);
		const fullNameFromParts = [firstName, lastName].filter(Boolean).join(" ");

		const label =
			readString(raw.displayName) ||
			readString(raw.label) ||
			readString(raw.fullName) ||
			readString(raw.full_name) ||
			readString(raw.name) ||
			readString(nestedUser?.displayName) ||
			readString(nestedUser?.label) ||
			readString(nestedUser?.fullName) ||
			readString(nestedUser?.full_name) ||
			readString(nestedUser?.name) ||
			fullNameFromParts ||
			readString(raw.login) ||
			readString(nestedUser?.login);
		if (!label) {
			continue;
		}

		const login = (readString(raw.login) || readString(nestedUser?.login)).toLowerCase();
		const key = login ? `login:${login}` : `id:${id}`;
		if (!deduped.has(key)) {
			deduped.set(key, { id, label });
		}
	}

	return Array.from(deduped.values()).sort((left, right) =>
		left.label.localeCompare(right.label, "pl", { sensitivity: "base" }),
	);
}

export async function fetchObligatingDecisions(
	operatorLogin: string,
): Promise<ApiResult<ObligatingDecisionListResponse>> {
	try {
		const response = await fetch("/api/obligating-decisions", {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		const payload = (await response.json()) as unknown;
		if (Array.isArray(payload)) {
			return {
				ok: true,
				data: {
					items: payload as ObligatingDecisionRead[],
					total: payload.length,
				},
			};
		}

		const data = (payload ?? {}) as Partial<ObligatingDecisionListResponse>;
		return {
			ok: true,
			data: {
				items: Array.isArray(data.items)
					? (data.items as ObligatingDecisionRead[])
					: [],
				total: typeof data.total === "number" ? data.total : 0,
			},
		};
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function fetchAvailableRecommendations(
	operatorLogin: string,
): Promise<ApiResult<AvailableRecommendation[]>> {
	try {
		const response = await fetch("/api/obligating-decisions/available-recommendations", {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		const payload = (await response.json()) as unknown;
		const items = Array.isArray(payload)
			? (payload as AvailableRecommendation[])
			: (Array.isArray((payload as { items?: unknown[] })?.items)
				? ((payload as { items: AvailableRecommendation[] }).items ?? [])
				: []);
		return { ok: true, data: items };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function fetchAvailableFirstInstancePeople(
	operatorLogin: string,
	recommendationKodZalecenia?: string,
): Promise<ApiResult<ObligatingDecisionPersonOption[]>> {
	try {
		const query = new URLSearchParams();
		const normalizedRecommendationCode =
			typeof recommendationKodZalecenia === "string"
				? recommendationKodZalecenia.trim()
				: "";
		if (normalizedRecommendationCode) {
			query.set("recommendationKodZalecenia", normalizedRecommendationCode);
		}
		const querySuffix = query.toString() ? `?${query.toString()}` : "";
		const response = await fetch(
			`/api/obligating-decisions/available-first-instance-people${querySuffix}`,
			{
				method: "GET",
				headers: {
					"Content-Type": "application/json",
					"X-Operator-Login": operatorLogin,
				},
				cache: "no-store",
			},
		);

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		const payload = (await response.json()) as unknown;
		return { ok: true, data: parseAvailablePeoplePayload(payload) };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function fetchAvailableSecondInstancePeople(
	operatorLogin: string,
): Promise<ApiResult<ObligatingDecisionPersonOption[]>> {
	try {
		const response = await fetch(
			"/api/obligating-decisions/available-second-instance-people",
			{
				method: "GET",
				headers: {
					"Content-Type": "application/json",
					"X-Operator-Login": operatorLogin,
				},
				cache: "no-store",
			},
		);

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		const payload = (await response.json()) as unknown;
		return { ok: true, data: parseAvailablePeoplePayload(payload) };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function createObligatingDecision(
	operatorLogin: string,
	payload: ObligatingDecisionWrite,
): Promise<ApiResult<ObligatingDecisionRead>> {
	try {
		const response = await fetch("/api/obligating-decisions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(payload),
		});

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		return { ok: true, data: (await response.json()) as ObligatingDecisionRead };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function updateObligatingDecision(
	operatorLogin: string,
	decisionId: number,
	payload: ObligatingDecisionWrite,
	options?: {
		expectedUpdatedAt?: string | null;
		lockToken?: string | null;
	},
): Promise<ApiResult<ObligatingDecisionRead>> {
	try {
		const requestPayload: Record<string, unknown> = {
			...payload,
		};

		if (typeof options?.expectedUpdatedAt === "string" && options.expectedUpdatedAt.trim()) {
			requestPayload.expectedUpdatedAt = options.expectedUpdatedAt.trim();
		}

		if (typeof options?.lockToken === "string" && options.lockToken.trim()) {
			requestPayload.lockToken = options.lockToken.trim();
		}

		const response = await fetch(`/api/obligating-decisions/${decisionId}`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(requestPayload),
		});

		if (!response.ok) {
			const contentType = response.headers.get("content-type") ?? "";
			const payload = contentType.includes("application/json")
				? ((await response.json()) as unknown)
				: null;
			const detailSource = payload && typeof payload === "object"
				? ((payload as { detail?: unknown; message?: unknown }).detail ??
					(payload as { detail?: unknown; message?: unknown }).message)
				: null;
			const detail = typeof detailSource === "string" ? detailSource : "";
			const base = getErrorMessageByStatus(response.status);
			const lockConflict = response.status === 423 ? parseLockConflict(payload) : undefined;
			const lockErrorCode =
				response.status === 423
					? parseErrorCode(payload)
					: undefined;
			const lockReason =
				response.status === 423
					? toStringValue(
							(getDomainPayloadSource(payload) as Record<string, unknown> | null)
								?.reason,
						) || undefined
					: undefined;
			const currentUpdatedAt = response.status === 409 ? parseCurrentUpdatedAt(payload) : undefined;
			const lockMessage =
				lockErrorCode === "RECORD_LOCKED"
					? "Nie możesz teraz edytować tego wpisu, ponieważ jest edytowany przez innego użytkownika."
					: lockErrorCode === "LOCK_REQUIRED" || lockReason === "lock_required"
						? "Do zapisu wymagana jest aktywna blokada rekordu. Odśwież dane i otwórz formularz ponownie."
						: lockErrorCode === "LOCK_TOKEN_INVALID" || lockReason === "lock_token_invalid"
							? "Blokada edycji wygasła lub jest nieprawidłowa. Odśwież dane i otwórz formularz ponownie."
							: base;
			return {
				ok: false,
				error:
					response.status === 423
						? detail
							? `${lockMessage} ${detail}`
							: lockMessage
						: detail
							? `${base} ${detail}`
							: base,
				status: response.status,
				errorCode: parseErrorCode(payload),
				lockConflict,
				lockErrorCode,
				lockReason,
				currentUpdatedAt,
			};
		}

		return { ok: true, data: (await response.json()) as ObligatingDecisionRead };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function deleteObligatingDecision(
	operatorLogin: string,
	decisionId: number,
): Promise<ApiResult<null>> {
	try {
		let response = await fetch(`/api/obligating-decisions/${decisionId}`, {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
		});

		if (response.status === 404) {
			response = await fetch(`/api/decyzje-zobowiazujace/${decisionId}`, {
				method: "DELETE",
				headers: {
					"Content-Type": "application/json",
					"X-Operator-Login": operatorLogin,
				},
			});
		}

		if (!response.ok) {
			const payload =
				response.headers.get("content-type")?.includes("application/json")
					? ((await response.clone().json()) as unknown)
					: null;
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
				errorCode: parseErrorCode(payload),
			};
		}

		return { ok: true, data: null };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

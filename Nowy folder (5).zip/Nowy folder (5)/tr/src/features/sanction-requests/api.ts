import type {
	SanctionRequestFilters,
	SanctionRequestListResponse,
	SanctionRequestRead,
	SanctionRequestWrite,
} from "@/features/sanction-requests/types";

export type SanctionRequestLockConflict = {
	module: string;
	recordId: string;
	ownerUserId: string;
	ownerLogin: string;
	ownerDisplayName: string;
	acquiredAt: string;
	expiresAt: string;
};

type ApiResult<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
			lockConflict?: SanctionRequestLockConflict;
			lockErrorCode?: string;
			lockReason?: string;
			currentUpdatedAt?: string;
	  };

function getErrorMessageByStatus(status: number) {
	if (status === 400) return "Błędne dane wejściowe.";
	if (status === 401) return "Brak autoryzacji operatora.";
	if (status === 403) return "Brak uprawnień do operacji.";
	if (status === 404) return "Nie znaleziono zasobu.";
	if (status === 409)
		return "Dane zostały zmienione przez innego użytkownika. Odśwież widok i spróbuj ponownie.";
	if (status === 423) return "Błąd blokady rekordu.";
	if (status === 422) return "Nieprawidłowy format danych.";
	return `Błąd API (${status}).`;
}

function toStringValue(value: unknown) {
	return typeof value === "string" ? value.trim() : "";
}

function parseLockConflict(payload: unknown): SanctionRequestLockConflict | undefined {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	if (toStringValue(source.code) !== "RECORD_LOCKED") {
		return undefined;
	}

	return {
		module: toStringValue(source.module),
		recordId: toStringValue(source.recordId),
		ownerUserId: toStringValue(source.ownerUserId),
		ownerLogin: toStringValue(source.ownerLogin),
		ownerDisplayName: toStringValue(source.ownerDisplayName),
		acquiredAt: toStringValue(source.acquiredAt),
		expiresAt: toStringValue(source.expiresAt),
	};
}

function parseCurrentUpdatedAt(payload: unknown) {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	const value = source.currentUpdatedAt ?? source.updatedAt;
	const parsed = toStringValue(value);
	return parsed || undefined;
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
		};
		const detail = payload.detail ?? payload.message;

		if (typeof detail === "string") {
			return detail;
		}

		if (Array.isArray(detail)) {
			return detail
				.map((item) => {
					if (typeof item === "string") return item;
					if (item && typeof item === "object") {
						const maybeMsg = (item as { msg?: unknown }).msg;
						return typeof maybeMsg === "string"
							? maybeMsg
							: JSON.stringify(item);
					}
					return "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

export async function fetchSanctionRequests(
	operatorLogin: string,
	filters: SanctionRequestFilters,
): Promise<ApiResult<SanctionRequestListResponse>> {
	try {
		const query = new URLSearchParams();

		if (
			typeof filters.inspectionId === "number" &&
			Number.isFinite(filters.inspectionId)
		) {
			query.set("inspectionId", String(filters.inspectionId));
		}

		if (filters.sortBy) {
			query.set("sortBy", filters.sortBy);
		}

		if (filters.sortOrder) {
			query.set("sortOrder", filters.sortOrder);
		}

		const querySuffix = query.toString() ? `?${query.toString()}` : "";
		const response = await fetch(`/api/sanction-requests${querySuffix}`, {
			method: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			cache: "no-store",
		});

		if (!response.ok) {
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
			};
		}

		const payload = (await response.json()) as unknown;
		if (Array.isArray(payload)) {
			return {
				ok: true,
				data: {
					items: payload as SanctionRequestRead[],
					total: payload.length,
				},
			};
		}

		const data = (payload ?? {}) as Partial<SanctionRequestListResponse>;
		return {
			ok: true,
			data: {
				items: Array.isArray(data.items)
					? (data.items as SanctionRequestRead[])
					: [],
				total: typeof data.total === "number" ? data.total : 0,
			},
		};
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function createSanctionRequest(
	operatorLogin: string,
	payload: SanctionRequestWrite,
): Promise<ApiResult<SanctionRequestRead>> {
	try {
		const response = await fetch("/api/sanction-requests", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(payload),
		});

		if (!response.ok) {
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
			};
		}

		return { ok: true, data: (await response.json()) as SanctionRequestRead };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function updateSanctionRequest(
	operatorLogin: string,
	id: number,
	payload: SanctionRequestWrite,
	options?: {
		expectedUpdatedAt?: string | null;
		lockToken?: string | null;
	},
): Promise<ApiResult<SanctionRequestRead>> {
	try {
		const requestPayload: Record<string, unknown> = {
			...payload,
		};

		if (typeof options?.expectedUpdatedAt === "string" && options.expectedUpdatedAt.trim()) {
			requestPayload.expectedUpdatedAt = options.expectedUpdatedAt.trim();
		}

		if (typeof options?.lockToken === "string" && options.lockToken.trim()) {
			requestPayload.lockToken = options.lockToken.trim();
		}

		const response = await fetch(`/api/sanction-requests/${id}`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(requestPayload),
		});

		if (!response.ok) {
			const contentType = response.headers.get("content-type") ?? "";
			const payload = contentType.includes("application/json")
				? ((await response.json()) as unknown)
				: null;
			const detailSource = payload && typeof payload === "object"
				? ((payload as { detail?: unknown; message?: unknown }).detail ??
					(payload as { detail?: unknown; message?: unknown }).message)
				: null;
			const detail = typeof detailSource === "string" ? detailSource : "";
			const base = getErrorMessageByStatus(response.status);
			const lockConflict = response.status === 423 ? parseLockConflict(payload) : undefined;
			const lockErrorCode =
				response.status === 423 && payload && typeof payload === "object"
					? toStringValue((payload as Record<string, unknown>).code) || undefined
					: undefined;
			const lockReason =
				response.status === 423 && payload && typeof payload === "object"
					? toStringValue((payload as Record<string, unknown>).reason) || undefined
					: undefined;
			const currentUpdatedAt = response.status === 409 ? parseCurrentUpdatedAt(payload) : undefined;
			const lockMessage =
				lockErrorCode === "RECORD_LOCKED"
					? "Nie możesz teraz edytować tego wpisu, ponieważ jest edytowany przez innego użytkownika."
					: lockErrorCode === "LOCK_REQUIRED" || lockReason === "lock_required"
						? "Do zapisu wymagana jest aktywna blokada rekordu. Odśwież dane i otwórz formularz ponownie."
						: lockErrorCode === "LOCK_TOKEN_INVALID" || lockReason === "lock_token_invalid"
							? "Blokada edycji wygasła lub jest nieprawidłowa. Odśwież dane i otwórz formularz ponownie."
							: base;
			return {
				ok: false,
				error:
					response.status === 423
						? detail
							? `${lockMessage} ${detail}`
							: lockMessage
						: detail
							? `${base} ${detail}`
							: base,
				status: response.status,
				lockConflict,
				lockErrorCode,
				lockReason,
				currentUpdatedAt,
			};
		}

		return { ok: true, data: (await response.json()) as SanctionRequestRead };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

export async function deleteSanctionRequest(
	operatorLogin: string,
	id: number,
): Promise<ApiResult<null>> {
	try {
		let response = await fetch(`/api/risk-exposure/${id}`, {
			method: "DELETE",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
		});

		if (response.status === 404) {
			response = await fetch(`/api/sanction-requests/${id}`, {
				method: "DELETE",
				headers: {
					"Content-Type": "application/json",
					"X-Operator-Login": operatorLogin,
				},
			});
		}

		if (!response.ok) {
			const detail = await readApiDetail(response);
			const base = getErrorMessageByStatus(response.status);
			return {
				ok: false,
				error: detail ? `${base} ${detail}` : base,
				status: response.status,
			};
		}

		return { ok: true, data: null };
	} catch {
		return {
			ok: false,
			error: "Nie udało się połączyć z API. Sprawdź połączenie i spróbuj ponownie.",
		};
	}
}

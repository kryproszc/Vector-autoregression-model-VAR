import Image from "next/image";

type WelcomeStartPanelProps = {
	operatorLogin: string;
};

export function WelcomeStartPanel({ operatorLogin }: WelcomeStartPanelProps) {
	return (
		<section className="flex min-h-[calc(100vh-8rem)] w-full items-center justify-center py-4">
			<div className="relative mx-auto w-full max-w-6xl overflow-hidden rounded-3xl border border-[#2f4a75] bg-linear-to-br from-[#12284a] via-[#102441] to-[#0d1c35] p-8 text-center shadow-[0_26px_70px_rgba(2,8,23,0.45)] md:p-12">
				<div className="-top-20 -translate-x-1/2 pointer-events-none absolute left-1/2 h-56 w-56 rounded-full bg-sky-300/10 blur-3xl" />

				<div className="relative">
					<p className="font-semibold text-slate-300/80 text-xs uppercase tracking-[0.18em]">
						System centralny
					</p>
					<h2 className="mt-2 font-bold text-5xl text-slate-100 leading-tight md:text-6xl">
						Rejestr spraw
					</h2>
					<p className="mt-2 font-semibold text-base text-sky-200/95 md:text-lg">
						Uniwersytet Jazdy Rowerem
					</p>
					<p className="mx-auto mt-3 max-w-3xl text-slate-200/80 text-sm md:text-base">
						Profesjonalny panel do prowadzenia i monitorowania spraw. Wybierz
						moduł z menu po lewej stronie, aby rozpocząć pracę.
					</p>

					<div className="mx-auto mt-8 w-full max-w-5xl overflow-hidden rounded-2xl border border-[#4f78ab] bg-[#183154]/45">
						<Image
							src="/Grafika_powitalna.png"
							alt="Grafika powitalna"
							width={2200}
							height={1200}
							priority
							className="h-auto w-full object-cover"
						/>
					</div>

					<p className="mt-4 text-slate-300/70 text-xs">
						Zalogowano jako:{" "}
						<span className="font-semibold text-slate-200">
							{operatorLogin}
						</span>
					</p>
				</div>
			</div>
		</section>
	);
}

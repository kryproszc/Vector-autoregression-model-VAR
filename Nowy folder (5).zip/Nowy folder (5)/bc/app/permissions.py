from __future__ import annotations

import sqlite3
from typing import Any

from fastapi import HTTPException

PERMISSION_INSPECTIONS_READ = "registry.inspections.read"
PERMISSION_RECOMMENDATIONS_READ = "registry.recommendations.read"
PERMISSION_OBLIGATING_DECISIONS_READ = "registry.obligating_decisions.read"
PERMISSION_RISK_EXPOSURE_READ = "registry.risk_exposure.read"
PERMISSION_REPORTS_EXECUTED_INSPECTIONS_READ = "reports.executed_inspections.read"
PERMISSION_REPORTS_PROTOCOL_TIME_READ = "reports.protocol_time.read"
PERMISSION_REPORTS_REPORT_TIME_READ = "reports.report_time.read"

ALL_PERMISSION_CODES: tuple[str, ...] = (
    PERMISSION_INSPECTIONS_READ,
    PERMISSION_RECOMMENDATIONS_READ,
    PERMISSION_OBLIGATING_DECISIONS_READ,
    PERMISSION_RISK_EXPOSURE_READ,
    PERMISSION_REPORTS_EXECUTED_INSPECTIONS_READ,
    PERMISSION_REPORTS_PROTOCOL_TIME_READ,
    PERMISSION_REPORTS_REPORT_TIME_READ,
)

PERMISSION_CATALOG: tuple[dict[str, str], ...] = (
    {
        "code": PERMISSION_INSPECTIONS_READ,
        "label": "Inspekcje",
        "group": "rejestry",
    },
    {
        "code": PERMISSION_RECOMMENDATIONS_READ,
        "label": "Zalecenia",
        "group": "rejestry",
    },
    {
        "code": PERMISSION_OBLIGATING_DECISIONS_READ,
        "label": "Decyzje zobowiazujace",
        "group": "rejestry",
    },
    {
        "code": PERMISSION_RISK_EXPOSURE_READ,
        "label": "Wnioski sankcyjne",
        "group": "rejestry",
    },
    {
        "code": PERMISSION_REPORTS_EXECUTED_INSPECTIONS_READ,
        "label": "Wykonane inspekcje",
        "group": "raporty",
    },
    {
        "code": PERMISSION_REPORTS_PROTOCOL_TIME_READ,
        "label": "Czas protokolu",
        "group": "raporty",
    },
    {
        "code": PERMISSION_REPORTS_REPORT_TIME_READ,
        "label": "Czas sprawozdania",
        "group": "raporty",
    },
)

ROLE_EXTERNAL_USER = 4
ACCOUNT_TYPE_OBSERVER = "observer"


def _is_observer_account(conn: sqlite3.Connection, user_id: int) -> bool:
    row = conn.execute(
        """
        SELECT account_type
        FROM users
        WHERE id = ?
        LIMIT 1
        """,
        (int(user_id),),
    ).fetchone()
    if row is None:
        return False
    return str(row["account_type"] or "").strip().lower() == ACCOUNT_TYPE_OBSERVER


def _is_permissions_scoped_account(conn: sqlite3.Connection, operator: dict[str, Any]) -> bool:
    if int(operator.get("rola_id", 0)) == ROLE_EXTERNAL_USER:
        return True
    return _is_observer_account(conn, int(operator["id"]))


def normalize_permission_codes(permission_codes: list[str]) -> list[str]:
    known = set(ALL_PERMISSION_CODES)
    deduped: list[str] = []
    seen: set[str] = set()
    for raw in permission_codes:
        code = str(raw or "").strip()
        if not code:
            continue
        if code not in known:
            raise HTTPException(status_code=400, detail=f"Nieznane uprawnienie: {code}")
        if code in seen:
            continue
        seen.add(code)
        deduped.append(code)
    return deduped


def get_user_permissions(conn: sqlite3.Connection, user_id: int) -> list[str]:
    rows = conn.execute(
        """
        SELECT permission_code
        FROM user_permissions
        WHERE user_id = ?
        ORDER BY permission_code ASC
        """,
        (int(user_id),),
    ).fetchall()
    return [str(row["permission_code"]) for row in rows]


def set_user_permissions(conn: sqlite3.Connection, user_id: int, permission_codes: list[str], granted_by_user_id: int) -> None:
    codes = normalize_permission_codes(permission_codes)
    conn.execute("DELETE FROM user_permissions WHERE user_id = ?", (int(user_id),))
    for code in codes:
        conn.execute(
            """
            INSERT INTO user_permissions (user_id, permission_code, granted_by_user_id)
            VALUES (?, ?, ?)
            """,
            (int(user_id), code, int(granted_by_user_id)),
        )


def get_effective_permissions(conn: sqlite3.Connection, user_id: int, role_id: int) -> list[str]:
    if int(role_id) == ROLE_EXTERNAL_USER:
        return get_user_permissions(conn, int(user_id))
    if _is_observer_account(conn, int(user_id)):
        return get_user_permissions(conn, int(user_id))
    return list(ALL_PERMISSION_CODES)


def require_permission(conn: sqlite3.Connection, operator: dict[str, Any], permission_code: str, detail: str = "Brak uprawnien") -> None:
    if not _is_permissions_scoped_account(conn, operator):
        return

    row = conn.execute(
        """
        SELECT 1
        FROM user_permissions
        WHERE user_id = ? AND permission_code = ?
        LIMIT 1
        """,
        (int(operator["id"]), permission_code),
    ).fetchone()
    if row is None:
        raise HTTPException(status_code=403, detail=detail)


def require_write_access(conn: sqlite3.Connection, operator: dict[str, Any], detail: str = "Brak uprawnien") -> None:
    if _is_permissions_scoped_account(conn, operator):
        raise HTTPException(status_code=403, detail=detail)

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
	getBaseInspectionColumnKeys,
	toSafeString,
} from "@/features/inspections/components/inspections-panel.utils";
import { INSPECTION_COLUMNS } from "@/features/inspections/data";
import type {
	InspectionColumnKey,
	InspectionRow,
	InspectionViewId,
} from "@/features/inspections/types";
import { getFloatingPanelAnchor } from "@/shared/utils/floating-panel";
import {
	createAdvancedDateRangeFilterToken,
	getAdvancedDateRangeFromSelectedValues,
	hasActiveTableFilters,
	isAdvancedDateRangeFilterToken,
	matchesAdvancedFilterCellValue,
	splitAdvancedFilterCellValue,
} from "@/shared/utils/table-filters";

type SortDirection = "asc" | "desc";

type UseInspectionsTableStateArgs = {
	inspectionRows: InspectionRow[];
	advancedFilterTokensByColumnByRowId?: Partial<
		Record<InspectionColumnKey, Record<string, string[]>>
	>;
	tableViewStorageKey?: string;
	tableViewStorageArea?: "localStorage" | "sessionStorage";
};

type HiddenColumnsByView = Record<InspectionViewId, InspectionColumnKey[]>;

const DEFAULT_INSPECTIONS_PAGE_SIZE = 30;

function readPersistedInspectionsPageSize(
	tableViewStorageKey: string | undefined,
	tableViewStorageArea: "localStorage" | "sessionStorage",
) {
	if (typeof window === "undefined" || !tableViewStorageKey) {
		return null;
	}

	const storage =
		tableViewStorageArea === "localStorage"
			? window.localStorage
			: window.sessionStorage;
	const raw = storage.getItem(tableViewStorageKey);
	if (!raw) {
		return null;
	}

	try {
		const parsed = JSON.parse(raw) as { pageSize?: unknown };
		if (typeof parsed.pageSize === "number" && Number.isFinite(parsed.pageSize)) {
			return Math.max(1, Math.trunc(parsed.pageSize));
		}

		return null;
	} catch {
		return null;
	}
}

function getResponsiveInspectionsPageSize(viewportHeight: number) {
	if (viewportHeight < 860) {
		return 20;
	}

	if (viewportHeight < 1080) {
		return 30;
	}

	return 30;
}

function createRange(start: number, end: number) {
	const length = end - start + 1;
	return Array.from({ length }, (_, index) => index + start);
}

type PaginationItem = number | "ellipsis";

function buildPaginationItems(
	currentPage: number,
	totalPages: number,
	siblingCount = 1,
): PaginationItem[] {
	const totalPageNumbers = siblingCount + 5;

	if (totalPageNumbers >= totalPages) {
		return createRange(1, totalPages);
	}

	const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
	const rightSiblingIndex = Math.min(currentPage + siblingCount, totalPages);

	const shouldShowLeftDots = leftSiblingIndex > 2;
	const shouldShowRightDots = rightSiblingIndex < totalPages - 2;

	if (!shouldShowLeftDots && shouldShowRightDots) {
		const leftItemCount = 3 + 2 * siblingCount;
		const leftRange = createRange(1, leftItemCount);
		return [...leftRange, "ellipsis", totalPages];
	}

	if (shouldShowLeftDots && !shouldShowRightDots) {
		const rightItemCount = 3 + 2 * siblingCount;
		const rightRange = createRange(totalPages - rightItemCount + 1, totalPages);
		return [1, "ellipsis", ...rightRange];
	}

	if (shouldShowLeftDots && shouldShowRightDots) {
		const middleRange = createRange(leftSiblingIndex, rightSiblingIndex);
		return [1, "ellipsis", ...middleRange, "ellipsis", totalPages];
	}

	return createRange(1, totalPages);
}

function getAllInspectionColumnKeys() {
	return INSPECTION_COLUMNS.map((column) => column.key);
}

function getDefaultHiddenColumnsForView(viewId: InspectionViewId) {
	if (viewId === "calosc") {
		return [] as InspectionColumnKey[];
	}

	const baseColumns = new Set(getBaseInspectionColumnKeys(viewId));
	return getAllInspectionColumnKeys().filter(
		(columnKey) => !baseColumns.has(columnKey),
	);
}

function createDefaultHiddenColumnsByView(): HiddenColumnsByView {
	return {
		calosc: getDefaultHiddenColumnsForView("calosc"),
		podstawowe: getDefaultHiddenColumnsForView("podstawowe"),
		terminy: getDefaultHiddenColumnsForView("terminy"),
	};
}

const INSPECTION_SEMICOLON_LIST_COLUMNS = new Set<InspectionColumnKey>([
	"zakresInspekcji",
	"skladZespolu",
]);

const INSPECTION_COMMA_LIST_COLUMNS = new Set<InspectionColumnKey>([
	"dataAkceptacjiNoty",
	"dataZalecen",
]);

const INSPECTION_DATE_RANGE_COLUMNS = new Set<InspectionColumnKey>([
	"poczatekInspekcji",
	"koniecInspekcji",
	"dataProtokolu",
	"dataDoreczeniaProtokolu",
	"dataAkceptacjiSprawozdania",
	"dataDoreczeniaPisma",
	"dataPismaZastrzezenia",
	"dataWyslaniaPismaZZastrzezeniami",
	"dataWplywuPisma",
	"dataPismaZOdpowiedzia",
	"dataWyslaniaPismaZOdpowiedzia",
	"dataAkceptacjiNoty",
	"dataZalecen",
]);

function splitInspectionAdvancedFilterCellValue(
	columnKey: InspectionColumnKey,
	rawValue: string,
) {
	const normalizedValue = rawValue.trim();
	if (!normalizedValue) {
		return ["(puste)"];
	}

	if (INSPECTION_COMMA_LIST_COLUMNS.has(columnKey)) {
		return splitAdvancedFilterCellValue(rawValue);
	}

	if (!INSPECTION_SEMICOLON_LIST_COLUMNS.has(columnKey)) {
		return [normalizedValue];
	}

	const tokens = normalizedValue
		.split(/[;\n]/)
		.map((item) => item.trim())
		.filter(Boolean);

	if (tokens.length === 0) {
		return ["(puste)"];
	}

	return Array.from(new Set(tokens));
}

function matchesInspectionAdvancedFilterCellValue(
	columnKey: InspectionColumnKey,
	rawValue: string,
	selectedValues: string[],
) {
	if (INSPECTION_DATE_RANGE_COLUMNS.has(columnKey)) {
		return matchesAdvancedFilterCellValue(rawValue, selectedValues);
	}

	if (selectedValues.length === 0) {
		return true;
	}

	const selectedDateRange = getAdvancedDateRangeFromSelectedValues(selectedValues);
	const selectedDiscreteValues = selectedValues.filter(
		(value) => !isAdvancedDateRangeFilterToken(value),
	);

	const cellTokens = splitInspectionAdvancedFilterCellValue(columnKey, rawValue);
	const hasDiscreteMatch =
		selectedDiscreteValues.length === 0 ||
		cellTokens.some((token) => selectedDiscreteValues.includes(token));

	if (!hasDiscreteMatch) {
		return false;
	}

	if (selectedDateRange) {
		return false;
	}

	return true;
}

export function useInspectionsTableState({
	inspectionRows,
	advancedFilterTokensByColumnByRowId,
	tableViewStorageKey,
	tableViewStorageArea = "sessionStorage",
}: UseInspectionsTableStateArgs) {
	const [hiddenColumnsByView, setHiddenColumnsByView] =
		useState<HiddenColumnsByView>(() => createDefaultHiddenColumnsByView());
	const [hiddenColumns, setHiddenColumns] = useState<InspectionColumnKey[]>(
		() => getDefaultHiddenColumnsForView("calosc"),
	);
	const [selectedInspectionView, setSelectedInspectionView] =
		useState<InspectionViewId>("calosc");
	const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);
	const [isAdvancedFilterModalOpen, setIsAdvancedFilterModalOpen] =
		useState(false);
	const [advancedFilterColumnKey, setAdvancedFilterColumnKey] =
		useState<InspectionColumnKey>("nazwaPodmiotu");
	const [advancedFilterSearch, setAdvancedFilterSearch] = useState("");
	const [advancedFilterAnchor, setAdvancedFilterAnchor] = useState({
		top: 120,
		left: 120,
	});
	const [advancedFilters, setAdvancedFilters] = useState<
		Partial<Record<InspectionColumnKey, string[]>>
	>({});
	const [draftSelectedInspectionView, setDraftSelectedInspectionView] =
		useState<InspectionViewId>("calosc");
	const [draftHiddenColumns, setDraftHiddenColumns] = useState<
		InspectionColumnKey[]
	>([]);
	const [draftHiddenColumnsByView, setDraftHiddenColumnsByView] =
		useState<HiddenColumnsByView>(() => createDefaultHiddenColumnsByView());
	const [sortColumnKey, setSortColumnKey] =
		useState<InspectionColumnKey | null>(null);
	const [sortDirection, setSortDirection] = useState<SortDirection | null>(
		null,
	);
	const [currentPage, setCurrentPage] = useState(1);
	const [pageSize, setPageSize] = useState(() => {
		if (typeof window === "undefined") {
			return DEFAULT_INSPECTIONS_PAGE_SIZE;
		}

		const persistedPageSize = readPersistedInspectionsPageSize(
			tableViewStorageKey,
			tableViewStorageArea,
		);
		if (persistedPageSize !== null) {
			return persistedPageSize;
		}

		return getResponsiveInspectionsPageSize(window.innerHeight);
	});
	const [columnFilters, setColumnFilters] = useState<
		Partial<Record<InspectionColumnKey, string>>
	>({});
	const [areTableViewSettingsHydrated, setAreTableViewSettingsHydrated] =
		useState(() => !tableViewStorageKey);
	const [didInitPageFromHydration, setDidInitPageFromHydration] = useState(false);
	const [hasPersistedPageSize, setHasPersistedPageSize] = useState(() => {
		return (
			readPersistedInspectionsPageSize(tableViewStorageKey, tableViewStorageArea) !==
			null
		);
	});
	const [hasReceivedNonEmptyRows, setHasReceivedNonEmptyRows] = useState(false);
	const previousPaginationControlKeyRef = useRef<string | null>(null);

	useEffect(() => {
		if (inspectionRows.length > 0) {
			setHasReceivedNonEmptyRows(true);
		}
	}, [inspectionRows.length]);

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		if (!tableViewStorageKey) {
			setAreTableViewSettingsHydrated(true);
			setDidInitPageFromHydration(true);
			return;
		}

		const storage =
			tableViewStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;
		const raw = storage.getItem(tableViewStorageKey);

		if (!raw) {
			setAreTableViewSettingsHydrated(true);
			setDidInitPageFromHydration(true);
			return;
		}

		try {
			const parsed = JSON.parse(raw) as {
				selectedInspectionView?: unknown;
				hiddenColumnsByView?: unknown;
				currentPage?: unknown;
				pageSize?: unknown;
			};
			const allColumnKeys = new Set(getAllInspectionColumnKeys());
			const normalizeHiddenColumns = (value: unknown) =>
				Array.isArray(value)
					? value.filter(
							(columnKey): columnKey is InspectionColumnKey =>
								typeof columnKey === "string" &&
								allColumnKeys.has(columnKey as InspectionColumnKey),
					  )
					: [];
			const parsedHiddenColumnsByView =
				parsed.hiddenColumnsByView &&
				typeof parsed.hiddenColumnsByView === "object" &&
				!Array.isArray(parsed.hiddenColumnsByView)
					? (parsed.hiddenColumnsByView as Partial<
						Record<InspectionViewId, unknown>
					  >)
					: {};
			const nextHiddenColumnsByView: HiddenColumnsByView = {
				calosc: normalizeHiddenColumns(parsedHiddenColumnsByView.calosc),
				podstawowe: normalizeHiddenColumns(parsedHiddenColumnsByView.podstawowe),
				terminy: normalizeHiddenColumns(parsedHiddenColumnsByView.terminy),
			};

			const nextSelectedView: InspectionViewId =
				parsed.selectedInspectionView === "podstawowe" ||
				parsed.selectedInspectionView === "terminy" ||
				parsed.selectedInspectionView === "calosc"
					? parsed.selectedInspectionView
					: "calosc";

			setHiddenColumnsByView(nextHiddenColumnsByView);
			setSelectedInspectionView(nextSelectedView);
			setHiddenColumns(nextHiddenColumnsByView[nextSelectedView]);

			const savedPageSize =
				typeof parsed.pageSize === "number" && Number.isFinite(parsed.pageSize)
					? Math.max(1, Math.trunc(parsed.pageSize))
					: null;
			if (savedPageSize !== null) {
				setPageSize(savedPageSize);
				setHasPersistedPageSize(true);
			}
		} catch {
			setHiddenColumnsByView(createDefaultHiddenColumnsByView());
			setSelectedInspectionView("calosc");
			setHiddenColumns(getDefaultHiddenColumnsForView("calosc"));
		}

		setAreTableViewSettingsHydrated(true);
		setDidInitPageFromHydration(true);
	}, [tableViewStorageArea, tableViewStorageKey]);

	useEffect(() => {
		if (typeof window === "undefined") {
			return;
		}

		if (!tableViewStorageKey || !areTableViewSettingsHydrated) {
			return;
		}

		const storage =
			tableViewStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;
		const nextHiddenColumnsByView: HiddenColumnsByView = {
			...hiddenColumnsByView,
			[selectedInspectionView]: hiddenColumns,
		};

		storage.setItem(
			tableViewStorageKey,
			JSON.stringify({
				selectedInspectionView,
				hiddenColumnsByView: nextHiddenColumnsByView,
				currentPage,
				pageSize,
			}),
		);
	}, [
		areTableViewSettingsHydrated,
		currentPage,
		hiddenColumns,
		hiddenColumnsByView,
		pageSize,
		selectedInspectionView,
		tableViewStorageArea,
		tableViewStorageKey,
	]);

	useEffect(() => {
		if (typeof window === "undefined" || hasPersistedPageSize) {
			return;
		}

		const updatePageSize = () => {
			setPageSize(getResponsiveInspectionsPageSize(window.innerHeight));
		};

		updatePageSize();
		window.addEventListener("resize", updatePageSize);

		return () => {
			window.removeEventListener("resize", updatePageSize);
		};
	}, [hasPersistedPageSize]);

	const visibleInspectionColumns = useMemo(
		() =>
			INSPECTION_COLUMNS.map((column) => column.key).filter(
				(columnKey) => !hiddenColumns.includes(columnKey),
			),
		[hiddenColumns],
	);

	const visibleInspectionColumnDefinitions = useMemo(
		() =>
			INSPECTION_COLUMNS.filter((column) =>
				visibleInspectionColumns.includes(column.key),
			),
		[visibleInspectionColumns],
	);

	const selectableColumnDefinitions = useMemo(
		() => INSPECTION_COLUMNS,
		[],
	);

	const draftVisibleInspectionColumns = useMemo(
		() =>
			INSPECTION_COLUMNS.map((column) => column.key).filter(
				(columnKey) => !draftHiddenColumns.includes(columnKey),
			),
		[draftHiddenColumns],
	);

	const draftSelectableColumnDefinitions = useMemo(
		() => INSPECTION_COLUMNS,
		[],
	);

	const hasActiveFilters = useMemo(
		() => hasActiveTableFilters(columnFilters, advancedFilters),
		[advancedFilters, columnFilters],
	);

	const canClearFilters = hasActiveFilters;

	const getAdvancedFilterTokensForRow = useCallback(
		(columnKey: InspectionColumnKey, row: InspectionRow) => {
			const tokenMap = advancedFilterTokensByColumnByRowId?.[columnKey];
			const mappedTokens = tokenMap?.[row.id] ?? [];
			if (mappedTokens.length > 0) {
				const normalizedMapped = mappedTokens
					.map((token) => token.trim())
					.filter(Boolean);
				if (normalizedMapped.length > 0) {
					return Array.from(new Set(normalizedMapped));
				}
			}

			return splitInspectionAdvancedFilterCellValue(
				columnKey,
				toSafeString(row[columnKey]),
			);
		},
		[advancedFilterTokensByColumnByRowId],
	);

	const advancedFilterValuesByColumn = useMemo(() => {
		const map: Partial<Record<InspectionColumnKey, string[]>> = {};

		INSPECTION_COLUMNS.forEach((column) => {
			const uniqueValues = Array.from(
				new Set(
					inspectionRows.flatMap((row) =>
						getAdvancedFilterTokensForRow(column.key, row),
					),
				),
			).sort((left, right) =>
				left.localeCompare(right, "pl", { sensitivity: "base", numeric: true }),
			);

			map[column.key] = uniqueValues;
		});

		return map;
	}, [getAdvancedFilterTokensForRow, inspectionRows]);

	const selectedAdvancedFilterValues = useMemo(
		() =>
			(advancedFilters[advancedFilterColumnKey] ?? []).filter(
				(value) => !isAdvancedDateRangeFilterToken(value),
			),
		[advancedFilterColumnKey, advancedFilters],
	);

	const selectedAdvancedFilterDateRange = useMemo(
		() =>
			getAdvancedDateRangeFromSelectedValues(
				advancedFilters[advancedFilterColumnKey] ?? [],
			),
		[advancedFilterColumnKey, advancedFilters],
	);

	const visibleAdvancedFilterValues = useMemo(() => {
		const sourceValues =
			advancedFilterValuesByColumn[advancedFilterColumnKey] ?? [];
		const normalizedSearch = advancedFilterSearch.trim().toLowerCase();

		if (!normalizedSearch) {
			return sourceValues;
		}

		return sourceValues.filter((value) =>
			value.toLowerCase().includes(normalizedSearch),
		);
	}, [
		advancedFilterColumnKey,
		advancedFilterSearch,
		advancedFilterValuesByColumn,
	]);

	const filteredAndSortedInspectionRows = useMemo(() => {
		const filteredRows = inspectionRows.filter((row) => {
			const advancedFiltersMatch = Object.entries(advancedFilters).every(
				([rawColumnKey, selectedValues]) => {
					const columnKey = rawColumnKey as InspectionColumnKey;
					const normalizedSelectedValues = Array.isArray(selectedValues)
						? selectedValues
						: [];

					if (INSPECTION_DATE_RANGE_COLUMNS.has(columnKey)) {
						return matchesInspectionAdvancedFilterCellValue(
							columnKey,
							toSafeString(row[columnKey]),
							normalizedSelectedValues,
						);
					}

					if (normalizedSelectedValues.length === 0) {
						return true;
					}

					const selectedDiscreteValues = normalizedSelectedValues.filter(
						(value) => !isAdvancedDateRangeFilterToken(value),
					);
					const cellTokens = getAdvancedFilterTokensForRow(columnKey, row);
					return (
						selectedDiscreteValues.length === 0 ||
						cellTokens.some((token) => selectedDiscreteValues.includes(token))
					);
				},
			);

			if (!advancedFiltersMatch) {
				return false;
			}

			return Object.entries(columnFilters).every(
				([rawColumnKey, rawFilterValue]) => {
					const filterValue = rawFilterValue?.trim();
					if (!filterValue) {
						return true;
					}

					const columnKey = rawColumnKey as InspectionColumnKey;
					const cellValue = toSafeString(row[columnKey]).toLowerCase();
					return cellValue.includes(filterValue.toLowerCase());
				},
			);
		});

		if (!sortColumnKey || !sortDirection) {
			return filteredRows;
		}

		const directionMultiplier = sortDirection === "asc" ? 1 : -1;
		return [...filteredRows].sort((leftRow, rightRow) => {
			if (sortColumnKey === "lp") {
				return (leftRow.lp - rightRow.lp) * directionMultiplier;
			}

			const leftValue = toSafeString(leftRow[sortColumnKey]);
			const rightValue = toSafeString(rightRow[sortColumnKey]);

			return (
				leftValue.localeCompare(rightValue, "pl", {
					numeric: true,
					sensitivity: "base",
				}) * directionMultiplier
			);
		});
	}, [
		inspectionRows,
		advancedFilters,
		columnFilters,
		getAdvancedFilterTokensForRow,
		sortColumnKey,
		sortDirection,
	]);

	const totalPages = useMemo(
		() =>
			Math.max(
				1,
				Math.ceil(filteredAndSortedInspectionRows.length / pageSize),
			),
		[filteredAndSortedInspectionRows.length, pageSize],
	);

	const paginationControlKey = useMemo(
		() =>
			JSON.stringify({
				advancedFilters,
				columnFilters,
				hiddenColumns,
				sortColumnKey,
				sortDirection,
				selectedInspectionView,
			}),
		[
			advancedFilters,
			columnFilters,
			hiddenColumns,
			sortColumnKey,
			sortDirection,
			selectedInspectionView,
		],
	);

	useEffect(() => {
		if (!didInitPageFromHydration) {
			return;
		}

		if (previousPaginationControlKeyRef.current === null) {
			previousPaginationControlKeyRef.current = paginationControlKey;
			return;
		}

		if (previousPaginationControlKeyRef.current !== paginationControlKey) {
			setCurrentPage(1);
			previousPaginationControlKeyRef.current = paginationControlKey;
		}
	}, [didInitPageFromHydration, paginationControlKey, totalPages]);

	useEffect(() => {
		if (!didInitPageFromHydration) {
			return;
		}

		if (hasReceivedNonEmptyRows) {
			setCurrentPage(1);
			return;
		}

		if (!hasReceivedNonEmptyRows && inspectionRows.length === 0) {
			return;
		}

		setCurrentPage((previous) => Math.min(Math.max(previous, 1), totalPages));
	}, [
		didInitPageFromHydration,
		hasReceivedNonEmptyRows,
		inspectionRows.length,
		totalPages,
	]);

	const paginatedInspectionRows = useMemo(() => {
		const totalItems = filteredAndSortedInspectionRows.length;
		if (totalItems === 0) {
			return [];
		}

		const startIndex = (currentPage - 1) * pageSize;
		const endIndex = startIndex + pageSize;
		return filteredAndSortedInspectionRows.slice(startIndex, endIndex);
	}, [currentPage, filteredAndSortedInspectionRows, pageSize]);

	const resolvePageForRowIndex = useCallback(
		(rowIndex: number) => {
			if (!Number.isFinite(rowIndex)) {
				return 1;
			}

			const normalizedRowIndex = Math.max(0, Math.trunc(rowIndex));
			const page = Math.floor(normalizedRowIndex / pageSize) + 1;
			return Math.min(Math.max(page, 1), totalPages);
		},
		[pageSize, totalPages],
	);

	const paginationItems = useMemo(
		() => buildPaginationItems(currentPage, totalPages),
		[currentPage, totalPages],
	);

	const handlePageChange = (nextPage: number) => {
		if (!Number.isFinite(nextPage)) {
			return;
		}

		const normalizedPage = Math.trunc(nextPage);
		const boundedPage = Math.min(Math.max(normalizedPage, 1), totalPages);
		setCurrentPage(boundedPage);

		if (typeof window === "undefined" || !tableViewStorageKey) {
			return;
		}

		const storage =
			tableViewStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;
		const nextHiddenColumnsByView: HiddenColumnsByView = {
			...hiddenColumnsByView,
			[selectedInspectionView]: hiddenColumns,
		};

		storage.setItem(
			tableViewStorageKey,
			JSON.stringify({
				selectedInspectionView,
				hiddenColumnsByView: nextHiddenColumnsByView,
				currentPage: boundedPage,
				pageSize,
			}),
		);
	};

	const handlePageSizeChange = (nextPageSize: number) => {
		if (!Number.isFinite(nextPageSize)) {
			return;
		}

		const normalizedPageSize = Math.max(1, Math.trunc(nextPageSize));
		setHasPersistedPageSize(true);
		setPageSize(normalizedPageSize);
		setCurrentPage(1);

		if (
			typeof window === "undefined" ||
			!tableViewStorageKey
		) {
			return;
		}

		const storage =
			tableViewStorageArea === "localStorage"
				? window.localStorage
				: window.sessionStorage;
		const nextHiddenColumnsByView: HiddenColumnsByView = {
			...hiddenColumnsByView,
			[selectedInspectionView]: hiddenColumns,
		};

		storage.setItem(
			tableViewStorageKey,
			JSON.stringify({
				selectedInspectionView,
				hiddenColumnsByView: nextHiddenColumnsByView,
				currentPage: 1,
				pageSize: normalizedPageSize,
			}),
		);
	};

	const handleSortByColumn = (columnKey: InspectionColumnKey) => {
		if (sortColumnKey !== columnKey) {
			setSortColumnKey(columnKey);
			setSortDirection("asc");
			return;
		}

		if (sortDirection === "asc") {
			setSortDirection("desc");
			return;
		}

		if (sortDirection === "desc") {
			setSortColumnKey(null);
			setSortDirection(null);
			return;
		}

		setSortDirection("asc");
	};

	const handleFilterChange = (
		columnKey: InspectionColumnKey,
		value: string,
	) => {
		setColumnFilters((prev) => ({ ...prev, [columnKey]: value }));
	};

	const clearFilters = () => {
		setColumnFilters({});
		setAdvancedFilters({});
	};

	const toggleAdvancedFilterValue = (value: string) => {
		setAdvancedFilters((prev) => {
			const currentValues = (prev[advancedFilterColumnKey] ?? []).filter(
				(item) => !isAdvancedDateRangeFilterToken(item),
			);
			const nextValues = currentValues.includes(value)
				? currentValues.filter((item) => item !== value)
				: [...currentValues, value];

			return {
				...prev,
				[advancedFilterColumnKey]: nextValues,
			};
		});
	};

	const selectAllVisibleAdvancedFilterValues = () => {
		setAdvancedFilters((prev) => {
			const currentValues = new Set(
				(prev[advancedFilterColumnKey] ?? []).filter(
					(value) => !isAdvancedDateRangeFilterToken(value),
				),
			);
			visibleAdvancedFilterValues.forEach((value) => currentValues.add(value));

			return {
				...prev,
				[advancedFilterColumnKey]: Array.from(currentValues),
			};
		});
	};

	const clearAdvancedFilterForSelectedColumn = () => {
		setAdvancedFilters((prev) => ({
			...prev,
			[advancedFilterColumnKey]: [],
		}));
	};

	const setAdvancedFilterDateRange = (range: { from: string; to: string }) => {
		setAdvancedFilters((prev) => {
			const token = createAdvancedDateRangeFilterToken(range);

			return {
				...prev,
				[advancedFilterColumnKey]: token ? [token] : [],
			};
		});
	};

	const openAdvancedFilterForColumn = (
		columnKey: InspectionColumnKey,
		triggerElement: HTMLElement,
	) => {
		setAdvancedFilterAnchor(getFloatingPanelAnchor(triggerElement));
		setAdvancedFilterColumnKey(columnKey);
		setAdvancedFilterSearch("");
		setIsAdvancedFilterModalOpen(true);
	};

	const hideColumnInDraft = (columnKey: InspectionColumnKey) => {
		if (draftHiddenColumns.includes(columnKey)) {
			return;
		}

		const nextHiddenColumns = [...draftHiddenColumns, columnKey];
		setDraftHiddenColumns(nextHiddenColumns);
		setDraftHiddenColumnsByView((prev) => ({
			...prev,
			[draftSelectedInspectionView]: nextHiddenColumns,
		}));
	};

	const handleDraftColumnVisibilityChange = (
		columnKey: InspectionColumnKey,
		isVisible: boolean,
	) => {
		if (!isVisible && draftVisibleInspectionColumns.length <= 1) {
			return;
		}

		if (isVisible) {
			const nextHiddenColumns = draftHiddenColumns.filter(
				(key) => key !== columnKey,
			);
			setDraftHiddenColumns(nextHiddenColumns);
			setDraftHiddenColumnsByView((prev) => ({
				...prev,
				[draftSelectedInspectionView]: nextHiddenColumns,
			}));
			return;
		}

		hideColumnInDraft(columnKey);
	};

	const handleOpenViewModal = () => {
		const nextDraftHiddenByView = {
			...hiddenColumnsByView,
			[selectedInspectionView]: hiddenColumns,
		};

		setDraftSelectedInspectionView(selectedInspectionView);
		setDraftHiddenColumns(hiddenColumns);
		setDraftHiddenColumnsByView(nextDraftHiddenByView);
		setIsColumnPickerOpen(true);
	};

	const handleDraftViewSelect = (viewId: InspectionViewId) => {
		const nextDraftHiddenByView = {
			...draftHiddenColumnsByView,
			[draftSelectedInspectionView]: draftHiddenColumns,
		};
		const nextHiddenColumns =
			nextDraftHiddenByView[viewId] ?? getDefaultHiddenColumnsForView(viewId);

		setDraftHiddenColumnsByView(nextDraftHiddenByView);
		setDraftSelectedInspectionView(viewId);
		setDraftHiddenColumns(nextHiddenColumns);
	};

	const handleDraftSelectAllColumns = () => {
		setDraftHiddenColumns([]);
		setDraftHiddenColumnsByView((prev) => ({
			...prev,
			[draftSelectedInspectionView]: [],
		}));
	};

	const handleDraftDeselectAllColumns = () => {
		const nextHiddenColumns = getAllInspectionColumnKeys();
		setDraftHiddenColumns(nextHiddenColumns);
		setDraftHiddenColumnsByView((prev) => ({
			...prev,
			[draftSelectedInspectionView]: nextHiddenColumns,
		}));
	};

	const handleDraftResetSelection = () => {
		const nextHiddenColumns = getDefaultHiddenColumnsForView(
			draftSelectedInspectionView,
		);
		setDraftHiddenColumns(nextHiddenColumns);
		setDraftHiddenColumnsByView((prev) => ({
			...prev,
			[draftSelectedInspectionView]: nextHiddenColumns,
		}));
	};

	const handleApplyViewChanges = () => {
		const nextHiddenByView = {
			...draftHiddenColumnsByView,
			[draftSelectedInspectionView]: draftHiddenColumns,
		};
		const nextHiddenColumns =
			nextHiddenByView[draftSelectedInspectionView] ??
			getDefaultHiddenColumnsForView(draftSelectedInspectionView);

		setHiddenColumnsByView(nextHiddenByView);
		setSelectedInspectionView(draftSelectedInspectionView);
		setHiddenColumns(nextHiddenColumns);
		setIsColumnPickerOpen(false);
	};

	return {
		advancedFilterAnchor,
		advancedFilterColumnKey,
		advancedFilterSearch,
		advancedFilters,
		clearAdvancedFilterForSelectedColumn,
		clearFilters,
		columnFilters,
		draftHiddenColumns,
		draftSelectableColumnDefinitions,
		draftVisibleInspectionColumnsCount: draftVisibleInspectionColumns.length,
		draftSelectedInspectionView,
		filteredAndSortedInspectionRows,
		paginatedInspectionRows,
		currentPage,
		totalPages,
		paginationItems,
		resolvePageForRowIndex,
		handlePageChange,
		handlePageSizeChange,
		pageSize,
		handleApplyViewChanges,
		handleDraftColumnVisibilityChange,
		handleDraftDeselectAllColumns,
		handleDraftResetSelection,
		handleDraftSelectAllColumns,
		handleDraftViewSelect,
		handleFilterChange,
		handleOpenViewModal,
		handleSortByColumn,
		hasActiveFilters,
		canClearFilters,
		isAdvancedFilterModalOpen,
		isColumnPickerOpen,
		selectedAdvancedFilterDateRange,
		openAdvancedFilterForColumn,
		selectableColumnDefinitions,
		selectedAdvancedFilterValues,
		selectedInspectionView,
		selectAllVisibleAdvancedFilterValues,
		setAdvancedFilterSearch,
		setAdvancedFilterDateRange,
		setDraftHiddenColumns,
		setIsAdvancedFilterModalOpen,
		setIsColumnPickerOpen,
		sortColumnKey,
		sortDirection,
		toggleAdvancedFilterValue,
		visibleAdvancedFilterValues,
		visibleInspectionColumnDefinitions,
	};
}

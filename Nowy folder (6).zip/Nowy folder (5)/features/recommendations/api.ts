import type {
	RecommendationFilters,
	RecommendationListResponse,
	RecommendationRead,
	RecommendationWrite,
} from "@/features/recommendations/types";

export type RecommendationLockConflict = {
	module: string;
	recordId: string;
	ownerUserId: string;
	ownerLogin: string;
	ownerDisplayName: string;
	acquiredAt: string;
	expiresAt: string;
};

type ApiResult<T> =
	| { ok: true; data: T }
	| {
			ok: false;
			error: string;
			status?: number;
			errorCode?: string;
			lockConflict?: RecommendationLockConflict;
			lockErrorCode?: string;
			lockReason?: string;
			currentUpdatedAt?: string;
	  };

function getErrorMessageByStatus(status: number) {
	if (status === 400) return "Błędne dane wejściowe.";
	if (status === 401) return "Brak autoryzacji operatora.";
	if (status === 403) return "Brak uprawnień do operacji.";
	if (status === 404) return "Nie znaleziono zasobu.";
	if (status === 409)
		return "Dane zostały zmienione przez innego użytkownika. Odśwież widok i spróbuj ponownie.";
	if (status === 423) return "Błąd blokady rekordu.";
	if (status === 422) return "Nieprawidłowy format danych.";
	return `Błąd API (${status}).`;
}

function toStringValue(value: unknown) {
	return typeof value === "string" ? value.trim() : "";
}

function toDateListValue(value: unknown) {
	if (!Array.isArray(value)) {
		return [] as string[];
	}

	return value
		.map((item) => toStringValue(item))
		.filter(Boolean);
}

function toNullableBoolean(value: unknown) {
	return typeof value === "boolean" ? value : null;
}

function toNullablePositiveNumber(value: unknown) {
	if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) {
		return null;
	}

	return value;
}

function toPositiveNumberList(value: unknown) {
	const source = Array.isArray(value)
		? value
		: typeof value === "number"
			? [value]
			: typeof value === "string"
				? value
					.split(/[;,]/)
					.map((item) => item.trim())
					.filter(Boolean)
				: [];

	return Array.from(
		new Set(
			source
				.map((item) =>
					typeof item === "number"
						? item
						: typeof item === "string"
							? Number(item.trim())
							: NaN,
				)
				.filter((item): item is number => Number.isFinite(item) && item > 0),
		),
	).sort((left, right) => left - right);
}

function buildRecommendationWritePayload(
	payload: RecommendationWrite,
	useSnakeCaseInspectionTeams: boolean,
) {
	const normalizedInspectionTeamIds = toPositiveNumberList(payload.inspectionTeamIds);
	const { inspectionTeamIds: _ignoredInspectionTeamIds, ...rest } = payload;

	if (useSnakeCaseInspectionTeams) {
		return {
			...rest,
			inspection_team_ids: normalizedInspectionTeamIds,
		};
	}

	return {
		...rest,
		inspectionTeamIds: normalizedInspectionTeamIds,
	};
}

function normalizeRecommendationRead(payload: unknown): RecommendationRead {
	const source = payload && typeof payload === "object"
		? (payload as Record<string, unknown>)
		: {};

	const dataZalecen = toStringValue(source.dataZalecen);
	const legacySingleDate = toStringValue(source.terminWykonaniaZalecen);
	const terminyWykonaniaZalecenList = toDateListValue(source.terminyWykonaniaZalecenList);
	const legacyDatesList = toDateListValue(source.dataZalecenList);
	const nazwaPodmiotuSkrocona = toStringValue(
		source.nazwaPodmiotuSkrocona ?? source.nazwaPodmiotuSkrot,
	);
	const statusSkrocona = toStringValue(source.statusSkrocona ?? source.statusSkrot);

	return {
		id: Number(source.id) || 0,
		lp: Number(source.lp) || 0,
		kodZalecenia: toStringValue(source.kodZalecenia) || null,
		canEdit: source.canEdit === true,
		inspectionId:
			typeof source.inspectionId === "number" && Number.isFinite(source.inspectionId)
				? source.inspectionId
				: null,
		inspectionLp:
			typeof source.inspectionLp === "number" && Number.isFinite(source.inspectionLp)
				? source.inspectionLp
				: null,
		inspectionKod: toStringValue(source.inspectionKod) || null,
		kodInspekcji: toStringValue(source.kodInspekcji) || null,
		pozycja: Number(source.pozycja) || 0,
		nazwaPodmiotuId: toNullablePositiveNumber(source.nazwaPodmiotuId),
		nazwaPodmiotu: toStringValue(source.nazwaPodmiotu),
		nazwaPodmiotuSkrocona: nazwaPodmiotuSkrocona || null,
		dataZalecen: dataZalecen || legacySingleDate || null,
		terminyWykonaniaZalecenList:
			terminyWykonaniaZalecenList.length > 0
				? terminyWykonaniaZalecenList
				: legacyDatesList,
		terminWykonaniaZalecen: legacySingleDate || dataZalecen || null,
		statusId: toNullablePositiveNumber(source.statusId),
		status: toStringValue(source.status) || null,
		statusSkrocona: statusSkrocona || null,
		komentarz: toStringValue(source.komentarz) || null,
		dataZalecenList:
			legacyDatesList.length > 0 ? legacyDatesList : terminyWykonaniaZalecenList,
		dataAkceptacjiNotyWeryfikacjiList: toDateListValue(
			source.dataAkceptacjiNotyWeryfikacjiList,
		),
		inspectionTeamIds: toPositiveNumberList(
			source.inspectionTeamIds ?? source.inspection_team_ids,
		),
		brakTerminowWykonaniaZalecen: toNullableBoolean(
			source.brakTerminowWykonaniaZalecen,
		),
		brakDatAkceptacjiNotyWeryfikacji: toNullableBoolean(
			source.brakDatAkceptacjiNotyWeryfikacji,
		),
		utworzonoO: toStringValue(source.utworzonoO) || null,
		zaktualizowanoO: toStringValue(source.zaktualizowanoO) || null,
	};
}

function parseLockConflict(payload: unknown): RecommendationLockConflict | undefined {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	if (toStringValue(source.code) !== "RECORD_LOCKED") {
		return undefined;
	}

	return {
		module: toStringValue(source.module),
		recordId: toStringValue(source.recordId),
		ownerUserId: toStringValue(source.ownerUserId),
		ownerLogin: toStringValue(source.ownerLogin),
		ownerDisplayName: toStringValue(source.ownerDisplayName),
		acquiredAt: toStringValue(source.acquiredAt),
		expiresAt: toStringValue(source.expiresAt),
	};
}

function parseCurrentUpdatedAt(payload: unknown) {
	if (!payload || typeof payload !== "object") {
		return undefined;
	}

	const source = payload as Record<string, unknown>;
	const value = source.currentUpdatedAt ?? source.updatedAt;
	const parsed = toStringValue(value);
	return parsed || undefined;
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
		};
		const detail = payload.detail ?? payload.message;

		if (typeof detail === "string") {
			return detail;
		}

		if (Array.isArray(detail)) {
			return detail
				.map((item) => {
					if (typeof item === "string") return item;
					if (item && typeof item === "object") {
						const maybeMsg = (item as { msg?: unknown }).msg;
						return typeof maybeMsg === "string"
							? maybeMsg
							: JSON.stringify(item);
					}
					return "";
				})
				.filter(Boolean)
				.join("; ");
		}

		return "";
	} catch {
		return "";
	}
}

export async function fetchRecommendations(
	operatorLogin: string,
	filters: RecommendationFilters,
): Promise<ApiResult<RecommendationListResponse>> {
	const query = new URLSearchParams();

	if (
		typeof filters.inspectionId === "number" &&
		Number.isFinite(filters.inspectionId)
	) {
		query.set("inspectionId", String(filters.inspectionId));
	}

	if (filters.status?.trim()) {
		query.set("status", filters.status.trim());
	}

	if (filters.nazwaPodmiotu?.trim()) {
		query.set("nazwaPodmiotu", filters.nazwaPodmiotu.trim());
	}

	if (filters.sortBy) {
		query.set("sortBy", filters.sortBy);
	}

	if (filters.sortOrder) {
		query.set("sortOrder", filters.sortOrder);
	}

	const querySuffix = query.toString() ? `?${query.toString()}` : "";
	const response = await fetch(`/api/recommendations${querySuffix}`, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		const base = getErrorMessageByStatus(response.status);
		return {
			ok: false,
			error: detail ? `${base} ${detail}` : base,
			status: response.status,
		};
	}

	const payload = (await response.json()) as unknown;
	const data = (payload ?? {}) as Partial<RecommendationListResponse>;
	return {
		ok: true,
		data: {
			items: Array.isArray(data.items)
				? data.items.map((item) => normalizeRecommendationRead(item))
				: [],
			total: typeof data.total === "number" ? data.total : 0,
		},
	};
}

export async function createRecommendation(
	operatorLogin: string,
	payload: RecommendationWrite,
): Promise<ApiResult<RecommendationRead>> {
	const sendCreateRequest = async (useSnakeCaseInspectionTeams: boolean) => {
		return fetch("/api/recommendations", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(
				buildRecommendationWritePayload(payload, useSnakeCaseInspectionTeams),
			),
		});
	};

	let response = await sendCreateRequest(false);
	if (!response.ok && response.status === 422) {
		response = await sendCreateRequest(true);
	}

	if (!response.ok) {
		const contentType = response.headers.get("content-type") ?? "";
		const responsePayload = contentType.includes("application/json")
			? ((await response.json()) as unknown)
			: null;
		const detailSource = responsePayload && typeof responsePayload === "object"
			? ((responsePayload as { detail?: unknown; message?: unknown }).detail ??
				(responsePayload as { detail?: unknown; message?: unknown }).message)
			: null;
		const detail = typeof detailSource === "string" ? detailSource : "";
		const errorCode =
			responsePayload && typeof responsePayload === "object"
				? toStringValue((responsePayload as Record<string, unknown>).code) || undefined
				: undefined;
		const isInspectionStatusBlocked =
			response.status === 409 && errorCode === "INSPECTION_STATUS_BLOCKS_OPERATION";
		const base =
			isInspectionStatusBlocked
				? ""
				: response.status === 409
				? "Konflikt danych biznesowych."
				: getErrorMessageByStatus(response.status);
		return {
			ok: false,
			error: isInspectionStatusBlocked
				? (detail || "Nie można zapisać rekordu dla inspekcji zamkniętej.")
				: detail
					? `${base} ${detail}`
					: base,
			status: response.status,
			errorCode,
		};
	}

	return { ok: true, data: normalizeRecommendationRead(await response.json()) };
}

export async function updateRecommendation(
	operatorLogin: string,
	recommendationId: number,
	payload: RecommendationWrite,
	options?: {
		expectedUpdatedAt?: string | null;
		lockToken?: string | null;
	},
): Promise<ApiResult<RecommendationRead>> {
	const buildUpdateRequestPayload = (useSnakeCaseInspectionTeams: boolean) => {
		const requestPayload: Record<string, unknown> = {
			...buildRecommendationWritePayload(payload, useSnakeCaseInspectionTeams),
		};

		if (
			typeof options?.expectedUpdatedAt === "string" &&
			options.expectedUpdatedAt.trim()
		) {
			requestPayload.expectedUpdatedAt = options.expectedUpdatedAt.trim();
		}

		if (typeof options?.lockToken === "string" && options.lockToken.trim()) {
			requestPayload.lockToken = options.lockToken.trim();
		}

		return requestPayload;
	};

	const sendUpdateRequest = async (useSnakeCaseInspectionTeams: boolean) => {
		return fetch(`/api/recommendations/${recommendationId}`, {
			method: "PUT",
			headers: {
				"Content-Type": "application/json",
				"X-Operator-Login": operatorLogin,
			},
			body: JSON.stringify(buildUpdateRequestPayload(useSnakeCaseInspectionTeams)),
		});
	};

	let response = await sendUpdateRequest(false);
	if (!response.ok && response.status === 422) {
		response = await sendUpdateRequest(true);
	}

	if (!response.ok) {
		const contentType = response.headers.get("content-type") ?? "";
		const responsePayload = contentType.includes("application/json")
			? ((await response.json()) as unknown)
			: null;
		const detailSource = responsePayload && typeof responsePayload === "object"
			? ((responsePayload as { detail?: unknown; message?: unknown }).detail ??
				(responsePayload as { detail?: unknown; message?: unknown }).message)
			: null;
		const detail = typeof detailSource === "string" ? detailSource : "";
		const base = getErrorMessageByStatus(response.status);
		const lockConflict =
			response.status === 423 ? parseLockConflict(responsePayload) : undefined;
		const lockErrorCode =
			response.status === 423 && responsePayload && typeof responsePayload === "object"
				? toStringValue((responsePayload as Record<string, unknown>).code) || undefined
				: undefined;
		const lockReason =
			response.status === 423 && responsePayload && typeof responsePayload === "object"
				? toStringValue((responsePayload as Record<string, unknown>).reason) || undefined
				: undefined;
		const errorCode =
			responsePayload && typeof responsePayload === "object"
				? toStringValue((responsePayload as Record<string, unknown>).code) || undefined
				: undefined;
		const isInspectionStatusBlocked =
			response.status === 409 && errorCode === "INSPECTION_STATUS_BLOCKS_OPERATION";
		const currentUpdatedAt =
			response.status === 409 && !isInspectionStatusBlocked
				? parseCurrentUpdatedAt(responsePayload)
				: undefined;
		const lockMessage =
			lockErrorCode === "RECORD_LOCKED"
				? "Nie możesz teraz edytować tego wpisu, ponieważ jest edytowany przez innego użytkownika."
				: lockErrorCode === "LOCK_REQUIRED" || lockReason === "lock_required"
					? "Do zapisu wymagana jest aktywna blokada rekordu. Odśwież dane i otwórz formularz ponownie."
					: lockErrorCode === "LOCK_TOKEN_INVALID" || lockReason === "lock_token_invalid"
						? "Blokada edycji wygasła lub jest nieprawidłowa. Odśwież dane i otwórz formularz ponownie."
						: base;
		return {
			ok: false,
			error:
				isInspectionStatusBlocked
					? (detail || "Nie można zapisać rekordu dla inspekcji zamkniętej.")
					: response.status === 423
					? detail
						? `${lockMessage} ${detail}`
						: lockMessage
					: detail
						? `${base} ${detail}`
						: base,
			status: response.status,
			errorCode,
			lockConflict,
			lockErrorCode,
			lockReason,
			currentUpdatedAt,
		};
	}

	return { ok: true, data: normalizeRecommendationRead(await response.json()) };
}

export async function deleteRecommendation(
	operatorLogin: string,
	recommendationId: number,
): Promise<ApiResult<null>> {
	const response = await fetch(`/api/recommendations/${recommendationId}`, {
		method: "DELETE",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
	});

	if (!response.ok) {
		const detail = await readApiDetail(response);
		const base = getErrorMessageByStatus(response.status);
		return {
			ok: false,
			error: detail ? `${base} ${detail}` : base,
			status: response.status,
		};
	}

	return { ok: true, data: null };
}

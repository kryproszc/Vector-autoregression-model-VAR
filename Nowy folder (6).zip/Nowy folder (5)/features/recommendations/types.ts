export type RecommendationRead = {
	id: number;
	lp: number;
	kodZalecenia?: string | null;
	canEdit: boolean;
	inspectionId: number | null;
	inspectionLp?: number | null;
	inspectionKod?: string | null;
	kodInspekcji?: string | null;
	pozycja: number;
	nazwaPodmiotuId?: number | null;
	nazwaPodmiotu: string;
	nazwaPodmiotuSkrocona: string | null;
	dataZalecen: string | null;
	terminyWykonaniaZalecenList: string[];
	// Legacy fields kept for backward compatibility with older backend responses.
	terminWykonaniaZalecen: string | null;
	statusId?: number | null;
	status: string | null;
	statusSkrocona: string | null;
	komentarz: string | null;
	dataZalecenList: string[];
	dataAkceptacjiNotyWeryfikacjiList: string[];
	brakTerminowWykonaniaZalecen?: boolean | null;
	brakDatAkceptacjiNotyWeryfikacji?: boolean | null;
	inspectionTeamIds: number[];
	utworzonoO: string | null;
	zaktualizowanoO: string | null;
};

export type RecommendationListResponse = {
	items: RecommendationRead[];
	total: number;
};

export type RecommendationWrite = {
	inspectionId: number | null;
	pozycja: number;
	nazwaPodmiotuId?: number;
	dataZalecen: string | null;
	terminyWykonaniaZalecenList: string[];
	brakTerminowWykonaniaZalecen: boolean;
	brakDatAkceptacjiNotyWeryfikacji: boolean;
	statusId?: number;
	komentarz: string | null;
	dataAkceptacjiNotyWeryfikacjiList: string[];
	inspectionTeamIds: number[];
};

export type RecommendationFilters = {
	inspectionId?: number;
	status?: string;
	nazwaPodmiotu?: string;
	sortBy?:
		| "id"
		| "pozycja"
		| "dataZalecen"
		| "terminWykonaniaZalecen"
		| "utworzonoO"
		| "zaktualizowanoO";
	sortOrder?: "asc" | "desc";
};

export const ENTITY_NAME_OPTIONS = [
	"Towarzystwo Ubezpieczen Aurora S.A.",
	"Compensa Zycie S.A.",
	"PZU Zycie S.A.",
	"Nationale-Nederlanden TUiR S.A.",
	"Allianz Polska S.A.",
];

export const INSPECTION_TYPE_OPTIONS = ["kontrola", "wizyta nadzorcza"];

export const INSPECTION_SCOPE_OPTIONS = [
	"Kontrola dokumentacji",
	"Wizyta nadzorcza",
	"Kontrola ryzyka operacyjnego",
	"Zakres z upowaznienia (oznaczenie skrotowe)",
];

export const EMPLOYEE_OPTIONS = [
	"Anna Kowalska",
	"Piotr Mazur",
	"Marta Nowak",
	"Pawel Zielinski",
	"Ewa Lewandowska",
	"Jan Kaczmarek",
];

export const MARKET_OPTIONS = ["ubezpieczeniowy", "dystrybucyjny"];

export const ENTITY_TYPE_OPTIONS = [
	"zaklad ubezpieczen/reasekuracji",
	"agent (inny niz bank)",
	"broker",
	"agent (bank)",
	"dostawca uslug",
];

export const INSPECTION_STATUS_OPTIONS = [
	"inspekcja zaplanowana",
	"inspekcja w przygotowaniu",
	"trwaja czynnosci inspekcyjne",
	"inspekcja zakonczona",
];

export const RECOMMENDATION_STATUS_OPTIONS = ["zalecenia wykonano", "xxx"];

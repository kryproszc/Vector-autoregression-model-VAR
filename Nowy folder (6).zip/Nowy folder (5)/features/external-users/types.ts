export type ExternalPermissionCatalogItem = {
	key: string;
	label: string;
	description: string;
};

export type ExternalUser = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	email: string | null;
	rolaId: number | null;
	zespolId: number | null;
	aktywny: boolean;
	permissions: string[];
};

export type CreateExternalUserForm = {
	login: string;
	imie: string;
	nazwisko: string;
	email: string;
	aktywny: boolean;
	permissions: string[];
};

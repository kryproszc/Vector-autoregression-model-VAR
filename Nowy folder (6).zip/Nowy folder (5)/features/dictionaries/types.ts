export type DictionaryType = {
	kodTypu: string;
	nazwaTypu: string;
	kategoria?: number | string | null;
};

export type DictionaryEntry = {
	id?: number;
	teamId?: number;
	kodTypu: string;
	kodPozycji: string;
	nazwaPozycji: string;
	nazwaUzytkowa?: string | null;
	skrotPozycji: string | null;
	kolejnosc: number | null;
	aktywny: boolean;
	kierownikUserId?: number | null;
	kierownikDisplayName?: string | null;
	kolor?: DictionaryColorPalette | null;
	odcien?: DictionaryColorShade | null;
	intensywnosc?: number | null;
};

export type DictionaryColorPalette =
	| "emerald"
	| "green"
	| "teal"
	| "lime"
	| "sky"
	| "cyan"
	| "blue"
	| "indigo"
	| "rose"
	| "red"
	| "pink"
	| "fuchsia"
	| "yellow"
	| "amber"
	| "orange";

export type DictionaryColorShade = 50 | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900 | 950;

export type AddDictionaryEntryForm = {
	kodPozycji: string;
	nazwaPozycji: string;
	nazwaUzytkowa: string;
	skrotPozycji: string;
	aktywny: boolean;
	kierownikUserId: number | null;
	kolor: DictionaryColorPalette | null;
	odcien: DictionaryColorShade | null;
	intensywnosc: number | null;
};

export type TeamLeaderOption = {
	id: number;
	displayName: string;
};

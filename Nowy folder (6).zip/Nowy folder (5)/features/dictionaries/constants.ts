import type {
	AddDictionaryEntryForm,
	DictionaryColorPalette,
	DictionaryColorShade,
} from "@/features/dictionaries/types";

export type InspectionStatusColorPreset = {
	key: "si2" | "si3" | "si4" | "si5to9";
	label: string;
	kolor: DictionaryColorPalette;
	odcien: DictionaryColorShade;
	intensywnosc: number;
};

export const INSPECTION_STATUS_COLOR_PRESETS: InspectionStatusColorPreset[] = [
	{
		key: "si2",
		label: "I_SI_2 (zielony)",
		kolor: "green",
		odcien: 300,
		intensywnosc: 65,
	},
	{
		key: "si3",
		label: "I_SI_3 (cyjan)",
		kolor: "cyan",
		odcien: 400,
		intensywnosc: 65,
	},
	{
		key: "si4",
		label: "I_SI_4 (różany)",
		kolor: "rose",
		odcien: 200,
		intensywnosc: 65,
	},
	{
		key: "si5to9",
		label: "I_SI_5-9 (żółty)",
		kolor: "yellow",
		odcien: 200,
		intensywnosc: 65,
	},
];

export function findInspectionStatusPresetKeyByValues(
	kolor: DictionaryColorPalette | null,
	odcien: DictionaryColorShade | null,
	intensywnosc: number | null,
): InspectionStatusColorPreset["key"] | null {
	if (!kolor || !odcien || intensywnosc === null) {
		return null;
	}

	const matched = INSPECTION_STATUS_COLOR_PRESETS.find(
		(item) =>
			item.kolor === kolor &&
			item.odcien === odcien &&
			item.intensywnosc === intensywnosc,
	);

	return matched?.key ?? null;
}

export const DICTIONARY_COLOR_OPTIONS: Array<{
	value: DictionaryColorPalette;
	label: string;
}> = [
	{ value: "green", label: "Zielony" },
	{ value: "emerald", label: "Szmaragdowy" },
	{ value: "teal", label: "Morski" },
	{ value: "lime", label: "Limonkowy" },
	{ value: "cyan", label: "Cyjan" },
	{ value: "sky", label: "Błękitny" },
	{ value: "blue", label: "Niebieski" },
	{ value: "indigo", label: "Indygo" },
	{ value: "rose", label: "Różany" },
	{ value: "pink", label: "Różowy" },
	{ value: "red", label: "Czerwony" },
	{ value: "fuchsia", label: "Fuksja" },
	{ value: "yellow", label: "Żółty" },
	{ value: "amber", label: "Bursztynowy" },
	{ value: "orange", label: "Pomarańczowy" },
];

export const DICTIONARY_SHADE_OPTIONS: DictionaryColorShade[] = [
	50,
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900,
	950,
];

export const DEFAULT_ADD_DICTIONARY_ENTRY_FORM: AddDictionaryEntryForm = {
	kodPozycji: "",
	nazwaPozycji: "",
	nazwaUzytkowa: "",
	skrotPozycji: "",
	aktywny: true,
	kierownikUserId: null,
	kolor: null,
	odcien: null,
	intensywnosc: null,
};

import { History, Pencil } from "lucide-react";

import type { AdminUser } from "@/features/admin-users/types";
import { getRoleLabelById } from "@/features/admin-users/utils";
import { TableSurface } from "@/shared/components/table/TableSurface";

type AdminUsersTableProps = {
	users: AdminUser[];
	usersError: string | null;
	isUsersLoading: boolean;
	canEditUser: (user: AdminUser) => boolean;
	onEditUser: (user: AdminUser) => void;
	onViewHistory: (user: AdminUser) => void;
	className?: string;
};

export function AdminUsersTable({
	users,
	usersError,
	isUsersLoading,
	canEditUser,
	onEditUser,
	onViewHistory,
	className,
}: AdminUsersTableProps) {
	const getAccountTypeLabel = (accountType: AdminUser["accountType"]) => {
		switch ((accountType ?? "").toLowerCase()) {
			case "diu":
				return "Pracownicy DIU";
			case "observer":
			case "observers":
				return "Użytkownicy obserwatorzy";
			case "technical":
				return "Użytkownicy techniczni";
			default:
				return "-";
		}
	};

	const getListVisibilityLabel = (listVisibility: AdminUser["listVisibility"]) => {
		switch ((listVisibility ?? "").toLowerCase()) {
			case "visible":
			case "widoczny":
				return "Widoczny";
			case "hidden":
			case "ukryty":
				return "Ukryty";
			default:
				return "-";
		}
	};

	const headerCellClass =
		"whitespace-nowrap border-slate-300 border-b bg-slate-100 px-3 py-2 text-left font-semibold text-slate-800";

	return (
		<TableSurface
			isLoading={isUsersLoading}
			loadingMessage="Ładowanie użytkowników..."
			errorMessage={usersError}
			containerClassName={className ?? "h-full"}
			scrollAreaClassName="h-full min-h-0 pr-2"
		>
			<table className="w-max min-w-full border-collapse text-slate-900 text-sm">
				<thead className="sticky top-0 z-10">
					<tr className="bg-slate-100 text-slate-800">
						<th className={headerCellClass}>
							Login
						</th>
						<th className={headerCellClass}>
							Imię i nazwisko
						</th>
						<th className={headerCellClass}>
							Typ konta
						</th>
						<th className={headerCellClass}>
							Rola
						</th>
						<th className={headerCellClass}>
							Zespół
						</th>
						<th className={headerCellClass}>
							Departament
						</th>
						<th className={headerCellClass}>
							E-mail
						</th>
						<th className={headerCellClass}>
							Status
						</th>
						<th className={headerCellClass}>
							Widoczność
						</th>
						<th className={`${headerCellClass} min-w-[11rem]`}>
							Akcje
						</th>
					</tr>
				</thead>

				<tbody>
					{users.map((user) => (
						<tr
							key={user.id}
							className="border-slate-200 border-b text-slate-900 last:border-b-0 hover:bg-slate-50"
						>
							<td className="whitespace-nowrap px-3 py-2.5 font-medium">
								{user.login || "brak"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.imie} {user.nazwisko}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getAccountTypeLabel(user.accountType)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getRoleLabelById(user.rolaId, user.rola)}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.zespolSkroconaNazwa ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.departmentCode ?? user.departmentLabel ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{user.email ?? "-"}
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								<span
									className={`inline-flex rounded-full px-2 py-0.5 font-semibold text-xs ${
										user.aktywny
											? "bg-emerald-100 text-emerald-800"
											: "bg-slate-200 text-slate-700"
									}`}
								>
									{user.aktywny ? "Aktywny" : "Nieaktywny"}
								</span>
							</td>
							<td className="whitespace-nowrap px-3 py-2.5">
								{getListVisibilityLabel(user.listVisibility)}
							</td>
							<td className="min-w-[11rem] whitespace-nowrap px-3 py-2.5">
								<button
									type="button"
									onClick={() => onViewHistory(user)}
									className="mr-2 inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100"
								>
									<History size={12} />
									Historia
								</button>
								<button
									type="button"
									onClick={() => onEditUser(user)}
									disabled={!canEditUser(user)}
									className="inline-flex items-center gap-1 rounded-md border border-slate-300 px-2 py-1 font-semibold text-slate-700 text-xs transition-colors hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50"
								>
									<Pencil size={12} />
									Edytuj
								</button>
							</td>
						</tr>
					))}

					{!isUsersLoading && users.length === 0 ? (
						<tr>
							<td colSpan={10} className="px-3 py-8 text-center text-slate-500">
								Brak użytkowników do wyświetlenia.
							</td>
						</tr>
					) : null}
				</tbody>
			</table>
		</TableSurface>
	);
}

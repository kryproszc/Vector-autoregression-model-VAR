import type { AddUserForm, RoleOption } from "@/features/admin-users/types";

export const ROLE_OPTIONS: RoleOption[] = [
	{ id: 1, apiName: "inspector", label: "Użytkownik" },
	{ id: 2, apiName: "team_lead", label: "Kierownik zespołu" },
	{ id: 3, apiName: "director", label: "Dyrektor" },
];

export const DEFAULT_ADD_USER_FORM: AddUserForm = {
	login: "",
	imie: "",
	nazwisko: "",
	email: "",
	rolaId: 1,
	zespolId: null,
	aktywny: true,
	accountType: "diu",
	departmentCode: "DIU",
	listVisibility: "visible",
};

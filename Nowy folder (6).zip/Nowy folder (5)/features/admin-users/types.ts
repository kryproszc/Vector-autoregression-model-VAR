export type ProfileChangeActor = {
	userId: number | null;
	login: string | null;
};

export type AdminUserProfileHistoryEntry = {
	id: number;
	validFrom: string;
	validTo: string | null;
	accountType: "diu" | "observer" | "technical" | string;
	departmentCode: string | null;
	departmentLabel: string | null;
	listVisibility: "visible" | "hidden" | string | null;
	changedAt: string;
	changedBy: ProfileChangeActor | null;
};

export type AdminUserProfileHistoryEventChange = {
	field: string;
	label: string;
	before: unknown;
	after: unknown;
};

export type AdminUserProfileHistoryEvent = {
	eventId: string;
	changedAt: string;
	changedBy: ProfileChangeActor | null;
	changes: AdminUserProfileHistoryEventChange[];
};

export type AdminUser = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	email: string | null;
	rolaId: number;
	rola: string;
	zespolId: number | null;
	zespolSkroconaNazwa: string | null;
	zespolPelnaNazwa: string | null;
	aktywny: boolean;
	accountType?: "diu" | "observer" | "technical" | string;
	departmentCode?: string | null;
	departmentLabel?: string | null;
	listVisibility?: "visible" | "hidden" | string | null;
	profileChangedAt?: string | null;
	profileChangedBy?: ProfileChangeActor | null;
	createdByOperator?: boolean;
	createdByLogin?: string | null;
};

export type AdminTeam = {
	id: number;
	skroconaNazwa: string;
	pelnaNazwa: string;
	kierownikUserId: number;
};

export type AddUserForm = {
	login: string;
	imie: string;
	nazwisko: string;
	email: string;
	rolaId: number;
	zespolId: number | null;
	aktywny: boolean;
	accountType: "diu" | "observer" | "technical";
	departmentCode: string | null;
	listVisibility: "visible" | "hidden";
};

export type RoleOption = {
	id: number;
	apiName: string;
	label: string;
};

import type {
	AddUserForm,
	AdminTeam,
	AdminUserProfileHistoryEvent,
	AdminUserProfileHistoryEventChange,
	AdminUserProfileHistoryEntry,
	AdminUser,
	ProfileChangeActor,
} from "@/features/admin-users/types";

type RawAdminTeam = {
	id?: unknown;
	skroconaNazwa?: unknown;
	pelnaNazwa?: unknown;
	kierownikUserId?: unknown;
	kod?: unknown;
	nazwa?: unknown;
};

function normalizeAdminTeam(rawTeam: RawAdminTeam): AdminTeam | null {
	const id =
		typeof rawTeam.id === "number" && Number.isFinite(rawTeam.id)
			? rawTeam.id
			: null;
	if (!id) {
		return null;
	}

	const skroconaNazwa =
		typeof rawTeam.skroconaNazwa === "string"
			? rawTeam.skroconaNazwa
			: typeof rawTeam.kod === "string"
				? rawTeam.kod
				: "";

	const pelnaNazwa =
		typeof rawTeam.pelnaNazwa === "string"
			? rawTeam.pelnaNazwa
			: typeof rawTeam.nazwa === "string"
				? rawTeam.nazwa
				: "";

	const kierownikUserId =
		typeof rawTeam.kierownikUserId === "number" &&
		Number.isFinite(rawTeam.kierownikUserId)
			? rawTeam.kierownikUserId
			: 0;

	return {
		id,
		skroconaNazwa,
		pelnaNazwa,
		kierownikUserId,
	};
}

type FetchAdminUsersParams = {
	operatorLogin: string;
};

type RawAdminUser = {
	id?: unknown;
	login?: unknown;
	imie?: unknown;
	nazwisko?: unknown;
	email?: unknown;
	rolaId?: unknown;
	rola?: unknown;
	zespolId?: unknown;
	zespolSkroconaNazwa?: unknown;
	zespolPelnaNazwa?: unknown;
	aktywny?: unknown;
	accountType?: unknown;
	typKonta?: unknown;
	departmentCode?: unknown;
	departamentKod?: unknown;
	departmentLabel?: unknown;
	departamentNazwa?: unknown;
	listVisibility?: unknown;
	widocznoscNaLiscie?: unknown;
	profileChangedAt?: unknown;
	changedAt?: unknown;
	updatedAt?: unknown;
	profileChangedBy?: unknown;
	changedBy?: unknown;
	updatedBy?: unknown;
	createdByOperator?: unknown;
	addedByOperator?: unknown;
	createdByLogin?: unknown;
	addedByLogin?: unknown;
	createdBy?: unknown;
};

function normalizeProfileActor(value: unknown): ProfileChangeActor | null {
	if (typeof value === "string") {
		const trimmed = value.trim();
		if (!trimmed) {
			return null;
		}

		return {
			userId: null,
			login: trimmed,
		};
	}

	if (!value || typeof value !== "object") {
		return null;
	}

	const actor = value as {
		userId?: unknown;
		login?: unknown;
		username?: unknown;
		changedBy?: unknown;
	};

	const login =
		typeof actor.login === "string"
			? actor.login
			: typeof actor.username === "string"
				? actor.username
				: typeof actor.changedBy === "string"
					? actor.changedBy
					: null;

	return {
		userId:
			typeof actor.userId === "number" && Number.isFinite(actor.userId)
				? actor.userId
				: null,
		login,
	};
}

type RawAdminUserProfileHistoryEntry = {
	id?: unknown;
	validFrom?: unknown;
	validTo?: unknown;
	accountType?: unknown;
	departmentCode?: unknown;
	departmentLabel?: unknown;
	listVisibility?: unknown;
	changedAt?: unknown;
	changedBy?: unknown;
};

type RawAdminUserProfileHistoryEventChange = {
	field?: unknown;
	label?: unknown;
	before?: unknown;
	after?: unknown;
};

type RawAdminUserProfileHistoryEvent = {
	eventId?: unknown;
	id?: unknown;
	changedAt?: unknown;
	changedBy?: unknown;
	changedByLogin?: unknown;
	login?: unknown;
	changes?: unknown;
};

function normalizeProfileHistoryEventChange(
	raw: RawAdminUserProfileHistoryEventChange,
): AdminUserProfileHistoryEventChange | null {
	const field = typeof raw.field === "string" ? raw.field.trim() : "";
	const fallbackLabel = field
		? field.charAt(0).toUpperCase() + field.slice(1)
		: "Pole";

	return {
		field: field || "unknown",
		label:
			typeof raw.label === "string" && raw.label.trim()
				? raw.label.trim()
				: fallbackLabel,
		before: raw.before ?? null,
		after: raw.after ?? null,
	};
}

function normalizeProfileHistoryEvent(
	raw: RawAdminUserProfileHistoryEvent,
): AdminUserProfileHistoryEvent | null {
	const changedAt = typeof raw.changedAt === "string" ? raw.changedAt : null;
	if (!changedAt) {
		return null;
	}

	const eventIdValue = raw.eventId ?? raw.id;
	const eventId =
		typeof eventIdValue === "string"
			? eventIdValue
			: typeof eventIdValue === "number" && Number.isFinite(eventIdValue)
				? String(eventIdValue)
				: null;

	if (!eventId) {
		return null;
	}

	const changes = Array.isArray(raw.changes)
		? raw.changes
				.map((item) =>
					normalizeProfileHistoryEventChange(
						(item ?? {}) as RawAdminUserProfileHistoryEventChange,
					),
				)
				.filter((item): item is AdminUserProfileHistoryEventChange => item !== null)
		: [];

	return {
		eventId,
		changedAt,
		changedBy:
			normalizeProfileActor(raw.changedBy) ??
			normalizeProfileActor(raw.changedByLogin) ??
			normalizeProfileActor(raw.login),
		changes,
	};
}

function normalizeProfileHistoryEntry(
	raw: RawAdminUserProfileHistoryEntry,
): AdminUserProfileHistoryEntry | null {
	const id = typeof raw.id === "number" && Number.isFinite(raw.id) ? raw.id : null;
	const validFrom = typeof raw.validFrom === "string" ? raw.validFrom : null;
	const changedAt = typeof raw.changedAt === "string" ? raw.changedAt : null;
	const accountType = typeof raw.accountType === "string" ? raw.accountType : null;
	if (!id || !validFrom || !changedAt || !accountType) {
		return null;
	}

	return {
		id,
		validFrom,
		validTo: typeof raw.validTo === "string" ? raw.validTo : null,
		accountType,
		departmentCode:
			typeof raw.departmentCode === "string" ? raw.departmentCode : null,
		departmentLabel:
			typeof raw.departmentLabel === "string" ? raw.departmentLabel : null,
		listVisibility:
			typeof raw.listVisibility === "string" ? raw.listVisibility : null,
		changedAt,
		changedBy: normalizeProfileActor(raw.changedBy),
	};
}

function normalizeAdminUser(raw: RawAdminUser): AdminUser | null {
	const id =
		typeof raw.id === "number" && Number.isFinite(raw.id) ? raw.id : null;
	if (!id) {
		return null;
	}

	const login = typeof raw.login === "string" ? raw.login.trim() : "";

	const asStringOrNull = (value: unknown): string | null =>
		typeof value === "string" ? value : null;

	const rolaId =
		typeof raw.rolaId === "number" && Number.isFinite(raw.rolaId)
			? raw.rolaId
			: 1;

	const zespolId =
		typeof raw.zespolId === "number" && Number.isFinite(raw.zespolId)
			? raw.zespolId
			: null;

	const aktywny = typeof raw.aktywny === "boolean" ? raw.aktywny : true;

	return {
		id,
		login,
		imie: typeof raw.imie === "string" ? raw.imie : "",
		nazwisko: typeof raw.nazwisko === "string" ? raw.nazwisko : "",
		email: asStringOrNull(raw.email),
		rolaId,
		rola: typeof raw.rola === "string" ? raw.rola : "",
		zespolId,
		zespolSkroconaNazwa: asStringOrNull(raw.zespolSkroconaNazwa),
		zespolPelnaNazwa: asStringOrNull(raw.zespolPelnaNazwa),
		aktywny,
		accountType:
			typeof raw.accountType === "string"
				? raw.accountType
				: typeof raw.typKonta === "string"
					? raw.typKonta
					: undefined,
		departmentCode:
			typeof raw.departmentCode === "string"
				? raw.departmentCode
				: typeof raw.departamentKod === "string"
					? raw.departamentKod
					: null,
		departmentLabel:
			typeof raw.departmentLabel === "string"
				? raw.departmentLabel
				: typeof raw.departamentNazwa === "string"
					? raw.departamentNazwa
					: null,
		listVisibility:
			typeof raw.listVisibility === "string"
				? raw.listVisibility
				: typeof raw.widocznoscNaLiscie === "string"
					? raw.widocznoscNaLiscie
					: null,
		profileChangedAt:
			typeof raw.profileChangedAt === "string"
				? raw.profileChangedAt
				: typeof raw.changedAt === "string"
					? raw.changedAt
					: typeof raw.updatedAt === "string"
						? raw.updatedAt
						: null,
		profileChangedBy:
			normalizeProfileActor(raw.profileChangedBy) ??
			normalizeProfileActor(raw.changedBy) ??
			normalizeProfileActor(raw.updatedBy),
		createdByOperator:
			typeof raw.createdByOperator === "boolean"
				? raw.createdByOperator
				: typeof raw.addedByOperator === "boolean"
					? raw.addedByOperator
					: false,
		createdByLogin:
			typeof raw.createdByLogin === "string"
				? raw.createdByLogin
				: typeof raw.addedByLogin === "string"
					? raw.addedByLogin
					: typeof raw.createdBy === "string"
						? raw.createdBy
						: null,
	};
}

async function readApiDetail(response: Response) {
	const contentType = response.headers.get("content-type") ?? "";
	if (!contentType.includes("application/json")) {
		return "";
	}

	try {
		const payload = (await response.json()) as {
			detail?: unknown;
			message?: unknown;
			error?: unknown;
		};

		const detail = payload.detail ?? payload.message ?? payload.error;
		if (typeof detail === "string") {
			return detail;
		}

		if (Array.isArray(detail)) {
			return detail
				.map((item) => {
					if (typeof item === "string") {
						return item;
					}

					if (item && typeof item === "object") {
						const messageValue = (item as { msg?: unknown }).msg;
						return typeof messageValue === "string" ? messageValue : "";
					}

					return "";
				})
				.filter(Boolean)
				.join(" ");
		}
	} catch {
		return "";
	}

	return "";
}

export async function fetchAdminUsers({
	operatorLogin,
}: FetchAdminUsersParams) {
	const response = await fetch("/api/admin/users", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		if (response.status === 404) {
			return {
				ok: false as const,
				error:
					"Endpoint /api/admin/users nie istnieje (404). Zrestartuj frontend po zmianie rewrites i sprawdź backend na porcie 8002.",
			};
		}

		if (response.status === 403) {
			return {
				ok: false as const,
				error: "Brak uprawnień do podglądu listy użytkowników.",
			};
		}

		if (response.status === 401) {
			return {
				ok: false as const,
				error: "Brak autoryzacji operatora. Zaloguj się ponownie.",
			};
		}

		if (response.status === 422) {
			return {
				ok: false as const,
				error: "Brakuje danych operatora (X-Operator-Login).",
			};
		}

		return {
			ok: false as const,
			error: `Nie udało się pobrać listy użytkowników (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const users = Array.isArray(payload)
		? payload
				.map((user) => normalizeAdminUser((user ?? {}) as RawAdminUser))
				.filter((user): user is AdminUser => user !== null)
		: [];
	return { ok: true as const, users };
}

type FetchAdminUserProfileHistoryParams = {
	operatorLogin: string;
	userId: number;
};

export async function fetchAdminUserProfileHistory({
	operatorLogin,
	userId,
}: FetchAdminUserProfileHistoryParams) {
	const response = await fetch(`/api/admin/users/${userId}/profile-history`, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		if (response.status === 403) {
			return {
				ok: false as const,
				error: "Brak uprawnień do podglądu historii profilu.",
			};
		}

		if (response.status === 404) {
			return {
				ok: false as const,
				error: "Nie znaleziono historii profilu dla użytkownika.",
			};
		}

		return {
			ok: false as const,
			error: `Nie udało się pobrać historii profilu (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const history = Array.isArray(payload)
		? payload
				.map((item) =>
					normalizeProfileHistoryEntry(
						(item ?? {}) as RawAdminUserProfileHistoryEntry,
					),
				)
				.filter((item): item is AdminUserProfileHistoryEntry => item !== null)
		: [];

	return { ok: true as const, history };
}

export async function fetchAdminUserProfileHistoryEvents({
	operatorLogin,
	userId,
}: FetchAdminUserProfileHistoryParams) {
	const response = await fetch(`/api/admin/users/${userId}/profile-history/events`, {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		cache: "no-store",
	});

	if (!response.ok) {
		if (response.status === 403) {
			return {
				ok: false as const,
				error: "Brak uprawnień do podglądu historii profilu.",
			};
		}

		if (response.status === 404) {
			return {
				ok: false as const,
				error: "Nie znaleziono historii profilu dla użytkownika.",
			};
		}

		return {
			ok: false as const,
			error: `Nie udało się pobrać historii profilu (${response.status}).`,
		};
	}

	const payload = (await response.json()) as unknown;
	const events = Array.isArray(payload)
		? payload
				.map((item) =>
					normalizeProfileHistoryEvent(
						(item ?? {}) as RawAdminUserProfileHistoryEvent,
					),
				)
				.filter((item): item is AdminUserProfileHistoryEvent => item !== null)
		: [];

	return { ok: true as const, events };
}

export async function fetchAdminTeams() {
	const response = await fetch("/api/admin/teams", {
		method: "GET",
		headers: {
			"Content-Type": "application/json",
		},
		cache: "no-store",
	});

	if (!response.ok) {
		return { ok: false as const, teams: [] as AdminTeam[] };
	}

	const payload = (await response.json()) as unknown;
	const teams = Array.isArray(payload)
		? payload
				.map((team) => normalizeAdminTeam((team ?? {}) as RawAdminTeam))
				.filter((team): team is AdminTeam => team !== null)
		: [];

	return { ok: true as const, teams };
}

type CreateAdminUserParams = {
	operatorLogin: string;
	form: AddUserForm;
};

export async function createAdminUser({
	operatorLogin,
	form,
}: CreateAdminUserParams) {
	const isTechnicalAccount = form.accountType === "technical";
	const effectiveIsActive = isTechnicalAccount ? false : form.aktywny;
	const shouldClearLogin = !effectiveIsActive || isTechnicalAccount;
	const effectiveLogin = shouldClearLogin ? "" : form.login.trim();
	const effectiveEmail =
		!effectiveIsActive || isTechnicalAccount ? null : form.email.trim() || null;

	const response = await fetch("/api/admin/users", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			login: effectiveLogin,
			imie: form.imie.trim(),
			nazwisko: form.nazwisko.trim(),
			email: effectiveEmail,
			accountType: form.accountType,
			departmentCode: form.departmentCode,
			listVisibility: form.listVisibility,
			rolaId: form.rolaId,
			zespolId:
				form.accountType !== "diu" || form.rolaId === 3
					? null
					: form.zespolId,
			aktywny: effectiveIsActive,
		}),
	});

	if (response.status === 409) {
		const detail = await readApiDetail(response);
		return { ok: false as const, error: detail || "Login już istnieje." };
	}

	if (response.status === 403) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Brak uprawnień do dodania użytkownika.",
		};
	}

	if (response.status === 401) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Operator nie istnieje. Zaloguj się ponownie.",
		};
	}

	if (response.status === 400) {
		const detail = await readApiDetail(response);
		return { ok: false as const, error: detail || "Błędne dane formularza." };
	}

	if (response.status === 422) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail ||
				"Walidacja backendu odrzuciła dane. Dla kont nieaktywnych i technicznych e-mail musi być pusty, a konto techniczne musi być nieaktywne.",
		};
	}

	if (!response.ok) {
		return { ok: false as const, error: "Nie udało się dodać użytkownika." };
	}

	return { ok: true as const };
}

type UpdateAdminUserParams = {
	operatorLogin: string;
	userId: number;
	form: AddUserForm;
};

export async function updateAdminUser({
	operatorLogin,
	userId,
	form,
}: UpdateAdminUserParams) {
	const isTechnicalAccount = form.accountType === "technical";
	const effectiveIsActive = isTechnicalAccount ? false : form.aktywny;
	const shouldClearLogin = !effectiveIsActive || isTechnicalAccount;
	const effectiveLogin = shouldClearLogin ? "" : form.login.trim();
	const effectiveEmail =
		!effectiveIsActive || isTechnicalAccount ? null : form.email.trim() || null;

	const response = await fetch(`/api/admin/users/${userId}`, {
		method: "PUT",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify({
			login: effectiveLogin,
			imie: form.imie.trim(),
			nazwisko: form.nazwisko.trim(),
			email: effectiveEmail,
			accountType: form.accountType,
			departmentCode: form.departmentCode,
			listVisibility: form.listVisibility,
			rolaId: form.rolaId,
			zespolId:
				form.accountType !== "diu" || form.rolaId === 3
					? null
					: form.zespolId,
			aktywny: effectiveIsActive,
		}),
	});

	if (response.status === 409) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Login już istnieje.",
			status: 409,
		};
	}

	if (response.status === 404) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Nie znaleziono użytkownika.",
			status: 404,
		};
	}

	if (response.status === 403) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Brak uprawnień do edycji użytkownika.",
			status: 403,
		};
	}

	if (response.status === 401) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Sesja wygasła. Zaloguj się ponownie.",
			status: 401,
		};
	}

	if (response.status === 400) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Błędne dane formularza.",
			status: 400,
		};
	}

	if (response.status === 422) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail ||
				"Walidacja backendu odrzuciła dane. Dla kont nieaktywnych i technicznych e-mail musi być pusty, a konto techniczne musi być nieaktywne.",
			status: 422,
		};
	}

	if (!response.ok) {
		return {
			ok: false as const,
			error: "Nie udało się zaktualizować użytkownika.",
			status: response.status,
		};
	}

	return { ok: true as const };
}

type SendAdminInviteParams = {
	operatorLogin: string;
	userId: number;
	frontendInviteUrl?: string;
};

type SendAdminInviteResponse = {
	ok: true;
	expiresAt: string;
	delivery: "log" | "smtp";
	inviteLink?: string;
};

export async function sendAdminUserInvite({
	operatorLogin,
	userId,
	frontendInviteUrl,
}: SendAdminInviteParams) {
	const requestBody = frontendInviteUrl ? { frontendInviteUrl } : {};

	const response = await fetch(`/api/admin/users/${userId}/send-invite`, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			"X-Operator-Login": operatorLogin,
		},
		body: JSON.stringify(requestBody),
	});

	if (response.status === 400) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail ||
				"Nie można wysłać zaproszenia. Użytkownik jest nieaktywny lub nie ma poprawnego e-maila.",
		};
	}

	if (response.status === 403) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail || "Brak uprawnień do wysłania zaproszenia dla tego użytkownika.",
		};
	}

	if (response.status === 401) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Sesja wygasła. Zaloguj się ponownie.",
		};
	}

	if (response.status === 422) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail ||
				"Dla konta technicznego nie można wysłać zaproszenia do ustawienia hasła.",
		};
	}

	if (response.status === 404) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error: detail || "Nie znaleziono użytkownika.",
		};
	}

	if (!response.ok) {
		const detail = await readApiDetail(response);
		return {
			ok: false as const,
			error:
				detail || `Nie udało się wysłać zaproszenia (${response.status}).`,
		};
	}

	const payload = (await response.json()) as Partial<SendAdminInviteResponse>;
	return {
		ok: true as const,
		data: {
			expiresAt:
				typeof payload.expiresAt === "string" ? payload.expiresAt : "",
			delivery: payload.delivery === "smtp" ? "smtp" : "log",
			inviteLink:
				typeof payload.inviteLink === "string" ? payload.inviteLink : undefined,
		},
	};
}

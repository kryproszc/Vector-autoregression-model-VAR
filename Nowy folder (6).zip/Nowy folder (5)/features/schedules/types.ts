export type ScheduleDateFieldItem = {
	code: string;
	label: string;
};

export type ScheduleRecipientStrategy = "inspection_context" | "author_only";

export type Schedule = {
	id: number;
	name: string;
	moduleType?: string;
	dateFieldA: string;
	checkEmptyField: string;
	daysDifference: number;
	subjectTemplate: string;
	bodyTemplate: string;
	sendHour: number;
	sendMinute: number;
	targetInspectionLeader: boolean;
	targetInspectionTeam: boolean;
	fallbackRecipient: "author";
	recipientStrategy: ScheduleRecipientStrategy;
	enabled: boolean;
	createdByUserId?: number | null;
	lastRunDate: string | null;
	createdAt?: string | null;
	updatedAt?: string | null;
};

export type ScheduleDispatchStatus = "sent" | "failed" | string;
export type ScheduleDispatchRecipientType =
	| "inspection_leader"
	| "inspection_team"
	| "inspection_leader_team"
	| "author"
	| string;

export type ScheduleDispatch = {
	id: number;
	scheduleId: number;
	ruleId: number | null;
	moduleType: string;
	recordId: number;
	inspectionId: string | null;
	recommendationId: string | null;
	sanctionRequestId: string | null;
	recipientEmail: string;
	recipientType: ScheduleDispatchRecipientType;
	status: ScheduleDispatchStatus;
	errorMessage: string | null;
	renderedSubject: string | null;
	renderedBody: string | null;
	createdAt: string;
};

export type ScheduleDispatchFilters = {
	limit?: number;
	period?: "all" | "week" | "month" | "year";
	status?: "sent" | "failed";
	recipientEmail?: string;
	recipientType?:
		| "inspection_leader"
		| "inspection_team"
		| "inspection_leader_team"
		| "author";
	dateFrom?: string;
	dateTo?: string;
};

export type ScheduleDispatchKpi = {
	scheduleId: number;
	total: number;
	sent: number;
	failed: number;
	successRate: number;
	byModule: Record<string, number>;
	byRecipientType: Record<string, number>;
};

export type ScheduleTemplateVariable = {
	token: string;
	label: string;
};

export type ScheduleFormValues = {
	name: string;
	dateFieldA: string;
	checkEmptyField: string;
	daysDifference: string;
	subjectTemplate: string;
	bodyTemplate: string;
	sendHour: string;
	sendMinute: string;
	targetInspectionLeader: boolean;
	targetInspectionTeam: boolean;
	enabled: boolean;
};

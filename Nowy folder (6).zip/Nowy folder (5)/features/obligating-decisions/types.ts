export type ObligatingDecisionRead = {
	id: number;
	kodDecyzji: string;
	canEdit: boolean;
	canEditIInstance?: boolean;
	canAssignIInstancePeople?: boolean;
	canEditIIInstance?: boolean;
	canAssignIIInstancePeople?: boolean;
	canEditComment?: boolean;
	recommendationKodZalecenia: string | null;
	nazwaPodmiotuId: number | null;
	nazwaPodmiotu: string | null;
	nazwaPodmiotuSkrocona: string | null;
	liczbaZalecen: number | null;
	dataWszczeciaPostepowaniaIInstancji: string | null;
	osobyProwadzaceIInstancjeIds: number[] | null;
	osobyProwadzaceIInstancjeList: string[] | null;
	dataDecyzjiIInstancji: string | null;
	dataDoreczeniaDecyzjiIInstancji: string | null;
	rozstrzygniecieIId: number | null;
	rozstrzygniecieI: string | null;
	rozstrzygniecieISkrocona: string | null;
	dataWnioskuPonowneRozpatrzenie: string | null;
	dataWplywuWnioskuPonowneRozpatrzenie: string | null;
	osobyProwadzaceIIInstancjeIds: number[] | null;
	osobyProwadzaceIIInstancjeList: string[] | null;
	dataDecyzjiIIInstancji: string | null;
	dataDoreczeniaDecyzjiIIInstancji: string | null;
	rozstrzygniecieIIId: number | null;
	rozstrzygniecieII: string | null;
	rozstrzygniecieIISkrocona: string | null;
	komentarz: string | null;
	utworzonoO: string | null;
	zaktualizowanoO: string | null;
};

export type ObligatingDecisionListResponse = {
	items: ObligatingDecisionRead[];
	total: number;
};

export type ObligatingDecisionWrite = {
	recommendationKodZalecenia?: string | null;
	nazwaPodmiotuId?: number | null;
	nazwaPodmiotu?: string | null;
	liczbaZalecen?: number | null;
	dataWszczeciaPostepowaniaIInstancji?: string | null;
	osobyProwadzaceIInstancjeIds?: number[] | null;
	osobyProwadzaceIInstancjeList?: string[] | null;
	dataDecyzjiIInstancji?: string | null;
	dataDoreczeniaDecyzjiIInstancji?: string | null;
	rozstrzygniecieIId?: number | null;
	rozstrzygniecieI?: string | null;
	dataWnioskuPonowneRozpatrzenie?: string | null;
	dataWplywuWnioskuPonowneRozpatrzenie?: string | null;
	osobyProwadzaceIIInstancjeIds?: number[] | null;
	osobyProwadzaceIIInstancjeList?: string[] | null;
	dataDecyzjiIIInstancji?: string | null;
	dataDoreczeniaDecyzjiIIInstancji?: string | null;
	rozstrzygniecieIIId?: number | null;
	rozstrzygniecieII?: string | null;
	komentarz?: string | null;
};

export type AvailableRecommendation = {
	id: number;
	kodZalecenia: string;
	pozycja: number;
	inspectionId: number | null;
	inspectionKod: string | null;
	nazwaPodmiotu: string;
	nazwaPodmiotuSkrocona?: string | null;
	canCreateDecisionForRecommendation?: boolean;
	createDeniedReasonCode?: string | null;
};

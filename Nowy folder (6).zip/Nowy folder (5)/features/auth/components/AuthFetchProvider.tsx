"use client";

import { useEffect } from "react";

import {
	clearStoredAuthSession,
	getStoredAuthSession,
	getStoredAuthToken,
} from "@/features/auth/session";

const AUTH_ROUTES_WITH_LOCAL_HANDLING = [
	"/api/auth/password-login",
	"/api/auth/forgot-password",
	"/api/auth/invitations/validate",
	"/api/auth/invitations/set-password",
	"/api/auth/password-reset/validate",
	"/api/auth/password-reset/confirm",
];

function shouldAttachAuthorizationHeader(apiPath: string) {
	return !AUTH_ROUTES_WITH_LOCAL_HANDLING.some((path) =>
		apiPath.startsWith(path),
	);
}

function toApiPath(input: RequestInfo | URL) {
	if (typeof input === "string") {
		if (input.startsWith("/api/")) {
			return input;
		}

		try {
			const parsed = new URL(input, window.location.origin);
			return parsed.pathname.startsWith("/api/") ? parsed.pathname : "";
		} catch {
			return "";
		}
	}

	if (input instanceof URL) {
		return input.pathname.startsWith("/api/") ? input.pathname : "";
	}

	return input.url.startsWith("/api/")
		? input.url
		: (() => {
			try {
				const parsed = new URL(input.url, window.location.origin);
				return parsed.pathname.startsWith("/api/") ? parsed.pathname : "";
			} catch {
				return "";
			}
		})();
}

function isAuthRouteWithOwnErrorHandling(apiPath: string) {
	return AUTH_ROUTES_WITH_LOCAL_HANDLING.some((path) => apiPath.startsWith(path));
}

export function AuthFetchProvider({
	children,
}: {
	children: React.ReactNode;
}) {
	useEffect(() => {
		const originalFetch = window.fetch.bind(window);

		window.fetch = async (input: RequestInfo | URL, init?: RequestInit) => {
			const apiPath = toApiPath(input);

			if (!apiPath) {
				return originalFetch(input, init);
			}

			const nextInit: RequestInit = { ...(init ?? {}) };
			const headers = new Headers(nextInit.headers);
			const token = getStoredAuthToken();
			const session = getStoredAuthSession();
			const operatorLogin = session?.user?.login?.trim() ?? "";

			if (
				token &&
				shouldAttachAuthorizationHeader(apiPath) &&
				!headers.has("Authorization")
			) {
				headers.set("Authorization", `Bearer ${token}`);
			}

			if (operatorLogin && !headers.has("X-Operator-Login")) {
				headers.set("X-Operator-Login", operatorLogin);
			}

			nextInit.headers = headers;

			const response = await originalFetch(input, nextInit);

			if (
				apiPath &&
				response.status === 401 &&
				!isAuthRouteWithOwnErrorHandling(apiPath)
			) {
				clearStoredAuthSession();
				if (
					window.location.pathname !== "/login" &&
					window.location.pathname !== "/set-password"
				) {
					window.location.assign("/login");
				}
			}

			return response;
		};

		return () => {
			window.fetch = originalFetch;
		};
	}, []);

	return <>{children}</>;
}

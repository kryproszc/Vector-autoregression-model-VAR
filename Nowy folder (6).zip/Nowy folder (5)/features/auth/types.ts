import type { AuthRole } from "@/app/_components/home-tabs/types";

export type LoginUser = {
	id: number;
	login: string;
	imie: string;
	nazwisko: string;
	rolaId: number;
	rola: string;
	zespolId: number | null;
	zespolSkroconaNazwa: string | null;
	zespolPelnaNazwa: string | null;
	accountType?: string;
	effectivePermissions?: string[];
	canViewTimeReports: boolean;
	canViewOwnTimeReport: boolean;
};

export type AuthSession = {
	token: string;
	expiresAt: string;
	user: LoginUser;
};

export function normalizeAuthRole(rawRole: unknown): AuthRole {
	if (typeof rawRole !== "string") {
		return "inspector";
	}

	const normalized = rawRole.trim().toLowerCase();
	if (
		normalized === "director" ||
		normalized === "team_lead" ||
		normalized === "inspector" ||
		normalized === "external_user"
	) {
		return normalized;
	}

	return "inspector";
}

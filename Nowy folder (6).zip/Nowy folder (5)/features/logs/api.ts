export type AuditLogRejestr =
	| "inspekcje"
	| "zalecenia"
	| "decyzje"
	| "wnioski_sankcyjne";

export type AuditLogAkcja = "CREATE" | "UPDATE" | "DELETE";
export type AuditLogFilterColumn =
	| "uzytkownik"
	| "akcja"
	| "pole"
	| "rejestr"
	| "id_rejestru";

export type AuditLogItem = {
	id: number;
	session_id: string;
	uzytkownik: string;
	akcja: AuditLogAkcja;
	data_godz: string;
	rejestr: AuditLogRejestr;
	rekord_kod: string;
	pole: string | null;
	przed: string | null;
	po: string | null;
};

export type AuditLogFilters = {
	rejestr?: AuditLogRejestr | AuditLogRejestr[];
	uzytkownik?: string | string[];
	akcja?: AuditLogAkcja | AuditLogAkcja[];
	pole?: string | string[];
	id_rejestru?: string | string[];
	data_od?: string;
	data_do?: string;
	limit?: number;
	offset?: number;
};

type AuditLogResponse = {
	total: number;
	limit: number;
	offset: number;
	items: AuditLogItem[];
	count?: number;
	total_count?: number;
	totalCount?: number;
	page_size?: number;
	pageSize?: number;
};

type AuditLogFilterOptionsResponse = {
	has_more?: boolean;
	hasMore?: boolean;
	total?: number;
	next_offset?: number;
	nextOffset?: number;
	values?: unknown;
	options?: unknown;
	items?: unknown;
	results?: unknown;
	data?: unknown;
	filters?: unknown;
	uzytkownik?: unknown;
	akcja?: unknown;
	pole?: unknown;
	rejestr?: unknown;
	id_rejestru?: unknown;
	rekord_kod?: unknown;
};

function buildHeaders(operatorLogin: string) {
	return {
		"Content-Type": "application/json",
		"X-Operator-Login": operatorLogin,
	};
}

function appendQueryValues(
	query: URLSearchParams,
	key: string,
	value: string | string[] | undefined,
) {
	if (!value) {
		return;
	}

	const values = Array.isArray(value) ? value : [value];

	for (const item of values) {
		const normalized = item.trim();
		if (!normalized) {
			continue;
		}

		query.append(key, normalized);
	}
}

function parseAuditLogItem(item: unknown): AuditLogItem | null {
	if (!item || typeof item !== "object") return null;
	const s = item as Record<string, unknown>;

	const id = typeof s.id === "number" ? s.id : Number(s.id);
	const session_id = typeof s.session_id === "string" ? s.session_id : "";
	const uzytkownik = typeof s.uzytkownik === "string" ? s.uzytkownik : "";
	const akcja =
		s.akcja === "CREATE" || s.akcja === "UPDATE" || s.akcja === "DELETE"
			? s.akcja
			: null;
	const data_godz = typeof s.data_godz === "string" ? s.data_godz : "";
	const rejestr =
		s.rejestr === "inspekcje" ||
		s.rejestr === "zalecenia" ||
		s.rejestr === "decyzje" ||
		s.rejestr === "wnioski_sankcyjne"
			? s.rejestr
			: null;
	const rekord_kod = typeof s.rekord_kod === "string" ? s.rekord_kod : "";
	const pole = typeof s.pole === "string" ? s.pole : null;
	const przed = typeof s.przed === "string" ? s.przed : null;
	const po = typeof s.po === "string" ? s.po : null;

	if (!akcja || !data_godz || !rejestr) return null;

	return {
		id: Number.isFinite(id) ? id : 0,
		session_id,
		uzytkownik,
		akcja,
		data_godz,
		rejestr,
		rekord_kod,
		pole,
		przed,
		po,
	};
}

export async function fetchAuditLog(
	operatorLogin: string,
	filters: AuditLogFilters = {},
): Promise<
	| { ok: true; total: number; limit: number; offset: number; items: AuditLogItem[] }
	| { ok: false; error: string }
> {
	const query = new URLSearchParams();

	appendQueryValues(
		query,
		"rejestr",
		Array.isArray(filters.rejestr)
			? filters.rejestr
			: filters.rejestr
				? [filters.rejestr]
				: undefined,
	);
	appendQueryValues(query, "uzytkownik", filters.uzytkownik);
	appendQueryValues(
		query,
		"akcja",
		Array.isArray(filters.akcja)
			? filters.akcja
			: filters.akcja
				? [filters.akcja]
				: undefined,
	);
	appendQueryValues(query, "pole", filters.pole);
	appendQueryValues(query, "id_rejestru", filters.id_rejestru);
	if (filters.data_od?.trim()) query.set("data_od", filters.data_od.trim());
	if (filters.data_do?.trim()) query.set("data_do", filters.data_do.trim());

	const limit = typeof filters.limit === "number" ? Math.max(1, Math.min(1000, Math.trunc(filters.limit))) : 50;
	query.set("limit", String(limit));
	query.set("offset", String(filters.offset ?? 0));

	try {
		const response = await fetch(`/api/audit-log?${query.toString()}`, {
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		});

		if (!response.ok) {
			if (response.status === 403) {
				return { ok: false, error: "Brak uprawnień do przeglądania logów." };
			}
			return { ok: false, error: `Nie udało się pobrać logów (${response.status}).` };
		}

		const payload = (await response.json()) as AuditLogResponse;
		const payloadRecord = payload as Record<string, unknown>;
		const items = Array.isArray(payload.items)
			? payload.items.map(parseAuditLogItem).filter((item): item is AuditLogItem => item !== null)
			: [];

		const parseNumber = (value: unknown) => {
			if (typeof value === "number" && Number.isFinite(value)) {
				return value;
			}

			if (typeof value === "string") {
				const parsed = Number(value.trim());
				if (Number.isFinite(parsed)) {
					return parsed;
				}
			}

			return null;
		};

		const resolvedOffset =
			parseNumber(payload.offset) ??
			parseNumber(payloadRecord.skip) ??
			parseNumber(payloadRecord.from) ??
			(filters.offset ?? 0);

		const resolvedLimit =
			parseNumber(payload.limit) ??
			parseNumber(payload.page_size) ??
			parseNumber(payload.pageSize) ??
			parseNumber(payloadRecord.per_page) ??
			limit;

		const resolvedTotal =
			parseNumber(payload.total) ??
			parseNumber(payload.count) ??
			parseNumber(payload.total_count) ??
			parseNumber(payload.totalCount) ??
			parseNumber(payloadRecord.recordsTotal) ??
			parseNumber(payloadRecord.total_records) ??
			resolvedOffset + items.length;

		return {
			ok: true,
			total: Math.max(0, Math.trunc(resolvedTotal)),
			limit: Math.max(1, Math.trunc(resolvedLimit)),
			offset: Math.max(0, Math.trunc(resolvedOffset)),
			items,
		};
	} catch {
		return { ok: false, error: "Błąd sieci podczas pobierania logów." };
	}
}

function normalizeStringList(value: unknown) {
	if (!Array.isArray(value)) {
		return [] as string[];
	}

	return Array.from(
		new Set(
			value
				.map((item) => {
					if (typeof item === "string") {
						return item.trim();
					}

					if (item && typeof item === "object") {
						const candidate = item as Record<string, unknown>;
						const primitive =
							typeof candidate.value === "string"
								? candidate.value
								: typeof candidate.label === "string"
									? candidate.label
									: typeof candidate.name === "string"
										? candidate.name
										: typeof candidate.code === "string"
											? candidate.code
											: "";
						return primitive.trim();
					}

					return "";
				})
				.filter(Boolean),
		),
	);
}

function extractColumnValues(
	payload: unknown,
	column: AuditLogFilterColumn,
): string[] {
	const getFromObject = (obj: Record<string, unknown>) => {
		const byColumnKey: Record<AuditLogFilterColumn, string[]> = {
			uzytkownik: ["uzytkownik", "uzytkownicy", "users"],
			akcja: ["akcja", "akcje", "actions"],
			pole: ["pole", "pozycja", "pozycje", "fields"],
			rejestr: ["rejestr", "rejestry", "registers"],
			id_rejestru: ["id_rejestru", "rekord_kod", "rekord", "record_id", "record_code"],
		};

		for (const key of byColumnKey[column]) {
			const values = normalizeStringList(obj[key]);
			if (values.length > 0) {
				return values;
			}
		}

		const genericArrayValues = normalizeStringList(
			obj.values ?? obj.options ?? obj.items ?? obj.results,
		);
		if (genericArrayValues.length > 0) {
			return genericArrayValues;
		}

		const nestedCandidate = obj.filters ?? obj.data;
		if (nestedCandidate && typeof nestedCandidate === "object") {
			return extractColumnValues(nestedCandidate, column);
		}

		return [] as string[];
	};

	if (Array.isArray(payload)) {
		return normalizeStringList(payload);
	}

	if (payload && typeof payload === "object") {
		return getFromObject(payload as Record<string, unknown>);
	}

	return [] as string[];
}

export async function fetchAuditLogFilterOptions(
	operatorLogin: string,
	column: AuditLogFilterColumn,
	filters: AuditLogFilters = {},
	pagination: { limit?: number; offset?: number } = {},
): Promise<
	| { ok: true; values: string[]; hasMore: boolean }
	| { ok: false; error: string }
> {
	const query = new URLSearchParams();
	query.set("column", column);
	query.set("field", column);
	query.set("filter", column);

	appendQueryValues(
		query,
		"rejestr",
		Array.isArray(filters.rejestr)
			? filters.rejestr
			: filters.rejestr
				? [filters.rejestr]
				: undefined,
	);
	appendQueryValues(query, "uzytkownik", filters.uzytkownik);
	appendQueryValues(
		query,
		"akcja",
		Array.isArray(filters.akcja)
			? filters.akcja
			: filters.akcja
				? [filters.akcja]
				: undefined,
	);
	appendQueryValues(query, "pole", filters.pole);
	appendQueryValues(query, "id_rejestru", filters.id_rejestru);
	if (filters.data_od?.trim()) query.set("data_od", filters.data_od.trim());
	if (filters.data_do?.trim()) query.set("data_do", filters.data_do.trim());

	const limit =
		typeof pagination.limit === "number"
			? Math.max(1, Math.min(200, Math.trunc(pagination.limit)))
			: 10;
	const offset =
		typeof pagination.offset === "number"
			? Math.max(0, Math.trunc(pagination.offset))
			: 0;

	query.set("limit", String(limit));
	query.set("offset", String(offset));

	try {
		const response = await fetch(`/api/audit-log/filter-options?${query.toString()}`, {
			method: "GET",
			headers: buildHeaders(operatorLogin),
			cache: "no-store",
		});

		if (!response.ok) {
			return {
				ok: false,
				error: `Nie udało się pobrać opcji filtrów (${response.status}).`,
			};
		}

		const payload = (await response.json()) as AuditLogFilterOptionsResponse;
		const values = extractColumnValues(payload, column);
		const hasMoreFromPayload = payload.has_more === true || payload.hasMore === true;
		const hasMoreFromTotal =
			typeof payload.total === "number" ? offset + values.length < payload.total : false;
		const hasMoreFromNextOffset =
			typeof payload.next_offset === "number" ||
			typeof payload.nextOffset === "number";

		return {
			ok: true,
			values,
			hasMore:
				hasMoreFromPayload ||
				hasMoreFromTotal ||
				hasMoreFromNextOffset ||
				values.length === limit,
		};
	} catch {
		return { ok: false, error: "Błąd sieci podczas pobierania opcji filtrów." };
	}
}

export type SanctionRequestRead = {
	id: number;
	lp: number;
	kodSankcji?: string | null;
	canEdit: boolean;
	inspectionId: number | null;
	inspectionLp?: number | null;
	inspectionKod?: string | null;
	kodInspekcji?: string | null;
	nazwaPodmiotuObjetegoInspekcjaId?: number | null;
	nazwaPodmiotuObjetegoInspekcja: string | null;
	nazwaPodmiotuObjetegoInspekcjaSkrocona: string | null;
	nazwaPodmiotuObjetegoSankcjaIds?: number[];
	nazwaPodmiotuObjetegoSankcjaList: string[];
	nazwaPodmiotuObjetegoSankcjaListSkrocona: string[];
	dataWniosku: string | null;
	wniosekDoId?: number | null;
	wniosekDo: string | null;
	wniosekDoSkrocona: string | null;
	sankcjaIds?: number[];
	sankcjaList: string[];
	sankcjaListSkrocona: string[];
	podstawaPrawnaSankcjiIds?: number[];
	podstawaPrawnaSankcjiList: string[];
	podstawaPrawnaSankcjiListSkrocona: string[];
	naruszeniaSkutkujaceSankcjaIds?: number[];
	naruszeniaSkutkujaceSankcjaList: string[];
	naruszeniaSkutkujaceSankcjaListSkrocona: string[];
	czyMamyInformacjeOWszczeciuPostepowaniaId?: number | null;
	czyMamyInformacjeOWszczeciuPostepowania: string | null;
	czyMamyInformacjeOWszczeciuPostepowaniaSkrocona: string | null;
	rozstrzygniecieId?: number | null;
	rozstrzygniecie: string | null;
	rozstrzygniecieSkrocona: string | null;
	komentarz: string | null;
	utworzonoO: string | null;
	zaktualizowanoO: string | null;
};

export type SanctionRequestListResponse = {
	items: SanctionRequestRead[];
	total: number;
};

export type SanctionRequestWrite = {
	inspectionId: number | null;
	nazwaPodmiotuObjetegoInspekcjaId?: number | null;
	nazwaPodmiotuObjetegoSankcjaIds: number[];
	dataWniosku: string | null;
	wniosekDoId?: number | null;
	sankcjaIds: number[];
	podstawaPrawnaSankcjiIds: number[];
	naruszeniaSkutkujaceSankcjaIds: number[];
	czyMamyInformacjeOWszczeciuPostepowaniaId?: number | null;
	rozstrzygniecieId?: number | null;
	komentarz: string | null;
};

export type SanctionRequestFilters = {
	inspectionId?: number;
	sortBy?: "id" | "lp" | "dataWniosku" | "utworzonoO" | "zaktualizowanoO";
	sortOrder?: "asc" | "desc";
};
